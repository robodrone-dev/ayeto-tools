// src/shared/state.ts
var SERVER_URL = { mode: "production", serverUrl: "https://ayeto.ai", appUrl: "https://ayeto.ai/app" }.serverUrl.replace(/\/+$/, "");
var APP_URL = { mode: "production", serverUrl: "https://ayeto.ai", appUrl: "https://ayeto.ai/app" }.appUrl.replace(/\/+$/, "");
var DEFAULT_SETTINGS = {
  api_key: null,
  api_key_name: "",
  api_key_id: null,
  device_name: "",
  enabled: true,
  confirm_mode: "risky",
  blocked_domains: []
};
var PANEL_PORT = "sidepanel";
function apiV1(serverUrl) {
  return `${serverUrl.replace(/\/+$/, "")}/api/v1`;
}
function apiV3(serverUrl) {
  return `${serverUrl.replace(/\/+$/, "")}/api/v3`;
}
function wsEndpoint(serverUrl) {
  return `${apiV1(serverUrl).replace(/^http/, "ws")}/browser_connector/ws`;
}

// src/shared/protocol.ts
class BrowserError extends Error {
  code;
  constructor(message, code = "internal") {
    super(message);
    this.code = code;
    this.name = "BrowserError";
  }
}

// src/background/cdp.ts
var PROTOCOL_VERSION = "1.3";
var COMMAND_TIMEOUT_MS = 20000;
var IDLE_DETACH_MS = 120000;
var AUTO_ATTACH = { autoAttach: true, waitForDebuggerOnStart: false, flatten: true };

class CdpManager {
  attached = new Set;
  attaching = new Map;
  idleTimers = new Map;
  dialogs = new Map;
  detachListeners = [];
  initialized = false;
  frameSessions = new Map;
  nextFrameIndex = new Map;
  init() {
    if (this.initialized)
      return;
    this.initialized = true;
    chrome.debugger.onDetach.addListener((source, reason) => {
      if (source.tabId === undefined)
        return;
      this.forget(source.tabId);
      for (const listener of this.detachListeners)
        listener(source.tabId, reason);
    });
    chrome.debugger.onEvent.addListener((source, method, params) => {
      if (source.tabId === undefined)
        return;
      const sessionId = source.sessionId;
      if (method === "Page.javascriptDialogOpening") {
        this.handleDialog(source.tabId, params, sessionId);
      } else if (method === "Target.attachedToTarget") {
        this.onFrameAttached(source.tabId, sessionId, params);
      } else if (method === "Target.detachedFromTarget") {
        this.frameSessions.get(source.tabId)?.delete(params.sessionId);
      }
    });
    chrome.tabs.onRemoved.addListener((tabId) => this.forget(tabId));
  }
  onDetach(listener) {
    this.detachListeners.push(listener);
  }
  isAttached(tabId) {
    return this.attached.has(tabId);
  }
  attachedTabs() {
    return [...this.attached];
  }
  async attach(tabId) {
    if (this.attached.has(tabId))
      return;
    const pending = this.attaching.get(tabId);
    if (pending)
      return pending;
    const attempt = this.doAttach(tabId).finally(() => this.attaching.delete(tabId));
    this.attaching.set(tabId, attempt);
    return attempt;
  }
  async doAttach(tabId) {
    try {
      await chrome.debugger.attach({ tabId }, PROTOCOL_VERSION);
    } catch (e) {
      const message = String(e?.message ?? e);
      if (/already attached/i.test(message)) {
        throw new BrowserError("Another debugger (DevTools) is attached to this tab. Close DevTools on it and try again.", "forbidden");
      }
      throw new BrowserError(`Cannot work in this tab: ${message}`, "forbidden");
    }
    this.attached.add(tabId);
    await this.send(tabId, "Page.enable");
    await this.send(tabId, "Target.setAutoAttach", AUTO_ATTACH).catch(() => {
      return;
    });
    this.touch(tabId);
  }
  async detach(tabId) {
    if (!this.attached.has(tabId))
      return;
    this.forget(tabId);
    try {
      await chrome.debugger.detach({ tabId });
    } catch {}
  }
  async detachAll() {
    await Promise.all([...this.attached].map((tabId) => this.detach(tabId)));
  }
  frames(tabId) {
    return [...this.frameSessions.get(tabId)?.values() ?? []];
  }
  frameByIndex(tabId, index) {
    return this.frames(tabId).find((f) => f.index === index);
  }
  frameById(tabId, frameId) {
    return this.frames(tabId).find((f) => f.frameId === frameId);
  }
  frameBySession(tabId, sessionId) {
    return this.frameSessions.get(tabId)?.get(sessionId);
  }
  async send(tabId, method, params, sessionId) {
    await this.attach(tabId);
    this.touch(tabId);
    let timer;
    const timeout = new Promise((_, reject) => {
      timer = setTimeout(() => reject(new BrowserError(`The page did not answer ${method} in time`, "timeout")), COMMAND_TIMEOUT_MS);
    });
    try {
      const target = sessionId ? { tabId, sessionId } : { tabId };
      return await Promise.race([
        chrome.debugger.sendCommand(target, method, params),
        timeout
      ]);
    } catch (e) {
      if (e instanceof BrowserError)
        throw e;
      throw new BrowserError(String(e?.message ?? e), "internal");
    } finally {
      clearTimeout(timer);
    }
  }
  takeDialogs(tabId) {
    const dialogs = this.dialogs.get(tabId) ?? [];
    this.dialogs.delete(tabId);
    return dialogs;
  }
  async handleDialog(tabId, params, sessionId) {
    const accept = params.type === "alert";
    const list = this.dialogs.get(tabId) ?? [];
    list.push({ type: params.type, message: params.message, handled: accept ? "accepted" : "dismissed" });
    this.dialogs.set(tabId, list.slice(-5));
    try {
      const target = sessionId ? { tabId, sessionId } : { tabId };
      await chrome.debugger.sendCommand(target, "Page.handleJavaScriptDialog", { accept });
    } catch {}
  }
  async onFrameAttached(tabId, parentSessionId, params) {
    if (params.targetInfo.type !== "iframe")
      return;
    const sessions = this.frameSessions.get(tabId) ?? new Map;
    this.frameSessions.set(tabId, sessions);
    const index = this.nextFrameIndex.get(tabId) ?? 1;
    this.nextFrameIndex.set(tabId, index + 1);
    sessions.set(params.sessionId, {
      sessionId: params.sessionId,
      frameId: params.targetInfo.targetId,
      parentSessionId,
      url: params.targetInfo.url,
      index
    });
    const target = { tabId, sessionId: params.sessionId };
    try {
      await chrome.debugger.sendCommand(target, "Page.enable");
      await chrome.debugger.sendCommand(target, "Target.setAutoAttach", AUTO_ATTACH);
    } catch {}
  }
  touch(tabId) {
    const timer = this.idleTimers.get(tabId);
    if (timer)
      clearTimeout(timer);
    this.idleTimers.set(tabId, setTimeout(() => void this.detach(tabId), IDLE_DETACH_MS));
  }
  forget(tabId) {
    this.attached.delete(tabId);
    this.frameSessions.delete(tabId);
    const timer = this.idleTimers.get(tabId);
    if (timer)
      clearTimeout(timer);
    this.idleTimers.delete(tabId);
  }
}
var cdp = new CdpManager;

// src/background/confirmations.ts
var CONFIRM_TIMEOUT_MS = 120000;
var HIGHLIGHT = {
  showInfo: true,
  contentColor: { r: 99, g: 102, b: 241, a: 0.25 },
  borderColor: { r: 79, g: 70, b: 229, a: 0.9 }
};

class Confirmations {
  current = null;
  waiter = null;
  listeners = [];
  get pending() {
    return this.current;
  }
  onChange(listener) {
    this.listeners.push(listener);
  }
  async ask(request, signal, highlight) {
    if (this.current)
      this.settle(false, "Another confirmation replaced this one");
    const confirmation = { ...request, id: crypto.randomUUID(), expires_at: Date.now() + CONFIRM_TIMEOUT_MS };
    this.current = confirmation;
    await this.highlight(confirmation.tab_id, highlight);
    chrome.action.setBadgeText({ text: "!" });
    chrome.action.setBadgeBackgroundColor({ color: "#4F46E5" });
    this.changed();
    try {
      await new Promise((resolve, reject) => {
        const timer = setTimeout(() => this.settle(false, "The user did not answer in time"), CONFIRM_TIMEOUT_MS);
        const onAbort = () => this.settle(false, "The user stopped the agent", "cancelled");
        signal.addEventListener("abort", onAbort, { once: true });
        const done = () => {
          clearTimeout(timer);
          signal.removeEventListener("abort", onAbort);
        };
        this.waiter = {
          resolve: () => {
            done();
            resolve();
          },
          reject: (e) => {
            done();
            reject(e);
          }
        };
        if (signal.aborted)
          onAbort();
      });
    } finally {
      if (this.current?.id === confirmation.id)
        this.current = null;
      this.waiter = null;
      chrome.action.setBadgeText({ text: "" });
      await this.unhighlight(confirmation.tab_id, highlight?.sessionId);
      this.changed();
    }
  }
  answer(id, allow) {
    if (this.current?.id !== id)
      return;
    this.settle(allow, "The user rejected it");
  }
  settle(allow, reason, code = "rejected") {
    const waiter = this.waiter;
    if (!waiter)
      return;
    this.waiter = null;
    if (allow)
      waiter.resolve();
    else
      waiter.reject(new BrowserError(reason, code));
  }
  changed() {
    for (const listener of this.listeners)
      listener();
  }
  async highlight(tabId, element) {
    if (tabId === null || !element)
      return;
    try {
      await cdp.send(tabId, "DOM.enable", undefined, element.sessionId);
      await cdp.send(tabId, "Overlay.enable", undefined, element.sessionId);
      await cdp.send(tabId, "Overlay.highlightNode", { highlightConfig: HIGHLIGHT, backendNodeId: element.backendNodeId }, element.sessionId);
    } catch {}
  }
  async unhighlight(tabId, sessionId) {
    if (tabId === null || !cdp.isAttached(tabId))
      return;
    try {
      await cdp.send(tabId, "Overlay.hideHighlight", undefined, sessionId);
    } catch {}
  }
}
var confirmations = new Confirmations;

// src/background/connection.ts
var PING_INTERVAL_MS = 20000;
var RECONNECT_MIN_MS = 1000;
var RECONNECT_MAX_MS = 30000;
var MAX_UNVERIFIED_CLOSES = 3;

class Connection {
  events;
  ws = null;
  identity = null;
  pingTimer = null;
  reconnectTimer = null;
  reconnectDelay = RECONNECT_MIN_MS;
  verified = false;
  unverifiedCloses = 0;
  stopped = true;
  queue = Promise.resolve();
  generation = 0;
  current = null;
  constructor(events) {
    this.events = events;
  }
  get connected() {
    return !!this.ws && this.ws.readyState === WebSocket.OPEN && this.verified;
  }
  start(identity) {
    const same = this.identity?.apiKey === identity.apiKey && this.identity?.serverUrl === identity.serverUrl;
    this.identity = identity;
    if (same && !this.stopped && this.ws && this.ws.readyState <= WebSocket.OPEN)
      return;
    this.stopped = false;
    this.unverifiedCloses = 0;
    this.reconnectDelay = RECONNECT_MIN_MS;
    this.open();
  }
  stop() {
    this.stopped = true;
    this.clearTimers();
    const ws = this.ws;
    this.ws = null;
    this.verified = false;
    if (ws && ws.readyState <= WebSocket.OPEN)
      ws.close(1000, "stopped");
    this.events.onStatus("disconnected");
  }
  cancelQueued() {
    this.generation++;
    this.current?.abort();
  }
  open() {
    if (!this.identity)
      return;
    this.clearTimers();
    this.verified = false;
    this.events.onStatus("connecting");
    let ws;
    try {
      ws = new WebSocket(wsEndpoint(this.identity.serverUrl));
    } catch (e) {
      this.events.onStatus("error", String(e?.message ?? e));
      this.scheduleReconnect();
      return;
    }
    this.ws = ws;
    ws.onopen = () => {
      this.send({ type: "hello", api_key: this.identity.apiKey, payload: this.identity.hello });
      this.pingTimer = setInterval(() => this.send({ type: "ping" }), PING_INTERVAL_MS);
    };
    ws.onmessage = (event) => this.onMessage(event.data);
    ws.onclose = () => {
      if (this.ws !== ws)
        return;
      this.ws = null;
      this.clearTimers();
      if (this.stopped)
        return;
      if (!this.verified)
        this.unverifiedCloses++;
      this.verified = false;
      if (this.unverifiedCloses >= MAX_UNVERIFIED_CLOSES) {
        this.stopped = true;
        this.events.onStatus("error", "AYETO refused the connection. The API key may have been revoked: pair the browser again.");
        return;
      }
      this.events.onStatus("connecting");
      this.scheduleReconnect();
    };
    ws.onerror = () => {};
  }
  scheduleReconnect() {
    if (this.stopped)
      return;
    const delay = this.reconnectDelay;
    this.reconnectDelay = Math.min(this.reconnectDelay * 2, RECONNECT_MAX_MS);
    this.reconnectTimer = setTimeout(() => this.open(), delay);
  }
  clearTimers() {
    if (this.pingTimer)
      clearInterval(this.pingTimer);
    if (this.reconnectTimer)
      clearTimeout(this.reconnectTimer);
    this.pingTimer = null;
    this.reconnectTimer = null;
  }
  send(frame) {
    if (this.ws && this.ws.readyState === WebSocket.OPEN)
      this.ws.send(JSON.stringify(frame));
  }
  onMessage(data) {
    let frame;
    try {
      frame = JSON.parse(data);
    } catch {
      return;
    }
    switch (frame.type) {
      case "hello":
        this.verified = true;
        this.unverifiedCloses = 0;
        this.reconnectDelay = RECONNECT_MIN_MS;
        this.events.onHello(frame.payload ?? {});
        this.events.onStatus("connected");
        return;
      case "ping":
        this.send({ type: "ping" });
        return;
      case "disconnect":
        this.send({ request_id: frame.id, type: "disconnect", payload: { ok: true } });
        this.stop();
        this.events.onServerDisconnect();
        return;
    }
    if (this.events.isOperation(frame)) {
      const generation = this.generation;
      this.queue = this.queue.then(() => this.answer(frame, generation));
      return;
    }
    this.send({ request_id: frame.id, type: frame.type, error: `Unsupported operation '${frame.type}', update the extension`, error_code: "invalid_request" });
  }
  async answer(frame, generation) {
    if (generation !== this.generation) {
      this.send({ request_id: frame.id, type: frame.type, error: "The user stopped the agent", error_code: "cancelled" });
      return;
    }
    const controller = new AbortController;
    this.current = controller;
    try {
      const payload = await this.events.onOperation(frame, controller.signal);
      this.send({ request_id: frame.id, type: frame.type, payload });
    } catch (e) {
      const error = controller.signal.aborted ? new BrowserError("The user stopped the agent", "cancelled") : e instanceof BrowserError ? e : new BrowserError(String(e?.message ?? e), "internal");
      this.send({ request_id: frame.id, type: frame.type, error: error.message, error_code: error.code });
    } finally {
      if (this.current === controller)
        this.current = null;
    }
  }
}

// src/background/snapshot.ts
var MAX_FRAMES = 10;
var MAX_FRAME_DEPTH = 3;
var FRAME_SESSION_WAIT_MS = 1500;
var FRAME_MIN_SIZE = 20;
var INTERACTIVE_ROLES = new Set([
  "button",
  "link",
  "textbox",
  "searchbox",
  "combobox",
  "checkbox",
  "radio",
  "switch",
  "slider",
  "spinbutton",
  "menuitem",
  "menuitemcheckbox",
  "menuitemradio",
  "option",
  "tab",
  "treeitem",
  "listbox",
  "textField",
  "TextField",
  "ComboBoxGrouping",
  "ComboBoxMenuButton",
  "PopUpButton",
  "DisclosureTriangle"
]);
var TRANSPARENT_ROLES = new Set(["none", "generic", "presentation", "InlineTextBox", "LineBreak", "LabelText", "Ignored", "GenericContainer"]);
var STATE_PROPERTIES = ["focused", "checked", "pressed", "selected", "expanded", "disabled", "required", "readonly", "invalid", "level", "modal", "multiselectable", "url"];
var SENSITIVE_SELECTOR = [
  "input[type=password]",
  "input[autocomplete^='cc-']",
  "input[autocomplete~='cc-number']",
  "input[autocomplete~='cc-csc']",
  "input[name*='cvv' i]",
  "input[name*='cvc' i]",
  "input[name*='cardnumber' i]",
  "input[name*='card_number' i]"
].join(",");
function refOf(backendNodeId, frameIndex) {
  return frameIndex ? `s${frameIndex}e${backendNodeId}` : `e${backendNodeId}`;
}
function parseRef(ref) {
  const m = /^(?:s(\d+))?e?(\d+)$/.exec(String(ref ?? "").trim());
  if (!m)
    throw new BrowserError(`Invalid element ref '${ref}', use a ref from the snapshot`, "invalid_request");
  return { frameIndex: m[1] ? Number(m[1]) : undefined, backendNodeId: Number(m[2]) };
}
function sessionOfRef(tabId, ref) {
  if (!ref.frameIndex)
    return;
  const frame = cdp.frameByIndex(tabId, ref.frameIndex);
  if (!frame)
    throw new BrowserError("The frame of this element is not on the page anymore; take a new snapshot", "not_found");
  return frame.sessionId;
}
async function axTree(tabId, sessionId, frameId) {
  await cdp.send(tabId, "Accessibility.enable", undefined, sessionId);
  const { nodes } = await cdp.send(tabId, "Accessibility.getFullAXTree", frameId ? { frameId } : {}, sessionId);
  return nodes ?? [];
}
async function sensitiveUnder(tabId, documentNodeId, refs, sessionId, frameIndex) {
  const { nodeIds } = await cdp.send(tabId, "DOM.querySelectorAll", { nodeId: documentNodeId, selector: SENSITIVE_SELECTOR }, sessionId);
  for (const nodeId of nodeIds ?? []) {
    const { node } = await cdp.send(tabId, "DOM.describeNode", { nodeId }, sessionId);
    refs.add(refOf(node.backendNodeId, frameIndex));
  }
}
async function sensitiveRefs(tabId, refs, sessionId, frameIndex, iframeBackendNodeId) {
  try {
    await cdp.send(tabId, "DOM.enable", undefined, sessionId);
    let documentNodeId;
    if (iframeBackendNodeId !== undefined) {
      const { object } = await cdp.send(tabId, "DOM.resolveNode", { backendNodeId: iframeBackendNodeId }, sessionId);
      const { result } = await cdp.send(tabId, "Runtime.callFunctionOn", {
        objectId: object.objectId,
        functionDeclaration: "function() { return this.contentDocument }"
      }, sessionId);
      if (!result.objectId)
        return;
      documentNodeId = (await cdp.send(tabId, "DOM.requestNode", { objectId: result.objectId }, sessionId)).nodeId;
    } else {
      documentNodeId = (await cdp.send(tabId, "DOM.getDocument", { depth: 0 }, sessionId)).root.nodeId;
    }
    await sensitiveUnder(tabId, documentNodeId, refs, sessionId, frameIndex);
  } catch {}
}
async function frameSession(tabId, frameId) {
  const deadline = Date.now() + FRAME_SESSION_WAIT_MS;
  for (;; ) {
    const frame = cdp.frameById(tabId, frameId);
    if (frame || Date.now() > deadline)
      return frame;
    await new Promise((r) => setTimeout(r, 100));
  }
}
async function pageTree(tabId) {
  const sensitive = new Set;
  const nodes = await axTree(tabId);
  await sensitiveRefs(tabId, sensitive);
  let frames = 0;
  const mergeFrames = async (tree, sessionId, frameIndex, depth, prefix) => {
    for (const iframe of tree.filter((n) => text(n.role) === "Iframe" && n.backendDOMNodeId !== undefined)) {
      if (frames >= MAX_FRAMES || depth >= MAX_FRAME_DEPTH)
        return;
      let frameId;
      try {
        frameId = (await cdp.send(tabId, "DOM.describeNode", { backendNodeId: iframe.backendDOMNodeId }, sessionId)).node.frameId;
      } catch {}
      if (!frameId)
        continue;
      try {
        const { quads } = await cdp.send(tabId, "DOM.getContentQuads", { backendNodeId: iframe.backendDOMNodeId }, sessionId);
        const q = quads?.[0];
        if (!q || Math.abs(q[4] - q[0]) < FRAME_MIN_SIZE || Math.abs(q[5] - q[1]) < FRAME_MIN_SIZE)
          continue;
      } catch {
        continue;
      }
      frames++;
      const child = await frameSession(tabId, frameId);
      let childNodes;
      try {
        childNodes = child ? await axTree(tabId, child.sessionId) : await axTree(tabId, sessionId, frameId);
      } catch {
        continue;
      }
      const childPrefix = `${prefix}f${frames}:`;
      const childIndex = child ? child.index : frameIndex;
      for (const node of childNodes) {
        node.nodeId = childPrefix + node.nodeId;
        node.childIds = (node.childIds ?? []).map((id) => childPrefix + id);
        if (node.parentId)
          node.parentId = childPrefix + node.parentId;
        node.frameIndex = childIndex;
      }
      const childIds = new Set(childNodes.flatMap((n) => n.childIds ?? []));
      const roots = childNodes.filter((n) => !childIds.has(n.nodeId));
      for (const root of roots)
        root.parentId = iframe.nodeId;
      iframe.childIds = [...iframe.childIds ?? [], ...roots.map((r) => r.nodeId)];
      nodes.push(...childNodes);
      if (child)
        await sensitiveRefs(tabId, sensitive, child.sessionId, child.index);
      else
        await sensitiveRefs(tabId, sensitive, sessionId, frameIndex, iframe.backendDOMNodeId);
      await mergeFrames(childNodes, child ? child.sessionId : sessionId, childIndex, depth + 1, childPrefix);
    }
  };
  await mergeFrames(nodes.slice(), undefined, undefined, 0, "");
  return { nodes, sensitive };
}
function text(value) {
  if (!value || value.value === undefined || value.value === null)
    return "";
  return String(value.value).replace(/\s+/g, " ").trim();
}
function quote(value, max = 200) {
  const cut = value.length > max ? `${value.slice(0, max)}…` : value;
  return `"${cut.replace(/"/g, "\\\"")}"`;
}
function roleOf(node) {
  return text(node.role) || "unknown";
}
function states(node) {
  const out = [];
  for (const prop of node.properties ?? []) {
    if (!STATE_PROPERTIES.includes(prop.name))
      continue;
    const v = prop.value?.value;
    if (v === false || v === undefined || v === null || v === "false")
      continue;
    if (prop.name === "url")
      continue;
    out.push(v === true || v === "true" ? prop.name : `${prop.name}=${v}`);
  }
  return out;
}
function urlOf(node) {
  const prop = (node.properties ?? []).find((p) => p.name === "url");
  return prop ? String(prop.value?.value ?? "") : "";
}
function nodeRef(node) {
  return refOf(node.backendDOMNodeId, node.frameIndex);
}
function isSensitive(node, sensitive) {
  return node.backendDOMNodeId !== undefined && sensitive.has(nodeRef(node));
}
function describe(node, sensitive) {
  const role = roleOf(node);
  const name = text(node.name);
  let line = role;
  if (name)
    line += ` ${quote(name)}`;
  if (node.backendDOMNodeId !== undefined)
    line += ` [ref=${nodeRef(node)}]`;
  const st = states(node);
  if (st.length)
    line += ` (${st.join(", ")})`;
  if (isSensitive(node, sensitive)) {
    line += " value: [hidden]";
  } else {
    const value = text(node.value);
    if (value && value !== name)
      line += ` value: ${quote(value)}`;
  }
  if (role === "link") {
    const url = urlOf(node);
    if (url && !url.startsWith("javascript:"))
      line += ` -> ${url.length > 200 ? `${url.slice(0, 200)}…` : url}`;
  }
  return line;
}
function renderSnapshot(nodes, sensitive, interactiveOnly, maxChars) {
  const byId = new Map(nodes.map((n) => [n.nodeId, n]));
  const childIds = new Set(nodes.flatMap((n) => n.childIds ?? []));
  const roots = nodes.filter((n) => !childIds.has(n.nodeId));
  const lines = [];
  let size = 0;
  let truncated = false;
  const push = (line) => {
    if (size + line.length + 1 > maxChars) {
      truncated = true;
      return false;
    }
    lines.push(line);
    size += line.length + 1;
    return true;
  };
  const stack = roots.reverse().map((r) => [r, 0, ""]);
  while (stack.length > 0 && !truncated) {
    const [node, depth, parentName] = stack.pop();
    const role = roleOf(node);
    let rendered = false;
    let nextDepth = depth;
    let nextParentName = parentName;
    const hiddenField = isSensitive(node, sensitive);
    if (!node.ignored && !TRANSPARENT_ROLES.has(role)) {
      if (role === "StaticText") {
        const value = text(node.name);
        if (!interactiveOnly && value && !parentName.includes(value)) {
          rendered = push(`${"  ".repeat(depth)}- text: ${quote(value, 500)}`);
        }
      } else if (role === "RootWebArea" || role === "WebArea") {} else if (!interactiveOnly || INTERACTIVE_ROLES.has(role)) {
        rendered = push(`${interactiveOnly ? "" : "  ".repeat(depth)}- ${describe(node, sensitive)}`);
        if (rendered) {
          nextDepth = depth + 1;
          nextParentName = `${text(node.name)}
${text(node.value)}`;
        }
      }
      if (!rendered && truncated)
        break;
    }
    if (hiddenField)
      continue;
    const children = (node.childIds ?? []).map((id) => byId.get(id)).filter((c) => !!c);
    for (let i = children.length - 1;i >= 0; i--) {
      stack.push([children[i], nextDepth, nextParentName]);
    }
  }
  return { snapshot: lines.join(`
`), truncated };
}
function findInTree(nodes, sensitive, query, maxMatches) {
  const words = query.toLowerCase().split(/\s+/).filter(Boolean);
  if (words.length === 0)
    throw new BrowserError("Empty query", "invalid_request");
  const byId = new Map(nodes.map((n) => [n.nodeId, n]));
  const seen = new Set;
  const interactive = [];
  const other = [];
  const owner = (node) => {
    let current = node.parentId ? byId.get(node.parentId) : undefined;
    while (current) {
      const role = roleOf(current);
      if (role === "RootWebArea" || role === "WebArea")
        return null;
      if (current.backendDOMNodeId !== undefined && role !== "StaticText" && role !== "InlineTextBox")
        return current;
      current = current.parentId ? byId.get(current.parentId) : undefined;
    }
    return null;
  };
  for (const node of nodes) {
    if (node.ignored)
      continue;
    const role = roleOf(node);
    if (role === "InlineTextBox" || role === "RootWebArea" || role === "WebArea")
      continue;
    const hidden = isSensitive(node, sensitive);
    const haystack = [role, text(node.name), hidden ? "" : text(node.value), text(node.description)].join(" ").toLowerCase();
    if (!words.every((w) => haystack.includes(w)))
      continue;
    const element = role === "StaticText" ? owner(node) : node;
    if (!element || element.backendDOMNodeId === undefined || seen.has(nodeRef(element)))
      continue;
    seen.add(nodeRef(element));
    const elementRole = roleOf(element);
    const match = {
      ref: nodeRef(element),
      role: elementRole,
      name: text(element.name).slice(0, 200),
      text: role === "StaticText" ? text(node.name).slice(0, 200) : ""
    };
    (INTERACTIVE_ROLES.has(elementRole) ? interactive : other).push(match);
  }
  const all = [...interactive, ...other];
  return { matches: all.slice(0, maxMatches), truncated: all.length > maxMatches };
}

// src/background/elements.ts
function attributesOf(list) {
  const out = {};
  for (let i = 0;list && i + 1 < list.length; i += 2)
    out[list[i].toLowerCase()] = list[i + 1];
  return out;
}
async function describeElement(tabId, ref) {
  const parsed = parseRef(ref);
  const { backendNodeId } = parsed;
  const sessionId = sessionOfRef(tabId, parsed);
  await cdp.send(tabId, "DOM.enable", undefined, sessionId);
  let node;
  try {
    node = (await cdp.send(tabId, "DOM.describeNode", { backendNodeId }, sessionId)).node;
  } catch {
    throw new BrowserError(`Element ${ref} is not on the page anymore; take a new snapshot`, "not_found");
  }
  let role = "";
  let name = "";
  try {
    await cdp.send(tabId, "Accessibility.enable", undefined, sessionId);
    const { nodes } = await cdp.send(tabId, "Accessibility.getPartialAXTree", { backendNodeId, fetchRelatives: false }, sessionId);
    const own = nodes.find((n) => n.backendDOMNodeId === backendNodeId) ?? nodes[0];
    role = String(own?.role?.value ?? "");
    name = String(own?.name?.value ?? "").replace(/\s+/g, " ").trim();
  } catch {}
  return { backendNodeId, sessionId, ref, tag: node.nodeName.toLowerCase(), role, name, attributes: attributesOf(node.attributes) };
}
async function activeElement(tabId) {
  try {
    let sessionId;
    let frameIndex;
    let objectId = (await cdp.send(tabId, "Runtime.evaluate", { expression: "document.activeElement" })).result.objectId;
    for (let depth = 0;objectId && depth < 4; depth++) {
      await cdp.send(tabId, "DOM.enable", undefined, sessionId);
      const { node } = await cdp.send(tabId, "DOM.describeNode", { objectId }, sessionId);
      if (node.nodeName === "BODY" || node.nodeName === "HTML")
        return null;
      if (node.nodeName !== "IFRAME" && node.nodeName !== "FRAME")
        return await describeElement(tabId, refOf(node.backendNodeId, frameIndex));
      const child = node.frameId ? cdp.frameById(tabId, node.frameId) : undefined;
      if (child) {
        sessionId = child.sessionId;
        frameIndex = child.index;
        objectId = (await cdp.send(tabId, "Runtime.evaluate", { expression: "document.activeElement" }, sessionId)).result.objectId;
      } else {
        objectId = (await cdp.send(tabId, "Runtime.callFunctionOn", {
          objectId,
          functionDeclaration: "function() { return this.contentDocument && this.contentDocument.activeElement }"
        }, sessionId)).result.objectId;
      }
    }
    return null;
  } catch {
    return null;
  }
}
async function frameOffset(tabId, sessionId) {
  if (!sessionId)
    return { x: 0, y: 0 };
  const frame = cdp.frameBySession(tabId, sessionId);
  if (!frame)
    throw new BrowserError("The frame is not on the page anymore; take a new snapshot", "not_found");
  const parent = frame.parentSessionId;
  await cdp.send(tabId, "DOM.enable", undefined, parent);
  const { backendNodeId } = await cdp.send(tabId, "DOM.getFrameOwner", { frameId: frame.frameId }, parent);
  try {
    await cdp.send(tabId, "DOM.scrollIntoViewIfNeeded", { backendNodeId }, parent);
  } catch {}
  const { quads } = await cdp.send(tabId, "DOM.getContentQuads", { backendNodeId }, parent);
  const quad = quads?.[0];
  if (!quad)
    throw new BrowserError("The frame is not visible on the page", "invalid_request");
  const up = await frameOffset(tabId, parent);
  return { x: Math.min(quad[0], quad[2], quad[4], quad[6]) + up.x, y: Math.min(quad[1], quad[3], quad[5], quad[7]) + up.y };
}
async function boxOf(tabId, info) {
  try {
    await cdp.send(tabId, "DOM.scrollIntoViewIfNeeded", { backendNodeId: info.backendNodeId }, info.sessionId);
  } catch {}
  let quads = [];
  try {
    quads = (await cdp.send(tabId, "DOM.getContentQuads", { backendNodeId: info.backendNodeId }, info.sessionId)).quads ?? [];
  } catch {}
  const quad = quads.find((q) => q.length >= 8);
  if (!quad)
    throw new BrowserError(`${label(info)} (${info.ref}) is not visible on the page`, "invalid_request");
  const offset = await frameOffset(tabId, info.sessionId);
  const xs = [quad[0], quad[2], quad[4], quad[6]];
  const ys = [quad[1], quad[3], quad[5], quad[7]];
  return {
    x: Math.min(...xs) + offset.x,
    y: Math.min(...ys) + offset.y,
    width: Math.max(...xs) - Math.min(...xs),
    height: Math.max(...ys) - Math.min(...ys)
  };
}
function label(info) {
  const kind = info.role && info.role !== "generic" ? info.role : info.tag;
  return info.name ? `${kind} "${info.name.slice(0, 80)}"` : kind;
}
async function centerOf(tabId, info) {
  const box = await boxOf(tabId, info);
  return { x: box.x + box.width / 2, y: box.y + box.height / 2 };
}
async function callOn(tabId, info, fn, ...args) {
  const { object } = await cdp.send(tabId, "DOM.resolveNode", { backendNodeId: info.backendNodeId }, info.sessionId);
  if (!object?.objectId)
    throw new BrowserError(`Element ${info.ref} is not on the page anymore; take a new snapshot`, "not_found");
  const { result, exceptionDetails } = await cdp.send(tabId, "Runtime.callFunctionOn", {
    objectId: object.objectId,
    functionDeclaration: fn.toString(),
    arguments: args.map((value) => ({ value })),
    returnByValue: true,
    awaitPromise: true
  }, info.sessionId);
  if (exceptionDetails) {
    throw new BrowserError(exceptionDetails.exception?.description?.split(`
`)[0] ?? exceptionDetails.text ?? "Script error", "invalid_request");
  }
  return result.value;
}
async function focus(tabId, info) {
  try {
    await cdp.send(tabId, "DOM.focus", { backendNodeId: info.backendNodeId }, info.sessionId);
  } catch {
    throw new BrowserError(`${label(info)} (${info.ref}) cannot be focused`, "invalid_request");
  }
}

// src/background/guard.ts
var RISKY_WORDS = [
  "pay",
  "buy",
  "purchase",
  "order",
  "checkout",
  "check out",
  "book",
  "subscribe",
  "donate",
  "transfer",
  "send",
  "submit",
  "post",
  "publish",
  "share",
  "invite",
  "delete",
  "remove",
  "erase",
  "cancel",
  "unsubscribe",
  "confirm",
  "approve",
  "sign up",
  "sign in",
  "close account",
  "deactivate",
  "zaplatit",
  "koupit",
  "objednat",
  "rezervovat",
  "odeslat",
  "poslat",
  "publikovat",
  "sdílet",
  "smazat",
  "odstranit",
  "zrušit",
  "potvrdit",
  "schválit",
  "podepsat",
  "převést",
  "objednávk",
  "payer",
  "acheter",
  "commander",
  "réserver",
  "envoyer",
  "publier",
  "partager",
  "supprimer",
  "annuler",
  "confirmer",
  "valider",
  "signer",
  "virement",
  "bezahlen",
  "kaufen",
  "bestellen",
  "senden",
  "löschen",
  "bestätigen"
];
function isSensitiveField(element) {
  const a = element.attributes;
  const type = (a.type ?? "").toLowerCase();
  const autocomplete = (a.autocomplete ?? "").toLowerCase();
  const id = `${a.name ?? ""} ${a.id ?? ""}`.toLowerCase();
  return type === "password" || /(^|\s)cc-(number|csc|exp)/.test(autocomplete) || autocomplete.includes("current-password") || autocomplete.includes("new-password") || /cvv|cvc|card.?number|ccnum|securitycode/.test(id);
}
function hasRiskyWord(text) {
  const t = ` ${text.toLowerCase()} `;
  return RISKY_WORDS.some((w) => t.includes(w));
}
function submitsForm() {
  const tag = String(this.tagName || "").toUpperCase();
  const type = String(this.getAttribute?.("type") || "").toLowerCase();
  if (tag === "BUTTON")
    return !!this.form && (type === "" || type === "submit");
  if (tag === "INPUT")
    return !!this.form && (type === "submit" || type === "image");
  return false;
}
function isSearchField() {
  const type = String(this.getAttribute?.("type") || "").toLowerCase();
  const role = String(this.getAttribute?.("role") || "").toLowerCase();
  const hints = [this.name, this.id, this.getAttribute?.("aria-label"), this.getAttribute?.("placeholder")].join(" ").toLowerCase();
  if (type === "search" || role === "searchbox" || this.closest?.("[role=search], form[role=search]"))
    return true;
  return /(^|\W)(q|query|search|hledat|vyhledat|rechercher|suche)(\W|$)/.test(hints);
}
var TOGGLE_ROLES = new Set(["checkbox", "radio", "switch", "tab", "option", "menuitemcheckbox", "menuitemradio", "treeitem"]);
function isTextField() {
  const tag = String(this.tagName || "").toUpperCase();
  return tag === "TEXTAREA" || tag === "INPUT" || !!this.isContentEditable;
}
async function activationRisk(tabId, element) {
  if (await callOn(tabId, element, submitsForm).catch(() => false))
    return "It submits a form";
  if (TOGGLE_ROLES.has(element.role))
    return null;
  if (hasRiskyWord(`${element.name} ${element.attributes.value ?? ""} ${element.attributes["aria-label"] ?? ""}`)) {
    return "It may pay, send, delete or confirm something";
  }
  return null;
}
async function submitRisk(tabId, element) {
  if (await callOn(tabId, element, isSearchField).catch(() => false))
    return null;
  return "It submits a form";
}
async function riskOf(action, mode) {
  if (mode === "never")
    return null;
  if (mode === "all" && CHANGING_ACTIONS.includes(action.type)) {
    return "You asked to confirm every action";
  }
  if (!action.tab)
    return null;
  const tabId = action.tab.id;
  const element = action.element;
  if (action.type === "click") {
    return element ? activationRisk(tabId, element) : "It clicks a point of the page the agent cannot describe";
  }
  if (action.type === "type" && action.submits && element)
    return submitRisk(tabId, element);
  if (action.type === "key" && element) {
    const keys = String(action.value ?? "").trim().toLowerCase();
    const activates = keys === "enter" || keys === "space" || keys === " ";
    if (!activates)
      return null;
    if (await callOn(tabId, element, isTextField).catch(() => false)) {
      return keys === "enter" ? submitRisk(tabId, element) : null;
    }
    return activationRisk(tabId, element);
  }
  return null;
}
function describe2(action) {
  const what = action.element ? label(action.element) : "";
  switch (action.type) {
    case "click":
      return what ? `Click ${what}` : `Click at ${action.value}`;
    case "type":
      return `Type into ${what}${action.submits ? " and press Enter" : ""}`;
    case "key":
      return `Press ${action.value}${what ? ` in ${what}` : ""}`;
    case "select":
      return `Choose ${action.value} in ${what}`;
    case "navigate":
      return `Go to ${action.value}`;
    case "open":
      return `Open ${action.value} in a new tab`;
    default:
      return action.type;
  }
}
var CHANGING_ACTIONS = ["click", "type", "key", "select", "navigate", "open"];
async function guardAction(action, mode, signal, forcedReason) {
  if (action.type === "type" && action.element && isSensitiveField(action.element)) {
    throw new BrowserError("This is a password or payment card field: the user fills it in, never the agent", "forbidden");
  }
  const reason = forcedReason && CHANGING_ACTIONS.includes(action.type) ? forcedReason : await riskOf(action, mode);
  if (!reason)
    return;
  await confirmations.ask({
    kind: "action",
    title: describe2(action),
    details: action.type === "type" ? String(action.value ?? "").slice(0, 300) : "",
    reason,
    url: action.tab?.url ?? "",
    tab_id: action.tab?.id ?? null
  }, signal, action.element ? { backendNodeId: action.element.backendNodeId, sessionId: action.element.sessionId } : undefined);
}
async function confirmTool(params, signal) {
  await confirmations.ask({
    kind: "tool",
    title: String(params.title ?? "A tool"),
    details: String(params.details ?? ""),
    reason: "It can send data out of AYETO",
    url: "",
    tab_id: null
  }, signal);
  return { allowed: true };
}

// src/background/policy.ts
var RESTRICTED_SCHEMES = ["chrome:", "chrome-extension:", "chrome-untrusted:", "devtools:", "edge:", "brave:", "opera:", "vivaldi:", "about:", "view-source:", "file:", "javascript:", "data:"];
var RESTRICTED_HOSTS = ["chromewebstore.google.com", "chrome.google.com", "microsoftedge.microsoft.com"];
var AYETO_HOSTS = ["ayeto.ai"];
var AYETO_PANEL_PATHS = ["/ayeto-booster-panel/", "/ayeto-booster-preview/"];
function hostMatches(host, domain) {
  return host === domain || host.endsWith(`.${domain}`);
}
var blockedDomains = [];
function setBlockedDomains(domains) {
  blockedDomains = domains.map(normalizeDomain).filter(Boolean);
}
function normalizeDomain(value) {
  let host = value.trim().toLowerCase();
  if (!host)
    return "";
  try {
    host = new URL(host.includes("://") ? host : `https://${host}`).hostname;
  } catch {
    return "";
  }
  return host.replace(/^www\./, "");
}
function restrictionOf(url, serverUrl) {
  if (!url)
    return null;
  let parsed;
  try {
    parsed = new URL(url);
  } catch {
    return "The address is not valid";
  }
  if (RESTRICTED_SCHEMES.includes(parsed.protocol))
    return "Browser and extension pages are off limits";
  const host = parsed.hostname.toLowerCase();
  if (RESTRICTED_HOSTS.some((d) => hostMatches(host, d)))
    return "The extension store is off limits";
  const isAyeto = AYETO_HOSTS.some((d) => hostMatches(host, d)) || ayetoHosts(serverUrl).includes(parsed.host.toLowerCase());
  if (isAyeto && !AYETO_PANEL_PATHS.some((p) => parsed.pathname.startsWith(p))) {
    return "The agent does not work in AYETO itself";
  }
  if (blockedDomains.some((d) => hostMatches(host, d)))
    return "The user blocked this site for the agent";
  return null;
}
function ayetoHosts(serverUrl) {
  const hosts = [];
  for (const url of [serverUrl, APP_URL]) {
    try {
      hosts.push(new URL(url).host.toLowerCase());
    } catch {}
  }
  return hosts;
}
function assertAllowedUrl(url, serverUrl) {
  const reason = restrictionOf(url, serverUrl);
  if (reason)
    throw new BrowserError(reason, "forbidden");
}
function assertOpenableUrl(url, serverUrl) {
  let parsed;
  try {
    parsed = new URL(url);
  } catch {
    throw new BrowserError(`Not a valid address: ${url}`, "invalid_request");
  }
  if (parsed.protocol !== "http:" && parsed.protocol !== "https:") {
    throw new BrowserError("Only http and https addresses can be opened", "forbidden");
  }
  assertAllowedUrl(parsed.toString(), serverUrl);
  return parsed.toString();
}

// src/background/input.ts
var MODIFIERS = { alt: 1, control: 2, ctrl: 2, meta: 4, cmd: 4, command: 4, shift: 8 };
var KEYS = {
  enter: { key: "Enter", code: "Enter", keyCode: 13, text: "\r" },
  tab: { key: "Tab", code: "Tab", keyCode: 9 },
  escape: { key: "Escape", code: "Escape", keyCode: 27 },
  esc: { key: "Escape", code: "Escape", keyCode: 27 },
  backspace: { key: "Backspace", code: "Backspace", keyCode: 8 },
  delete: { key: "Delete", code: "Delete", keyCode: 46 },
  space: { key: " ", code: "Space", keyCode: 32, text: " " },
  arrowup: { key: "ArrowUp", code: "ArrowUp", keyCode: 38 },
  arrowdown: { key: "ArrowDown", code: "ArrowDown", keyCode: 40 },
  arrowleft: { key: "ArrowLeft", code: "ArrowLeft", keyCode: 37 },
  arrowright: { key: "ArrowRight", code: "ArrowRight", keyCode: 39 },
  up: { key: "ArrowUp", code: "ArrowUp", keyCode: 38 },
  down: { key: "ArrowDown", code: "ArrowDown", keyCode: 40 },
  left: { key: "ArrowLeft", code: "ArrowLeft", keyCode: 37 },
  right: { key: "ArrowRight", code: "ArrowRight", keyCode: 39 },
  home: { key: "Home", code: "Home", keyCode: 36 },
  end: { key: "End", code: "End", keyCode: 35 },
  pageup: { key: "PageUp", code: "PageUp", keyCode: 33 },
  pagedown: { key: "PageDown", code: "PageDown", keyCode: 34 }
};
function keyDefinition(name) {
  const known = KEYS[name.toLowerCase()];
  if (known)
    return known;
  const fn = /^f([1-9]|1[0-2])$/i.exec(name);
  if (fn)
    return { key: `F${fn[1]}`, code: `F${fn[1]}`, keyCode: 111 + Number(fn[1]) };
  if (name.length === 1) {
    const upper = name.toUpperCase();
    const isLetter = /[A-Z]/.test(upper);
    const isDigit = /[0-9]/.test(name);
    return {
      key: name,
      code: isLetter ? `Key${upper}` : isDigit ? `Digit${name}` : "",
      keyCode: isLetter || isDigit ? upper.charCodeAt(0) : 0,
      text: name
    };
  }
  throw new BrowserError(`Unknown key '${name}'`, "invalid_request");
}
async function pressKeys(tabId, combination) {
  const parts = combination.split("+").map((p) => p.trim()).filter(Boolean);
  if (parts.length === 0)
    throw new BrowserError("No key given", "invalid_request");
  let modifiers = 0;
  for (const part of parts.slice(0, -1)) {
    const bit = MODIFIERS[part.toLowerCase()];
    if (bit === undefined)
      throw new BrowserError(`Unknown modifier '${part}'`, "invalid_request");
    modifiers |= bit;
  }
  const key = keyDefinition(parts[parts.length - 1]);
  const text = modifiers & ~MODIFIERS.shift ? undefined : key.text;
  const common = { modifiers, key: key.key, code: key.code, windowsVirtualKeyCode: key.keyCode, nativeVirtualKeyCode: key.keyCode };
  await cdp.send(tabId, "Input.dispatchKeyEvent", { type: text ? "keyDown" : "rawKeyDown", ...common, text, unmodifiedText: text });
  await cdp.send(tabId, "Input.dispatchKeyEvent", { type: "keyUp", ...common });
}
async function selectAll(tabId) {
  const isMac = (await chrome.runtime.getPlatformInfo()).os === "mac";
  await pressKeys(tabId, isMac ? "Meta+A" : "Control+A");
}
async function insertText(tabId, text) {
  await cdp.send(tabId, "Input.insertText", { text });
}
async function clickAt(tabId, x, y, clickCount = 1) {
  await cdp.send(tabId, "Input.dispatchMouseEvent", { type: "mouseMoved", x, y });
  for (let i = 1;i <= clickCount; i++) {
    await cdp.send(tabId, "Input.dispatchMouseEvent", { type: "mousePressed", x, y, button: "left", clickCount: i });
    await cdp.send(tabId, "Input.dispatchMouseEvent", { type: "mouseReleased", x, y, button: "left", clickCount: i });
  }
}
async function wheel(tabId, x, y, deltaX, deltaY) {
  await cdp.send(tabId, "Input.dispatchMouseEvent", { type: "mouseWheel", x, y, deltaX, deltaY });
}

// src/shared/storage.ts
var SETTINGS_KEY = "ayeto.settings";
var SESSION_KEY = "ayeto.session";
var DEFAULT_SESSION = {
  group_ids: [],
  agent_tab_id: null
};
async function loadSettings() {
  const stored = await chrome.storage.local.get(SETTINGS_KEY);
  return { ...DEFAULT_SETTINGS, ...stored[SETTINGS_KEY] ?? {} };
}
async function saveSettings(update) {
  const settings = { ...await loadSettings(), ...update };
  await chrome.storage.local.set({ [SETTINGS_KEY]: settings });
  return settings;
}
async function loadSession() {
  const stored = await chrome.storage.session.get(SESSION_KEY);
  return { ...DEFAULT_SESSION, ...stored[SESSION_KEY] ?? {} };
}
async function saveSession(update) {
  const session = { ...await loadSession(), ...update };
  await chrome.storage.session.set({ [SESSION_KEY]: session });
  return session;
}

// src/background/tabs.ts
var GROUP_TITLE = "AYETO";
var GROUP_COLOR = "blue";
var LOAD_TIMEOUT_MS = 15000;
var NO_TAB_MESSAGE = "No tab is given to the agent. Open one with the tabs tool (action open), or ask the user to give " + "the agent a tab in the AYETO side panel.";
async function waitForTabLoad(tabId, timeoutMs = LOAD_TIMEOUT_MS) {
  const tab = await chrome.tabs.get(tabId).catch(() => null);
  if (!tab || tab.status === "complete")
    return;
  await new Promise((resolve) => {
    const timer = setTimeout(done, timeoutMs);
    function done() {
      clearTimeout(timer);
      chrome.tabs.onUpdated.removeListener(listener);
      chrome.tabs.onRemoved.removeListener(removed);
      resolve();
    }
    function listener(id, info) {
      if (id === tabId && info.status === "complete")
        done();
    }
    function removed(id) {
      if (id === tabId)
        done();
    }
    chrome.tabs.onUpdated.addListener(listener);
    chrome.tabs.onRemoved.addListener(removed);
  });
}

class AgentTabs {
  async groupIds() {
    const session = await loadSession();
    const alive = [];
    for (const id of session.group_ids) {
      const group = await chrome.tabGroups.get(id).catch(() => null);
      if (group)
        alive.push(id);
    }
    if (alive.length !== session.group_ids.length)
      await saveSession({ group_ids: alive });
    return alive;
  }
  async controlledTabs() {
    const tabs = [];
    for (const groupId of await this.groupIds()) {
      tabs.push(...await chrome.tabs.query({ groupId }));
    }
    return tabs.filter((t) => t.id !== undefined);
  }
  async isControlled(tabId) {
    const tab = await chrome.tabs.get(tabId).catch(() => null);
    if (!tab || tab.groupId === undefined || tab.groupId < 0)
      return false;
    return (await this.groupIds()).includes(tab.groupId);
  }
  async give(tabId, serverUrl) {
    const tab = await chrome.tabs.get(tabId);
    assertAllowedUrl(tab.url || tab.pendingUrl, serverUrl);
    let groupId;
    for (const id of await this.groupIds()) {
      const group = await chrome.tabGroups.get(id);
      if (group.windowId === tab.windowId)
        groupId = id;
    }
    const newGroupId = await chrome.tabs.group({ tabIds: [tabId], ...groupId !== undefined ? { groupId } : {} });
    if (groupId === undefined) {
      await chrome.tabGroups.update(newGroupId, { title: GROUP_TITLE, color: GROUP_COLOR });
      const session = await loadSession();
      await saveSession({ group_ids: [...session.group_ids, newGroupId] });
    }
    const session = await loadSession();
    if (session.agent_tab_id === null || !await this.isControlled(session.agent_tab_id)) {
      await saveSession({ agent_tab_id: tabId });
    }
  }
  async release(tabId) {
    await cdp.detach(tabId);
    if (await this.isControlled(tabId))
      await chrome.tabs.ungroup(tabId).catch(() => {
        return;
      });
    const session = await loadSession();
    if (session.agent_tab_id === tabId)
      await saveSession({ agent_tab_id: null });
  }
  async releaseAll() {
    for (const tab of await this.controlledTabs())
      await this.release(tab.id);
    await saveSession({ group_ids: [], agent_tab_id: null });
  }
  async resolve(requestedTabId, serverUrl) {
    let tabId = requestedTabId ?? null;
    if (tabId === null) {
      const session = await loadSession();
      if (session.agent_tab_id !== null && await this.isControlled(session.agent_tab_id)) {
        tabId = session.agent_tab_id;
      } else {
        const tabs = await this.controlledTabs();
        if (tabs.length === 0)
          throw new BrowserError(NO_TAB_MESSAGE, "forbidden");
        tabId = (tabs.find((t) => t.active) ?? tabs[0]).id;
        await saveSession({ agent_tab_id: tabId });
      }
    }
    const tab = await chrome.tabs.get(tabId).catch(() => null);
    if (!tab)
      throw new BrowserError(`Tab ${tabId} does not exist`, "not_found");
    if (!await this.isControlled(tabId)) {
      throw new BrowserError(`Tab ${tabId} is not given to the agent; ask the user to give it in the AYETO side panel`, "forbidden");
    }
    assertAllowedUrl(tab.url || tab.pendingUrl, serverUrl);
    return tab;
  }
  async agentTabId() {
    const session = await loadSession();
    if (session.agent_tab_id !== null && await this.isControlled(session.agent_tab_id))
      return session.agent_tab_id;
    return null;
  }
  async list() {
    const controlled = await this.controlledTabs();
    const agentTabId = await this.agentTabId();
    const tabs = controlled.map((t) => ({
      tab_id: t.id,
      title: t.title ?? "",
      url: t.url ?? t.pendingUrl ?? "",
      active: t.id === agentTabId,
      controlled: true
    }));
    const [focused] = await chrome.tabs.query({ active: true, lastFocusedWindow: true });
    if (focused?.id !== undefined && !tabs.some((t) => t.tab_id === focused.id)) {
      tabs.push({ tab_id: focused.id, title: focused.title ?? "", url: focused.url ?? "", active: false, controlled: false });
    }
    return { tabs, active_tab_id: agentTabId };
  }
  async open(url, serverUrl) {
    const target = assertOpenableUrl(url, serverUrl);
    const groups = await this.groupIds();
    let windowId;
    if (groups.length > 0)
      windowId = (await chrome.tabGroups.get(groups[0])).windowId;
    const tab = await chrome.tabs.create({ url: target, active: false, ...windowId !== undefined ? { windowId } : {} });
    await this.give(tab.id, serverUrl).catch(async (e) => {
      await chrome.tabs.remove(tab.id).catch(() => {
        return;
      });
      throw e;
    });
    await saveSession({ agent_tab_id: tab.id });
    await waitForTabLoad(tab.id);
  }
  async select(tabId, serverUrl) {
    const tab = await this.resolve(tabId, serverUrl);
    await chrome.tabs.update(tab.id, { active: true });
    await saveSession({ agent_tab_id: tab.id });
  }
  async close(tabId, serverUrl) {
    const tab = await this.resolve(tabId, serverUrl);
    await cdp.detach(tab.id);
    await chrome.tabs.remove(tab.id);
    const session = await loadSession();
    if (session.agent_tab_id === tab.id)
      await saveSession({ agent_tab_id: null });
  }
}
var agentTabs = new AgentTabs;

// src/background/actions.ts
var SETTLE_MS = 400;
var NAVIGATION_TIMEOUT_MS = 15000;
var WAIT_POLL_MS = 300;
var WAIT_MAX_SECONDS = 30;
var BATCH_MAX_STEPS = 20;
function sleep(ms, signal) {
  return new Promise((resolve, reject) => {
    if (signal.aborted)
      return reject(new BrowserError("The user stopped the agent", "cancelled"));
    const timer = setTimeout(resolve, ms);
    signal.addEventListener("abort", () => {
      clearTimeout(timer);
      reject(new BrowserError("The user stopped the agent", "cancelled"));
    }, { once: true });
  });
}
function checkCancelled(signal) {
  if (signal.aborted)
    throw new BrowserError("The user stopped the agent", "cancelled");
}
async function settle(tab, urlBefore, ctx) {
  await sleep(SETTLE_MS, ctx.signal);
  let fresh = await chrome.tabs.get(tab.id).catch(() => null);
  if (!fresh)
    throw new BrowserError("The tab was closed", "not_found");
  const navigated = fresh.status === "loading" || (fresh.url ?? "") !== urlBefore;
  if (navigated) {
    await waitForTabLoad(tab.id, NAVIGATION_TIMEOUT_MS);
    fresh = await chrome.tabs.get(tab.id).catch(() => null) ?? fresh;
  }
  return { navigated, tab: fresh };
}
async function payload(tab, result, navigated) {
  const fresh = await chrome.tabs.get(tab.id).catch(() => null) ?? tab;
  return { tab_id: fresh.id ?? null, url: fresh.url ?? "", title: fresh.title ?? "", result, navigated };
}
function requireString(params, key) {
  const value = params[key];
  if (typeof value !== "string" || !value)
    throw new BrowserError(`${key} is required`, "invalid_request");
  return value;
}
async function navigate(tab, params, ctx) {
  const tabId = tab.id;
  const action = String(params.action ?? "goto");
  if (action === "goto") {
    const url = assertOpenableUrl(requireString(params, "url"), ctx.serverUrl);
    await ctx.guard({ type: "navigate", tab, value: url });
    ctx.setActivity(`Opening ${url}`, tabId);
    const { errorText } = await cdp.send(tabId, "Page.navigate", { url });
    if (errorText)
      throw new BrowserError(`The page could not be opened: ${errorText}`, "not_found");
  } else if (action === "back" || action === "forward") {
    const { currentIndex, entries } = await cdp.send(tabId, "Page.getNavigationHistory");
    const target = entries[currentIndex + (action === "back" ? -1 : 1)];
    if (!target)
      throw new BrowserError(`There is no page to go ${action} to`, "invalid_request");
    await ctx.guard({ type: "navigate", tab, value: action });
    await cdp.send(tabId, "Page.navigateToHistoryEntry", { entryId: target.id });
  } else if (action === "reload") {
    await ctx.guard({ type: "navigate", tab, value: action });
    await cdp.send(tabId, "Page.reload");
  } else {
    throw new BrowserError(`Unknown navigate action '${action}'`, "invalid_request");
  }
  await sleep(SETTLE_MS, ctx.signal);
  await waitForTabLoad(tabId, NAVIGATION_TIMEOUT_MS);
  const fresh = await payload(tab, action === "goto" ? `Opened ${params.url}` : `Went ${action}`, true);
  return fresh;
}
async function click(tab, params, ctx) {
  const tabId = tab.id;
  const urlBefore = tab.url ?? "";
  let point;
  let what;
  if (params.ref) {
    const element = await describeElement(tabId, String(params.ref));
    await ctx.guard({ type: "click", tab, element });
    point = await centerOf(tabId, element);
    what = label(element);
  } else {
    if (typeof params.x !== "number" || typeof params.y !== "number")
      throw new BrowserError("ref or x and y are required", "invalid_request");
    await ctx.guard({ type: "click", tab, value: `${params.x},${params.y}` });
    point = { x: params.x, y: params.y };
    what = `the point ${params.x}, ${params.y}`;
  }
  ctx.setActivity(`Clicking ${what}`, tabId);
  await clickAt(tabId, point.x, point.y, params.double ? 2 : 1);
  const after = await settle(tab, urlBefore, ctx);
  return payload(after.tab, `${params.double ? "Double-clicked" : "Clicked"} ${what}`, after.navigated);
}
function isEditable() {
  if (this.isContentEditable)
    return true;
  const tag = String(this.tagName || "").toUpperCase();
  if (tag === "TEXTAREA")
    return !this.readOnly && !this.disabled;
  if (tag !== "INPUT")
    return false;
  const type = String(this.type || "text").toLowerCase();
  return !this.readOnly && !this.disabled && !["checkbox", "radio", "button", "submit", "reset", "file", "image", "range", "color", "hidden"].includes(type);
}
async function type(tab, params, ctx) {
  const tabId = tab.id;
  const urlBefore = tab.url ?? "";
  const text = typeof params.text === "string" ? params.text : "";
  const element = await describeElement(tabId, requireString(params, "ref"));
  if (!await callOn(tabId, element, isEditable)) {
    throw new BrowserError(`${label(element)} (${element.ref}) does not take text; use click, select or key`, "invalid_request");
  }
  await ctx.guard({ type: "type", tab, element, value: text, submits: !!params.submit });
  ctx.setActivity(`Typing into ${label(element)}`, tabId);
  await focus(tabId, element);
  if (params.clear !== false) {
    await selectAll(tabId);
    await pressKeys(tabId, "Backspace");
  }
  if (text)
    await insertText(tabId, text);
  if (params.submit)
    await pressKeys(tabId, "Enter");
  const after = await settle(tab, urlBefore, ctx);
  return payload(after.tab, `Typed ${text.length} characters into ${label(element)}${params.submit ? " and pressed Enter" : ""}`, after.navigated);
}
async function key(tab, params, ctx) {
  const tabId = tab.id;
  const urlBefore = tab.url ?? "";
  const keys = requireString(params, "keys");
  const element = params.ref ? await describeElement(tabId, String(params.ref)) : await activeElement(tabId) ?? undefined;
  await ctx.guard({ type: "key", tab, element, value: keys, submits: /(^|\+)enter$/i.test(keys.trim()) });
  if (element && params.ref)
    await focus(tabId, element);
  ctx.setActivity(`Pressing ${keys}`, tabId);
  await pressKeys(tabId, keys);
  const after = await settle(tab, urlBefore, ctx);
  return payload(after.tab, `Pressed ${keys}${element ? ` in ${label(element)}` : ""}`, after.navigated);
}
async function scroll(tab, params, ctx) {
  const tabId = tab.id;
  if (params.ref) {
    const element = await describeElement(tabId, String(params.ref));
    await centerOf(tabId, element);
    return payload(tab, `Scrolled ${label(element)} into view`, false);
  }
  const direction = String(params.direction ?? "down");
  const amount = Math.min(20, Math.max(0.1, Number(params.amount ?? 1)));
  const { cssVisualViewport: vp } = await cdp.send(tabId, "Page.getLayoutMetrics");
  const dy = direction === "down" ? 1 : direction === "up" ? -1 : 0;
  const dx = direction === "right" ? 1 : direction === "left" ? -1 : 0;
  if (!dx && !dy)
    throw new BrowserError(`Unknown direction '${direction}'`, "invalid_request");
  await wheel(tabId, vp.clientWidth / 2, vp.clientHeight / 2, dx * vp.clientWidth * 0.85 * amount, dy * vp.clientHeight * 0.85 * amount);
  await sleep(SETTLE_MS, ctx.signal);
  const { result } = await cdp.send(tabId, "Runtime.evaluate", {
    expression: "({ y: Math.round(scrollY), h: Math.round(document.documentElement.scrollHeight), vh: Math.round(innerHeight) })",
    returnByValue: true
  });
  const pos = result.value;
  const atEnd = pos.y + pos.vh >= pos.h - 2;
  return payload(tab, `Scrolled ${direction}; now at ${pos.y} of ${pos.h} px${atEnd && dy > 0 ? " (end of the page)" : ""}`, false);
}
function selectOptions(values) {
  if (String(this.tagName).toUpperCase() !== "SELECT")
    throw new Error("Not a select element; operate it with clicks");
  const options = Array.from(this.options);
  const chosen = [];
  for (const value of values) {
    const wanted = String(value).trim().toLowerCase();
    const option = options.find((o) => o.value === value) ?? options.find((o) => String(o.label || o.text).trim().toLowerCase() === wanted);
    if (!option)
      throw new Error(`No option '${value}'. Options: ${options.map((o) => String(o.label || o.text).trim()).slice(0, 30).join(", ")}`);
    chosen.push(option);
  }
  if (!this.multiple && chosen.length > 1)
    throw new Error("This select takes one option");
  for (const option of options)
    option.selected = chosen.includes(option);
  this.dispatchEvent(new Event("input", { bubbles: true }));
  this.dispatchEvent(new Event("change", { bubbles: true }));
  return chosen.map((o) => String(o.label || o.text).trim());
}
async function select(tab, params, ctx) {
  const tabId = tab.id;
  const urlBefore = tab.url ?? "";
  const values = Array.isArray(params.values) ? params.values.map(String) : [];
  if (values.length === 0)
    throw new BrowserError("values are required", "invalid_request");
  const element = await describeElement(tabId, requireString(params, "ref"));
  await ctx.guard({ type: "select", tab, element, value: values.join(", ") });
  ctx.setActivity(`Choosing ${values.join(", ")}`, tabId);
  const chosen = await callOn(tabId, element, selectOptions, values);
  const after = await settle(tab, urlBefore, ctx);
  return payload(after.tab, `Selected ${chosen.join(", ")} in ${label(element)}`, after.navigated);
}
async function wait(tab, params, ctx) {
  const tabId = tab.id;
  const seconds = Math.min(WAIT_MAX_SECONDS, Math.max(0.1, Number(params.seconds ?? 5)));
  const deadline = Date.now() + seconds * 1000;
  if (typeof params.text === "string" && params.text) {
    ctx.setActivity(`Waiting for "${params.text}"`, tabId);
    const expression = `!!document.body && document.body.innerText.includes(${JSON.stringify(params.text)})`;
    while (Date.now() < deadline) {
      checkCancelled(ctx.signal);
      const { result } = await cdp.send(tabId, "Runtime.evaluate", { expression, returnByValue: true });
      if (result.value)
        return payload(tab, `The text "${params.text}" is on the page`, false);
      await sleep(WAIT_POLL_MS, ctx.signal);
    }
    return payload(tab, `The text "${params.text}" did not appear within ${seconds} s`, false);
  }
  if (params.navigation) {
    ctx.setActivity("Waiting for the page", tabId);
    await waitForTabLoad(tabId, seconds * 1000);
    const fresh = await chrome.tabs.get(tabId);
    return payload(fresh, fresh.status === "complete" ? "The page finished loading" : `The page is still loading after ${seconds} s`, true);
  }
  ctx.setActivity(`Waiting ${seconds} s`, tabId);
  await sleep(seconds * 1000, ctx.signal);
  return payload(tab, `Waited ${seconds} s`, false);
}
var ACTIONS = {
  navigate,
  click,
  type,
  key,
  scroll,
  select,
  wait
};
var ACTION_TYPES = [...Object.keys(ACTIONS), "batch"];
async function batch(tab, params, ctx) {
  const steps = Array.isArray(params.steps) ? params.steps : [];
  if (steps.length === 0 || steps.length > BATCH_MAX_STEPS) {
    throw new BrowserError(`A batch has 1 to ${BATCH_MAX_STEPS} steps`, "invalid_request");
  }
  const outcomes = [];
  let current = tab;
  for (const step of steps) {
    const action = String(step.action ?? "");
    const run = ACTIONS[action];
    if (!run) {
      outcomes.push({ action, ok: false, result: "", error: `Unknown action '${action}'` });
      break;
    }
    try {
      const result = await run(current, step, ctx);
      outcomes.push({ action, ok: true, result: result.result });
      current = await chrome.tabs.get(tab.id).catch(() => null) ?? current;
    } catch (e) {
      if (e instanceof BrowserError && e.code === "cancelled")
        throw e;
      outcomes.push({ action, ok: false, result: "", error: String(e?.message ?? e) });
      break;
    }
  }
  const fresh = await chrome.tabs.get(tab.id).catch(() => null) ?? current;
  return {
    tab_id: fresh.id ?? null,
    url: fresh.url ?? "",
    title: fresh.title ?? "",
    steps: outcomes,
    completed: outcomes.filter((o) => o.ok).length
  };
}
async function runAction(frame, ctx) {
  const tab = await agentTabs.resolve(frame.tab_id, ctx.serverUrl);
  ctx.setActivity(frame.type, tab.id);
  const params = frame.params ?? {};
  if (frame.type === "batch")
    return batch(tab, params, ctx);
  const run = ACTIONS[frame.type];
  if (!run)
    throw new BrowserError(`Unknown action '${frame.type}'`, "invalid_request");
  return run(tab, params, ctx);
}

// src/background/extract.ts
function extractReadableText(maxChars) {
  const SKIP = new Set(["SCRIPT", "STYLE", "NOSCRIPT", "TEMPLATE", "SVG", "CANVAS", "OBJECT", "EMBED", "INPUT", "TEXTAREA", "SELECT", "OPTION", "HEAD", "META", "LINK"]);
  const BLOCK = new Set(["P", "DIV", "SECTION", "ARTICLE", "MAIN", "HEADER", "FORM", "FIELDSET", "FIGURE", "FIGCAPTION", "BLOCKQUOTE", "UL", "OL", "DL", "DT", "DD", "DETAILS", "SUMMARY", "ADDRESS", "LEGEND", "LABEL", "HR"]);
  const CHROME = new Set(["NAV", "ASIDE", "FOOTER"]);
  const CHROME_ROLES = new Set(["navigation", "complementary", "contentinfo", "banner"]);
  const element = this instanceof Element ? this : null;
  let root = element;
  let skipChrome = false;
  if (!root) {
    const main = document.querySelector("main, [role=main], article");
    const mainText = main ? main.innerText ?? "" : "";
    root = main && mainText.trim().length > 200 ? main : document.body;
    skipChrome = root === document.body;
  }
  if (!root)
    return { text: "", truncated: false };
  const clean = (s) => s.replace(/\s+/g, " ").trim();
  const hidden = (el) => {
    if (el.getAttribute("aria-hidden") === "true")
      return true;
    if (el.hidden)
      return true;
    const check = el.checkVisibility;
    if (typeof check === "function")
      return !check.call(el, { visibilityProperty: true, opacityProperty: false });
    const style = getComputedStyle(el);
    return style.display === "none" || style.visibility === "hidden";
  };
  let budget = maxChars * 2;
  const render = (node, listDepth) => {
    if (budget <= 0)
      return "";
    if (node.nodeType === Node.TEXT_NODE) {
      const t = (node.textContent ?? "").replace(/\s+/g, " ");
      budget -= t.length;
      return t;
    }
    if (node.nodeType !== Node.ELEMENT_NODE)
      return "";
    const el = node;
    const tag = el.tagName.toUpperCase();
    if (SKIP.has(tag) || hidden(el))
      return "";
    if (skipChrome && (CHROME.has(tag) || CHROME_ROLES.has(el.getAttribute("role") ?? "")))
      return "";
    const nextDepth = tag === "UL" || tag === "OL" ? listDepth + 1 : listDepth;
    const inner = () => Array.from(el.childNodes).map((c) => render(c, nextDepth)).join("");
    if (/^H[1-6]$/.test(tag))
      return `

${"#".repeat(Number(tag[1]))} ${clean(inner())}

`;
    switch (tag) {
      case "A": {
        const label = clean(inner());
        const href = el.href;
        if (!label)
          return "";
        return href && !href.startsWith("javascript:") ? `[${label}](${href})` : label;
      }
      case "BR":
        return `
`;
      case "IFRAME":
      case "FRAME": {
        let body = null;
        try {
          body = el.contentDocument?.body ?? null;
        } catch {}
        return body ? `

${render(body, 0)}

` : "";
      }
      case "IMG": {
        const alt = clean(el.getAttribute("alt") ?? "");
        return alt ? `![${alt}]` : "";
      }
      case "LI": {
        const own = [];
        const nested = [];
        for (const c of Array.from(el.childNodes)) {
          const isList = c.nodeType === Node.ELEMENT_NODE && /^(UL|OL)$/i.test(c.tagName);
          (isList ? nested : own).push(render(c, nextDepth));
        }
        return `
${"  ".repeat(Math.max(0, listDepth - 1))}- ${clean(own.join(""))}${nested.join("")}`;
      }
      case "UL":
      case "OL":
        return listDepth > 0 ? inner() : `

${inner()}

`;
      case "PRE":
      case "CODE":
        if (tag === "CODE" && el.parentElement?.tagName.toUpperCase() !== "PRE")
          return ` \`${clean(el.textContent ?? "")}\` `;
        return `

\`\`\`
${(el.textContent ?? "").replace(/\n+$/, "")}
\`\`\`

`;
      case "TABLE": {
        const rows = Array.from(el.rows).map((row) => `| ${Array.from(row.cells).map((cell) => clean(Array.from(cell.childNodes).map((c) => render(c, listDepth)).join("")).replace(/\|/g, "\\|")).join(" | ")} |`);
        if (rows.length > 1) {
          const columns = el.rows[0]?.cells.length ?? 1;
          rows.splice(1, 0, `|${" --- |".repeat(columns)}`);
        }
        return `

${rows.join(`
`)}

`;
      }
      case "BUTTON":
        return ` ${clean(inner())} `;
      case "BLOCKQUOTE":
        return `

> ${clean(inner())}

`;
      default:
        return BLOCK.has(tag) ? `

${inner()}

` : inner();
    }
  };
  const raw = render(root, 0);
  const text = raw.replace(/[ \t]+\n/g, `
`).replace(/\n[ \t]+(?=[^-\s])/g, `
`).replace(/\n{3,}/g, `

`).replace(/([^\n ]) {2,}/g, "$1 ").trim();
  if (text.length > maxChars)
    return { text: text.slice(0, maxChars), truncated: true };
  return { text, truncated: budget <= 0 };
}

// src/background/operations.ts
var DEFAULT_MAX_CHARS = 40000;
var DEFAULT_MAX_MATCHES = 50;
var READY_TIMEOUT_MS = 1e4;
var SCREENSHOT_MAX_WIDTH = 1600;
var SCREENSHOT_MAX_HEIGHT = 8000;
var SCREENSHOT_QUALITY = 80;
var FRAME_TEXT_MIN_SIZE = 50;
var FRAME_TEXT_MAX = 5;
function numberParam(value, fallback) {
  const n = Number(value);
  return Number.isFinite(n) && n > 0 ? n : fallback;
}
async function pageInfo(tab) {
  const fresh = await chrome.tabs.get(tab.id).catch(() => tab);
  return { tab_id: fresh.id ?? null, url: fresh.url ?? "", title: fresh.title ?? "" };
}
function withDialogs(payload, dialogs) {
  return dialogs.length ? { ...payload, dialogs } : payload;
}
async function tabs(frame, ctx) {
  const params = frame.params ?? {};
  const action = params.action ?? "list";
  switch (action) {
    case "list":
      break;
    case "open": {
      if (!params.url)
        throw new BrowserError("url is required to open a tab", "invalid_request");
      const url = assertOpenableUrl(String(params.url), ctx.serverUrl);
      await ctx.guard({ type: "open", value: url });
      ctx.setActivity(`Opening ${url}`, null);
      await agentTabs.open(url, ctx.serverUrl);
      break;
    }
    case "select":
      if (frame.tab_id == null)
        throw new BrowserError("tab_id is required", "invalid_request");
      await agentTabs.select(frame.tab_id, ctx.serverUrl);
      break;
    case "close":
      if (frame.tab_id == null)
        throw new BrowserError("tab_id is required", "invalid_request");
      await agentTabs.close(frame.tab_id, ctx.serverUrl);
      break;
    default:
      throw new BrowserError(`Unknown tabs action '${action}'`, "invalid_request");
  }
  return agentTabs.list();
}
async function readyTab(frame, ctx, operation) {
  const tab = await agentTabs.resolve(frame.tab_id, ctx.serverUrl);
  ctx.setActivity(operation, tab.id);
  await waitForTabLoad(tab.id, READY_TIMEOUT_MS);
  return tab;
}
async function snapshot(frame, ctx) {
  const tab = await readyTab(frame, ctx, "Reading the page");
  const params = frame.params ?? {};
  const { nodes, sensitive } = await pageTree(tab.id);
  const result = renderSnapshot(nodes, sensitive, !!params.interactive_only, numberParam(params.max_chars, DEFAULT_MAX_CHARS));
  const payload = { ...await pageInfo(tab), ...result };
  return withDialogs(payload, cdp.takeDialogs(tab.id));
}
async function find(frame, ctx) {
  const params = frame.params ?? {};
  const query = String(params.query ?? "").trim();
  if (!query)
    throw new BrowserError("query is required", "invalid_request");
  const tab = await readyTab(frame, ctx, `Looking for "${query}"`);
  const { nodes, sensitive } = await pageTree(tab.id);
  const result = findInTree(nodes, sensitive, query, numberParam(params.max_matches, DEFAULT_MAX_MATCHES));
  const payload = { ...await pageInfo(tab), ...result };
  return withDialogs(payload, cdp.takeDialogs(tab.id));
}
async function framesText(tabId, maxChars) {
  const parts = [];
  let budget = maxChars;
  for (const frame of cdp.frames(tabId)) {
    if (parts.length >= FRAME_TEXT_MAX || budget <= 0)
      break;
    try {
      const { backendNodeId } = await cdp.send(tabId, "DOM.getFrameOwner", { frameId: frame.frameId }, frame.parentSessionId);
      const { quads } = await cdp.send(tabId, "DOM.getContentQuads", { backendNodeId }, frame.parentSessionId);
      const q = quads?.[0];
      if (!q || Math.abs(q[4] - q[0]) < FRAME_TEXT_MIN_SIZE || Math.abs(q[5] - q[1]) < FRAME_TEXT_MIN_SIZE)
        continue;
      const { result } = await cdp.send(tabId, "Runtime.evaluate", {
        expression: `({ ...(${extractReadableText.toString()}).call(null, ${budget}), url: location.href })`,
        returnByValue: true
      }, frame.sessionId);
      const text = result.value?.text?.trim();
      if (!text)
        continue;
      parts.push(`--- frame ${result.value.url} ---
${text}`);
      budget -= text.length;
    } catch {}
  }
  return parts.join(`

`);
}
async function readText(frame, ctx) {
  const tab = await readyTab(frame, ctx, "Reading the page text");
  const params = frame.params ?? {};
  const maxChars = numberParam(params.max_chars, DEFAULT_MAX_CHARS);
  let result;
  if (params.ref) {
    const element = await describeElement(tab.id, String(params.ref));
    result = await callOn(tab.id, element, extractReadableText, maxChars);
  } else {
    const { result: value, exceptionDetails } = await cdp.send(tab.id, "Runtime.evaluate", {
      expression: `(${extractReadableText.toString()}).call(null, ${maxChars})`,
      returnByValue: true
    });
    if (exceptionDetails)
      throw new BrowserError("Reading the page failed", "internal");
    result = value.value;
    const frames = await framesText(tab.id, maxChars - result.text.length);
    if (frames)
      result = { text: `${result.text}

${frames}`.slice(0, maxChars), truncated: result.truncated };
  }
  const payload = { ...await pageInfo(tab), text: result.text, truncated: result.truncated };
  return withDialogs(payload, cdp.takeDialogs(tab.id));
}
async function screenshot(frame, ctx) {
  const tab = await readyTab(frame, ctx, "Taking a screenshot");
  const tabId = tab.id;
  const params = frame.params ?? {};
  const metrics = await cdp.send(tabId, "Page.getLayoutMetrics");
  const viewport = metrics.cssVisualViewport;
  let clip;
  let beyondViewport = false;
  if (params.ref) {
    const element = await describeElement(tabId, String(params.ref));
    const box = await boxOf(tabId, element);
    const fresh = (await cdp.send(tabId, "Page.getLayoutMetrics")).cssVisualViewport;
    clip = {
      x: box.x + fresh.pageX,
      y: box.y + fresh.pageY,
      width: Math.max(1, box.width),
      height: Math.max(1, Math.min(SCREENSHOT_MAX_HEIGHT, box.height))
    };
    beyondViewport = true;
  } else if (params.full_page) {
    clip = {
      x: 0,
      y: 0,
      width: metrics.cssContentSize.width,
      height: Math.min(metrics.cssContentSize.height, SCREENSHOT_MAX_HEIGHT)
    };
    beyondViewport = true;
  } else {
    clip = { x: viewport.pageX, y: viewport.pageY, width: viewport.clientWidth, height: viewport.clientHeight };
  }
  const scale = Math.min(1, SCREENSHOT_MAX_WIDTH / Math.max(1, clip.width));
  const { data } = await cdp.send(tabId, "Page.captureScreenshot", {
    format: "jpeg",
    quality: SCREENSHOT_QUALITY,
    clip: { ...clip, scale },
    captureBeyondViewport: beyondViewport
  });
  const payload = {
    ...await pageInfo(tab),
    mime_type: "image/jpeg",
    data,
    width: Math.round(clip.width * scale),
    height: Math.round(clip.height * scale)
  };
  return withDialogs(payload, cdp.takeDialogs(tabId));
}
async function confirm(frame, ctx) {
  ctx.setActivity("Waiting for your confirmation", null);
  return confirmTool(frame.params ?? {}, ctx.signal);
}
var OPERATIONS = {
  tabs,
  confirm,
  snapshot,
  find,
  read_text: readText,
  screenshot
};
function isOperation(frame) {
  return frame.type in OPERATIONS || ACTION_TYPES.includes(frame.type);
}
async function runOperation(frame, ctx) {
  const operation = OPERATIONS[frame.type];
  if (operation)
    return operation(frame, ctx);
  if (!ACTION_TYPES.includes(frame.type))
    throw new BrowserError(`Unknown operation '${frame.type}'`, "invalid_request");
  const result = await runAction(frame, ctx);
  return result.tab_id != null ? withDialogs(result, cdp.takeDialogs(result.tab_id)) : result;
}

// src/background/pairing.ts
var CLIENT = "ayeto-browser";
async function post(url, body, signal) {
  const response = await fetch(url, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(body),
    signal
  });
  if (!response.ok) {
    let detail = response.statusText;
    try {
      detail = (await response.json()).detail ?? detail;
    } catch {}
    throw new Error(`${response.status}: ${detail}`);
  }
  return response.json();
}
function sleep2(ms, signal) {
  return new Promise((resolve, reject) => {
    const timer = setTimeout(resolve, ms);
    signal.addEventListener("abort", () => {
      clearTimeout(timer);
      reject(new DOMException("aborted", "AbortError"));
    }, { once: true });
  });
}
function approvalUrl(verifyUrl, appUrl = APP_URL) {
  try {
    const page = new URL(verifyUrl);
    return `${appUrl}${page.pathname}${page.search}`;
  } catch {
    return verifyUrl;
  }
}
async function deviceDescription() {
  const platform = (await chrome.runtime.getPlatformInfo()).os;
  const brands = navigator.userAgentData?.brands ?? [];
  const browser = brands.map((b) => b.brand).find((b) => !/not.?a.?brand|chromium/i.test(b)) ?? "Chromium";
  return { name: `${browser} (${platform})`, platform, browser };
}
async function pair(serverUrl, deviceName, onCode, signal) {
  const device = await deviceDescription();
  const started = await post(`${apiV1(serverUrl)}/connectors/pair/start`, {
    kind: "browser",
    client: CLIENT,
    version: chrome.runtime.getManifest().version,
    hostname: "",
    platform: device.platform,
    name: deviceName || device.name
  }, signal);
  onCode({ code: started.code, verify_url: approvalUrl(started.verify_url), expires_at: Date.now() + started.expires_in * 1000 });
  const interval = Math.max(1, started.poll_interval) * 1000;
  const deadline = Date.now() + started.expires_in * 1000;
  while (Date.now() < deadline) {
    await sleep2(interval, signal);
    const polled = await post(`${apiV1(serverUrl)}/connectors/pair/poll`, {
      code: started.code,
      device_secret: started.device_secret
    }, signal);
    if (polled.status === "approved" && polled.api_key) {
      return { api_key: polled.api_key, api_key_name: polled.api_key_name };
    }
    if (polled.status === "expired")
      break;
  }
  throw new Error("The pairing code expired. Start the pairing again.");
}

// src/background/index.ts
var KEEPALIVE_ALARM = "ayeto-keepalive";
var status = "unpaired";
var statusError = "";
var connectionId = null;
var pairingState = null;
var pairingAbort = null;
var activity = null;
var ports = new Set;
var connection = new Connection({
  onStatus: (next, error) => {
    status = next;
    statusError = error ?? "";
    if (next !== "connected")
      connectionId = null;
    broadcast();
  },
  onHello: (payload) => {
    connectionId = payload.connection_id ?? null;
    if (payload.api_key_id)
      saveSettings({ api_key_id: payload.api_key_id }).then(broadcast);
  },
  onServerDisconnect: () => {
    saveSettings({ enabled: false }).then(broadcast);
  },
  isOperation,
  onOperation: async (frame, signal) => {
    const settings = await loadSettings();
    setBlockedDomains(settings.blocked_domains);
    try {
      return await runOperation(frame, {
        serverUrl: SERVER_URL,
        signal,
        guard: (action) => guardAction(action, settings.confirm_mode, signal, frame.confirm_reason ?? undefined),
        setActivity: (operation, tabId) => {
          activity = { operation, tab_id: tabId, started_at: Date.now() };
          broadcast();
        }
      });
    } finally {
      activity = null;
      broadcast();
    }
  }
});
async function controlledTabs() {
  const tabs = await agentTabs.controlledTabs();
  return tabs.map((t) => ({
    tab_id: t.id,
    title: t.title ?? "",
    url: t.url ?? t.pendingUrl ?? "",
    favicon: t.favIconUrl ?? "",
    attached: cdp.isAttached(t.id)
  }));
}
async function buildState() {
  const settings = await loadSettings();
  return {
    status: settings.api_key ? status : pairingState ? "pairing" : "unpaired",
    error: statusError,
    server_url: SERVER_URL,
    paired: !!settings.api_key,
    api_key_name: settings.api_key_name,
    api_key_id: settings.api_key_id,
    device_name: settings.device_name,
    connection_id: connectionId,
    pairing: pairingState,
    tabs: await controlledTabs(),
    agent_tab_id: await agentTabs.agentTabId(),
    activity,
    confirmation: confirmations.pending,
    confirm_mode: settings.confirm_mode,
    blocked_domains: settings.blocked_domains
  };
}
var broadcastTimer = null;
function broadcast() {
  if (broadcastTimer)
    return Promise.resolve();
  return new Promise((resolve) => {
    broadcastTimer = setTimeout(async () => {
      broadcastTimer = null;
      if (ports.size > 0) {
        const message = { type: "state", state: await buildState() };
        for (const port of ports) {
          try {
            port.postMessage(message);
          } catch {}
        }
      }
      resolve();
    }, 50);
  });
}
async function ensureConnection() {
  const settings = await loadSettings();
  if (!settings.api_key) {
    connection.stop();
    status = "unpaired";
    return;
  }
  if (!settings.enabled) {
    connection.stop();
    status = "disconnected";
    return;
  }
  const device = await deviceDescription();
  connection.start({
    apiKey: settings.api_key,
    serverUrl: SERVER_URL,
    hello: {
      client: "ayeto-browser",
      version: chrome.runtime.getManifest().version,
      hostname: "",
      platform: device.platform,
      name: settings.device_name || device.name,
      details: { browser: device.browser, user_agent: navigator.userAgent }
    }
  });
}
async function startPairing() {
  pairingAbort?.abort();
  const abort = new AbortController;
  pairingAbort = abort;
  statusError = "";
  const settings = await loadSettings();
  try {
    const result = await pair(SERVER_URL, settings.device_name, (state) => {
      pairingState = state;
      chrome.tabs.create({ url: state.verify_url });
      broadcast();
    }, abort.signal);
    await saveSettings({ api_key: result.api_key, api_key_name: result.api_key_name, api_key_id: null, enabled: true });
    pairingState = null;
    await ensureConnection();
  } catch (e) {
    pairingState = null;
    if (e?.name !== "AbortError") {
      status = "error";
      statusError = String(e?.message ?? e);
    }
  } finally {
    if (pairingAbort === abort)
      pairingAbort = null;
    broadcast();
  }
}
async function stopAgent() {
  connection.cancelQueued();
  activity = null;
  await cdp.detachAll();
}
async function handlePanelMessage(message) {
  switch (message.type) {
    case "get_state":
      break;
    case "set_device_name":
      await saveSettings({ device_name: message.device_name.trim().slice(0, 64) });
      break;
    case "pair":
      startPairing();
      break;
    case "cancel_pairing":
      pairingAbort?.abort();
      pairingState = null;
      break;
    case "unpair":
      connection.stop();
      await stopAgent();
      await agentTabs.releaseAll();
      await saveSettings({ api_key: null, api_key_name: "", api_key_id: null });
      status = "unpaired";
      statusError = "";
      break;
    case "connect":
      await saveSettings({ enabled: true });
      await ensureConnection();
      break;
    case "disconnect":
      await saveSettings({ enabled: false });
      await stopAgent();
      connection.stop();
      break;
    case "give_tab": {
      const settings = await loadSettings();
      try {
        await agentTabs.give(message.tab_id, SERVER_URL);
        statusError = "";
      } catch (e) {
        statusError = String(e?.message ?? e);
      }
      break;
    }
    case "release_tab":
      await agentTabs.release(message.tab_id);
      break;
    case "stop":
      await stopAgent();
      break;
    case "confirm":
      confirmations.answer(message.id, message.allow);
      break;
    case "set_confirm_mode":
      await saveSettings({ confirm_mode: message.mode });
      break;
    case "set_blocked_domains": {
      const domains = [...new Set(message.domains.map(normalizeDomain).filter(Boolean))];
      await saveSettings({ blocked_domains: domains });
      for (const tab of await agentTabs.controlledTabs()) {
        const host = normalizeDomain(tab.url ?? "");
        if (host && domains.some((d) => host === d || host.endsWith(`.${d}`)))
          await agentTabs.release(tab.id);
      }
      break;
    }
  }
  await broadcast();
}
cdp.init();
confirmations.onChange(() => void broadcast());
loadSettings().then((settings) => setBlockedDomains(settings.blocked_domains));
chrome.storage.onChanged.addListener((_, area) => {
  if (area === "local")
    loadSettings().then((settings) => setBlockedDomains(settings.blocked_domains));
});
cdp.onDetach((tabId, reason) => {
  if (reason === "canceled_by_user") {
    connection.cancelQueued();
    agentTabs.release(tabId).then(broadcast);
  } else {
    broadcast();
  }
});
chrome.runtime.onConnect.addListener((port) => {
  if (port.name !== PANEL_PORT)
    return;
  ports.add(port);
  port.onMessage.addListener((message) => void handlePanelMessage(message));
  port.onDisconnect.addListener(() => ports.delete(port));
  ensureConnection().then(broadcast);
});
chrome.runtime.onInstalled.addListener(() => {
  chrome.sidePanel.setPanelBehavior({ openPanelOnActionClick: true });
});
chrome.runtime.onStartup.addListener(() => void ensureConnection());
chrome.alarms.create(KEEPALIVE_ALARM, { periodInMinutes: 0.5 });
chrome.alarms.onAlarm.addListener((alarm) => {
  if (alarm.name === KEEPALIVE_ALARM)
    ensureConnection();
});
var refresh = () => void broadcast();
chrome.tabs.onUpdated.addListener(refresh);
chrome.tabs.onRemoved.addListener(refresh);
chrome.tabs.onActivated.addListener(refresh);
chrome.tabGroups.onUpdated.addListener(refresh);
chrome.tabGroups.onRemoved.addListener(refresh);
ensureConnection();

//# debugId=BC8CF2A616A6A25264756E2164756E21
//# sourceMappingURL=background.js.map
