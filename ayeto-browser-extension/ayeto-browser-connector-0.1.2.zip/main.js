var __create = Object.create;
var __getProtoOf = Object.getPrototypeOf;
var __defProp = Object.defineProperty;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
function __accessProp(key) {
  return this[key];
}
var __toESMCache_node;
var __toESMCache_esm;
var __toESM = (mod, isNodeMode, target) => {
  var canCache = mod != null && typeof mod === "object";
  if (canCache) {
    var cache = isNodeMode ? __toESMCache_node ??= new WeakMap : __toESMCache_esm ??= new WeakMap;
    var cached = cache.get(mod);
    if (cached)
      return cached;
  }
  target = mod != null ? __create(__getProtoOf(mod)) : {};
  const to = isNodeMode || !mod || !mod.__esModule || !__hasOwnProp.call(mod, "default") ? __defProp(target, "default", { value: mod, enumerable: true }) : target;
  if (mod && typeof mod === "object" || typeof mod === "function") {
    for (let key of __getOwnPropNames(mod))
      if (!__hasOwnProp.call(to, key))
        __defProp(to, key, {
          get: __accessProp.bind(mod, key),
          enumerable: true
        });
  }
  if (canCache)
    cache.set(mod, to);
  return to;
};
var __commonJS = (cb, mod) => () => (mod || cb((mod = { exports: {} }).exports, mod), mod.exports);
var __returnValue = (v) => v;
function __exportSetter(name, newValue) {
  this[name] = __returnValue.bind(null, newValue);
}
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, {
      get: all[name],
      enumerable: true,
      configurable: true,
      set: __exportSetter.bind(all, name)
    });
};
var __esm = (fn, res, err) => () => {
  if (fn)
    try {
      res = fn(fn = 0);
    } catch (e) {
      err = [e];
    }
  if (err)
    throw err[0];
  return res;
};
var __exportCjs = (target, getters, setters) => {
  for (var name in getters)
    __defProp(target, name, {
      get: getters[name],
      set: setters[name],
      enumerable: true,
      configurable: true
    });
};

// node_modules/react/cjs/react.production.min.js
var exports_react_production_min = {};
__exportCjs(exports_react_production_min, {
  Children: () => $Children,
  Component: () => $Component,
  Fragment: () => $Fragment,
  Profiler: () => $Profiler,
  PureComponent: () => $PureComponent,
  StrictMode: () => $StrictMode,
  Suspense: () => $Suspense,
  __SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED: () => $__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED,
  act: () => $act,
  cloneElement: () => $cloneElement,
  createContext: () => $createContext,
  createElement: () => $createElement,
  createFactory: () => $createFactory,
  createRef: () => $createRef,
  forwardRef: () => $forwardRef,
  isValidElement: () => $isValidElement,
  lazy: () => $lazy,
  memo: () => $memo,
  startTransition: () => $startTransition,
  unstable_act: () => $unstable_act,
  useCallback: () => $useCallback,
  useContext: () => $useContext,
  useDebugValue: () => $useDebugValue,
  useDeferredValue: () => $useDeferredValue,
  useEffect: () => $useEffect,
  useId: () => $useId,
  useImperativeHandle: () => $useImperativeHandle,
  useInsertionEffect: () => $useInsertionEffect,
  useLayoutEffect: () => $useLayoutEffect,
  useMemo: () => $useMemo,
  useReducer: () => $useReducer,
  useRef: () => $useRef,
  useState: () => $useState,
  useSyncExternalStore: () => $useSyncExternalStore,
  useTransition: () => $useTransition,
  version: () => $version
}, {
  Children: (value) => $Children = value,
  Component: (value) => $Component = value,
  Fragment: (value) => $Fragment = value,
  Profiler: (value) => $Profiler = value,
  PureComponent: (value) => $PureComponent = value,
  StrictMode: (value) => $StrictMode = value,
  Suspense: (value) => $Suspense = value,
  __SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED: (value) => $__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED = value,
  act: (value) => $act = value,
  cloneElement: (value) => $cloneElement = value,
  createContext: (value) => $createContext = value,
  createElement: (value) => $createElement = value,
  createFactory: (value) => $createFactory = value,
  createRef: (value) => $createRef = value,
  forwardRef: (value) => $forwardRef = value,
  isValidElement: (value) => $isValidElement = value,
  lazy: (value) => $lazy = value,
  memo: (value) => $memo = value,
  startTransition: (value) => $startTransition = value,
  unstable_act: (value) => $unstable_act = value,
  useCallback: (value) => $useCallback = value,
  useContext: (value) => $useContext = value,
  useDebugValue: (value) => $useDebugValue = value,
  useDeferredValue: (value) => $useDeferredValue = value,
  useEffect: (value) => $useEffect = value,
  useId: (value) => $useId = value,
  useImperativeHandle: (value) => $useImperativeHandle = value,
  useInsertionEffect: (value) => $useInsertionEffect = value,
  useLayoutEffect: (value) => $useLayoutEffect = value,
  useMemo: (value) => $useMemo = value,
  useReducer: (value) => $useReducer = value,
  useRef: (value) => $useRef = value,
  useState: (value) => $useState = value,
  useSyncExternalStore: (value) => $useSyncExternalStore = value,
  useTransition: (value) => $useTransition = value,
  version: (value) => $version = value
});
function A(a) {
  if (a === null || typeof a !== "object")
    return null;
  a = z && a[z] || a["@@iterator"];
  return typeof a === "function" ? a : null;
}
function E(a, b, e) {
  this.props = a;
  this.context = b;
  this.refs = D;
  this.updater = e || B;
}
function F() {}
function G(a, b, e) {
  this.props = a;
  this.context = b;
  this.refs = D;
  this.updater = e || B;
}
function M(a, b, e) {
  var d, c = {}, k = null, h = null;
  if (b != null)
    for (d in b.ref !== undefined && (h = b.ref), b.key !== undefined && (k = "" + b.key), b)
      J.call(b, d) && !L.hasOwnProperty(d) && (c[d] = b[d]);
  var g = arguments.length - 2;
  if (g === 1)
    c.children = e;
  else if (1 < g) {
    for (var f = Array(g), m = 0;m < g; m++)
      f[m] = arguments[m + 2];
    c.children = f;
  }
  if (a && a.defaultProps)
    for (d in g = a.defaultProps, g)
      c[d] === undefined && (c[d] = g[d]);
  return { $$typeof: l, type: a, key: k, ref: h, props: c, _owner: K.current };
}
function N(a, b) {
  return { $$typeof: l, type: a.type, key: b, ref: a.ref, props: a.props, _owner: a._owner };
}
function O(a) {
  return typeof a === "object" && a !== null && a.$$typeof === l;
}
function escape(a) {
  var b = { "=": "=0", ":": "=2" };
  return "$" + a.replace(/[=:]/g, function(a) {
    return b[a];
  });
}
function Q(a, b) {
  return typeof a === "object" && a !== null && a.key != null ? escape("" + a.key) : b.toString(36);
}
function R(a, b, e, d, c) {
  var k = typeof a;
  if (k === "undefined" || k === "boolean")
    a = null;
  var h = false;
  if (a === null)
    h = true;
  else
    switch (k) {
      case "string":
      case "number":
        h = true;
        break;
      case "object":
        switch (a.$$typeof) {
          case l:
          case n:
            h = true;
        }
    }
  if (h)
    return h = a, c = c(h), a = d === "" ? "." + Q(h, 0) : d, I(c) ? (e = "", a != null && (e = a.replace(P, "$&/") + "/"), R(c, b, e, "", function(a) {
      return a;
    })) : c != null && (O(c) && (c = N(c, e + (!c.key || h && h.key === c.key ? "" : ("" + c.key).replace(P, "$&/") + "/") + a)), b.push(c)), 1;
  h = 0;
  d = d === "" ? "." : d + ":";
  if (I(a))
    for (var g = 0;g < a.length; g++) {
      k = a[g];
      var f = d + Q(k, g);
      h += R(k, b, e, f, c);
    }
  else if (f = A(a), typeof f === "function")
    for (a = f.call(a), g = 0;!(k = a.next()).done; )
      k = k.value, f = d + Q(k, g++), h += R(k, b, e, f, c);
  else if (k === "object")
    throw b = String(a), Error("Objects are not valid as a React child (found: " + (b === "[object Object]" ? "object with keys {" + Object.keys(a).join(", ") + "}" : b) + "). If you meant to render a collection of children, use an array instead.");
  return h;
}
function S(a, b, e) {
  if (a == null)
    return a;
  var d = [], c = 0;
  R(a, d, "", "", function(a) {
    return b.call(e, a, c++);
  });
  return d;
}
function T(a) {
  if (a._status === -1) {
    var b = a._result;
    b = b();
    b.then(function(b) {
      if (a._status === 0 || a._status === -1)
        a._status = 1, a._result = b;
    }, function(b) {
      if (a._status === 0 || a._status === -1)
        a._status = 2, a._result = b;
    });
    a._status === -1 && (a._status = 0, a._result = b);
  }
  if (a._status === 1)
    return a._result.default;
  throw a._result;
}
function X() {
  throw Error("act(...) is not supported in production builds of React.");
}
var l, n, p, q, r, t, u, v, w, x, y, z, B, C, D, H, I, J, K, L, P, U, V, W, $Children, $Component, $Fragment, $Profiler, $PureComponent, $StrictMode, $Suspense, $__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED, $act, $cloneElement = function(a, b, e) {
  if (a === null || a === undefined)
    throw Error("React.cloneElement(...): The argument must be a React element, but you passed " + a + ".");
  var d = C({}, a.props), { key: c, ref: k, _owner: h } = a;
  if (b != null) {
    b.ref !== undefined && (k = b.ref, h = K.current);
    b.key !== undefined && (c = "" + b.key);
    if (a.type && a.type.defaultProps)
      var g = a.type.defaultProps;
    for (f in b)
      J.call(b, f) && !L.hasOwnProperty(f) && (d[f] = b[f] === undefined && g !== undefined ? g[f] : b[f]);
  }
  var f = arguments.length - 2;
  if (f === 1)
    d.children = e;
  else if (1 < f) {
    g = Array(f);
    for (var m = 0;m < f; m++)
      g[m] = arguments[m + 2];
    d.children = g;
  }
  return { $$typeof: l, type: a.type, key: c, ref: k, props: d, _owner: h };
}, $createContext = function(a) {
  a = { $$typeof: u, _currentValue: a, _currentValue2: a, _threadCount: 0, Provider: null, Consumer: null, _defaultValue: null, _globalName: null };
  a.Provider = { $$typeof: t, _context: a };
  return a.Consumer = a;
}, $createElement, $createFactory = function(a) {
  var b = M.bind(null, a);
  b.type = a;
  return b;
}, $createRef = function() {
  return { current: null };
}, $forwardRef = function(a) {
  return { $$typeof: v, render: a };
}, $isValidElement, $lazy = function(a) {
  return { $$typeof: y, _payload: { _status: -1, _result: a }, _init: T };
}, $memo = function(a, b) {
  return { $$typeof: x, type: a, compare: b === undefined ? null : b };
}, $startTransition = function(a) {
  var b = V.transition;
  V.transition = {};
  try {
    a();
  } finally {
    V.transition = b;
  }
}, $unstable_act, $useCallback = function(a, b) {
  return U.current.useCallback(a, b);
}, $useContext = function(a) {
  return U.current.useContext(a);
}, $useDebugValue = function() {}, $useDeferredValue = function(a) {
  return U.current.useDeferredValue(a);
}, $useEffect = function(a, b) {
  return U.current.useEffect(a, b);
}, $useId = function() {
  return U.current.useId();
}, $useImperativeHandle = function(a, b, e) {
  return U.current.useImperativeHandle(a, b, e);
}, $useInsertionEffect = function(a, b) {
  return U.current.useInsertionEffect(a, b);
}, $useLayoutEffect = function(a, b) {
  return U.current.useLayoutEffect(a, b);
}, $useMemo = function(a, b) {
  return U.current.useMemo(a, b);
}, $useReducer = function(a, b, e) {
  return U.current.useReducer(a, b, e);
}, $useRef = function(a) {
  return U.current.useRef(a);
}, $useState = function(a) {
  return U.current.useState(a);
}, $useSyncExternalStore = function(a, b, e) {
  return U.current.useSyncExternalStore(a, b, e);
}, $useTransition = function() {
  return U.current.useTransition();
}, $version = "18.3.1";
var init_react_production_min = __esm(() => {
  l = Symbol.for("react.element");
  n = Symbol.for("react.portal");
  p = Symbol.for("react.fragment");
  q = Symbol.for("react.strict_mode");
  r = Symbol.for("react.profiler");
  t = Symbol.for("react.provider");
  u = Symbol.for("react.context");
  v = Symbol.for("react.forward_ref");
  w = Symbol.for("react.suspense");
  x = Symbol.for("react.memo");
  y = Symbol.for("react.lazy");
  z = Symbol.iterator;
  B = { isMounted: function() {
    return false;
  }, enqueueForceUpdate: function() {}, enqueueReplaceState: function() {}, enqueueSetState: function() {} };
  C = Object.assign;
  D = {};
  E.prototype.isReactComponent = {};
  E.prototype.setState = function(a, b) {
    if (typeof a !== "object" && typeof a !== "function" && a != null)
      throw Error("setState(...): takes an object of state variables to update or a function which returns an object of state variables.");
    this.updater.enqueueSetState(this, a, b, "setState");
  };
  E.prototype.forceUpdate = function(a) {
    this.updater.enqueueForceUpdate(this, a, "forceUpdate");
  };
  F.prototype = E.prototype;
  H = G.prototype = new F;
  H.constructor = G;
  C(H, E.prototype);
  H.isPureReactComponent = true;
  I = Array.isArray;
  J = Object.prototype.hasOwnProperty;
  K = { current: null };
  L = { key: true, ref: true, __self: true, __source: true };
  P = /\/+/g;
  U = { current: null };
  V = { transition: null };
  W = { ReactCurrentDispatcher: U, ReactCurrentBatchConfig: V, ReactCurrentOwner: K };
  $Children = { map: S, forEach: function(a, b, e) {
    S(a, function() {
      b.apply(this, arguments);
    }, e);
  }, count: function(a) {
    var b = 0;
    S(a, function() {
      b++;
    });
    return b;
  }, toArray: function(a) {
    return S(a, function(a) {
      return a;
    }) || [];
  }, only: function(a) {
    if (!O(a))
      throw Error("React.Children.only expected to receive a single React element child.");
    return a;
  } };
  $Component = E;
  $Fragment = p;
  $Profiler = r;
  $PureComponent = G;
  $StrictMode = q;
  $Suspense = w;
  $__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED = W;
  $act = X;
  $createElement = M;
  $isValidElement = O;
  $unstable_act = X;
});

// node_modules/react/index.js
var require_react = __commonJS(function(exports, module) {
  init_react_production_min();
  if (true) {
    module.exports = exports_react_production_min;
  }
});

// node_modules/scheduler/cjs/scheduler.production.min.js
var require_scheduler_production_min = __commonJS(function(exports) {
  function f(a, b) {
    var c = a.length;
    a.push(b);
    a:
      for (;0 < c; ) {
        var d = c - 1 >>> 1, e = a[d];
        if (0 < g(e, b))
          a[d] = b, a[c] = e, c = d;
        else
          break a;
      }
  }
  function h(a) {
    return a.length === 0 ? null : a[0];
  }
  function k(a) {
    if (a.length === 0)
      return null;
    var b = a[0], c = a.pop();
    if (c !== b) {
      a[0] = c;
      a:
        for (var d = 0, e = a.length, w = e >>> 1;d < w; ) {
          var m = 2 * (d + 1) - 1, C = a[m], n = m + 1, x = a[n];
          if (0 > g(C, c))
            n < e && 0 > g(x, C) ? (a[d] = x, a[n] = c, d = n) : (a[d] = C, a[m] = c, d = m);
          else if (n < e && 0 > g(x, c))
            a[d] = x, a[n] = c, d = n;
          else
            break a;
        }
    }
    return b;
  }
  function g(a, b) {
    var c = a.sortIndex - b.sortIndex;
    return c !== 0 ? c : a.id - b.id;
  }
  if (typeof performance === "object" && typeof performance.now === "function") {
    l = performance;
    exports.unstable_now = function() {
      return l.now();
    };
  } else {
    p = Date, q = p.now();
    exports.unstable_now = function() {
      return p.now() - q;
    };
  }
  var l;
  var p;
  var q;
  var r = [];
  var t = [];
  var u = 1;
  var v = null;
  var y = 3;
  var z = false;
  var A = false;
  var B = false;
  var D = typeof setTimeout === "function" ? setTimeout : null;
  var E = typeof clearTimeout === "function" ? clearTimeout : null;
  var F = typeof setImmediate !== "undefined" ? setImmediate : null;
  typeof navigator !== "undefined" && navigator.scheduling !== undefined && navigator.scheduling.isInputPending !== undefined && navigator.scheduling.isInputPending.bind(navigator.scheduling);
  function G(a) {
    for (var b = h(t);b !== null; ) {
      if (b.callback === null)
        k(t);
      else if (b.startTime <= a)
        k(t), b.sortIndex = b.expirationTime, f(r, b);
      else
        break;
      b = h(t);
    }
  }
  function H(a) {
    B = false;
    G(a);
    if (!A)
      if (h(r) !== null)
        A = true, I(J);
      else {
        var b = h(t);
        b !== null && K(H, b.startTime - a);
      }
  }
  function J(a, b) {
    A = false;
    B && (B = false, E(L), L = -1);
    z = true;
    var c = y;
    try {
      G(b);
      for (v = h(r);v !== null && (!(v.expirationTime > b) || a && !M()); ) {
        var d = v.callback;
        if (typeof d === "function") {
          v.callback = null;
          y = v.priorityLevel;
          var e = d(v.expirationTime <= b);
          b = exports.unstable_now();
          typeof e === "function" ? v.callback = e : v === h(r) && k(r);
          G(b);
        } else
          k(r);
        v = h(r);
      }
      if (v !== null)
        var w = true;
      else {
        var m = h(t);
        m !== null && K(H, m.startTime - b);
        w = false;
      }
      return w;
    } finally {
      v = null, y = c, z = false;
    }
  }
  var N = false;
  var O = null;
  var L = -1;
  var P = 5;
  var Q = -1;
  function M() {
    return exports.unstable_now() - Q < P ? false : true;
  }
  function R() {
    if (O !== null) {
      var a = exports.unstable_now();
      Q = a;
      var b = true;
      try {
        b = O(true, a);
      } finally {
        b ? S() : (N = false, O = null);
      }
    } else
      N = false;
  }
  var S;
  if (typeof F === "function")
    S = function() {
      F(R);
    };
  else if (typeof MessageChannel !== "undefined") {
    T = new MessageChannel, U = T.port2;
    T.port1.onmessage = R;
    S = function() {
      U.postMessage(null);
    };
  } else
    S = function() {
      D(R, 0);
    };
  var T;
  var U;
  function I(a) {
    O = a;
    N || (N = true, S());
  }
  function K(a, b) {
    L = D(function() {
      a(exports.unstable_now());
    }, b);
  }
  exports.unstable_IdlePriority = 5;
  exports.unstable_ImmediatePriority = 1;
  exports.unstable_LowPriority = 4;
  exports.unstable_NormalPriority = 3;
  exports.unstable_Profiling = null;
  exports.unstable_UserBlockingPriority = 2;
  exports.unstable_cancelCallback = function(a) {
    a.callback = null;
  };
  exports.unstable_continueExecution = function() {
    A || z || (A = true, I(J));
  };
  exports.unstable_forceFrameRate = function(a) {
    0 > a || 125 < a ? console.error("forceFrameRate takes a positive int between 0 and 125, forcing frame rates higher than 125 fps is not supported") : P = 0 < a ? Math.floor(1000 / a) : 5;
  };
  exports.unstable_getCurrentPriorityLevel = function() {
    return y;
  };
  exports.unstable_getFirstCallbackNode = function() {
    return h(r);
  };
  exports.unstable_next = function(a) {
    switch (y) {
      case 1:
      case 2:
      case 3:
        var b = 3;
        break;
      default:
        b = y;
    }
    var c = y;
    y = b;
    try {
      return a();
    } finally {
      y = c;
    }
  };
  exports.unstable_pauseExecution = function() {};
  exports.unstable_requestPaint = function() {};
  exports.unstable_runWithPriority = function(a, b) {
    switch (a) {
      case 1:
      case 2:
      case 3:
      case 4:
      case 5:
        break;
      default:
        a = 3;
    }
    var c = y;
    y = a;
    try {
      return b();
    } finally {
      y = c;
    }
  };
  exports.unstable_scheduleCallback = function(a, b, c) {
    var d = exports.unstable_now();
    typeof c === "object" && c !== null ? (c = c.delay, c = typeof c === "number" && 0 < c ? d + c : d) : c = d;
    switch (a) {
      case 1:
        var e = -1;
        break;
      case 2:
        e = 250;
        break;
      case 5:
        e = 1073741823;
        break;
      case 4:
        e = 1e4;
        break;
      default:
        e = 5000;
    }
    e = c + e;
    a = { id: u++, callback: b, priorityLevel: a, startTime: c, expirationTime: e, sortIndex: -1 };
    c > d ? (a.sortIndex = c, f(t, a), h(r) === null && a === h(t) && (B ? (E(L), L = -1) : B = true, K(H, c - d))) : (a.sortIndex = e, f(r, a), A || z || (A = true, I(J)));
    return a;
  };
  exports.unstable_shouldYield = M;
  exports.unstable_wrapCallback = function(a) {
    var b = y;
    return function() {
      var c = y;
      y = b;
      try {
        return a.apply(this, arguments);
      } finally {
        y = c;
      }
    };
  };
});

// node_modules/scheduler/index.js
var require_scheduler = __commonJS(function(exports, module) {
  var scheduler_production_min = __toESM(require_scheduler_production_min());
  if (true) {
    module.exports = scheduler_production_min;
  }
});

// node_modules/react-dom/cjs/react-dom.production.min.js
var exports_react_dom_production_min = {};
__exportCjs(exports_react_dom_production_min, {
  __SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED: () => $__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED2,
  createPortal: () => $createPortal,
  createRoot: () => $createRoot,
  findDOMNode: () => $findDOMNode,
  flushSync: () => $flushSync,
  hydrate: () => $hydrate,
  hydrateRoot: () => $hydrateRoot,
  render: () => $render,
  unmountComponentAtNode: () => $unmountComponentAtNode,
  unstable_batchedUpdates: () => $unstable_batchedUpdates,
  unstable_renderSubtreeIntoContainer: () => $unstable_renderSubtreeIntoContainer,
  version: () => $version2
}, {
  __SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED: (value2) => $__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED2 = value2,
  createPortal: (value2) => $createPortal = value2,
  createRoot: (value2) => $createRoot = value2,
  findDOMNode: (value2) => $findDOMNode = value2,
  flushSync: (value2) => $flushSync = value2,
  hydrate: (value2) => $hydrate = value2,
  hydrateRoot: (value2) => $hydrateRoot = value2,
  render: (value2) => $render = value2,
  unmountComponentAtNode: (value2) => $unmountComponentAtNode = value2,
  unstable_batchedUpdates: (value2) => $unstable_batchedUpdates = value2,
  unstable_renderSubtreeIntoContainer: (value2) => $unstable_renderSubtreeIntoContainer = value2,
  version: (value2) => $version2 = value2
});
function p2(a) {
  for (var b = "https://reactjs.org/docs/error-decoder.html?invariant=" + a, c = 1;c < arguments.length; c++)
    b += "&args[]=" + encodeURIComponent(arguments[c]);
  return "Minified React error #" + a + "; visit " + b + " for the full message or use the non-minified dev environment for full errors and additional helpful warnings.";
}
function fa(a, b) {
  ha(a, b);
  ha(a + "Capture", b);
}
function ha(a, b) {
  ea[a] = b;
  for (a = 0;a < b.length; a++)
    da.add(b[a]);
}
function oa(a) {
  if (ja.call(ma, a))
    return true;
  if (ja.call(la, a))
    return false;
  if (ka.test(a))
    return ma[a] = true;
  la[a] = true;
  return false;
}
function pa(a, b, c, d) {
  if (c !== null && c.type === 0)
    return false;
  switch (typeof b) {
    case "function":
    case "symbol":
      return true;
    case "boolean":
      if (d)
        return false;
      if (c !== null)
        return !c.acceptsBooleans;
      a = a.toLowerCase().slice(0, 5);
      return a !== "data-" && a !== "aria-";
    default:
      return false;
  }
}
function qa(a, b, c, d) {
  if (b === null || typeof b === "undefined" || pa(a, b, c, d))
    return true;
  if (d)
    return false;
  if (c !== null)
    switch (c.type) {
      case 3:
        return !b;
      case 4:
        return b === false;
      case 5:
        return isNaN(b);
      case 6:
        return isNaN(b) || 1 > b;
    }
  return false;
}
function v2(a, b, c, d, e, f, g) {
  this.acceptsBooleans = b === 2 || b === 3 || b === 4;
  this.attributeName = d;
  this.attributeNamespace = e;
  this.mustUseProperty = c;
  this.propertyName = a;
  this.type = b;
  this.sanitizeURL = f;
  this.removeEmptyString = g;
}
function sa(a) {
  return a[1].toUpperCase();
}
function ta(a, b, c, d) {
  var e = z2.hasOwnProperty(b) ? z2[b] : null;
  if (e !== null ? e.type !== 0 : d || !(2 < b.length) || b[0] !== "o" && b[0] !== "O" || b[1] !== "n" && b[1] !== "N")
    qa(b, c, e, d) && (c = null), d || e === null ? oa(b) && (c === null ? a.removeAttribute(b) : a.setAttribute(b, "" + c)) : e.mustUseProperty ? a[e.propertyName] = c === null ? e.type === 3 ? false : "" : c : (b = e.attributeName, d = e.attributeNamespace, c === null ? a.removeAttribute(b) : (e = e.type, c = e === 3 || e === 4 && c === true ? "" : "" + c, d ? a.setAttributeNS(d, b, c) : a.setAttribute(b, c)));
}
function Ka(a) {
  if (a === null || typeof a !== "object")
    return null;
  a = Ja && a[Ja] || a["@@iterator"];
  return typeof a === "function" ? a : null;
}
function Ma(a) {
  if (La === undefined)
    try {
      throw Error();
    } catch (c) {
      var b = c.stack.trim().match(/\n( *(at )?)/);
      La = b && b[1] || "";
    }
  return `
` + La + a;
}
function Oa(a, b) {
  if (!a || Na)
    return "";
  Na = true;
  var c = Error.prepareStackTrace;
  Error.prepareStackTrace = undefined;
  try {
    if (b)
      if (b = function() {
        throw Error();
      }, Object.defineProperty(b.prototype, "props", { set: function() {
        throw Error();
      } }), typeof Reflect === "object" && Reflect.construct) {
        try {
          Reflect.construct(b, []);
        } catch (l) {
          var d = l;
        }
        Reflect.construct(a, [], b);
      } else {
        try {
          b.call();
        } catch (l) {
          d = l;
        }
        a.call(b.prototype);
      }
    else {
      try {
        throw Error();
      } catch (l) {
        d = l;
      }
      a();
    }
  } catch (l) {
    if (l && d && typeof l.stack === "string") {
      for (var e = l.stack.split(`
`), f = d.stack.split(`
`), g = e.length - 1, h = f.length - 1;1 <= g && 0 <= h && e[g] !== f[h]; )
        h--;
      for (;1 <= g && 0 <= h; g--, h--)
        if (e[g] !== f[h]) {
          if (g !== 1 || h !== 1) {
            do
              if (g--, h--, 0 > h || e[g] !== f[h]) {
                var k = `
` + e[g].replace(" at new ", " at ");
                a.displayName && k.includes("<anonymous>") && (k = k.replace("<anonymous>", a.displayName));
                return k;
              }
            while (1 <= g && 0 <= h);
          }
          break;
        }
    }
  } finally {
    Na = false, Error.prepareStackTrace = c;
  }
  return (a = a ? a.displayName || a.name : "") ? Ma(a) : "";
}
function Pa(a) {
  switch (a.tag) {
    case 5:
      return Ma(a.type);
    case 16:
      return Ma("Lazy");
    case 13:
      return Ma("Suspense");
    case 19:
      return Ma("SuspenseList");
    case 0:
    case 2:
    case 15:
      return a = Oa(a.type, false), a;
    case 11:
      return a = Oa(a.type.render, false), a;
    case 1:
      return a = Oa(a.type, true), a;
    default:
      return "";
  }
}
function Qa(a) {
  if (a == null)
    return null;
  if (typeof a === "function")
    return a.displayName || a.name || null;
  if (typeof a === "string")
    return a;
  switch (a) {
    case ya:
      return "Fragment";
    case wa:
      return "Portal";
    case Aa:
      return "Profiler";
    case za:
      return "StrictMode";
    case Ea:
      return "Suspense";
    case Fa:
      return "SuspenseList";
  }
  if (typeof a === "object")
    switch (a.$$typeof) {
      case Ca:
        return (a.displayName || "Context") + ".Consumer";
      case Ba:
        return (a._context.displayName || "Context") + ".Provider";
      case Da:
        var b = a.render;
        a = a.displayName;
        a || (a = b.displayName || b.name || "", a = a !== "" ? "ForwardRef(" + a + ")" : "ForwardRef");
        return a;
      case Ga:
        return b = a.displayName || null, b !== null ? b : Qa(a.type) || "Memo";
      case Ha:
        b = a._payload;
        a = a._init;
        try {
          return Qa(a(b));
        } catch (c) {}
    }
  return null;
}
function Ra(a) {
  var b = a.type;
  switch (a.tag) {
    case 24:
      return "Cache";
    case 9:
      return (b.displayName || "Context") + ".Consumer";
    case 10:
      return (b._context.displayName || "Context") + ".Provider";
    case 18:
      return "DehydratedFragment";
    case 11:
      return a = b.render, a = a.displayName || a.name || "", b.displayName || (a !== "" ? "ForwardRef(" + a + ")" : "ForwardRef");
    case 7:
      return "Fragment";
    case 5:
      return b;
    case 4:
      return "Portal";
    case 3:
      return "Root";
    case 6:
      return "Text";
    case 16:
      return Qa(b);
    case 8:
      return b === za ? "StrictMode" : "Mode";
    case 22:
      return "Offscreen";
    case 12:
      return "Profiler";
    case 21:
      return "Scope";
    case 13:
      return "Suspense";
    case 19:
      return "SuspenseList";
    case 25:
      return "TracingMarker";
    case 1:
    case 0:
    case 17:
    case 2:
    case 14:
    case 15:
      if (typeof b === "function")
        return b.displayName || b.name || null;
      if (typeof b === "string")
        return b;
  }
  return null;
}
function Sa(a) {
  switch (typeof a) {
    case "boolean":
    case "number":
    case "string":
    case "undefined":
      return a;
    case "object":
      return a;
    default:
      return "";
  }
}
function Ta(a) {
  var b = a.type;
  return (a = a.nodeName) && a.toLowerCase() === "input" && (b === "checkbox" || b === "radio");
}
function Ua(a) {
  var b = Ta(a) ? "checked" : "value", c = Object.getOwnPropertyDescriptor(a.constructor.prototype, b), d = "" + a[b];
  if (!a.hasOwnProperty(b) && typeof c !== "undefined" && typeof c.get === "function" && typeof c.set === "function") {
    var { get: e, set: f } = c;
    Object.defineProperty(a, b, { configurable: true, get: function() {
      return e.call(this);
    }, set: function(a) {
      d = "" + a;
      f.call(this, a);
    } });
    Object.defineProperty(a, b, { enumerable: c.enumerable });
    return { getValue: function() {
      return d;
    }, setValue: function(a) {
      d = "" + a;
    }, stopTracking: function() {
      a._valueTracker = null;
      delete a[b];
    } };
  }
}
function Va(a) {
  a._valueTracker || (a._valueTracker = Ua(a));
}
function Wa(a) {
  if (!a)
    return false;
  var b = a._valueTracker;
  if (!b)
    return true;
  var c = b.getValue();
  var d = "";
  a && (d = Ta(a) ? a.checked ? "true" : "false" : a.value);
  a = d;
  return a !== c ? (b.setValue(a), true) : false;
}
function Xa(a) {
  a = a || (typeof document !== "undefined" ? document : undefined);
  if (typeof a === "undefined")
    return null;
  try {
    return a.activeElement || a.body;
  } catch (b) {
    return a.body;
  }
}
function Ya(a, b) {
  var c = b.checked;
  return A2({}, b, { defaultChecked: undefined, defaultValue: undefined, value: undefined, checked: c != null ? c : a._wrapperState.initialChecked });
}
function Za(a, b) {
  var c = b.defaultValue == null ? "" : b.defaultValue, d = b.checked != null ? b.checked : b.defaultChecked;
  c = Sa(b.value != null ? b.value : c);
  a._wrapperState = { initialChecked: d, initialValue: c, controlled: b.type === "checkbox" || b.type === "radio" ? b.checked != null : b.value != null };
}
function ab(a, b) {
  b = b.checked;
  b != null && ta(a, "checked", b, false);
}
function bb(a, b) {
  ab(a, b);
  var c = Sa(b.value), d = b.type;
  if (c != null)
    if (d === "number") {
      if (c === 0 && a.value === "" || a.value != c)
        a.value = "" + c;
    } else
      a.value !== "" + c && (a.value = "" + c);
  else if (d === "submit" || d === "reset") {
    a.removeAttribute("value");
    return;
  }
  b.hasOwnProperty("value") ? cb(a, b.type, c) : b.hasOwnProperty("defaultValue") && cb(a, b.type, Sa(b.defaultValue));
  b.checked == null && b.defaultChecked != null && (a.defaultChecked = !!b.defaultChecked);
}
function db(a, b, c) {
  if (b.hasOwnProperty("value") || b.hasOwnProperty("defaultValue")) {
    var d = b.type;
    if (!(d !== "submit" && d !== "reset" || b.value !== undefined && b.value !== null))
      return;
    b = "" + a._wrapperState.initialValue;
    c || b === a.value || (a.value = b);
    a.defaultValue = b;
  }
  c = a.name;
  c !== "" && (a.name = "");
  a.defaultChecked = !!a._wrapperState.initialChecked;
  c !== "" && (a.name = c);
}
function cb(a, b, c) {
  if (b !== "number" || Xa(a.ownerDocument) !== a)
    c == null ? a.defaultValue = "" + a._wrapperState.initialValue : a.defaultValue !== "" + c && (a.defaultValue = "" + c);
}
function fb(a, b, c, d) {
  a = a.options;
  if (b) {
    b = {};
    for (var e = 0;e < c.length; e++)
      b["$" + c[e]] = true;
    for (c = 0;c < a.length; c++)
      e = b.hasOwnProperty("$" + a[c].value), a[c].selected !== e && (a[c].selected = e), e && d && (a[c].defaultSelected = true);
  } else {
    c = "" + Sa(c);
    b = null;
    for (e = 0;e < a.length; e++) {
      if (a[e].value === c) {
        a[e].selected = true;
        d && (a[e].defaultSelected = true);
        return;
      }
      b !== null || a[e].disabled || (b = a[e]);
    }
    b !== null && (b.selected = true);
  }
}
function gb(a, b) {
  if (b.dangerouslySetInnerHTML != null)
    throw Error(p2(91));
  return A2({}, b, { value: undefined, defaultValue: undefined, children: "" + a._wrapperState.initialValue });
}
function hb(a, b) {
  var c = b.value;
  if (c == null) {
    c = b.children;
    b = b.defaultValue;
    if (c != null) {
      if (b != null)
        throw Error(p2(92));
      if (eb(c)) {
        if (1 < c.length)
          throw Error(p2(93));
        c = c[0];
      }
      b = c;
    }
    b == null && (b = "");
    c = b;
  }
  a._wrapperState = { initialValue: Sa(c) };
}
function ib(a, b) {
  var c = Sa(b.value), d = Sa(b.defaultValue);
  c != null && (c = "" + c, c !== a.value && (a.value = c), b.defaultValue == null && a.defaultValue !== c && (a.defaultValue = c));
  d != null && (a.defaultValue = "" + d);
}
function jb(a) {
  var b = a.textContent;
  b === a._wrapperState.initialValue && b !== "" && b !== null && (a.value = b);
}
function kb(a) {
  switch (a) {
    case "svg":
      return "http://www.w3.org/2000/svg";
    case "math":
      return "http://www.w3.org/1998/Math/MathML";
    default:
      return "http://www.w3.org/1999/xhtml";
  }
}
function lb(a, b) {
  return a == null || a === "http://www.w3.org/1999/xhtml" ? kb(b) : a === "http://www.w3.org/2000/svg" && b === "foreignObject" ? "http://www.w3.org/1999/xhtml" : a;
}
function ob(a, b) {
  if (b) {
    var c = a.firstChild;
    if (c && c === a.lastChild && c.nodeType === 3) {
      c.nodeValue = b;
      return;
    }
  }
  a.textContent = b;
}
function rb(a, b, c) {
  return b == null || typeof b === "boolean" || b === "" ? "" : c || typeof b !== "number" || b === 0 || pb.hasOwnProperty(a) && pb[a] ? ("" + b).trim() : b + "px";
}
function sb(a, b) {
  a = a.style;
  for (var c in b)
    if (b.hasOwnProperty(c)) {
      var d = c.indexOf("--") === 0, e = rb(c, b[c], d);
      c === "float" && (c = "cssFloat");
      d ? a.setProperty(c, e) : a[c] = e;
    }
}
function ub(a, b) {
  if (b) {
    if (tb[a] && (b.children != null || b.dangerouslySetInnerHTML != null))
      throw Error(p2(137, a));
    if (b.dangerouslySetInnerHTML != null) {
      if (b.children != null)
        throw Error(p2(60));
      if (typeof b.dangerouslySetInnerHTML !== "object" || !("__html" in b.dangerouslySetInnerHTML))
        throw Error(p2(61));
    }
    if (b.style != null && typeof b.style !== "object")
      throw Error(p2(62));
  }
}
function vb(a, b) {
  if (a.indexOf("-") === -1)
    return typeof b.is === "string";
  switch (a) {
    case "annotation-xml":
    case "color-profile":
    case "font-face":
    case "font-face-src":
    case "font-face-uri":
    case "font-face-format":
    case "font-face-name":
    case "missing-glyph":
      return false;
    default:
      return true;
  }
}
function xb(a) {
  a = a.target || a.srcElement || window;
  a.correspondingUseElement && (a = a.correspondingUseElement);
  return a.nodeType === 3 ? a.parentNode : a;
}
function Bb(a) {
  if (a = Cb(a)) {
    if (typeof yb !== "function")
      throw Error(p2(280));
    var b = a.stateNode;
    b && (b = Db(b), yb(a.stateNode, a.type, b));
  }
}
function Eb(a) {
  zb ? Ab ? Ab.push(a) : Ab = [a] : zb = a;
}
function Fb() {
  if (zb) {
    var a = zb, b = Ab;
    Ab = zb = null;
    Bb(a);
    if (b)
      for (a = 0;a < b.length; a++)
        Bb(b[a]);
  }
}
function Gb(a, b) {
  return a(b);
}
function Hb() {}
function Jb(a, b, c) {
  if (Ib)
    return a(b, c);
  Ib = true;
  try {
    return Gb(a, b, c);
  } finally {
    if (Ib = false, zb !== null || Ab !== null)
      Hb(), Fb();
  }
}
function Kb(a, b) {
  var c = a.stateNode;
  if (c === null)
    return null;
  var d = Db(c);
  if (d === null)
    return null;
  c = d[b];
  a:
    switch (b) {
      case "onClick":
      case "onClickCapture":
      case "onDoubleClick":
      case "onDoubleClickCapture":
      case "onMouseDown":
      case "onMouseDownCapture":
      case "onMouseMove":
      case "onMouseMoveCapture":
      case "onMouseUp":
      case "onMouseUpCapture":
      case "onMouseEnter":
        (d = !d.disabled) || (a = a.type, d = !(a === "button" || a === "input" || a === "select" || a === "textarea"));
        a = !d;
        break a;
      default:
        a = false;
    }
  if (a)
    return null;
  if (c && typeof c !== "function")
    throw Error(p2(231, b, typeof c));
  return c;
}
function Nb(a, b, c, d, e, f, g, h, k) {
  var l = Array.prototype.slice.call(arguments, 3);
  try {
    b.apply(c, l);
  } catch (m) {
    this.onError(m);
  }
}
function Tb(a, b, c, d, e, f, g, h, k) {
  Ob = false;
  Pb = null;
  Nb.apply(Sb, arguments);
}
function Ub(a, b, c, d, e, f, g, h, k) {
  Tb.apply(this, arguments);
  if (Ob) {
    if (Ob) {
      var l = Pb;
      Ob = false;
      Pb = null;
    } else
      throw Error(p2(198));
    Qb || (Qb = true, Rb = l);
  }
}
function Vb(a) {
  var b = a, c = a;
  if (a.alternate)
    for (;b.return; )
      b = b.return;
  else {
    a = b;
    do
      b = a, (b.flags & 4098) !== 0 && (c = b.return), a = b.return;
    while (a);
  }
  return b.tag === 3 ? c : null;
}
function Wb(a) {
  if (a.tag === 13) {
    var b = a.memoizedState;
    b === null && (a = a.alternate, a !== null && (b = a.memoizedState));
    if (b !== null)
      return b.dehydrated;
  }
  return null;
}
function Xb(a) {
  if (Vb(a) !== a)
    throw Error(p2(188));
}
function Yb(a) {
  var b = a.alternate;
  if (!b) {
    b = Vb(a);
    if (b === null)
      throw Error(p2(188));
    return b !== a ? null : a;
  }
  for (var c = a, d = b;; ) {
    var e = c.return;
    if (e === null)
      break;
    var f = e.alternate;
    if (f === null) {
      d = e.return;
      if (d !== null) {
        c = d;
        continue;
      }
      break;
    }
    if (e.child === f.child) {
      for (f = e.child;f; ) {
        if (f === c)
          return Xb(e), a;
        if (f === d)
          return Xb(e), b;
        f = f.sibling;
      }
      throw Error(p2(188));
    }
    if (c.return !== d.return)
      c = e, d = f;
    else {
      for (var g = false, h = e.child;h; ) {
        if (h === c) {
          g = true;
          c = e;
          d = f;
          break;
        }
        if (h === d) {
          g = true;
          d = e;
          c = f;
          break;
        }
        h = h.sibling;
      }
      if (!g) {
        for (h = f.child;h; ) {
          if (h === c) {
            g = true;
            c = f;
            d = e;
            break;
          }
          if (h === d) {
            g = true;
            d = f;
            c = e;
            break;
          }
          h = h.sibling;
        }
        if (!g)
          throw Error(p2(189));
      }
    }
    if (c.alternate !== d)
      throw Error(p2(190));
  }
  if (c.tag !== 3)
    throw Error(p2(188));
  return c.stateNode.current === c ? a : b;
}
function Zb(a) {
  a = Yb(a);
  return a !== null ? $b(a) : null;
}
function $b(a) {
  if (a.tag === 5 || a.tag === 6)
    return a;
  for (a = a.child;a !== null; ) {
    var b = $b(a);
    if (b !== null)
      return b;
    a = a.sibling;
  }
  return null;
}
function mc(a) {
  if (lc && typeof lc.onCommitFiberRoot === "function")
    try {
      lc.onCommitFiberRoot(kc, a, undefined, (a.current.flags & 128) === 128);
    } catch (b) {}
}
function nc(a) {
  a >>>= 0;
  return a === 0 ? 32 : 31 - (pc(a) / qc | 0) | 0;
}
function tc(a) {
  switch (a & -a) {
    case 1:
      return 1;
    case 2:
      return 2;
    case 4:
      return 4;
    case 8:
      return 8;
    case 16:
      return 16;
    case 32:
      return 32;
    case 64:
    case 128:
    case 256:
    case 512:
    case 1024:
    case 2048:
    case 4096:
    case 8192:
    case 16384:
    case 32768:
    case 65536:
    case 131072:
    case 262144:
    case 524288:
    case 1048576:
    case 2097152:
      return a & 4194240;
    case 4194304:
    case 8388608:
    case 16777216:
    case 33554432:
    case 67108864:
      return a & 130023424;
    case 134217728:
      return 134217728;
    case 268435456:
      return 268435456;
    case 536870912:
      return 536870912;
    case 1073741824:
      return 1073741824;
    default:
      return a;
  }
}
function uc(a, b) {
  var c = a.pendingLanes;
  if (c === 0)
    return 0;
  var d = 0, e = a.suspendedLanes, f = a.pingedLanes, g = c & 268435455;
  if (g !== 0) {
    var h = g & ~e;
    h !== 0 ? d = tc(h) : (f &= g, f !== 0 && (d = tc(f)));
  } else
    g = c & ~e, g !== 0 ? d = tc(g) : f !== 0 && (d = tc(f));
  if (d === 0)
    return 0;
  if (b !== 0 && b !== d && (b & e) === 0 && (e = d & -d, f = b & -b, e >= f || e === 16 && (f & 4194240) !== 0))
    return b;
  (d & 4) !== 0 && (d |= c & 16);
  b = a.entangledLanes;
  if (b !== 0)
    for (a = a.entanglements, b &= d;0 < b; )
      c = 31 - oc(b), e = 1 << c, d |= a[c], b &= ~e;
  return d;
}
function vc(a, b) {
  switch (a) {
    case 1:
    case 2:
    case 4:
      return b + 250;
    case 8:
    case 16:
    case 32:
    case 64:
    case 128:
    case 256:
    case 512:
    case 1024:
    case 2048:
    case 4096:
    case 8192:
    case 16384:
    case 32768:
    case 65536:
    case 131072:
    case 262144:
    case 524288:
    case 1048576:
    case 2097152:
      return b + 5000;
    case 4194304:
    case 8388608:
    case 16777216:
    case 33554432:
    case 67108864:
      return -1;
    case 134217728:
    case 268435456:
    case 536870912:
    case 1073741824:
      return -1;
    default:
      return -1;
  }
}
function wc(a, b) {
  for (var { suspendedLanes: c, pingedLanes: d, expirationTimes: e, pendingLanes: f } = a;0 < f; ) {
    var g = 31 - oc(f), h = 1 << g, k = e[g];
    if (k === -1) {
      if ((h & c) === 0 || (h & d) !== 0)
        e[g] = vc(h, b);
    } else
      k <= b && (a.expiredLanes |= h);
    f &= ~h;
  }
}
function xc(a) {
  a = a.pendingLanes & -1073741825;
  return a !== 0 ? a : a & 1073741824 ? 1073741824 : 0;
}
function yc() {
  var a = rc;
  rc <<= 1;
  (rc & 4194240) === 0 && (rc = 64);
  return a;
}
function zc(a) {
  for (var b = [], c = 0;31 > c; c++)
    b.push(a);
  return b;
}
function Ac(a, b, c) {
  a.pendingLanes |= b;
  b !== 536870912 && (a.suspendedLanes = 0, a.pingedLanes = 0);
  a = a.eventTimes;
  b = 31 - oc(b);
  a[b] = c;
}
function Bc(a, b) {
  var c = a.pendingLanes & ~b;
  a.pendingLanes = b;
  a.suspendedLanes = 0;
  a.pingedLanes = 0;
  a.expiredLanes &= b;
  a.mutableReadLanes &= b;
  a.entangledLanes &= b;
  b = a.entanglements;
  var d = a.eventTimes;
  for (a = a.expirationTimes;0 < c; ) {
    var e = 31 - oc(c), f = 1 << e;
    b[e] = 0;
    d[e] = -1;
    a[e] = -1;
    c &= ~f;
  }
}
function Cc(a, b) {
  var c = a.entangledLanes |= b;
  for (a = a.entanglements;c; ) {
    var d = 31 - oc(c), e = 1 << d;
    e & b | a[d] & b && (a[d] |= b);
    c &= ~e;
  }
}
function Dc(a) {
  a &= -a;
  return 1 < a ? 4 < a ? (a & 268435455) !== 0 ? 16 : 536870912 : 4 : 1;
}
function Sc(a, b) {
  switch (a) {
    case "focusin":
    case "focusout":
      Lc = null;
      break;
    case "dragenter":
    case "dragleave":
      Mc = null;
      break;
    case "mouseover":
    case "mouseout":
      Nc = null;
      break;
    case "pointerover":
    case "pointerout":
      Oc.delete(b.pointerId);
      break;
    case "gotpointercapture":
    case "lostpointercapture":
      Pc.delete(b.pointerId);
  }
}
function Tc(a, b, c, d, e, f) {
  if (a === null || a.nativeEvent !== f)
    return a = { blockedOn: b, domEventName: c, eventSystemFlags: d, nativeEvent: f, targetContainers: [e] }, b !== null && (b = Cb(b), b !== null && Fc(b)), a;
  a.eventSystemFlags |= d;
  b = a.targetContainers;
  e !== null && b.indexOf(e) === -1 && b.push(e);
  return a;
}
function Uc(a, b, c, d, e) {
  switch (b) {
    case "focusin":
      return Lc = Tc(Lc, a, b, c, d, e), true;
    case "dragenter":
      return Mc = Tc(Mc, a, b, c, d, e), true;
    case "mouseover":
      return Nc = Tc(Nc, a, b, c, d, e), true;
    case "pointerover":
      var f = e.pointerId;
      Oc.set(f, Tc(Oc.get(f) || null, a, b, c, d, e));
      return true;
    case "gotpointercapture":
      return f = e.pointerId, Pc.set(f, Tc(Pc.get(f) || null, a, b, c, d, e)), true;
  }
  return false;
}
function Vc(a) {
  var b = Wc(a.target);
  if (b !== null) {
    var c = Vb(b);
    if (c !== null) {
      if (b = c.tag, b === 13) {
        if (b = Wb(c), b !== null) {
          a.blockedOn = b;
          Ic(a.priority, function() {
            Gc(c);
          });
          return;
        }
      } else if (b === 3 && c.stateNode.current.memoizedState.isDehydrated) {
        a.blockedOn = c.tag === 3 ? c.stateNode.containerInfo : null;
        return;
      }
    }
  }
  a.blockedOn = null;
}
function Xc(a) {
  if (a.blockedOn !== null)
    return false;
  for (var b = a.targetContainers;0 < b.length; ) {
    var c = Yc(a.domEventName, a.eventSystemFlags, b[0], a.nativeEvent);
    if (c === null) {
      c = a.nativeEvent;
      var d = new c.constructor(c.type, c);
      wb = d;
      c.target.dispatchEvent(d);
      wb = null;
    } else
      return b = Cb(c), b !== null && Fc(b), a.blockedOn = c, false;
    b.shift();
  }
  return true;
}
function Zc(a, b, c) {
  Xc(a) && c.delete(b);
}
function $c() {
  Jc = false;
  Lc !== null && Xc(Lc) && (Lc = null);
  Mc !== null && Xc(Mc) && (Mc = null);
  Nc !== null && Xc(Nc) && (Nc = null);
  Oc.forEach(Zc);
  Pc.forEach(Zc);
}
function ad(a, b) {
  a.blockedOn === b && (a.blockedOn = null, Jc || (Jc = true, ca.unstable_scheduleCallback(ca.unstable_NormalPriority, $c)));
}
function bd(a) {
  function b(b) {
    return ad(b, a);
  }
  if (0 < Kc.length) {
    ad(Kc[0], a);
    for (var c = 1;c < Kc.length; c++) {
      var d = Kc[c];
      d.blockedOn === a && (d.blockedOn = null);
    }
  }
  Lc !== null && ad(Lc, a);
  Mc !== null && ad(Mc, a);
  Nc !== null && ad(Nc, a);
  Oc.forEach(b);
  Pc.forEach(b);
  for (c = 0;c < Qc.length; c++)
    d = Qc[c], d.blockedOn === a && (d.blockedOn = null);
  for (;0 < Qc.length && (c = Qc[0], c.blockedOn === null); )
    Vc(c), c.blockedOn === null && Qc.shift();
}
function ed(a, b, c, d) {
  var e = C2, f = cd.transition;
  cd.transition = null;
  try {
    C2 = 1, fd(a, b, c, d);
  } finally {
    C2 = e, cd.transition = f;
  }
}
function gd(a, b, c, d) {
  var e = C2, f = cd.transition;
  cd.transition = null;
  try {
    C2 = 4, fd(a, b, c, d);
  } finally {
    C2 = e, cd.transition = f;
  }
}
function fd(a, b, c, d) {
  if (dd) {
    var e = Yc(a, b, c, d);
    if (e === null)
      hd(a, b, d, id, c), Sc(a, d);
    else if (Uc(e, a, b, c, d))
      d.stopPropagation();
    else if (Sc(a, d), b & 4 && -1 < Rc.indexOf(a)) {
      for (;e !== null; ) {
        var f = Cb(e);
        f !== null && Ec(f);
        f = Yc(a, b, c, d);
        f === null && hd(a, b, d, id, c);
        if (f === e)
          break;
        e = f;
      }
      e !== null && d.stopPropagation();
    } else
      hd(a, b, d, null, c);
  }
}
function Yc(a, b, c, d) {
  id = null;
  a = xb(d);
  a = Wc(a);
  if (a !== null)
    if (b = Vb(a), b === null)
      a = null;
    else if (c = b.tag, c === 13) {
      a = Wb(b);
      if (a !== null)
        return a;
      a = null;
    } else if (c === 3) {
      if (b.stateNode.current.memoizedState.isDehydrated)
        return b.tag === 3 ? b.stateNode.containerInfo : null;
      a = null;
    } else
      b !== a && (a = null);
  id = a;
  return null;
}
function jd(a) {
  switch (a) {
    case "cancel":
    case "click":
    case "close":
    case "contextmenu":
    case "copy":
    case "cut":
    case "auxclick":
    case "dblclick":
    case "dragend":
    case "dragstart":
    case "drop":
    case "focusin":
    case "focusout":
    case "input":
    case "invalid":
    case "keydown":
    case "keypress":
    case "keyup":
    case "mousedown":
    case "mouseup":
    case "paste":
    case "pause":
    case "play":
    case "pointercancel":
    case "pointerdown":
    case "pointerup":
    case "ratechange":
    case "reset":
    case "resize":
    case "seeked":
    case "submit":
    case "touchcancel":
    case "touchend":
    case "touchstart":
    case "volumechange":
    case "change":
    case "selectionchange":
    case "textInput":
    case "compositionstart":
    case "compositionend":
    case "compositionupdate":
    case "beforeblur":
    case "afterblur":
    case "beforeinput":
    case "blur":
    case "fullscreenchange":
    case "focus":
    case "hashchange":
    case "popstate":
    case "select":
    case "selectstart":
      return 1;
    case "drag":
    case "dragenter":
    case "dragexit":
    case "dragleave":
    case "dragover":
    case "mousemove":
    case "mouseout":
    case "mouseover":
    case "pointermove":
    case "pointerout":
    case "pointerover":
    case "scroll":
    case "toggle":
    case "touchmove":
    case "wheel":
    case "mouseenter":
    case "mouseleave":
    case "pointerenter":
    case "pointerleave":
      return 4;
    case "message":
      switch (ec()) {
        case fc:
          return 1;
        case gc:
          return 4;
        case hc:
        case ic:
          return 16;
        case jc:
          return 536870912;
        default:
          return 16;
      }
    default:
      return 16;
  }
}
function nd() {
  if (md)
    return md;
  var a, b = ld, c = b.length, d, e = "value" in kd ? kd.value : kd.textContent, f = e.length;
  for (a = 0;a < c && b[a] === e[a]; a++)
    ;
  var g = c - a;
  for (d = 1;d <= g && b[c - d] === e[f - d]; d++)
    ;
  return md = e.slice(a, 1 < d ? 1 - d : undefined);
}
function od(a) {
  var b = a.keyCode;
  "charCode" in a ? (a = a.charCode, a === 0 && b === 13 && (a = 13)) : a = b;
  a === 10 && (a = 13);
  return 32 <= a || a === 13 ? a : 0;
}
function pd() {
  return true;
}
function qd() {
  return false;
}
function rd(a) {
  function b(b, d, e, f, g) {
    this._reactName = b;
    this._targetInst = e;
    this.type = d;
    this.nativeEvent = f;
    this.target = g;
    this.currentTarget = null;
    for (var c in a)
      a.hasOwnProperty(c) && (b = a[c], this[c] = b ? b(f) : f[c]);
    this.isDefaultPrevented = (f.defaultPrevented != null ? f.defaultPrevented : f.returnValue === false) ? pd : qd;
    this.isPropagationStopped = qd;
    return this;
  }
  A2(b.prototype, { preventDefault: function() {
    this.defaultPrevented = true;
    var a = this.nativeEvent;
    a && (a.preventDefault ? a.preventDefault() : typeof a.returnValue !== "unknown" && (a.returnValue = false), this.isDefaultPrevented = pd);
  }, stopPropagation: function() {
    var a = this.nativeEvent;
    a && (a.stopPropagation ? a.stopPropagation() : typeof a.cancelBubble !== "unknown" && (a.cancelBubble = true), this.isPropagationStopped = pd);
  }, persist: function() {}, isPersistent: pd });
  return b;
}
function Pd(a) {
  var b = this.nativeEvent;
  return b.getModifierState ? b.getModifierState(a) : (a = Od[a]) ? !!b[a] : false;
}
function zd() {
  return Pd;
}
function ge(a, b) {
  switch (a) {
    case "keyup":
      return $d.indexOf(b.keyCode) !== -1;
    case "keydown":
      return b.keyCode !== 229;
    case "keypress":
    case "mousedown":
    case "focusout":
      return true;
    default:
      return false;
  }
}
function he(a) {
  a = a.detail;
  return typeof a === "object" && "data" in a ? a.data : null;
}
function je(a, b) {
  switch (a) {
    case "compositionend":
      return he(b);
    case "keypress":
      if (b.which !== 32)
        return null;
      fe = true;
      return ee;
    case "textInput":
      return a = b.data, a === ee && fe ? null : a;
    default:
      return null;
  }
}
function ke(a, b) {
  if (ie)
    return a === "compositionend" || !ae && ge(a, b) ? (a = nd(), md = ld = kd = null, ie = false, a) : null;
  switch (a) {
    case "paste":
      return null;
    case "keypress":
      if (!(b.ctrlKey || b.altKey || b.metaKey) || b.ctrlKey && b.altKey) {
        if (b.char && 1 < b.char.length)
          return b.char;
        if (b.which)
          return String.fromCharCode(b.which);
      }
      return null;
    case "compositionend":
      return de && b.locale !== "ko" ? null : b.data;
    default:
      return null;
  }
}
function me(a) {
  var b = a && a.nodeName && a.nodeName.toLowerCase();
  return b === "input" ? !!le[a.type] : b === "textarea" ? true : false;
}
function ne(a, b, c, d) {
  Eb(d);
  b = oe(b, "onChange");
  0 < b.length && (c = new td("onChange", "change", null, c, d), a.push({ event: c, listeners: b }));
}
function re(a) {
  se(a, 0);
}
function te(a) {
  var b = ue(a);
  if (Wa(b))
    return a;
}
function ve(a, b) {
  if (a === "change")
    return b;
}
function Ae() {
  pe && (pe.detachEvent("onpropertychange", Be), qe = pe = null);
}
function Be(a) {
  if (a.propertyName === "value" && te(qe)) {
    var b = [];
    ne(b, qe, a, xb(a));
    Jb(re, b);
  }
}
function Ce(a, b, c) {
  a === "focusin" ? (Ae(), pe = b, qe = c, pe.attachEvent("onpropertychange", Be)) : a === "focusout" && Ae();
}
function De(a) {
  if (a === "selectionchange" || a === "keyup" || a === "keydown")
    return te(qe);
}
function Ee(a, b) {
  if (a === "click")
    return te(b);
}
function Fe(a, b) {
  if (a === "input" || a === "change")
    return te(b);
}
function Ge(a, b) {
  return a === b && (a !== 0 || 1 / a === 1 / b) || a !== a && b !== b;
}
function Ie(a, b) {
  if (He(a, b))
    return true;
  if (typeof a !== "object" || a === null || typeof b !== "object" || b === null)
    return false;
  var c = Object.keys(a), d = Object.keys(b);
  if (c.length !== d.length)
    return false;
  for (d = 0;d < c.length; d++) {
    var e = c[d];
    if (!ja.call(b, e) || !He(a[e], b[e]))
      return false;
  }
  return true;
}
function Je(a) {
  for (;a && a.firstChild; )
    a = a.firstChild;
  return a;
}
function Ke(a, b) {
  var c = Je(a);
  a = 0;
  for (var d;c; ) {
    if (c.nodeType === 3) {
      d = a + c.textContent.length;
      if (a <= b && d >= b)
        return { node: c, offset: b - a };
      a = d;
    }
    a: {
      for (;c; ) {
        if (c.nextSibling) {
          c = c.nextSibling;
          break a;
        }
        c = c.parentNode;
      }
      c = undefined;
    }
    c = Je(c);
  }
}
function Le(a, b) {
  return a && b ? a === b ? true : a && a.nodeType === 3 ? false : b && b.nodeType === 3 ? Le(a, b.parentNode) : ("contains" in a) ? a.contains(b) : a.compareDocumentPosition ? !!(a.compareDocumentPosition(b) & 16) : false : false;
}
function Me() {
  for (var a = window, b = Xa();b instanceof a.HTMLIFrameElement; ) {
    try {
      var c = typeof b.contentWindow.location.href === "string";
    } catch (d) {
      c = false;
    }
    if (c)
      a = b.contentWindow;
    else
      break;
    b = Xa(a.document);
  }
  return b;
}
function Ne(a) {
  var b = a && a.nodeName && a.nodeName.toLowerCase();
  return b && (b === "input" && (a.type === "text" || a.type === "search" || a.type === "tel" || a.type === "url" || a.type === "password") || b === "textarea" || a.contentEditable === "true");
}
function Oe(a) {
  var b = Me(), c = a.focusedElem, d = a.selectionRange;
  if (b !== c && c && c.ownerDocument && Le(c.ownerDocument.documentElement, c)) {
    if (d !== null && Ne(c)) {
      if (b = d.start, a = d.end, a === undefined && (a = b), "selectionStart" in c)
        c.selectionStart = b, c.selectionEnd = Math.min(a, c.value.length);
      else if (a = (b = c.ownerDocument || document) && b.defaultView || window, a.getSelection) {
        a = a.getSelection();
        var e = c.textContent.length, f = Math.min(d.start, e);
        d = d.end === undefined ? f : Math.min(d.end, e);
        !a.extend && f > d && (e = d, d = f, f = e);
        e = Ke(c, f);
        var g = Ke(c, d);
        e && g && (a.rangeCount !== 1 || a.anchorNode !== e.node || a.anchorOffset !== e.offset || a.focusNode !== g.node || a.focusOffset !== g.offset) && (b = b.createRange(), b.setStart(e.node, e.offset), a.removeAllRanges(), f > d ? (a.addRange(b), a.extend(g.node, g.offset)) : (b.setEnd(g.node, g.offset), a.addRange(b)));
      }
    }
    b = [];
    for (a = c;a = a.parentNode; )
      a.nodeType === 1 && b.push({ element: a, left: a.scrollLeft, top: a.scrollTop });
    typeof c.focus === "function" && c.focus();
    for (c = 0;c < b.length; c++)
      a = b[c], a.element.scrollLeft = a.left, a.element.scrollTop = a.top;
  }
}
function Ue(a, b, c) {
  var d = c.window === c ? c.document : c.nodeType === 9 ? c : c.ownerDocument;
  Te || Qe == null || Qe !== Xa(d) || (d = Qe, ("selectionStart" in d) && Ne(d) ? d = { start: d.selectionStart, end: d.selectionEnd } : (d = (d.ownerDocument && d.ownerDocument.defaultView || window).getSelection(), d = { anchorNode: d.anchorNode, anchorOffset: d.anchorOffset, focusNode: d.focusNode, focusOffset: d.focusOffset }), Se && Ie(Se, d) || (Se = d, d = oe(Re, "onSelect"), 0 < d.length && (b = new td("onSelect", "select", null, b, c), a.push({ event: b, listeners: d }), b.target = Qe)));
}
function Ve(a, b) {
  var c = {};
  c[a.toLowerCase()] = b.toLowerCase();
  c["Webkit" + a] = "webkit" + b;
  c["Moz" + a] = "moz" + b;
  return c;
}
function Ze(a) {
  if (Xe[a])
    return Xe[a];
  if (!We[a])
    return a;
  var b = We[a], c;
  for (c in b)
    if (b.hasOwnProperty(c) && c in Ye)
      return Xe[a] = b[c];
  return a;
}
function ff(a, b) {
  df.set(a, b);
  fa(b, [a]);
}
function nf(a, b, c) {
  var d = a.type || "unknown-event";
  a.currentTarget = c;
  Ub(d, b, undefined, a);
  a.currentTarget = null;
}
function se(a, b) {
  b = (b & 4) !== 0;
  for (var c = 0;c < a.length; c++) {
    var d = a[c], e = d.event;
    d = d.listeners;
    a: {
      var f = undefined;
      if (b)
        for (var g = d.length - 1;0 <= g; g--) {
          var h = d[g], k = h.instance, l = h.currentTarget;
          h = h.listener;
          if (k !== f && e.isPropagationStopped())
            break a;
          nf(e, h, l);
          f = k;
        }
      else
        for (g = 0;g < d.length; g++) {
          h = d[g];
          k = h.instance;
          l = h.currentTarget;
          h = h.listener;
          if (k !== f && e.isPropagationStopped())
            break a;
          nf(e, h, l);
          f = k;
        }
    }
  }
  if (Qb)
    throw a = Rb, Qb = false, Rb = null, a;
}
function D2(a, b) {
  var c = b[of];
  c === undefined && (c = b[of] = new Set);
  var d = a + "__bubble";
  c.has(d) || (pf(b, a, 2, false), c.add(d));
}
function qf(a, b, c) {
  var d = 0;
  b && (d |= 4);
  pf(c, a, d, b);
}
function sf(a) {
  if (!a[rf]) {
    a[rf] = true;
    da.forEach(function(b) {
      b !== "selectionchange" && (mf.has(b) || qf(b, false, a), qf(b, true, a));
    });
    var b = a.nodeType === 9 ? a : a.ownerDocument;
    b === null || b[rf] || (b[rf] = true, qf("selectionchange", false, b));
  }
}
function pf(a, b, c, d) {
  switch (jd(b)) {
    case 1:
      var e = ed;
      break;
    case 4:
      e = gd;
      break;
    default:
      e = fd;
  }
  c = e.bind(null, b, c, a);
  e = undefined;
  !Lb || b !== "touchstart" && b !== "touchmove" && b !== "wheel" || (e = true);
  d ? e !== undefined ? a.addEventListener(b, c, { capture: true, passive: e }) : a.addEventListener(b, c, true) : e !== undefined ? a.addEventListener(b, c, { passive: e }) : a.addEventListener(b, c, false);
}
function hd(a, b, c, d, e) {
  var f = d;
  if ((b & 1) === 0 && (b & 2) === 0 && d !== null)
    a:
      for (;; ) {
        if (d === null)
          return;
        var g = d.tag;
        if (g === 3 || g === 4) {
          var h = d.stateNode.containerInfo;
          if (h === e || h.nodeType === 8 && h.parentNode === e)
            break;
          if (g === 4)
            for (g = d.return;g !== null; ) {
              var k = g.tag;
              if (k === 3 || k === 4) {
                if (k = g.stateNode.containerInfo, k === e || k.nodeType === 8 && k.parentNode === e)
                  return;
              }
              g = g.return;
            }
          for (;h !== null; ) {
            g = Wc(h);
            if (g === null)
              return;
            k = g.tag;
            if (k === 5 || k === 6) {
              d = f = g;
              continue a;
            }
            h = h.parentNode;
          }
        }
        d = d.return;
      }
  Jb(function() {
    var d = f, e = xb(c), g = [];
    a: {
      var h = df.get(a);
      if (h !== undefined) {
        var k = td, n = a;
        switch (a) {
          case "keypress":
            if (od(c) === 0)
              break a;
          case "keydown":
          case "keyup":
            k = Rd;
            break;
          case "focusin":
            n = "focus";
            k = Fd;
            break;
          case "focusout":
            n = "blur";
            k = Fd;
            break;
          case "beforeblur":
          case "afterblur":
            k = Fd;
            break;
          case "click":
            if (c.button === 2)
              break a;
          case "auxclick":
          case "dblclick":
          case "mousedown":
          case "mousemove":
          case "mouseup":
          case "mouseout":
          case "mouseover":
          case "contextmenu":
            k = Bd;
            break;
          case "drag":
          case "dragend":
          case "dragenter":
          case "dragexit":
          case "dragleave":
          case "dragover":
          case "dragstart":
          case "drop":
            k = Dd;
            break;
          case "touchcancel":
          case "touchend":
          case "touchmove":
          case "touchstart":
            k = Vd;
            break;
          case $e:
          case af:
          case bf:
            k = Hd;
            break;
          case cf:
            k = Xd;
            break;
          case "scroll":
            k = vd;
            break;
          case "wheel":
            k = Zd;
            break;
          case "copy":
          case "cut":
          case "paste":
            k = Jd;
            break;
          case "gotpointercapture":
          case "lostpointercapture":
          case "pointercancel":
          case "pointerdown":
          case "pointermove":
          case "pointerout":
          case "pointerover":
          case "pointerup":
            k = Td;
        }
        var t = (b & 4) !== 0, J = !t && a === "scroll", x = t ? h !== null ? h + "Capture" : null : h;
        t = [];
        for (var w = d, u;w !== null; ) {
          u = w;
          var F = u.stateNode;
          u.tag === 5 && F !== null && (u = F, x !== null && (F = Kb(w, x), F != null && t.push(tf(w, F, u))));
          if (J)
            break;
          w = w.return;
        }
        0 < t.length && (h = new k(h, n, null, c, e), g.push({ event: h, listeners: t }));
      }
    }
    if ((b & 7) === 0) {
      a: {
        h = a === "mouseover" || a === "pointerover";
        k = a === "mouseout" || a === "pointerout";
        if (h && c !== wb && (n = c.relatedTarget || c.fromElement) && (Wc(n) || n[uf]))
          break a;
        if (k || h) {
          h = e.window === e ? e : (h = e.ownerDocument) ? h.defaultView || h.parentWindow : window;
          if (k) {
            if (n = c.relatedTarget || c.toElement, k = d, n = n ? Wc(n) : null, n !== null && (J = Vb(n), n !== J || n.tag !== 5 && n.tag !== 6))
              n = null;
          } else
            k = null, n = d;
          if (k !== n) {
            t = Bd;
            F = "onMouseLeave";
            x = "onMouseEnter";
            w = "mouse";
            if (a === "pointerout" || a === "pointerover")
              t = Td, F = "onPointerLeave", x = "onPointerEnter", w = "pointer";
            J = k == null ? h : ue(k);
            u = n == null ? h : ue(n);
            h = new t(F, w + "leave", k, c, e);
            h.target = J;
            h.relatedTarget = u;
            F = null;
            Wc(e) === d && (t = new t(x, w + "enter", n, c, e), t.target = u, t.relatedTarget = J, F = t);
            J = F;
            if (k && n)
              b: {
                t = k;
                x = n;
                w = 0;
                for (u = t;u; u = vf(u))
                  w++;
                u = 0;
                for (F = x;F; F = vf(F))
                  u++;
                for (;0 < w - u; )
                  t = vf(t), w--;
                for (;0 < u - w; )
                  x = vf(x), u--;
                for (;w--; ) {
                  if (t === x || x !== null && t === x.alternate)
                    break b;
                  t = vf(t);
                  x = vf(x);
                }
                t = null;
              }
            else
              t = null;
            k !== null && wf(g, h, k, t, false);
            n !== null && J !== null && wf(g, J, n, t, true);
          }
        }
      }
      a: {
        h = d ? ue(d) : window;
        k = h.nodeName && h.nodeName.toLowerCase();
        if (k === "select" || k === "input" && h.type === "file")
          var na = ve;
        else if (me(h))
          if (we)
            na = Fe;
          else {
            na = De;
            var xa = Ce;
          }
        else
          (k = h.nodeName) && k.toLowerCase() === "input" && (h.type === "checkbox" || h.type === "radio") && (na = Ee);
        if (na && (na = na(a, d))) {
          ne(g, na, c, e);
          break a;
        }
        xa && xa(a, h, d);
        a === "focusout" && (xa = h._wrapperState) && xa.controlled && h.type === "number" && cb(h, "number", h.value);
      }
      xa = d ? ue(d) : window;
      switch (a) {
        case "focusin":
          if (me(xa) || xa.contentEditable === "true")
            Qe = xa, Re = d, Se = null;
          break;
        case "focusout":
          Se = Re = Qe = null;
          break;
        case "mousedown":
          Te = true;
          break;
        case "contextmenu":
        case "mouseup":
        case "dragend":
          Te = false;
          Ue(g, c, e);
          break;
        case "selectionchange":
          if (Pe)
            break;
        case "keydown":
        case "keyup":
          Ue(g, c, e);
      }
      var $a;
      if (ae)
        b: {
          switch (a) {
            case "compositionstart":
              var ba = "onCompositionStart";
              break b;
            case "compositionend":
              ba = "onCompositionEnd";
              break b;
            case "compositionupdate":
              ba = "onCompositionUpdate";
              break b;
          }
          ba = undefined;
        }
      else
        ie ? ge(a, c) && (ba = "onCompositionEnd") : a === "keydown" && c.keyCode === 229 && (ba = "onCompositionStart");
      ba && (de && c.locale !== "ko" && (ie || ba !== "onCompositionStart" ? ba === "onCompositionEnd" && ie && ($a = nd()) : (kd = e, ld = ("value" in kd) ? kd.value : kd.textContent, ie = true)), xa = oe(d, ba), 0 < xa.length && (ba = new Ld(ba, a, null, c, e), g.push({ event: ba, listeners: xa }), $a ? ba.data = $a : ($a = he(c), $a !== null && (ba.data = $a))));
      if ($a = ce ? je(a, c) : ke(a, c))
        d = oe(d, "onBeforeInput"), 0 < d.length && (e = new Ld("onBeforeInput", "beforeinput", null, c, e), g.push({ event: e, listeners: d }), e.data = $a);
    }
    se(g, b);
  });
}
function tf(a, b, c) {
  return { instance: a, listener: b, currentTarget: c };
}
function oe(a, b) {
  for (var c = b + "Capture", d = [];a !== null; ) {
    var e = a, f = e.stateNode;
    e.tag === 5 && f !== null && (e = f, f = Kb(a, c), f != null && d.unshift(tf(a, f, e)), f = Kb(a, b), f != null && d.push(tf(a, f, e)));
    a = a.return;
  }
  return d;
}
function vf(a) {
  if (a === null)
    return null;
  do
    a = a.return;
  while (a && a.tag !== 5);
  return a ? a : null;
}
function wf(a, b, c, d, e) {
  for (var f = b._reactName, g = [];c !== null && c !== d; ) {
    var h = c, k = h.alternate, l = h.stateNode;
    if (k !== null && k === d)
      break;
    h.tag === 5 && l !== null && (h = l, e ? (k = Kb(c, f), k != null && g.unshift(tf(c, k, h))) : e || (k = Kb(c, f), k != null && g.push(tf(c, k, h))));
    c = c.return;
  }
  g.length !== 0 && a.push({ event: b, listeners: g });
}
function zf(a) {
  return (typeof a === "string" ? a : "" + a).replace(xf, `
`).replace(yf, "");
}
function Af(a, b, c) {
  b = zf(b);
  if (zf(a) !== b && c)
    throw Error(p2(425));
}
function Bf() {}
function Ef(a, b) {
  return a === "textarea" || a === "noscript" || typeof b.children === "string" || typeof b.children === "number" || typeof b.dangerouslySetInnerHTML === "object" && b.dangerouslySetInnerHTML !== null && b.dangerouslySetInnerHTML.__html != null;
}
function If(a) {
  setTimeout(function() {
    throw a;
  });
}
function Kf(a, b) {
  var c = b, d = 0;
  do {
    var e = c.nextSibling;
    a.removeChild(c);
    if (e && e.nodeType === 8)
      if (c = e.data, c === "/$") {
        if (d === 0) {
          a.removeChild(e);
          bd(b);
          return;
        }
        d--;
      } else
        c !== "$" && c !== "$?" && c !== "$!" || d++;
    c = e;
  } while (c);
  bd(b);
}
function Lf(a) {
  for (;a != null; a = a.nextSibling) {
    var b = a.nodeType;
    if (b === 1 || b === 3)
      break;
    if (b === 8) {
      b = a.data;
      if (b === "$" || b === "$!" || b === "$?")
        break;
      if (b === "/$")
        return null;
    }
  }
  return a;
}
function Mf(a) {
  a = a.previousSibling;
  for (var b = 0;a; ) {
    if (a.nodeType === 8) {
      var c = a.data;
      if (c === "$" || c === "$!" || c === "$?") {
        if (b === 0)
          return a;
        b--;
      } else
        c === "/$" && b++;
    }
    a = a.previousSibling;
  }
  return null;
}
function Wc(a) {
  var b = a[Of];
  if (b)
    return b;
  for (var c = a.parentNode;c; ) {
    if (b = c[uf] || c[Of]) {
      c = b.alternate;
      if (b.child !== null || c !== null && c.child !== null)
        for (a = Mf(a);a !== null; ) {
          if (c = a[Of])
            return c;
          a = Mf(a);
        }
      return b;
    }
    a = c;
    c = a.parentNode;
  }
  return null;
}
function Cb(a) {
  a = a[Of] || a[uf];
  return !a || a.tag !== 5 && a.tag !== 6 && a.tag !== 13 && a.tag !== 3 ? null : a;
}
function ue(a) {
  if (a.tag === 5 || a.tag === 6)
    return a.stateNode;
  throw Error(p2(33));
}
function Db(a) {
  return a[Pf] || null;
}
function Uf(a) {
  return { current: a };
}
function E2(a) {
  0 > Tf || (a.current = Sf[Tf], Sf[Tf] = null, Tf--);
}
function G2(a, b) {
  Tf++;
  Sf[Tf] = a.current;
  a.current = b;
}
function Yf(a, b) {
  var c = a.type.contextTypes;
  if (!c)
    return Vf;
  var d = a.stateNode;
  if (d && d.__reactInternalMemoizedUnmaskedChildContext === b)
    return d.__reactInternalMemoizedMaskedChildContext;
  var e = {}, f;
  for (f in c)
    e[f] = b[f];
  d && (a = a.stateNode, a.__reactInternalMemoizedUnmaskedChildContext = b, a.__reactInternalMemoizedMaskedChildContext = e);
  return e;
}
function Zf(a) {
  a = a.childContextTypes;
  return a !== null && a !== undefined;
}
function $f() {
  E2(Wf);
  E2(H2);
}
function ag(a, b, c) {
  if (H2.current !== Vf)
    throw Error(p2(168));
  G2(H2, b);
  G2(Wf, c);
}
function bg(a, b, c) {
  var d = a.stateNode;
  b = b.childContextTypes;
  if (typeof d.getChildContext !== "function")
    return c;
  d = d.getChildContext();
  for (var e in d)
    if (!(e in b))
      throw Error(p2(108, Ra(a) || "Unknown", e));
  return A2({}, c, d);
}
function cg(a) {
  a = (a = a.stateNode) && a.__reactInternalMemoizedMergedChildContext || Vf;
  Xf = H2.current;
  G2(H2, a);
  G2(Wf, Wf.current);
  return true;
}
function dg(a, b, c) {
  var d = a.stateNode;
  if (!d)
    throw Error(p2(169));
  c ? (a = bg(a, b, Xf), d.__reactInternalMemoizedMergedChildContext = a, E2(Wf), E2(H2), G2(H2, a)) : E2(Wf);
  G2(Wf, c);
}
function hg(a) {
  eg === null ? eg = [a] : eg.push(a);
}
function ig(a) {
  fg = true;
  hg(a);
}
function jg() {
  if (!gg && eg !== null) {
    gg = true;
    var a = 0, b = C2;
    try {
      var c = eg;
      for (C2 = 1;a < c.length; a++) {
        var d = c[a];
        do
          d = d(true);
        while (d !== null);
      }
      eg = null;
      fg = false;
    } catch (e) {
      throw eg !== null && (eg = eg.slice(a + 1)), ac(fc, jg), e;
    } finally {
      C2 = b, gg = false;
    }
  }
  return null;
}
function tg(a, b) {
  kg[lg++] = ng;
  kg[lg++] = mg;
  mg = a;
  ng = b;
}
function ug(a, b, c) {
  og[pg++] = rg;
  og[pg++] = sg;
  og[pg++] = qg;
  qg = a;
  var d = rg;
  a = sg;
  var e = 32 - oc(d) - 1;
  d &= ~(1 << e);
  c += 1;
  var f = 32 - oc(b) + e;
  if (30 < f) {
    var g = e - e % 5;
    f = (d & (1 << g) - 1).toString(32);
    d >>= g;
    e -= g;
    rg = 1 << 32 - oc(b) + e | c << e | d;
    sg = f + a;
  } else
    rg = 1 << f | c << e | d, sg = a;
}
function vg(a) {
  a.return !== null && (tg(a, 1), ug(a, 1, 0));
}
function wg(a) {
  for (;a === mg; )
    mg = kg[--lg], kg[lg] = null, ng = kg[--lg], kg[lg] = null;
  for (;a === qg; )
    qg = og[--pg], og[pg] = null, sg = og[--pg], og[pg] = null, rg = og[--pg], og[pg] = null;
}
function Ag(a, b) {
  var c = Bg(5, null, null, 0);
  c.elementType = "DELETED";
  c.stateNode = b;
  c.return = a;
  b = a.deletions;
  b === null ? (a.deletions = [c], a.flags |= 16) : b.push(c);
}
function Cg(a, b) {
  switch (a.tag) {
    case 5:
      var c = a.type;
      b = b.nodeType !== 1 || c.toLowerCase() !== b.nodeName.toLowerCase() ? null : b;
      return b !== null ? (a.stateNode = b, xg = a, yg = Lf(b.firstChild), true) : false;
    case 6:
      return b = a.pendingProps === "" || b.nodeType !== 3 ? null : b, b !== null ? (a.stateNode = b, xg = a, yg = null, true) : false;
    case 13:
      return b = b.nodeType !== 8 ? null : b, b !== null ? (c = qg !== null ? { id: rg, overflow: sg } : null, a.memoizedState = { dehydrated: b, treeContext: c, retryLane: 1073741824 }, c = Bg(18, null, null, 0), c.stateNode = b, c.return = a, a.child = c, xg = a, yg = null, true) : false;
    default:
      return false;
  }
}
function Dg(a) {
  return (a.mode & 1) !== 0 && (a.flags & 128) === 0;
}
function Eg(a) {
  if (I2) {
    var b = yg;
    if (b) {
      var c = b;
      if (!Cg(a, b)) {
        if (Dg(a))
          throw Error(p2(418));
        b = Lf(c.nextSibling);
        var d = xg;
        b && Cg(a, b) ? Ag(d, c) : (a.flags = a.flags & -4097 | 2, I2 = false, xg = a);
      }
    } else {
      if (Dg(a))
        throw Error(p2(418));
      a.flags = a.flags & -4097 | 2;
      I2 = false;
      xg = a;
    }
  }
}
function Fg(a) {
  for (a = a.return;a !== null && a.tag !== 5 && a.tag !== 3 && a.tag !== 13; )
    a = a.return;
  xg = a;
}
function Gg(a) {
  if (a !== xg)
    return false;
  if (!I2)
    return Fg(a), I2 = true, false;
  var b;
  (b = a.tag !== 3) && !(b = a.tag !== 5) && (b = a.type, b = b !== "head" && b !== "body" && !Ef(a.type, a.memoizedProps));
  if (b && (b = yg)) {
    if (Dg(a))
      throw Hg(), Error(p2(418));
    for (;b; )
      Ag(a, b), b = Lf(b.nextSibling);
  }
  Fg(a);
  if (a.tag === 13) {
    a = a.memoizedState;
    a = a !== null ? a.dehydrated : null;
    if (!a)
      throw Error(p2(317));
    a: {
      a = a.nextSibling;
      for (b = 0;a; ) {
        if (a.nodeType === 8) {
          var c = a.data;
          if (c === "/$") {
            if (b === 0) {
              yg = Lf(a.nextSibling);
              break a;
            }
            b--;
          } else
            c !== "$" && c !== "$!" && c !== "$?" || b++;
        }
        a = a.nextSibling;
      }
      yg = null;
    }
  } else
    yg = xg ? Lf(a.stateNode.nextSibling) : null;
  return true;
}
function Hg() {
  for (var a = yg;a; )
    a = Lf(a.nextSibling);
}
function Ig() {
  yg = xg = null;
  I2 = false;
}
function Jg(a) {
  zg === null ? zg = [a] : zg.push(a);
}
function Lg(a, b, c) {
  a = c.ref;
  if (a !== null && typeof a !== "function" && typeof a !== "object") {
    if (c._owner) {
      c = c._owner;
      if (c) {
        if (c.tag !== 1)
          throw Error(p2(309));
        var d = c.stateNode;
      }
      if (!d)
        throw Error(p2(147, a));
      var e = d, f = "" + a;
      if (b !== null && b.ref !== null && typeof b.ref === "function" && b.ref._stringRef === f)
        return b.ref;
      b = function(a) {
        var b = e.refs;
        a === null ? delete b[f] : b[f] = a;
      };
      b._stringRef = f;
      return b;
    }
    if (typeof a !== "string")
      throw Error(p2(284));
    if (!c._owner)
      throw Error(p2(290, a));
  }
  return a;
}
function Mg(a, b) {
  a = Object.prototype.toString.call(b);
  throw Error(p2(31, a === "[object Object]" ? "object with keys {" + Object.keys(b).join(", ") + "}" : a));
}
function Ng(a) {
  var b = a._init;
  return b(a._payload);
}
function Og(a) {
  function b(b, c) {
    if (a) {
      var d = b.deletions;
      d === null ? (b.deletions = [c], b.flags |= 16) : d.push(c);
    }
  }
  function c(c, d) {
    if (!a)
      return null;
    for (;d !== null; )
      b(c, d), d = d.sibling;
    return null;
  }
  function d(a, b) {
    for (a = new Map;b !== null; )
      b.key !== null ? a.set(b.key, b) : a.set(b.index, b), b = b.sibling;
    return a;
  }
  function e(a, b) {
    a = Pg(a, b);
    a.index = 0;
    a.sibling = null;
    return a;
  }
  function f(b, c, d) {
    b.index = d;
    if (!a)
      return b.flags |= 1048576, c;
    d = b.alternate;
    if (d !== null)
      return d = d.index, d < c ? (b.flags |= 2, c) : d;
    b.flags |= 2;
    return c;
  }
  function g(b) {
    a && b.alternate === null && (b.flags |= 2);
    return b;
  }
  function h(a, b, c, d) {
    if (b === null || b.tag !== 6)
      return b = Qg(c, a.mode, d), b.return = a, b;
    b = e(b, c);
    b.return = a;
    return b;
  }
  function k(a, b, c, d) {
    var f = c.type;
    if (f === ya)
      return m(a, b, c.props.children, d, c.key);
    if (b !== null && (b.elementType === f || typeof f === "object" && f !== null && f.$$typeof === Ha && Ng(f) === b.type))
      return d = e(b, c.props), d.ref = Lg(a, b, c), d.return = a, d;
    d = Rg(c.type, c.key, c.props, null, a.mode, d);
    d.ref = Lg(a, b, c);
    d.return = a;
    return d;
  }
  function l(a, b, c, d) {
    if (b === null || b.tag !== 4 || b.stateNode.containerInfo !== c.containerInfo || b.stateNode.implementation !== c.implementation)
      return b = Sg(c, a.mode, d), b.return = a, b;
    b = e(b, c.children || []);
    b.return = a;
    return b;
  }
  function m(a, b, c, d, f) {
    if (b === null || b.tag !== 7)
      return b = Tg(c, a.mode, d, f), b.return = a, b;
    b = e(b, c);
    b.return = a;
    return b;
  }
  function q(a, b, c) {
    if (typeof b === "string" && b !== "" || typeof b === "number")
      return b = Qg("" + b, a.mode, c), b.return = a, b;
    if (typeof b === "object" && b !== null) {
      switch (b.$$typeof) {
        case va:
          return c = Rg(b.type, b.key, b.props, null, a.mode, c), c.ref = Lg(a, null, b), c.return = a, c;
        case wa:
          return b = Sg(b, a.mode, c), b.return = a, b;
        case Ha:
          var d = b._init;
          return q(a, d(b._payload), c);
      }
      if (eb(b) || Ka(b))
        return b = Tg(b, a.mode, c, null), b.return = a, b;
      Mg(a, b);
    }
    return null;
  }
  function r(a, b, c, d) {
    var e = b !== null ? b.key : null;
    if (typeof c === "string" && c !== "" || typeof c === "number")
      return e !== null ? null : h(a, b, "" + c, d);
    if (typeof c === "object" && c !== null) {
      switch (c.$$typeof) {
        case va:
          return c.key === e ? k(a, b, c, d) : null;
        case wa:
          return c.key === e ? l(a, b, c, d) : null;
        case Ha:
          return e = c._init, r(a, b, e(c._payload), d);
      }
      if (eb(c) || Ka(c))
        return e !== null ? null : m(a, b, c, d, null);
      Mg(a, c);
    }
    return null;
  }
  function y(a, b, c, d, e) {
    if (typeof d === "string" && d !== "" || typeof d === "number")
      return a = a.get(c) || null, h(b, a, "" + d, e);
    if (typeof d === "object" && d !== null) {
      switch (d.$$typeof) {
        case va:
          return a = a.get(d.key === null ? c : d.key) || null, k(b, a, d, e);
        case wa:
          return a = a.get(d.key === null ? c : d.key) || null, l(b, a, d, e);
        case Ha:
          var f = d._init;
          return y(a, b, c, f(d._payload), e);
      }
      if (eb(d) || Ka(d))
        return a = a.get(c) || null, m(b, a, d, e, null);
      Mg(b, d);
    }
    return null;
  }
  function n(e, g, h, k) {
    for (var l = null, m = null, u = g, w = g = 0, x = null;u !== null && w < h.length; w++) {
      u.index > w ? (x = u, u = null) : x = u.sibling;
      var n = r(e, u, h[w], k);
      if (n === null) {
        u === null && (u = x);
        break;
      }
      a && u && n.alternate === null && b(e, u);
      g = f(n, g, w);
      m === null ? l = n : m.sibling = n;
      m = n;
      u = x;
    }
    if (w === h.length)
      return c(e, u), I2 && tg(e, w), l;
    if (u === null) {
      for (;w < h.length; w++)
        u = q(e, h[w], k), u !== null && (g = f(u, g, w), m === null ? l = u : m.sibling = u, m = u);
      I2 && tg(e, w);
      return l;
    }
    for (u = d(e, u);w < h.length; w++)
      x = y(u, e, w, h[w], k), x !== null && (a && x.alternate !== null && u.delete(x.key === null ? w : x.key), g = f(x, g, w), m === null ? l = x : m.sibling = x, m = x);
    a && u.forEach(function(a) {
      return b(e, a);
    });
    I2 && tg(e, w);
    return l;
  }
  function t(e, g, h, k) {
    var l = Ka(h);
    if (typeof l !== "function")
      throw Error(p2(150));
    h = l.call(h);
    if (h == null)
      throw Error(p2(151));
    for (var u = l = null, m = g, w = g = 0, x = null, n = h.next();m !== null && !n.done; w++, n = h.next()) {
      m.index > w ? (x = m, m = null) : x = m.sibling;
      var t = r(e, m, n.value, k);
      if (t === null) {
        m === null && (m = x);
        break;
      }
      a && m && t.alternate === null && b(e, m);
      g = f(t, g, w);
      u === null ? l = t : u.sibling = t;
      u = t;
      m = x;
    }
    if (n.done)
      return c(e, m), I2 && tg(e, w), l;
    if (m === null) {
      for (;!n.done; w++, n = h.next())
        n = q(e, n.value, k), n !== null && (g = f(n, g, w), u === null ? l = n : u.sibling = n, u = n);
      I2 && tg(e, w);
      return l;
    }
    for (m = d(e, m);!n.done; w++, n = h.next())
      n = y(m, e, w, n.value, k), n !== null && (a && n.alternate !== null && m.delete(n.key === null ? w : n.key), g = f(n, g, w), u === null ? l = n : u.sibling = n, u = n);
    a && m.forEach(function(a) {
      return b(e, a);
    });
    I2 && tg(e, w);
    return l;
  }
  function J(a, d, f, h) {
    typeof f === "object" && f !== null && f.type === ya && f.key === null && (f = f.props.children);
    if (typeof f === "object" && f !== null) {
      switch (f.$$typeof) {
        case va:
          a: {
            for (var k = f.key, l = d;l !== null; ) {
              if (l.key === k) {
                k = f.type;
                if (k === ya) {
                  if (l.tag === 7) {
                    c(a, l.sibling);
                    d = e(l, f.props.children);
                    d.return = a;
                    a = d;
                    break a;
                  }
                } else if (l.elementType === k || typeof k === "object" && k !== null && k.$$typeof === Ha && Ng(k) === l.type) {
                  c(a, l.sibling);
                  d = e(l, f.props);
                  d.ref = Lg(a, l, f);
                  d.return = a;
                  a = d;
                  break a;
                }
                c(a, l);
                break;
              } else
                b(a, l);
              l = l.sibling;
            }
            f.type === ya ? (d = Tg(f.props.children, a.mode, h, f.key), d.return = a, a = d) : (h = Rg(f.type, f.key, f.props, null, a.mode, h), h.ref = Lg(a, d, f), h.return = a, a = h);
          }
          return g(a);
        case wa:
          a: {
            for (l = f.key;d !== null; ) {
              if (d.key === l)
                if (d.tag === 4 && d.stateNode.containerInfo === f.containerInfo && d.stateNode.implementation === f.implementation) {
                  c(a, d.sibling);
                  d = e(d, f.children || []);
                  d.return = a;
                  a = d;
                  break a;
                } else {
                  c(a, d);
                  break;
                }
              else
                b(a, d);
              d = d.sibling;
            }
            d = Sg(f, a.mode, h);
            d.return = a;
            a = d;
          }
          return g(a);
        case Ha:
          return l = f._init, J(a, d, l(f._payload), h);
      }
      if (eb(f))
        return n(a, d, f, h);
      if (Ka(f))
        return t(a, d, f, h);
      Mg(a, f);
    }
    return typeof f === "string" && f !== "" || typeof f === "number" ? (f = "" + f, d !== null && d.tag === 6 ? (c(a, d.sibling), d = e(d, f), d.return = a, a = d) : (c(a, d), d = Qg(f, a.mode, h), d.return = a, a = d), g(a)) : c(a, d);
  }
  return J;
}
function $g() {
  Zg = Yg = Xg = null;
}
function ah(a) {
  var b = Wg.current;
  E2(Wg);
  a._currentValue = b;
}
function bh(a, b, c) {
  for (;a !== null; ) {
    var d = a.alternate;
    (a.childLanes & b) !== b ? (a.childLanes |= b, d !== null && (d.childLanes |= b)) : d !== null && (d.childLanes & b) !== b && (d.childLanes |= b);
    if (a === c)
      break;
    a = a.return;
  }
}
function ch(a, b) {
  Xg = a;
  Zg = Yg = null;
  a = a.dependencies;
  a !== null && a.firstContext !== null && ((a.lanes & b) !== 0 && (dh = true), a.firstContext = null);
}
function eh(a) {
  var b = a._currentValue;
  if (Zg !== a)
    if (a = { context: a, memoizedValue: b, next: null }, Yg === null) {
      if (Xg === null)
        throw Error(p2(308));
      Yg = a;
      Xg.dependencies = { lanes: 0, firstContext: a };
    } else
      Yg = Yg.next = a;
  return b;
}
function gh(a) {
  fh === null ? fh = [a] : fh.push(a);
}
function hh(a, b, c, d) {
  var e = b.interleaved;
  e === null ? (c.next = c, gh(b)) : (c.next = e.next, e.next = c);
  b.interleaved = c;
  return ih(a, d);
}
function ih(a, b) {
  a.lanes |= b;
  var c = a.alternate;
  c !== null && (c.lanes |= b);
  c = a;
  for (a = a.return;a !== null; )
    a.childLanes |= b, c = a.alternate, c !== null && (c.childLanes |= b), c = a, a = a.return;
  return c.tag === 3 ? c.stateNode : null;
}
function kh(a) {
  a.updateQueue = { baseState: a.memoizedState, firstBaseUpdate: null, lastBaseUpdate: null, shared: { pending: null, interleaved: null, lanes: 0 }, effects: null };
}
function lh(a, b) {
  a = a.updateQueue;
  b.updateQueue === a && (b.updateQueue = { baseState: a.baseState, firstBaseUpdate: a.firstBaseUpdate, lastBaseUpdate: a.lastBaseUpdate, shared: a.shared, effects: a.effects });
}
function mh(a, b) {
  return { eventTime: a, lane: b, tag: 0, payload: null, callback: null, next: null };
}
function nh(a, b, c) {
  var d = a.updateQueue;
  if (d === null)
    return null;
  d = d.shared;
  if ((K2 & 2) !== 0) {
    var e = d.pending;
    e === null ? b.next = b : (b.next = e.next, e.next = b);
    d.pending = b;
    return ih(a, c);
  }
  e = d.interleaved;
  e === null ? (b.next = b, gh(d)) : (b.next = e.next, e.next = b);
  d.interleaved = b;
  return ih(a, c);
}
function oh(a, b, c) {
  b = b.updateQueue;
  if (b !== null && (b = b.shared, (c & 4194240) !== 0)) {
    var d = b.lanes;
    d &= a.pendingLanes;
    c |= d;
    b.lanes = c;
    Cc(a, c);
  }
}
function ph(a, b) {
  var c = a.updateQueue, d = a.alternate;
  if (d !== null && (d = d.updateQueue, c === d)) {
    var e = null, f = null;
    c = c.firstBaseUpdate;
    if (c !== null) {
      do {
        var g = { eventTime: c.eventTime, lane: c.lane, tag: c.tag, payload: c.payload, callback: c.callback, next: null };
        f === null ? e = f = g : f = f.next = g;
        c = c.next;
      } while (c !== null);
      f === null ? e = f = b : f = f.next = b;
    } else
      e = f = b;
    c = { baseState: d.baseState, firstBaseUpdate: e, lastBaseUpdate: f, shared: d.shared, effects: d.effects };
    a.updateQueue = c;
    return;
  }
  a = c.lastBaseUpdate;
  a === null ? c.firstBaseUpdate = b : a.next = b;
  c.lastBaseUpdate = b;
}
function qh(a, b, c, d) {
  var e = a.updateQueue;
  jh = false;
  var f = e.firstBaseUpdate, g = e.lastBaseUpdate, h = e.shared.pending;
  if (h !== null) {
    e.shared.pending = null;
    var k = h, l = k.next;
    k.next = null;
    g === null ? f = l : g.next = l;
    g = k;
    var m = a.alternate;
    m !== null && (m = m.updateQueue, h = m.lastBaseUpdate, h !== g && (h === null ? m.firstBaseUpdate = l : h.next = l, m.lastBaseUpdate = k));
  }
  if (f !== null) {
    var q = e.baseState;
    g = 0;
    m = l = k = null;
    h = f;
    do {
      var r = h.lane, y = h.eventTime;
      if ((d & r) === r) {
        m !== null && (m = m.next = {
          eventTime: y,
          lane: 0,
          tag: h.tag,
          payload: h.payload,
          callback: h.callback,
          next: null
        });
        a: {
          var n = a, t = h;
          r = b;
          y = c;
          switch (t.tag) {
            case 1:
              n = t.payload;
              if (typeof n === "function") {
                q = n.call(y, q, r);
                break a;
              }
              q = n;
              break a;
            case 3:
              n.flags = n.flags & -65537 | 128;
            case 0:
              n = t.payload;
              r = typeof n === "function" ? n.call(y, q, r) : n;
              if (r === null || r === undefined)
                break a;
              q = A2({}, q, r);
              break a;
            case 2:
              jh = true;
          }
        }
        h.callback !== null && h.lane !== 0 && (a.flags |= 64, r = e.effects, r === null ? e.effects = [h] : r.push(h));
      } else
        y = { eventTime: y, lane: r, tag: h.tag, payload: h.payload, callback: h.callback, next: null }, m === null ? (l = m = y, k = q) : m = m.next = y, g |= r;
      h = h.next;
      if (h === null)
        if (h = e.shared.pending, h === null)
          break;
        else
          r = h, h = r.next, r.next = null, e.lastBaseUpdate = r, e.shared.pending = null;
    } while (1);
    m === null && (k = q);
    e.baseState = k;
    e.firstBaseUpdate = l;
    e.lastBaseUpdate = m;
    b = e.shared.interleaved;
    if (b !== null) {
      e = b;
      do
        g |= e.lane, e = e.next;
      while (e !== b);
    } else
      f === null && (e.shared.lanes = 0);
    rh |= g;
    a.lanes = g;
    a.memoizedState = q;
  }
}
function sh(a, b, c) {
  a = b.effects;
  b.effects = null;
  if (a !== null)
    for (b = 0;b < a.length; b++) {
      var d = a[b], e = d.callback;
      if (e !== null) {
        d.callback = null;
        d = c;
        if (typeof e !== "function")
          throw Error(p2(191, e));
        e.call(d);
      }
    }
}
function xh(a) {
  if (a === th)
    throw Error(p2(174));
  return a;
}
function yh(a, b) {
  G2(wh, b);
  G2(vh, a);
  G2(uh, th);
  a = b.nodeType;
  switch (a) {
    case 9:
    case 11:
      b = (b = b.documentElement) ? b.namespaceURI : lb(null, "");
      break;
    default:
      a = a === 8 ? b.parentNode : b, b = a.namespaceURI || null, a = a.tagName, b = lb(b, a);
  }
  E2(uh);
  G2(uh, b);
}
function zh() {
  E2(uh);
  E2(vh);
  E2(wh);
}
function Ah(a) {
  xh(wh.current);
  var b = xh(uh.current);
  var c = lb(b, a.type);
  b !== c && (G2(vh, a), G2(uh, c));
}
function Bh(a) {
  vh.current === a && (E2(uh), E2(vh));
}
function Ch(a) {
  for (var b = a;b !== null; ) {
    if (b.tag === 13) {
      var c = b.memoizedState;
      if (c !== null && (c = c.dehydrated, c === null || c.data === "$?" || c.data === "$!"))
        return b;
    } else if (b.tag === 19 && b.memoizedProps.revealOrder !== undefined) {
      if ((b.flags & 128) !== 0)
        return b;
    } else if (b.child !== null) {
      b.child.return = b;
      b = b.child;
      continue;
    }
    if (b === a)
      break;
    for (;b.sibling === null; ) {
      if (b.return === null || b.return === a)
        return null;
      b = b.return;
    }
    b.sibling.return = b.return;
    b = b.sibling;
  }
  return null;
}
function Eh() {
  for (var a = 0;a < Dh.length; a++)
    Dh[a]._workInProgressVersionPrimary = null;
  Dh.length = 0;
}
function P2() {
  throw Error(p2(321));
}
function Mh(a, b) {
  if (b === null)
    return false;
  for (var c = 0;c < b.length && c < a.length; c++)
    if (!He(a[c], b[c]))
      return false;
  return true;
}
function Nh(a, b, c, d, e, f) {
  Hh = f;
  M2 = b;
  b.memoizedState = null;
  b.updateQueue = null;
  b.lanes = 0;
  Fh.current = a === null || a.memoizedState === null ? Oh : Ph;
  a = c(d, e);
  if (Jh) {
    f = 0;
    do {
      Jh = false;
      Kh = 0;
      if (25 <= f)
        throw Error(p2(301));
      f += 1;
      O2 = N2 = null;
      b.updateQueue = null;
      Fh.current = Qh;
      a = c(d, e);
    } while (Jh);
  }
  Fh.current = Rh;
  b = N2 !== null && N2.next !== null;
  Hh = 0;
  O2 = N2 = M2 = null;
  Ih = false;
  if (b)
    throw Error(p2(300));
  return a;
}
function Sh() {
  var a = Kh !== 0;
  Kh = 0;
  return a;
}
function Th() {
  var a = { memoizedState: null, baseState: null, baseQueue: null, queue: null, next: null };
  O2 === null ? M2.memoizedState = O2 = a : O2 = O2.next = a;
  return O2;
}
function Uh() {
  if (N2 === null) {
    var a = M2.alternate;
    a = a !== null ? a.memoizedState : null;
  } else
    a = N2.next;
  var b = O2 === null ? M2.memoizedState : O2.next;
  if (b !== null)
    O2 = b, N2 = a;
  else {
    if (a === null)
      throw Error(p2(310));
    N2 = a;
    a = { memoizedState: N2.memoizedState, baseState: N2.baseState, baseQueue: N2.baseQueue, queue: N2.queue, next: null };
    O2 === null ? M2.memoizedState = O2 = a : O2 = O2.next = a;
  }
  return O2;
}
function Vh(a, b) {
  return typeof b === "function" ? b(a) : b;
}
function Wh(a) {
  var b = Uh(), c = b.queue;
  if (c === null)
    throw Error(p2(311));
  c.lastRenderedReducer = a;
  var d = N2, e = d.baseQueue, f = c.pending;
  if (f !== null) {
    if (e !== null) {
      var g = e.next;
      e.next = f.next;
      f.next = g;
    }
    d.baseQueue = e = f;
    c.pending = null;
  }
  if (e !== null) {
    f = e.next;
    d = d.baseState;
    var h = g = null, k = null, l = f;
    do {
      var m = l.lane;
      if ((Hh & m) === m)
        k !== null && (k = k.next = { lane: 0, action: l.action, hasEagerState: l.hasEagerState, eagerState: l.eagerState, next: null }), d = l.hasEagerState ? l.eagerState : a(d, l.action);
      else {
        var q = {
          lane: m,
          action: l.action,
          hasEagerState: l.hasEagerState,
          eagerState: l.eagerState,
          next: null
        };
        k === null ? (h = k = q, g = d) : k = k.next = q;
        M2.lanes |= m;
        rh |= m;
      }
      l = l.next;
    } while (l !== null && l !== f);
    k === null ? g = d : k.next = h;
    He(d, b.memoizedState) || (dh = true);
    b.memoizedState = d;
    b.baseState = g;
    b.baseQueue = k;
    c.lastRenderedState = d;
  }
  a = c.interleaved;
  if (a !== null) {
    e = a;
    do
      f = e.lane, M2.lanes |= f, rh |= f, e = e.next;
    while (e !== a);
  } else
    e === null && (c.lanes = 0);
  return [b.memoizedState, c.dispatch];
}
function Xh(a) {
  var b = Uh(), c = b.queue;
  if (c === null)
    throw Error(p2(311));
  c.lastRenderedReducer = a;
  var { dispatch: d, pending: e } = c, f = b.memoizedState;
  if (e !== null) {
    c.pending = null;
    var g = e = e.next;
    do
      f = a(f, g.action), g = g.next;
    while (g !== e);
    He(f, b.memoizedState) || (dh = true);
    b.memoizedState = f;
    b.baseQueue === null && (b.baseState = f);
    c.lastRenderedState = f;
  }
  return [f, d];
}
function Yh() {}
function Zh(a, b) {
  var c = M2, d = Uh(), e = b(), f = !He(d.memoizedState, e);
  f && (d.memoizedState = e, dh = true);
  d = d.queue;
  $h(ai.bind(null, c, d, a), [a]);
  if (d.getSnapshot !== b || f || O2 !== null && O2.memoizedState.tag & 1) {
    c.flags |= 2048;
    bi(9, ci.bind(null, c, d, e, b), undefined, null);
    if (Q2 === null)
      throw Error(p2(349));
    (Hh & 30) !== 0 || di(c, b, e);
  }
  return e;
}
function di(a, b, c) {
  a.flags |= 16384;
  a = { getSnapshot: b, value: c };
  b = M2.updateQueue;
  b === null ? (b = { lastEffect: null, stores: null }, M2.updateQueue = b, b.stores = [a]) : (c = b.stores, c === null ? b.stores = [a] : c.push(a));
}
function ci(a, b, c, d) {
  b.value = c;
  b.getSnapshot = d;
  ei(b) && fi(a);
}
function ai(a, b, c) {
  return c(function() {
    ei(b) && fi(a);
  });
}
function ei(a) {
  var b = a.getSnapshot;
  a = a.value;
  try {
    var c = b();
    return !He(a, c);
  } catch (d) {
    return true;
  }
}
function fi(a) {
  var b = ih(a, 1);
  b !== null && gi(b, a, 1, -1);
}
function hi(a) {
  var b = Th();
  typeof a === "function" && (a = a());
  b.memoizedState = b.baseState = a;
  a = { pending: null, interleaved: null, lanes: 0, dispatch: null, lastRenderedReducer: Vh, lastRenderedState: a };
  b.queue = a;
  a = a.dispatch = ii.bind(null, M2, a);
  return [b.memoizedState, a];
}
function bi(a, b, c, d) {
  a = { tag: a, create: b, destroy: c, deps: d, next: null };
  b = M2.updateQueue;
  b === null ? (b = { lastEffect: null, stores: null }, M2.updateQueue = b, b.lastEffect = a.next = a) : (c = b.lastEffect, c === null ? b.lastEffect = a.next = a : (d = c.next, c.next = a, a.next = d, b.lastEffect = a));
  return a;
}
function ji() {
  return Uh().memoizedState;
}
function ki(a, b, c, d) {
  var e = Th();
  M2.flags |= a;
  e.memoizedState = bi(1 | b, c, undefined, d === undefined ? null : d);
}
function li(a, b, c, d) {
  var e = Uh();
  d = d === undefined ? null : d;
  var f = undefined;
  if (N2 !== null) {
    var g = N2.memoizedState;
    f = g.destroy;
    if (d !== null && Mh(d, g.deps)) {
      e.memoizedState = bi(b, c, f, d);
      return;
    }
  }
  M2.flags |= a;
  e.memoizedState = bi(1 | b, c, f, d);
}
function mi(a, b) {
  return ki(8390656, 8, a, b);
}
function $h(a, b) {
  return li(2048, 8, a, b);
}
function ni(a, b) {
  return li(4, 2, a, b);
}
function oi(a, b) {
  return li(4, 4, a, b);
}
function pi(a, b) {
  if (typeof b === "function")
    return a = a(), b(a), function() {
      b(null);
    };
  if (b !== null && b !== undefined)
    return a = a(), b.current = a, function() {
      b.current = null;
    };
}
function qi(a, b, c) {
  c = c !== null && c !== undefined ? c.concat([a]) : null;
  return li(4, 4, pi.bind(null, b, a), c);
}
function ri() {}
function si(a, b) {
  var c = Uh();
  b = b === undefined ? null : b;
  var d = c.memoizedState;
  if (d !== null && b !== null && Mh(b, d[1]))
    return d[0];
  c.memoizedState = [a, b];
  return a;
}
function ti(a, b) {
  var c = Uh();
  b = b === undefined ? null : b;
  var d = c.memoizedState;
  if (d !== null && b !== null && Mh(b, d[1]))
    return d[0];
  a = a();
  c.memoizedState = [a, b];
  return a;
}
function ui(a, b, c) {
  if ((Hh & 21) === 0)
    return a.baseState && (a.baseState = false, dh = true), a.memoizedState = c;
  He(c, b) || (c = yc(), M2.lanes |= c, rh |= c, a.baseState = true);
  return b;
}
function vi(a, b) {
  var c = C2;
  C2 = c !== 0 && 4 > c ? c : 4;
  a(true);
  var d = Gh.transition;
  Gh.transition = {};
  try {
    a(false), b();
  } finally {
    C2 = c, Gh.transition = d;
  }
}
function wi() {
  return Uh().memoizedState;
}
function xi(a, b, c) {
  var d = yi(a);
  c = { lane: d, action: c, hasEagerState: false, eagerState: null, next: null };
  if (zi(a))
    Ai(b, c);
  else if (c = hh(a, b, c, d), c !== null) {
    var e = R2();
    gi(c, a, d, e);
    Bi(c, b, d);
  }
}
function ii(a, b, c) {
  var d = yi(a), e = { lane: d, action: c, hasEagerState: false, eagerState: null, next: null };
  if (zi(a))
    Ai(b, e);
  else {
    var f = a.alternate;
    if (a.lanes === 0 && (f === null || f.lanes === 0) && (f = b.lastRenderedReducer, f !== null))
      try {
        var g = b.lastRenderedState, h = f(g, c);
        e.hasEagerState = true;
        e.eagerState = h;
        if (He(h, g)) {
          var k = b.interleaved;
          k === null ? (e.next = e, gh(b)) : (e.next = k.next, k.next = e);
          b.interleaved = e;
          return;
        }
      } catch (l) {} finally {}
    c = hh(a, b, e, d);
    c !== null && (e = R2(), gi(c, a, d, e), Bi(c, b, d));
  }
}
function zi(a) {
  var b = a.alternate;
  return a === M2 || b !== null && b === M2;
}
function Ai(a, b) {
  Jh = Ih = true;
  var c = a.pending;
  c === null ? b.next = b : (b.next = c.next, c.next = b);
  a.pending = b;
}
function Bi(a, b, c) {
  if ((c & 4194240) !== 0) {
    var d = b.lanes;
    d &= a.pendingLanes;
    c |= d;
    b.lanes = c;
    Cc(a, c);
  }
}
function Ci(a, b) {
  if (a && a.defaultProps) {
    b = A2({}, b);
    a = a.defaultProps;
    for (var c in a)
      b[c] === undefined && (b[c] = a[c]);
    return b;
  }
  return b;
}
function Di(a, b, c, d) {
  b = a.memoizedState;
  c = c(d, b);
  c = c === null || c === undefined ? b : A2({}, b, c);
  a.memoizedState = c;
  a.lanes === 0 && (a.updateQueue.baseState = c);
}
function Fi(a, b, c, d, e, f, g) {
  a = a.stateNode;
  return typeof a.shouldComponentUpdate === "function" ? a.shouldComponentUpdate(d, f, g) : b.prototype && b.prototype.isPureReactComponent ? !Ie(c, d) || !Ie(e, f) : true;
}
function Gi(a, b, c) {
  var d = false, e = Vf;
  var f = b.contextType;
  typeof f === "object" && f !== null ? f = eh(f) : (e = Zf(b) ? Xf : H2.current, d = b.contextTypes, f = (d = d !== null && d !== undefined) ? Yf(a, e) : Vf);
  b = new b(c, f);
  a.memoizedState = b.state !== null && b.state !== undefined ? b.state : null;
  b.updater = Ei;
  a.stateNode = b;
  b._reactInternals = a;
  d && (a = a.stateNode, a.__reactInternalMemoizedUnmaskedChildContext = e, a.__reactInternalMemoizedMaskedChildContext = f);
  return b;
}
function Hi(a, b, c, d) {
  a = b.state;
  typeof b.componentWillReceiveProps === "function" && b.componentWillReceiveProps(c, d);
  typeof b.UNSAFE_componentWillReceiveProps === "function" && b.UNSAFE_componentWillReceiveProps(c, d);
  b.state !== a && Ei.enqueueReplaceState(b, b.state, null);
}
function Ii(a, b, c, d) {
  var e = a.stateNode;
  e.props = c;
  e.state = a.memoizedState;
  e.refs = {};
  kh(a);
  var f = b.contextType;
  typeof f === "object" && f !== null ? e.context = eh(f) : (f = Zf(b) ? Xf : H2.current, e.context = Yf(a, f));
  e.state = a.memoizedState;
  f = b.getDerivedStateFromProps;
  typeof f === "function" && (Di(a, b, f, c), e.state = a.memoizedState);
  typeof b.getDerivedStateFromProps === "function" || typeof e.getSnapshotBeforeUpdate === "function" || typeof e.UNSAFE_componentWillMount !== "function" && typeof e.componentWillMount !== "function" || (b = e.state, typeof e.componentWillMount === "function" && e.componentWillMount(), typeof e.UNSAFE_componentWillMount === "function" && e.UNSAFE_componentWillMount(), b !== e.state && Ei.enqueueReplaceState(e, e.state, null), qh(a, c, e, d), e.state = a.memoizedState);
  typeof e.componentDidMount === "function" && (a.flags |= 4194308);
}
function Ji(a, b) {
  try {
    var c = "", d = b;
    do
      c += Pa(d), d = d.return;
    while (d);
    var e = c;
  } catch (f) {
    e = `
Error generating stack: ` + f.message + `
` + f.stack;
  }
  return { value: a, source: b, stack: e, digest: null };
}
function Ki(a, b, c) {
  return { value: a, source: null, stack: c != null ? c : null, digest: b != null ? b : null };
}
function Li(a, b) {
  try {
    console.error(b.value);
  } catch (c) {
    setTimeout(function() {
      throw c;
    });
  }
}
function Ni(a, b, c) {
  c = mh(-1, c);
  c.tag = 3;
  c.payload = { element: null };
  var d = b.value;
  c.callback = function() {
    Oi || (Oi = true, Pi = d);
    Li(a, b);
  };
  return c;
}
function Qi(a, b, c) {
  c = mh(-1, c);
  c.tag = 3;
  var d = a.type.getDerivedStateFromError;
  if (typeof d === "function") {
    var e = b.value;
    c.payload = function() {
      return d(e);
    };
    c.callback = function() {
      Li(a, b);
    };
  }
  var f = a.stateNode;
  f !== null && typeof f.componentDidCatch === "function" && (c.callback = function() {
    Li(a, b);
    typeof d !== "function" && (Ri === null ? Ri = new Set([this]) : Ri.add(this));
    var c = b.stack;
    this.componentDidCatch(b.value, { componentStack: c !== null ? c : "" });
  });
  return c;
}
function Si(a, b, c) {
  var d = a.pingCache;
  if (d === null) {
    d = a.pingCache = new Mi;
    var e = new Set;
    d.set(b, e);
  } else
    e = d.get(b), e === undefined && (e = new Set, d.set(b, e));
  e.has(c) || (e.add(c), a = Ti.bind(null, a, b, c), b.then(a, a));
}
function Ui(a) {
  do {
    var b;
    if (b = a.tag === 13)
      b = a.memoizedState, b = b !== null ? b.dehydrated !== null ? true : false : true;
    if (b)
      return a;
    a = a.return;
  } while (a !== null);
  return null;
}
function Vi(a, b, c, d, e) {
  if ((a.mode & 1) === 0)
    return a === b ? a.flags |= 65536 : (a.flags |= 128, c.flags |= 131072, c.flags &= -52805, c.tag === 1 && (c.alternate === null ? c.tag = 17 : (b = mh(-1, 1), b.tag = 2, nh(c, b, 1))), c.lanes |= 1), a;
  a.flags |= 65536;
  a.lanes = e;
  return a;
}
function Xi(a, b, c, d) {
  b.child = a === null ? Vg(b, null, c, d) : Ug(b, a.child, c, d);
}
function Yi(a, b, c, d, e) {
  c = c.render;
  var f = b.ref;
  ch(b, e);
  d = Nh(a, b, c, d, f, e);
  c = Sh();
  if (a !== null && !dh)
    return b.updateQueue = a.updateQueue, b.flags &= -2053, a.lanes &= ~e, Zi(a, b, e);
  I2 && c && vg(b);
  b.flags |= 1;
  Xi(a, b, d, e);
  return b.child;
}
function $i(a, b, c, d, e) {
  if (a === null) {
    var f = c.type;
    if (typeof f === "function" && !aj(f) && f.defaultProps === undefined && c.compare === null && c.defaultProps === undefined)
      return b.tag = 15, b.type = f, bj(a, b, f, d, e);
    a = Rg(c.type, null, d, b, b.mode, e);
    a.ref = b.ref;
    a.return = b;
    return b.child = a;
  }
  f = a.child;
  if ((a.lanes & e) === 0) {
    var g = f.memoizedProps;
    c = c.compare;
    c = c !== null ? c : Ie;
    if (c(g, d) && a.ref === b.ref)
      return Zi(a, b, e);
  }
  b.flags |= 1;
  a = Pg(f, d);
  a.ref = b.ref;
  a.return = b;
  return b.child = a;
}
function bj(a, b, c, d, e) {
  if (a !== null) {
    var f = a.memoizedProps;
    if (Ie(f, d) && a.ref === b.ref)
      if (dh = false, b.pendingProps = d = f, (a.lanes & e) !== 0)
        (a.flags & 131072) !== 0 && (dh = true);
      else
        return b.lanes = a.lanes, Zi(a, b, e);
  }
  return cj(a, b, c, d, e);
}
function dj(a, b, c) {
  var d = b.pendingProps, e = d.children, f = a !== null ? a.memoizedState : null;
  if (d.mode === "hidden")
    if ((b.mode & 1) === 0)
      b.memoizedState = { baseLanes: 0, cachePool: null, transitions: null }, G2(ej, fj), fj |= c;
    else {
      if ((c & 1073741824) === 0)
        return a = f !== null ? f.baseLanes | c : c, b.lanes = b.childLanes = 1073741824, b.memoizedState = { baseLanes: a, cachePool: null, transitions: null }, b.updateQueue = null, G2(ej, fj), fj |= a, null;
      b.memoizedState = { baseLanes: 0, cachePool: null, transitions: null };
      d = f !== null ? f.baseLanes : c;
      G2(ej, fj);
      fj |= d;
    }
  else
    f !== null ? (d = f.baseLanes | c, b.memoizedState = null) : d = c, G2(ej, fj), fj |= d;
  Xi(a, b, e, c);
  return b.child;
}
function gj(a, b) {
  var c = b.ref;
  if (a === null && c !== null || a !== null && a.ref !== c)
    b.flags |= 512, b.flags |= 2097152;
}
function cj(a, b, c, d, e) {
  var f = Zf(c) ? Xf : H2.current;
  f = Yf(b, f);
  ch(b, e);
  c = Nh(a, b, c, d, f, e);
  d = Sh();
  if (a !== null && !dh)
    return b.updateQueue = a.updateQueue, b.flags &= -2053, a.lanes &= ~e, Zi(a, b, e);
  I2 && d && vg(b);
  b.flags |= 1;
  Xi(a, b, c, e);
  return b.child;
}
function hj(a, b, c, d, e) {
  if (Zf(c)) {
    var f = true;
    cg(b);
  } else
    f = false;
  ch(b, e);
  if (b.stateNode === null)
    ij(a, b), Gi(b, c, d), Ii(b, c, d, e), d = true;
  else if (a === null) {
    var { stateNode: g, memoizedProps: h } = b;
    g.props = h;
    var k = g.context, l = c.contextType;
    typeof l === "object" && l !== null ? l = eh(l) : (l = Zf(c) ? Xf : H2.current, l = Yf(b, l));
    var m = c.getDerivedStateFromProps, q = typeof m === "function" || typeof g.getSnapshotBeforeUpdate === "function";
    q || typeof g.UNSAFE_componentWillReceiveProps !== "function" && typeof g.componentWillReceiveProps !== "function" || (h !== d || k !== l) && Hi(b, g, d, l);
    jh = false;
    var r = b.memoizedState;
    g.state = r;
    qh(b, d, g, e);
    k = b.memoizedState;
    h !== d || r !== k || Wf.current || jh ? (typeof m === "function" && (Di(b, c, m, d), k = b.memoizedState), (h = jh || Fi(b, c, h, d, r, k, l)) ? (q || typeof g.UNSAFE_componentWillMount !== "function" && typeof g.componentWillMount !== "function" || (typeof g.componentWillMount === "function" && g.componentWillMount(), typeof g.UNSAFE_componentWillMount === "function" && g.UNSAFE_componentWillMount()), typeof g.componentDidMount === "function" && (b.flags |= 4194308)) : (typeof g.componentDidMount === "function" && (b.flags |= 4194308), b.memoizedProps = d, b.memoizedState = k), g.props = d, g.state = k, g.context = l, d = h) : (typeof g.componentDidMount === "function" && (b.flags |= 4194308), d = false);
  } else {
    g = b.stateNode;
    lh(a, b);
    h = b.memoizedProps;
    l = b.type === b.elementType ? h : Ci(b.type, h);
    g.props = l;
    q = b.pendingProps;
    r = g.context;
    k = c.contextType;
    typeof k === "object" && k !== null ? k = eh(k) : (k = Zf(c) ? Xf : H2.current, k = Yf(b, k));
    var y = c.getDerivedStateFromProps;
    (m = typeof y === "function" || typeof g.getSnapshotBeforeUpdate === "function") || typeof g.UNSAFE_componentWillReceiveProps !== "function" && typeof g.componentWillReceiveProps !== "function" || (h !== q || r !== k) && Hi(b, g, d, k);
    jh = false;
    r = b.memoizedState;
    g.state = r;
    qh(b, d, g, e);
    var n = b.memoizedState;
    h !== q || r !== n || Wf.current || jh ? (typeof y === "function" && (Di(b, c, y, d), n = b.memoizedState), (l = jh || Fi(b, c, l, d, r, n, k) || false) ? (m || typeof g.UNSAFE_componentWillUpdate !== "function" && typeof g.componentWillUpdate !== "function" || (typeof g.componentWillUpdate === "function" && g.componentWillUpdate(d, n, k), typeof g.UNSAFE_componentWillUpdate === "function" && g.UNSAFE_componentWillUpdate(d, n, k)), typeof g.componentDidUpdate === "function" && (b.flags |= 4), typeof g.getSnapshotBeforeUpdate === "function" && (b.flags |= 1024)) : (typeof g.componentDidUpdate !== "function" || h === a.memoizedProps && r === a.memoizedState || (b.flags |= 4), typeof g.getSnapshotBeforeUpdate !== "function" || h === a.memoizedProps && r === a.memoizedState || (b.flags |= 1024), b.memoizedProps = d, b.memoizedState = n), g.props = d, g.state = n, g.context = k, d = l) : (typeof g.componentDidUpdate !== "function" || h === a.memoizedProps && r === a.memoizedState || (b.flags |= 4), typeof g.getSnapshotBeforeUpdate !== "function" || h === a.memoizedProps && r === a.memoizedState || (b.flags |= 1024), d = false);
  }
  return jj(a, b, c, d, f, e);
}
function jj(a, b, c, d, e, f) {
  gj(a, b);
  var g = (b.flags & 128) !== 0;
  if (!d && !g)
    return e && dg(b, c, false), Zi(a, b, f);
  d = b.stateNode;
  Wi.current = b;
  var h = g && typeof c.getDerivedStateFromError !== "function" ? null : d.render();
  b.flags |= 1;
  a !== null && g ? (b.child = Ug(b, a.child, null, f), b.child = Ug(b, null, h, f)) : Xi(a, b, h, f);
  b.memoizedState = d.state;
  e && dg(b, c, true);
  return b.child;
}
function kj(a) {
  var b = a.stateNode;
  b.pendingContext ? ag(a, b.pendingContext, b.pendingContext !== b.context) : b.context && ag(a, b.context, false);
  yh(a, b.containerInfo);
}
function lj(a, b, c, d, e) {
  Ig();
  Jg(e);
  b.flags |= 256;
  Xi(a, b, c, d);
  return b.child;
}
function nj(a) {
  return { baseLanes: a, cachePool: null, transitions: null };
}
function oj(a, b, c) {
  var d = b.pendingProps, e = L2.current, f = false, g = (b.flags & 128) !== 0, h;
  (h = g) || (h = a !== null && a.memoizedState === null ? false : (e & 2) !== 0);
  if (h)
    f = true, b.flags &= -129;
  else if (a === null || a.memoizedState !== null)
    e |= 1;
  G2(L2, e & 1);
  if (a === null) {
    Eg(b);
    a = b.memoizedState;
    if (a !== null && (a = a.dehydrated, a !== null))
      return (b.mode & 1) === 0 ? b.lanes = 1 : a.data === "$!" ? b.lanes = 8 : b.lanes = 1073741824, null;
    g = d.children;
    a = d.fallback;
    return f ? (d = b.mode, f = b.child, g = { mode: "hidden", children: g }, (d & 1) === 0 && f !== null ? (f.childLanes = 0, f.pendingProps = g) : f = pj(g, d, 0, null), a = Tg(a, d, c, null), f.return = b, a.return = b, f.sibling = a, b.child = f, b.child.memoizedState = nj(c), b.memoizedState = mj, a) : qj(b, g);
  }
  e = a.memoizedState;
  if (e !== null && (h = e.dehydrated, h !== null))
    return rj(a, b, g, d, h, e, c);
  if (f) {
    f = d.fallback;
    g = b.mode;
    e = a.child;
    h = e.sibling;
    var k = { mode: "hidden", children: d.children };
    (g & 1) === 0 && b.child !== e ? (d = b.child, d.childLanes = 0, d.pendingProps = k, b.deletions = null) : (d = Pg(e, k), d.subtreeFlags = e.subtreeFlags & 14680064);
    h !== null ? f = Pg(h, f) : (f = Tg(f, g, c, null), f.flags |= 2);
    f.return = b;
    d.return = b;
    d.sibling = f;
    b.child = d;
    d = f;
    f = b.child;
    g = a.child.memoizedState;
    g = g === null ? nj(c) : { baseLanes: g.baseLanes | c, cachePool: null, transitions: g.transitions };
    f.memoizedState = g;
    f.childLanes = a.childLanes & ~c;
    b.memoizedState = mj;
    return d;
  }
  f = a.child;
  a = f.sibling;
  d = Pg(f, { mode: "visible", children: d.children });
  (b.mode & 1) === 0 && (d.lanes = c);
  d.return = b;
  d.sibling = null;
  a !== null && (c = b.deletions, c === null ? (b.deletions = [a], b.flags |= 16) : c.push(a));
  b.child = d;
  b.memoizedState = null;
  return d;
}
function qj(a, b) {
  b = pj({ mode: "visible", children: b }, a.mode, 0, null);
  b.return = a;
  return a.child = b;
}
function sj(a, b, c, d) {
  d !== null && Jg(d);
  Ug(b, a.child, null, c);
  a = qj(b, b.pendingProps.children);
  a.flags |= 2;
  b.memoizedState = null;
  return a;
}
function rj(a, b, c, d, e, f, g) {
  if (c) {
    if (b.flags & 256)
      return b.flags &= -257, d = Ki(Error(p2(422))), sj(a, b, g, d);
    if (b.memoizedState !== null)
      return b.child = a.child, b.flags |= 128, null;
    f = d.fallback;
    e = b.mode;
    d = pj({ mode: "visible", children: d.children }, e, 0, null);
    f = Tg(f, e, g, null);
    f.flags |= 2;
    d.return = b;
    f.return = b;
    d.sibling = f;
    b.child = d;
    (b.mode & 1) !== 0 && Ug(b, a.child, null, g);
    b.child.memoizedState = nj(g);
    b.memoizedState = mj;
    return f;
  }
  if ((b.mode & 1) === 0)
    return sj(a, b, g, null);
  if (e.data === "$!") {
    d = e.nextSibling && e.nextSibling.dataset;
    if (d)
      var h = d.dgst;
    d = h;
    f = Error(p2(419));
    d = Ki(f, d, undefined);
    return sj(a, b, g, d);
  }
  h = (g & a.childLanes) !== 0;
  if (dh || h) {
    d = Q2;
    if (d !== null) {
      switch (g & -g) {
        case 4:
          e = 2;
          break;
        case 16:
          e = 8;
          break;
        case 64:
        case 128:
        case 256:
        case 512:
        case 1024:
        case 2048:
        case 4096:
        case 8192:
        case 16384:
        case 32768:
        case 65536:
        case 131072:
        case 262144:
        case 524288:
        case 1048576:
        case 2097152:
        case 4194304:
        case 8388608:
        case 16777216:
        case 33554432:
        case 67108864:
          e = 32;
          break;
        case 536870912:
          e = 268435456;
          break;
        default:
          e = 0;
      }
      e = (e & (d.suspendedLanes | g)) !== 0 ? 0 : e;
      e !== 0 && e !== f.retryLane && (f.retryLane = e, ih(a, e), gi(d, a, e, -1));
    }
    tj();
    d = Ki(Error(p2(421)));
    return sj(a, b, g, d);
  }
  if (e.data === "$?")
    return b.flags |= 128, b.child = a.child, b = uj.bind(null, a), e._reactRetry = b, null;
  a = f.treeContext;
  yg = Lf(e.nextSibling);
  xg = b;
  I2 = true;
  zg = null;
  a !== null && (og[pg++] = rg, og[pg++] = sg, og[pg++] = qg, rg = a.id, sg = a.overflow, qg = b);
  b = qj(b, d.children);
  b.flags |= 4096;
  return b;
}
function vj(a, b, c) {
  a.lanes |= b;
  var d = a.alternate;
  d !== null && (d.lanes |= b);
  bh(a.return, b, c);
}
function wj(a, b, c, d, e) {
  var f = a.memoizedState;
  f === null ? a.memoizedState = { isBackwards: b, rendering: null, renderingStartTime: 0, last: d, tail: c, tailMode: e } : (f.isBackwards = b, f.rendering = null, f.renderingStartTime = 0, f.last = d, f.tail = c, f.tailMode = e);
}
function xj(a, b, c) {
  var d = b.pendingProps, e = d.revealOrder, f = d.tail;
  Xi(a, b, d.children, c);
  d = L2.current;
  if ((d & 2) !== 0)
    d = d & 1 | 2, b.flags |= 128;
  else {
    if (a !== null && (a.flags & 128) !== 0)
      a:
        for (a = b.child;a !== null; ) {
          if (a.tag === 13)
            a.memoizedState !== null && vj(a, c, b);
          else if (a.tag === 19)
            vj(a, c, b);
          else if (a.child !== null) {
            a.child.return = a;
            a = a.child;
            continue;
          }
          if (a === b)
            break a;
          for (;a.sibling === null; ) {
            if (a.return === null || a.return === b)
              break a;
            a = a.return;
          }
          a.sibling.return = a.return;
          a = a.sibling;
        }
    d &= 1;
  }
  G2(L2, d);
  if ((b.mode & 1) === 0)
    b.memoizedState = null;
  else
    switch (e) {
      case "forwards":
        c = b.child;
        for (e = null;c !== null; )
          a = c.alternate, a !== null && Ch(a) === null && (e = c), c = c.sibling;
        c = e;
        c === null ? (e = b.child, b.child = null) : (e = c.sibling, c.sibling = null);
        wj(b, false, e, c, f);
        break;
      case "backwards":
        c = null;
        e = b.child;
        for (b.child = null;e !== null; ) {
          a = e.alternate;
          if (a !== null && Ch(a) === null) {
            b.child = e;
            break;
          }
          a = e.sibling;
          e.sibling = c;
          c = e;
          e = a;
        }
        wj(b, true, c, null, f);
        break;
      case "together":
        wj(b, false, null, null, undefined);
        break;
      default:
        b.memoizedState = null;
    }
  return b.child;
}
function ij(a, b) {
  (b.mode & 1) === 0 && a !== null && (a.alternate = null, b.alternate = null, b.flags |= 2);
}
function Zi(a, b, c) {
  a !== null && (b.dependencies = a.dependencies);
  rh |= b.lanes;
  if ((c & b.childLanes) === 0)
    return null;
  if (a !== null && b.child !== a.child)
    throw Error(p2(153));
  if (b.child !== null) {
    a = b.child;
    c = Pg(a, a.pendingProps);
    b.child = c;
    for (c.return = b;a.sibling !== null; )
      a = a.sibling, c = c.sibling = Pg(a, a.pendingProps), c.return = b;
    c.sibling = null;
  }
  return b.child;
}
function yj(a, b, c) {
  switch (b.tag) {
    case 3:
      kj(b);
      Ig();
      break;
    case 5:
      Ah(b);
      break;
    case 1:
      Zf(b.type) && cg(b);
      break;
    case 4:
      yh(b, b.stateNode.containerInfo);
      break;
    case 10:
      var d = b.type._context, e = b.memoizedProps.value;
      G2(Wg, d._currentValue);
      d._currentValue = e;
      break;
    case 13:
      d = b.memoizedState;
      if (d !== null) {
        if (d.dehydrated !== null)
          return G2(L2, L2.current & 1), b.flags |= 128, null;
        if ((c & b.child.childLanes) !== 0)
          return oj(a, b, c);
        G2(L2, L2.current & 1);
        a = Zi(a, b, c);
        return a !== null ? a.sibling : null;
      }
      G2(L2, L2.current & 1);
      break;
    case 19:
      d = (c & b.childLanes) !== 0;
      if ((a.flags & 128) !== 0) {
        if (d)
          return xj(a, b, c);
        b.flags |= 128;
      }
      e = b.memoizedState;
      e !== null && (e.rendering = null, e.tail = null, e.lastEffect = null);
      G2(L2, L2.current);
      if (d)
        break;
      else
        return null;
    case 22:
    case 23:
      return b.lanes = 0, dj(a, b, c);
  }
  return Zi(a, b, c);
}
function Dj(a, b) {
  if (!I2)
    switch (a.tailMode) {
      case "hidden":
        b = a.tail;
        for (var c = null;b !== null; )
          b.alternate !== null && (c = b), b = b.sibling;
        c === null ? a.tail = null : c.sibling = null;
        break;
      case "collapsed":
        c = a.tail;
        for (var d = null;c !== null; )
          c.alternate !== null && (d = c), c = c.sibling;
        d === null ? b || a.tail === null ? a.tail = null : a.tail.sibling = null : d.sibling = null;
    }
}
function S2(a) {
  var b = a.alternate !== null && a.alternate.child === a.child, c = 0, d = 0;
  if (b)
    for (var e = a.child;e !== null; )
      c |= e.lanes | e.childLanes, d |= e.subtreeFlags & 14680064, d |= e.flags & 14680064, e.return = a, e = e.sibling;
  else
    for (e = a.child;e !== null; )
      c |= e.lanes | e.childLanes, d |= e.subtreeFlags, d |= e.flags, e.return = a, e = e.sibling;
  a.subtreeFlags |= d;
  a.childLanes = c;
  return b;
}
function Ej(a, b, c) {
  var d = b.pendingProps;
  wg(b);
  switch (b.tag) {
    case 2:
    case 16:
    case 15:
    case 0:
    case 11:
    case 7:
    case 8:
    case 12:
    case 9:
    case 14:
      return S2(b), null;
    case 1:
      return Zf(b.type) && $f(), S2(b), null;
    case 3:
      d = b.stateNode;
      zh();
      E2(Wf);
      E2(H2);
      Eh();
      d.pendingContext && (d.context = d.pendingContext, d.pendingContext = null);
      if (a === null || a.child === null)
        Gg(b) ? b.flags |= 4 : a === null || a.memoizedState.isDehydrated && (b.flags & 256) === 0 || (b.flags |= 1024, zg !== null && (Fj(zg), zg = null));
      Aj(a, b);
      S2(b);
      return null;
    case 5:
      Bh(b);
      var e = xh(wh.current);
      c = b.type;
      if (a !== null && b.stateNode != null)
        Bj(a, b, c, d, e), a.ref !== b.ref && (b.flags |= 512, b.flags |= 2097152);
      else {
        if (!d) {
          if (b.stateNode === null)
            throw Error(p2(166));
          S2(b);
          return null;
        }
        a = xh(uh.current);
        if (Gg(b)) {
          d = b.stateNode;
          c = b.type;
          var f = b.memoizedProps;
          d[Of] = b;
          d[Pf] = f;
          a = (b.mode & 1) !== 0;
          switch (c) {
            case "dialog":
              D2("cancel", d);
              D2("close", d);
              break;
            case "iframe":
            case "object":
            case "embed":
              D2("load", d);
              break;
            case "video":
            case "audio":
              for (e = 0;e < lf.length; e++)
                D2(lf[e], d);
              break;
            case "source":
              D2("error", d);
              break;
            case "img":
            case "image":
            case "link":
              D2("error", d);
              D2("load", d);
              break;
            case "details":
              D2("toggle", d);
              break;
            case "input":
              Za(d, f);
              D2("invalid", d);
              break;
            case "select":
              d._wrapperState = { wasMultiple: !!f.multiple };
              D2("invalid", d);
              break;
            case "textarea":
              hb(d, f), D2("invalid", d);
          }
          ub(c, f);
          e = null;
          for (var g in f)
            if (f.hasOwnProperty(g)) {
              var h = f[g];
              g === "children" ? typeof h === "string" ? d.textContent !== h && (f.suppressHydrationWarning !== true && Af(d.textContent, h, a), e = ["children", h]) : typeof h === "number" && d.textContent !== "" + h && (f.suppressHydrationWarning !== true && Af(d.textContent, h, a), e = ["children", "" + h]) : ea.hasOwnProperty(g) && h != null && g === "onScroll" && D2("scroll", d);
            }
          switch (c) {
            case "input":
              Va(d);
              db(d, f, true);
              break;
            case "textarea":
              Va(d);
              jb(d);
              break;
            case "select":
            case "option":
              break;
            default:
              typeof f.onClick === "function" && (d.onclick = Bf);
          }
          d = e;
          b.updateQueue = d;
          d !== null && (b.flags |= 4);
        } else {
          g = e.nodeType === 9 ? e : e.ownerDocument;
          a === "http://www.w3.org/1999/xhtml" && (a = kb(c));
          a === "http://www.w3.org/1999/xhtml" ? c === "script" ? (a = g.createElement("div"), a.innerHTML = "<script></script>", a = a.removeChild(a.firstChild)) : typeof d.is === "string" ? a = g.createElement(c, { is: d.is }) : (a = g.createElement(c), c === "select" && (g = a, d.multiple ? g.multiple = true : d.size && (g.size = d.size))) : a = g.createElementNS(a, c);
          a[Of] = b;
          a[Pf] = d;
          zj(a, b, false, false);
          b.stateNode = a;
          a: {
            g = vb(c, d);
            switch (c) {
              case "dialog":
                D2("cancel", a);
                D2("close", a);
                e = d;
                break;
              case "iframe":
              case "object":
              case "embed":
                D2("load", a);
                e = d;
                break;
              case "video":
              case "audio":
                for (e = 0;e < lf.length; e++)
                  D2(lf[e], a);
                e = d;
                break;
              case "source":
                D2("error", a);
                e = d;
                break;
              case "img":
              case "image":
              case "link":
                D2("error", a);
                D2("load", a);
                e = d;
                break;
              case "details":
                D2("toggle", a);
                e = d;
                break;
              case "input":
                Za(a, d);
                e = Ya(a, d);
                D2("invalid", a);
                break;
              case "option":
                e = d;
                break;
              case "select":
                a._wrapperState = { wasMultiple: !!d.multiple };
                e = A2({}, d, { value: undefined });
                D2("invalid", a);
                break;
              case "textarea":
                hb(a, d);
                e = gb(a, d);
                D2("invalid", a);
                break;
              default:
                e = d;
            }
            ub(c, e);
            h = e;
            for (f in h)
              if (h.hasOwnProperty(f)) {
                var k = h[f];
                f === "style" ? sb(a, k) : f === "dangerouslySetInnerHTML" ? (k = k ? k.__html : undefined, k != null && nb(a, k)) : f === "children" ? typeof k === "string" ? (c !== "textarea" || k !== "") && ob(a, k) : typeof k === "number" && ob(a, "" + k) : f !== "suppressContentEditableWarning" && f !== "suppressHydrationWarning" && f !== "autoFocus" && (ea.hasOwnProperty(f) ? k != null && f === "onScroll" && D2("scroll", a) : k != null && ta(a, f, k, g));
              }
            switch (c) {
              case "input":
                Va(a);
                db(a, d, false);
                break;
              case "textarea":
                Va(a);
                jb(a);
                break;
              case "option":
                d.value != null && a.setAttribute("value", "" + Sa(d.value));
                break;
              case "select":
                a.multiple = !!d.multiple;
                f = d.value;
                f != null ? fb(a, !!d.multiple, f, false) : d.defaultValue != null && fb(a, !!d.multiple, d.defaultValue, true);
                break;
              default:
                typeof e.onClick === "function" && (a.onclick = Bf);
            }
            switch (c) {
              case "button":
              case "input":
              case "select":
              case "textarea":
                d = !!d.autoFocus;
                break a;
              case "img":
                d = true;
                break a;
              default:
                d = false;
            }
          }
          d && (b.flags |= 4);
        }
        b.ref !== null && (b.flags |= 512, b.flags |= 2097152);
      }
      S2(b);
      return null;
    case 6:
      if (a && b.stateNode != null)
        Cj(a, b, a.memoizedProps, d);
      else {
        if (typeof d !== "string" && b.stateNode === null)
          throw Error(p2(166));
        c = xh(wh.current);
        xh(uh.current);
        if (Gg(b)) {
          d = b.stateNode;
          c = b.memoizedProps;
          d[Of] = b;
          if (f = d.nodeValue !== c) {
            if (a = xg, a !== null)
              switch (a.tag) {
                case 3:
                  Af(d.nodeValue, c, (a.mode & 1) !== 0);
                  break;
                case 5:
                  a.memoizedProps.suppressHydrationWarning !== true && Af(d.nodeValue, c, (a.mode & 1) !== 0);
              }
          }
          f && (b.flags |= 4);
        } else
          d = (c.nodeType === 9 ? c : c.ownerDocument).createTextNode(d), d[Of] = b, b.stateNode = d;
      }
      S2(b);
      return null;
    case 13:
      E2(L2);
      d = b.memoizedState;
      if (a === null || a.memoizedState !== null && a.memoizedState.dehydrated !== null) {
        if (I2 && yg !== null && (b.mode & 1) !== 0 && (b.flags & 128) === 0)
          Hg(), Ig(), b.flags |= 98560, f = false;
        else if (f = Gg(b), d !== null && d.dehydrated !== null) {
          if (a === null) {
            if (!f)
              throw Error(p2(318));
            f = b.memoizedState;
            f = f !== null ? f.dehydrated : null;
            if (!f)
              throw Error(p2(317));
            f[Of] = b;
          } else
            Ig(), (b.flags & 128) === 0 && (b.memoizedState = null), b.flags |= 4;
          S2(b);
          f = false;
        } else
          zg !== null && (Fj(zg), zg = null), f = true;
        if (!f)
          return b.flags & 65536 ? b : null;
      }
      if ((b.flags & 128) !== 0)
        return b.lanes = c, b;
      d = d !== null;
      d !== (a !== null && a.memoizedState !== null) && d && (b.child.flags |= 8192, (b.mode & 1) !== 0 && (a === null || (L2.current & 1) !== 0 ? T2 === 0 && (T2 = 3) : tj()));
      b.updateQueue !== null && (b.flags |= 4);
      S2(b);
      return null;
    case 4:
      return zh(), Aj(a, b), a === null && sf(b.stateNode.containerInfo), S2(b), null;
    case 10:
      return ah(b.type._context), S2(b), null;
    case 17:
      return Zf(b.type) && $f(), S2(b), null;
    case 19:
      E2(L2);
      f = b.memoizedState;
      if (f === null)
        return S2(b), null;
      d = (b.flags & 128) !== 0;
      g = f.rendering;
      if (g === null)
        if (d)
          Dj(f, false);
        else {
          if (T2 !== 0 || a !== null && (a.flags & 128) !== 0)
            for (a = b.child;a !== null; ) {
              g = Ch(a);
              if (g !== null) {
                b.flags |= 128;
                Dj(f, false);
                d = g.updateQueue;
                d !== null && (b.updateQueue = d, b.flags |= 4);
                b.subtreeFlags = 0;
                d = c;
                for (c = b.child;c !== null; )
                  f = c, a = d, f.flags &= 14680066, g = f.alternate, g === null ? (f.childLanes = 0, f.lanes = a, f.child = null, f.subtreeFlags = 0, f.memoizedProps = null, f.memoizedState = null, f.updateQueue = null, f.dependencies = null, f.stateNode = null) : (f.childLanes = g.childLanes, f.lanes = g.lanes, f.child = g.child, f.subtreeFlags = 0, f.deletions = null, f.memoizedProps = g.memoizedProps, f.memoizedState = g.memoizedState, f.updateQueue = g.updateQueue, f.type = g.type, a = g.dependencies, f.dependencies = a === null ? null : { lanes: a.lanes, firstContext: a.firstContext }), c = c.sibling;
                G2(L2, L2.current & 1 | 2);
                return b.child;
              }
              a = a.sibling;
            }
          f.tail !== null && B2() > Gj && (b.flags |= 128, d = true, Dj(f, false), b.lanes = 4194304);
        }
      else {
        if (!d)
          if (a = Ch(g), a !== null) {
            if (b.flags |= 128, d = true, c = a.updateQueue, c !== null && (b.updateQueue = c, b.flags |= 4), Dj(f, true), f.tail === null && f.tailMode === "hidden" && !g.alternate && !I2)
              return S2(b), null;
          } else
            2 * B2() - f.renderingStartTime > Gj && c !== 1073741824 && (b.flags |= 128, d = true, Dj(f, false), b.lanes = 4194304);
        f.isBackwards ? (g.sibling = b.child, b.child = g) : (c = f.last, c !== null ? c.sibling = g : b.child = g, f.last = g);
      }
      if (f.tail !== null)
        return b = f.tail, f.rendering = b, f.tail = b.sibling, f.renderingStartTime = B2(), b.sibling = null, c = L2.current, G2(L2, d ? c & 1 | 2 : c & 1), b;
      S2(b);
      return null;
    case 22:
    case 23:
      return Hj(), d = b.memoizedState !== null, a !== null && a.memoizedState !== null !== d && (b.flags |= 8192), d && (b.mode & 1) !== 0 ? (fj & 1073741824) !== 0 && (S2(b), b.subtreeFlags & 6 && (b.flags |= 8192)) : S2(b), null;
    case 24:
      return null;
    case 25:
      return null;
  }
  throw Error(p2(156, b.tag));
}
function Ij(a, b) {
  wg(b);
  switch (b.tag) {
    case 1:
      return Zf(b.type) && $f(), a = b.flags, a & 65536 ? (b.flags = a & -65537 | 128, b) : null;
    case 3:
      return zh(), E2(Wf), E2(H2), Eh(), a = b.flags, (a & 65536) !== 0 && (a & 128) === 0 ? (b.flags = a & -65537 | 128, b) : null;
    case 5:
      return Bh(b), null;
    case 13:
      E2(L2);
      a = b.memoizedState;
      if (a !== null && a.dehydrated !== null) {
        if (b.alternate === null)
          throw Error(p2(340));
        Ig();
      }
      a = b.flags;
      return a & 65536 ? (b.flags = a & -65537 | 128, b) : null;
    case 19:
      return E2(L2), null;
    case 4:
      return zh(), null;
    case 10:
      return ah(b.type._context), null;
    case 22:
    case 23:
      return Hj(), null;
    case 24:
      return null;
    default:
      return null;
  }
}
function Lj(a, b) {
  var c = a.ref;
  if (c !== null)
    if (typeof c === "function")
      try {
        c(null);
      } catch (d) {
        W2(a, b, d);
      }
    else
      c.current = null;
}
function Mj(a, b, c) {
  try {
    c();
  } catch (d) {
    W2(a, b, d);
  }
}
function Oj(a, b) {
  Cf = dd;
  a = Me();
  if (Ne(a)) {
    if ("selectionStart" in a)
      var c = { start: a.selectionStart, end: a.selectionEnd };
    else
      a: {
        c = (c = a.ownerDocument) && c.defaultView || window;
        var d = c.getSelection && c.getSelection();
        if (d && d.rangeCount !== 0) {
          c = d.anchorNode;
          var e = d.anchorOffset, f = d.focusNode;
          d = d.focusOffset;
          try {
            c.nodeType, f.nodeType;
          } catch (F) {
            c = null;
            break a;
          }
          var g = 0, h = -1, k = -1, l = 0, m = 0, q = a, r = null;
          b:
            for (;; ) {
              for (var y;; ) {
                q !== c || e !== 0 && q.nodeType !== 3 || (h = g + e);
                q !== f || d !== 0 && q.nodeType !== 3 || (k = g + d);
                q.nodeType === 3 && (g += q.nodeValue.length);
                if ((y = q.firstChild) === null)
                  break;
                r = q;
                q = y;
              }
              for (;; ) {
                if (q === a)
                  break b;
                r === c && ++l === e && (h = g);
                r === f && ++m === d && (k = g);
                if ((y = q.nextSibling) !== null)
                  break;
                q = r;
                r = q.parentNode;
              }
              q = y;
            }
          c = h === -1 || k === -1 ? null : { start: h, end: k };
        } else
          c = null;
      }
    c = c || { start: 0, end: 0 };
  } else
    c = null;
  Df = { focusedElem: a, selectionRange: c };
  dd = false;
  for (V2 = b;V2 !== null; )
    if (b = V2, a = b.child, (b.subtreeFlags & 1028) !== 0 && a !== null)
      a.return = b, V2 = a;
    else
      for (;V2 !== null; ) {
        b = V2;
        try {
          var n = b.alternate;
          if ((b.flags & 1024) !== 0)
            switch (b.tag) {
              case 0:
              case 11:
              case 15:
                break;
              case 1:
                if (n !== null) {
                  var t = n.memoizedProps, J = n.memoizedState, x = b.stateNode, w = x.getSnapshotBeforeUpdate(b.elementType === b.type ? t : Ci(b.type, t), J);
                  x.__reactInternalSnapshotBeforeUpdate = w;
                }
                break;
              case 3:
                var u = b.stateNode.containerInfo;
                u.nodeType === 1 ? u.textContent = "" : u.nodeType === 9 && u.documentElement && u.removeChild(u.documentElement);
                break;
              case 5:
              case 6:
              case 4:
              case 17:
                break;
              default:
                throw Error(p2(163));
            }
        } catch (F) {
          W2(b, b.return, F);
        }
        a = b.sibling;
        if (a !== null) {
          a.return = b.return;
          V2 = a;
          break;
        }
        V2 = b.return;
      }
  n = Nj;
  Nj = false;
  return n;
}
function Pj(a, b, c) {
  var d = b.updateQueue;
  d = d !== null ? d.lastEffect : null;
  if (d !== null) {
    var e = d = d.next;
    do {
      if ((e.tag & a) === a) {
        var f = e.destroy;
        e.destroy = undefined;
        f !== undefined && Mj(b, c, f);
      }
      e = e.next;
    } while (e !== d);
  }
}
function Qj(a, b) {
  b = b.updateQueue;
  b = b !== null ? b.lastEffect : null;
  if (b !== null) {
    var c = b = b.next;
    do {
      if ((c.tag & a) === a) {
        var d = c.create;
        c.destroy = d();
      }
      c = c.next;
    } while (c !== b);
  }
}
function Rj(a) {
  var b = a.ref;
  if (b !== null) {
    var c = a.stateNode;
    switch (a.tag) {
      case 5:
        a = c;
        break;
      default:
        a = c;
    }
    typeof b === "function" ? b(a) : b.current = a;
  }
}
function Sj(a) {
  var b = a.alternate;
  b !== null && (a.alternate = null, Sj(b));
  a.child = null;
  a.deletions = null;
  a.sibling = null;
  a.tag === 5 && (b = a.stateNode, b !== null && (delete b[Of], delete b[Pf], delete b[of], delete b[Qf], delete b[Rf]));
  a.stateNode = null;
  a.return = null;
  a.dependencies = null;
  a.memoizedProps = null;
  a.memoizedState = null;
  a.pendingProps = null;
  a.stateNode = null;
  a.updateQueue = null;
}
function Tj(a) {
  return a.tag === 5 || a.tag === 3 || a.tag === 4;
}
function Uj(a) {
  a:
    for (;; ) {
      for (;a.sibling === null; ) {
        if (a.return === null || Tj(a.return))
          return null;
        a = a.return;
      }
      a.sibling.return = a.return;
      for (a = a.sibling;a.tag !== 5 && a.tag !== 6 && a.tag !== 18; ) {
        if (a.flags & 2)
          continue a;
        if (a.child === null || a.tag === 4)
          continue a;
        else
          a.child.return = a, a = a.child;
      }
      if (!(a.flags & 2))
        return a.stateNode;
    }
}
function Vj(a, b, c) {
  var d = a.tag;
  if (d === 5 || d === 6)
    a = a.stateNode, b ? c.nodeType === 8 ? c.parentNode.insertBefore(a, b) : c.insertBefore(a, b) : (c.nodeType === 8 ? (b = c.parentNode, b.insertBefore(a, c)) : (b = c, b.appendChild(a)), c = c._reactRootContainer, c !== null && c !== undefined || b.onclick !== null || (b.onclick = Bf));
  else if (d !== 4 && (a = a.child, a !== null))
    for (Vj(a, b, c), a = a.sibling;a !== null; )
      Vj(a, b, c), a = a.sibling;
}
function Wj(a, b, c) {
  var d = a.tag;
  if (d === 5 || d === 6)
    a = a.stateNode, b ? c.insertBefore(a, b) : c.appendChild(a);
  else if (d !== 4 && (a = a.child, a !== null))
    for (Wj(a, b, c), a = a.sibling;a !== null; )
      Wj(a, b, c), a = a.sibling;
}
function Yj(a, b, c) {
  for (c = c.child;c !== null; )
    Zj(a, b, c), c = c.sibling;
}
function Zj(a, b, c) {
  if (lc && typeof lc.onCommitFiberUnmount === "function")
    try {
      lc.onCommitFiberUnmount(kc, c);
    } catch (h) {}
  switch (c.tag) {
    case 5:
      U2 || Lj(c, b);
    case 6:
      var d = X2, e = Xj;
      X2 = null;
      Yj(a, b, c);
      X2 = d;
      Xj = e;
      X2 !== null && (Xj ? (a = X2, c = c.stateNode, a.nodeType === 8 ? a.parentNode.removeChild(c) : a.removeChild(c)) : X2.removeChild(c.stateNode));
      break;
    case 18:
      X2 !== null && (Xj ? (a = X2, c = c.stateNode, a.nodeType === 8 ? Kf(a.parentNode, c) : a.nodeType === 1 && Kf(a, c), bd(a)) : Kf(X2, c.stateNode));
      break;
    case 4:
      d = X2;
      e = Xj;
      X2 = c.stateNode.containerInfo;
      Xj = true;
      Yj(a, b, c);
      X2 = d;
      Xj = e;
      break;
    case 0:
    case 11:
    case 14:
    case 15:
      if (!U2 && (d = c.updateQueue, d !== null && (d = d.lastEffect, d !== null))) {
        e = d = d.next;
        do {
          var f = e, g = f.destroy;
          f = f.tag;
          g !== undefined && ((f & 2) !== 0 ? Mj(c, b, g) : (f & 4) !== 0 && Mj(c, b, g));
          e = e.next;
        } while (e !== d);
      }
      Yj(a, b, c);
      break;
    case 1:
      if (!U2 && (Lj(c, b), d = c.stateNode, typeof d.componentWillUnmount === "function"))
        try {
          d.props = c.memoizedProps, d.state = c.memoizedState, d.componentWillUnmount();
        } catch (h) {
          W2(c, b, h);
        }
      Yj(a, b, c);
      break;
    case 21:
      Yj(a, b, c);
      break;
    case 22:
      c.mode & 1 ? (U2 = (d = U2) || c.memoizedState !== null, Yj(a, b, c), U2 = d) : Yj(a, b, c);
      break;
    default:
      Yj(a, b, c);
  }
}
function ak(a) {
  var b = a.updateQueue;
  if (b !== null) {
    a.updateQueue = null;
    var c = a.stateNode;
    c === null && (c = a.stateNode = new Kj);
    b.forEach(function(b) {
      var d = bk.bind(null, a, b);
      c.has(b) || (c.add(b), b.then(d, d));
    });
  }
}
function ck(a, b) {
  var c = b.deletions;
  if (c !== null)
    for (var d = 0;d < c.length; d++) {
      var e = c[d];
      try {
        var f = a, g = b, h = g;
        a:
          for (;h !== null; ) {
            switch (h.tag) {
              case 5:
                X2 = h.stateNode;
                Xj = false;
                break a;
              case 3:
                X2 = h.stateNode.containerInfo;
                Xj = true;
                break a;
              case 4:
                X2 = h.stateNode.containerInfo;
                Xj = true;
                break a;
            }
            h = h.return;
          }
        if (X2 === null)
          throw Error(p2(160));
        Zj(f, g, e);
        X2 = null;
        Xj = false;
        var k = e.alternate;
        k !== null && (k.return = null);
        e.return = null;
      } catch (l) {
        W2(e, b, l);
      }
    }
  if (b.subtreeFlags & 12854)
    for (b = b.child;b !== null; )
      dk(b, a), b = b.sibling;
}
function dk(a, b) {
  var { alternate: c, flags: d } = a;
  switch (a.tag) {
    case 0:
    case 11:
    case 14:
    case 15:
      ck(b, a);
      ek(a);
      if (d & 4) {
        try {
          Pj(3, a, a.return), Qj(3, a);
        } catch (t) {
          W2(a, a.return, t);
        }
        try {
          Pj(5, a, a.return);
        } catch (t) {
          W2(a, a.return, t);
        }
      }
      break;
    case 1:
      ck(b, a);
      ek(a);
      d & 512 && c !== null && Lj(c, c.return);
      break;
    case 5:
      ck(b, a);
      ek(a);
      d & 512 && c !== null && Lj(c, c.return);
      if (a.flags & 32) {
        var e = a.stateNode;
        try {
          ob(e, "");
        } catch (t) {
          W2(a, a.return, t);
        }
      }
      if (d & 4 && (e = a.stateNode, e != null)) {
        var f = a.memoizedProps, g = c !== null ? c.memoizedProps : f, { type: h, updateQueue: k } = a;
        a.updateQueue = null;
        if (k !== null)
          try {
            h === "input" && f.type === "radio" && f.name != null && ab(e, f);
            vb(h, g);
            var l = vb(h, f);
            for (g = 0;g < k.length; g += 2) {
              var m = k[g], q = k[g + 1];
              m === "style" ? sb(e, q) : m === "dangerouslySetInnerHTML" ? nb(e, q) : m === "children" ? ob(e, q) : ta(e, m, q, l);
            }
            switch (h) {
              case "input":
                bb(e, f);
                break;
              case "textarea":
                ib(e, f);
                break;
              case "select":
                var r = e._wrapperState.wasMultiple;
                e._wrapperState.wasMultiple = !!f.multiple;
                var y = f.value;
                y != null ? fb(e, !!f.multiple, y, false) : r !== !!f.multiple && (f.defaultValue != null ? fb(e, !!f.multiple, f.defaultValue, true) : fb(e, !!f.multiple, f.multiple ? [] : "", false));
            }
            e[Pf] = f;
          } catch (t) {
            W2(a, a.return, t);
          }
      }
      break;
    case 6:
      ck(b, a);
      ek(a);
      if (d & 4) {
        if (a.stateNode === null)
          throw Error(p2(162));
        e = a.stateNode;
        f = a.memoizedProps;
        try {
          e.nodeValue = f;
        } catch (t) {
          W2(a, a.return, t);
        }
      }
      break;
    case 3:
      ck(b, a);
      ek(a);
      if (d & 4 && c !== null && c.memoizedState.isDehydrated)
        try {
          bd(b.containerInfo);
        } catch (t) {
          W2(a, a.return, t);
        }
      break;
    case 4:
      ck(b, a);
      ek(a);
      break;
    case 13:
      ck(b, a);
      ek(a);
      e = a.child;
      e.flags & 8192 && (f = e.memoizedState !== null, e.stateNode.isHidden = f, !f || e.alternate !== null && e.alternate.memoizedState !== null || (fk = B2()));
      d & 4 && ak(a);
      break;
    case 22:
      m = c !== null && c.memoizedState !== null;
      a.mode & 1 ? (U2 = (l = U2) || m, ck(b, a), U2 = l) : ck(b, a);
      ek(a);
      if (d & 8192) {
        l = a.memoizedState !== null;
        if ((a.stateNode.isHidden = l) && !m && (a.mode & 1) !== 0)
          for (V2 = a, m = a.child;m !== null; ) {
            for (q = V2 = m;V2 !== null; ) {
              r = V2;
              y = r.child;
              switch (r.tag) {
                case 0:
                case 11:
                case 14:
                case 15:
                  Pj(4, r, r.return);
                  break;
                case 1:
                  Lj(r, r.return);
                  var n = r.stateNode;
                  if (typeof n.componentWillUnmount === "function") {
                    d = r;
                    c = r.return;
                    try {
                      b = d, n.props = b.memoizedProps, n.state = b.memoizedState, n.componentWillUnmount();
                    } catch (t) {
                      W2(d, c, t);
                    }
                  }
                  break;
                case 5:
                  Lj(r, r.return);
                  break;
                case 22:
                  if (r.memoizedState !== null) {
                    gk(q);
                    continue;
                  }
              }
              y !== null ? (y.return = r, V2 = y) : gk(q);
            }
            m = m.sibling;
          }
        a:
          for (m = null, q = a;; ) {
            if (q.tag === 5) {
              if (m === null) {
                m = q;
                try {
                  e = q.stateNode, l ? (f = e.style, typeof f.setProperty === "function" ? f.setProperty("display", "none", "important") : f.display = "none") : (h = q.stateNode, k = q.memoizedProps.style, g = k !== undefined && k !== null && k.hasOwnProperty("display") ? k.display : null, h.style.display = rb("display", g));
                } catch (t) {
                  W2(a, a.return, t);
                }
              }
            } else if (q.tag === 6) {
              if (m === null)
                try {
                  q.stateNode.nodeValue = l ? "" : q.memoizedProps;
                } catch (t) {
                  W2(a, a.return, t);
                }
            } else if ((q.tag !== 22 && q.tag !== 23 || q.memoizedState === null || q === a) && q.child !== null) {
              q.child.return = q;
              q = q.child;
              continue;
            }
            if (q === a)
              break a;
            for (;q.sibling === null; ) {
              if (q.return === null || q.return === a)
                break a;
              m === q && (m = null);
              q = q.return;
            }
            m === q && (m = null);
            q.sibling.return = q.return;
            q = q.sibling;
          }
      }
      break;
    case 19:
      ck(b, a);
      ek(a);
      d & 4 && ak(a);
      break;
    case 21:
      break;
    default:
      ck(b, a), ek(a);
  }
}
function ek(a) {
  var b = a.flags;
  if (b & 2) {
    try {
      a: {
        for (var c = a.return;c !== null; ) {
          if (Tj(c)) {
            var d = c;
            break a;
          }
          c = c.return;
        }
        throw Error(p2(160));
      }
      switch (d.tag) {
        case 5:
          var e = d.stateNode;
          d.flags & 32 && (ob(e, ""), d.flags &= -33);
          var f = Uj(a);
          Wj(a, f, e);
          break;
        case 3:
        case 4:
          var g = d.stateNode.containerInfo, h = Uj(a);
          Vj(a, h, g);
          break;
        default:
          throw Error(p2(161));
      }
    } catch (k) {
      W2(a, a.return, k);
    }
    a.flags &= -3;
  }
  b & 4096 && (a.flags &= -4097);
}
function hk(a, b, c) {
  V2 = a;
  ik(a, b, c);
}
function ik(a, b, c) {
  for (var d = (a.mode & 1) !== 0;V2 !== null; ) {
    var e = V2, f = e.child;
    if (e.tag === 22 && d) {
      var g = e.memoizedState !== null || Jj;
      if (!g) {
        var h = e.alternate, k = h !== null && h.memoizedState !== null || U2;
        h = Jj;
        var l = U2;
        Jj = g;
        if ((U2 = k) && !l)
          for (V2 = e;V2 !== null; )
            g = V2, k = g.child, g.tag === 22 && g.memoizedState !== null ? jk(e) : k !== null ? (k.return = g, V2 = k) : jk(e);
        for (;f !== null; )
          V2 = f, ik(f, b, c), f = f.sibling;
        V2 = e;
        Jj = h;
        U2 = l;
      }
      kk(a, b, c);
    } else
      (e.subtreeFlags & 8772) !== 0 && f !== null ? (f.return = e, V2 = f) : kk(a, b, c);
  }
}
function kk(a) {
  for (;V2 !== null; ) {
    var b = V2;
    if ((b.flags & 8772) !== 0) {
      var c = b.alternate;
      try {
        if ((b.flags & 8772) !== 0)
          switch (b.tag) {
            case 0:
            case 11:
            case 15:
              U2 || Qj(5, b);
              break;
            case 1:
              var d = b.stateNode;
              if (b.flags & 4 && !U2)
                if (c === null)
                  d.componentDidMount();
                else {
                  var e = b.elementType === b.type ? c.memoizedProps : Ci(b.type, c.memoizedProps);
                  d.componentDidUpdate(e, c.memoizedState, d.__reactInternalSnapshotBeforeUpdate);
                }
              var f = b.updateQueue;
              f !== null && sh(b, f, d);
              break;
            case 3:
              var g = b.updateQueue;
              if (g !== null) {
                c = null;
                if (b.child !== null)
                  switch (b.child.tag) {
                    case 5:
                      c = b.child.stateNode;
                      break;
                    case 1:
                      c = b.child.stateNode;
                  }
                sh(b, g, c);
              }
              break;
            case 5:
              var h = b.stateNode;
              if (c === null && b.flags & 4) {
                c = h;
                var k = b.memoizedProps;
                switch (b.type) {
                  case "button":
                  case "input":
                  case "select":
                  case "textarea":
                    k.autoFocus && c.focus();
                    break;
                  case "img":
                    k.src && (c.src = k.src);
                }
              }
              break;
            case 6:
              break;
            case 4:
              break;
            case 12:
              break;
            case 13:
              if (b.memoizedState === null) {
                var l = b.alternate;
                if (l !== null) {
                  var m = l.memoizedState;
                  if (m !== null) {
                    var q = m.dehydrated;
                    q !== null && bd(q);
                  }
                }
              }
              break;
            case 19:
            case 17:
            case 21:
            case 22:
            case 23:
            case 25:
              break;
            default:
              throw Error(p2(163));
          }
        U2 || b.flags & 512 && Rj(b);
      } catch (r) {
        W2(b, b.return, r);
      }
    }
    if (b === a) {
      V2 = null;
      break;
    }
    c = b.sibling;
    if (c !== null) {
      c.return = b.return;
      V2 = c;
      break;
    }
    V2 = b.return;
  }
}
function gk(a) {
  for (;V2 !== null; ) {
    var b = V2;
    if (b === a) {
      V2 = null;
      break;
    }
    var c = b.sibling;
    if (c !== null) {
      c.return = b.return;
      V2 = c;
      break;
    }
    V2 = b.return;
  }
}
function jk(a) {
  for (;V2 !== null; ) {
    var b = V2;
    try {
      switch (b.tag) {
        case 0:
        case 11:
        case 15:
          var c = b.return;
          try {
            Qj(4, b);
          } catch (k) {
            W2(b, c, k);
          }
          break;
        case 1:
          var d = b.stateNode;
          if (typeof d.componentDidMount === "function") {
            var e = b.return;
            try {
              d.componentDidMount();
            } catch (k) {
              W2(b, e, k);
            }
          }
          var f = b.return;
          try {
            Rj(b);
          } catch (k) {
            W2(b, f, k);
          }
          break;
        case 5:
          var g = b.return;
          try {
            Rj(b);
          } catch (k) {
            W2(b, g, k);
          }
      }
    } catch (k) {
      W2(b, b.return, k);
    }
    if (b === a) {
      V2 = null;
      break;
    }
    var h = b.sibling;
    if (h !== null) {
      h.return = b.return;
      V2 = h;
      break;
    }
    V2 = b.return;
  }
}
function R2() {
  return (K2 & 6) !== 0 ? B2() : Ak !== -1 ? Ak : Ak = B2();
}
function yi(a) {
  if ((a.mode & 1) === 0)
    return 1;
  if ((K2 & 2) !== 0 && Z !== 0)
    return Z & -Z;
  if (Kg.transition !== null)
    return Bk === 0 && (Bk = yc()), Bk;
  a = C2;
  if (a !== 0)
    return a;
  a = window.event;
  a = a === undefined ? 16 : jd(a.type);
  return a;
}
function gi(a, b, c, d) {
  if (50 < yk)
    throw yk = 0, zk = null, Error(p2(185));
  Ac(a, c, d);
  if ((K2 & 2) === 0 || a !== Q2)
    a === Q2 && ((K2 & 2) === 0 && (qk |= c), T2 === 4 && Ck(a, Z)), Dk(a, d), c === 1 && K2 === 0 && (b.mode & 1) === 0 && (Gj = B2() + 500, fg && jg());
}
function Dk(a, b) {
  var c = a.callbackNode;
  wc(a, b);
  var d = uc(a, a === Q2 ? Z : 0);
  if (d === 0)
    c !== null && bc(c), a.callbackNode = null, a.callbackPriority = 0;
  else if (b = d & -d, a.callbackPriority !== b) {
    c != null && bc(c);
    if (b === 1)
      a.tag === 0 ? ig(Ek.bind(null, a)) : hg(Ek.bind(null, a)), Jf(function() {
        (K2 & 6) === 0 && jg();
      }), c = null;
    else {
      switch (Dc(d)) {
        case 1:
          c = fc;
          break;
        case 4:
          c = gc;
          break;
        case 16:
          c = hc;
          break;
        case 536870912:
          c = jc;
          break;
        default:
          c = hc;
      }
      c = Fk(c, Gk.bind(null, a));
    }
    a.callbackPriority = b;
    a.callbackNode = c;
  }
}
function Gk(a, b) {
  Ak = -1;
  Bk = 0;
  if ((K2 & 6) !== 0)
    throw Error(p2(327));
  var c = a.callbackNode;
  if (Hk() && a.callbackNode !== c)
    return null;
  var d = uc(a, a === Q2 ? Z : 0);
  if (d === 0)
    return null;
  if ((d & 30) !== 0 || (d & a.expiredLanes) !== 0 || b)
    b = Ik(a, d);
  else {
    b = d;
    var e = K2;
    K2 |= 2;
    var f = Jk();
    if (Q2 !== a || Z !== b)
      uk = null, Gj = B2() + 500, Kk(a, b);
    do
      try {
        Lk();
        break;
      } catch (h) {
        Mk(a, h);
      }
    while (1);
    $g();
    mk.current = f;
    K2 = e;
    Y !== null ? b = 0 : (Q2 = null, Z = 0, b = T2);
  }
  if (b !== 0) {
    b === 2 && (e = xc(a), e !== 0 && (d = e, b = Nk(a, e)));
    if (b === 1)
      throw c = pk, Kk(a, 0), Ck(a, d), Dk(a, B2()), c;
    if (b === 6)
      Ck(a, d);
    else {
      e = a.current.alternate;
      if ((d & 30) === 0 && !Ok(e) && (b = Ik(a, d), b === 2 && (f = xc(a), f !== 0 && (d = f, b = Nk(a, f))), b === 1))
        throw c = pk, Kk(a, 0), Ck(a, d), Dk(a, B2()), c;
      a.finishedWork = e;
      a.finishedLanes = d;
      switch (b) {
        case 0:
        case 1:
          throw Error(p2(345));
        case 2:
          Pk(a, tk, uk);
          break;
        case 3:
          Ck(a, d);
          if ((d & 130023424) === d && (b = fk + 500 - B2(), 10 < b)) {
            if (uc(a, 0) !== 0)
              break;
            e = a.suspendedLanes;
            if ((e & d) !== d) {
              R2();
              a.pingedLanes |= a.suspendedLanes & e;
              break;
            }
            a.timeoutHandle = Ff(Pk.bind(null, a, tk, uk), b);
            break;
          }
          Pk(a, tk, uk);
          break;
        case 4:
          Ck(a, d);
          if ((d & 4194240) === d)
            break;
          b = a.eventTimes;
          for (e = -1;0 < d; ) {
            var g = 31 - oc(d);
            f = 1 << g;
            g = b[g];
            g > e && (e = g);
            d &= ~f;
          }
          d = e;
          d = B2() - d;
          d = (120 > d ? 120 : 480 > d ? 480 : 1080 > d ? 1080 : 1920 > d ? 1920 : 3000 > d ? 3000 : 4320 > d ? 4320 : 1960 * lk(d / 1960)) - d;
          if (10 < d) {
            a.timeoutHandle = Ff(Pk.bind(null, a, tk, uk), d);
            break;
          }
          Pk(a, tk, uk);
          break;
        case 5:
          Pk(a, tk, uk);
          break;
        default:
          throw Error(p2(329));
      }
    }
  }
  Dk(a, B2());
  return a.callbackNode === c ? Gk.bind(null, a) : null;
}
function Nk(a, b) {
  var c = sk;
  a.current.memoizedState.isDehydrated && (Kk(a, b).flags |= 256);
  a = Ik(a, b);
  a !== 2 && (b = tk, tk = c, b !== null && Fj(b));
  return a;
}
function Fj(a) {
  tk === null ? tk = a : tk.push.apply(tk, a);
}
function Ok(a) {
  for (var b = a;; ) {
    if (b.flags & 16384) {
      var c = b.updateQueue;
      if (c !== null && (c = c.stores, c !== null))
        for (var d = 0;d < c.length; d++) {
          var e = c[d], f = e.getSnapshot;
          e = e.value;
          try {
            if (!He(f(), e))
              return false;
          } catch (g) {
            return false;
          }
        }
    }
    c = b.child;
    if (b.subtreeFlags & 16384 && c !== null)
      c.return = b, b = c;
    else {
      if (b === a)
        break;
      for (;b.sibling === null; ) {
        if (b.return === null || b.return === a)
          return true;
        b = b.return;
      }
      b.sibling.return = b.return;
      b = b.sibling;
    }
  }
  return true;
}
function Ck(a, b) {
  b &= ~rk;
  b &= ~qk;
  a.suspendedLanes |= b;
  a.pingedLanes &= ~b;
  for (a = a.expirationTimes;0 < b; ) {
    var c = 31 - oc(b), d = 1 << c;
    a[c] = -1;
    b &= ~d;
  }
}
function Ek(a) {
  if ((K2 & 6) !== 0)
    throw Error(p2(327));
  Hk();
  var b = uc(a, 0);
  if ((b & 1) === 0)
    return Dk(a, B2()), null;
  var c = Ik(a, b);
  if (a.tag !== 0 && c === 2) {
    var d = xc(a);
    d !== 0 && (b = d, c = Nk(a, d));
  }
  if (c === 1)
    throw c = pk, Kk(a, 0), Ck(a, b), Dk(a, B2()), c;
  if (c === 6)
    throw Error(p2(345));
  a.finishedWork = a.current.alternate;
  a.finishedLanes = b;
  Pk(a, tk, uk);
  Dk(a, B2());
  return null;
}
function Qk(a, b) {
  var c = K2;
  K2 |= 1;
  try {
    return a(b);
  } finally {
    K2 = c, K2 === 0 && (Gj = B2() + 500, fg && jg());
  }
}
function Rk(a) {
  wk !== null && wk.tag === 0 && (K2 & 6) === 0 && Hk();
  var b = K2;
  K2 |= 1;
  var c = ok.transition, d = C2;
  try {
    if (ok.transition = null, C2 = 1, a)
      return a();
  } finally {
    C2 = d, ok.transition = c, K2 = b, (K2 & 6) === 0 && jg();
  }
}
function Hj() {
  fj = ej.current;
  E2(ej);
}
function Kk(a, b) {
  a.finishedWork = null;
  a.finishedLanes = 0;
  var c = a.timeoutHandle;
  c !== -1 && (a.timeoutHandle = -1, Gf(c));
  if (Y !== null)
    for (c = Y.return;c !== null; ) {
      var d = c;
      wg(d);
      switch (d.tag) {
        case 1:
          d = d.type.childContextTypes;
          d !== null && d !== undefined && $f();
          break;
        case 3:
          zh();
          E2(Wf);
          E2(H2);
          Eh();
          break;
        case 5:
          Bh(d);
          break;
        case 4:
          zh();
          break;
        case 13:
          E2(L2);
          break;
        case 19:
          E2(L2);
          break;
        case 10:
          ah(d.type._context);
          break;
        case 22:
        case 23:
          Hj();
      }
      c = c.return;
    }
  Q2 = a;
  Y = a = Pg(a.current, null);
  Z = fj = b;
  T2 = 0;
  pk = null;
  rk = qk = rh = 0;
  tk = sk = null;
  if (fh !== null) {
    for (b = 0;b < fh.length; b++)
      if (c = fh[b], d = c.interleaved, d !== null) {
        c.interleaved = null;
        var e = d.next, f = c.pending;
        if (f !== null) {
          var g = f.next;
          f.next = e;
          d.next = g;
        }
        c.pending = d;
      }
    fh = null;
  }
  return a;
}
function Mk(a, b) {
  do {
    var c = Y;
    try {
      $g();
      Fh.current = Rh;
      if (Ih) {
        for (var d = M2.memoizedState;d !== null; ) {
          var e = d.queue;
          e !== null && (e.pending = null);
          d = d.next;
        }
        Ih = false;
      }
      Hh = 0;
      O2 = N2 = M2 = null;
      Jh = false;
      Kh = 0;
      nk.current = null;
      if (c === null || c.return === null) {
        T2 = 1;
        pk = b;
        Y = null;
        break;
      }
      a: {
        var f = a, g = c.return, h = c, k = b;
        b = Z;
        h.flags |= 32768;
        if (k !== null && typeof k === "object" && typeof k.then === "function") {
          var l = k, m = h, q = m.tag;
          if ((m.mode & 1) === 0 && (q === 0 || q === 11 || q === 15)) {
            var r = m.alternate;
            r ? (m.updateQueue = r.updateQueue, m.memoizedState = r.memoizedState, m.lanes = r.lanes) : (m.updateQueue = null, m.memoizedState = null);
          }
          var y = Ui(g);
          if (y !== null) {
            y.flags &= -257;
            Vi(y, g, h, f, b);
            y.mode & 1 && Si(f, l, b);
            b = y;
            k = l;
            var n = b.updateQueue;
            if (n === null) {
              var t = new Set;
              t.add(k);
              b.updateQueue = t;
            } else
              n.add(k);
            break a;
          } else {
            if ((b & 1) === 0) {
              Si(f, l, b);
              tj();
              break a;
            }
            k = Error(p2(426));
          }
        } else if (I2 && h.mode & 1) {
          var J = Ui(g);
          if (J !== null) {
            (J.flags & 65536) === 0 && (J.flags |= 256);
            Vi(J, g, h, f, b);
            Jg(Ji(k, h));
            break a;
          }
        }
        f = k = Ji(k, h);
        T2 !== 4 && (T2 = 2);
        sk === null ? sk = [f] : sk.push(f);
        f = g;
        do {
          switch (f.tag) {
            case 3:
              f.flags |= 65536;
              b &= -b;
              f.lanes |= b;
              var x = Ni(f, k, b);
              ph(f, x);
              break a;
            case 1:
              h = k;
              var w = f.type, u = f.stateNode;
              if ((f.flags & 128) === 0 && (typeof w.getDerivedStateFromError === "function" || u !== null && typeof u.componentDidCatch === "function" && (Ri === null || !Ri.has(u)))) {
                f.flags |= 65536;
                b &= -b;
                f.lanes |= b;
                var F = Qi(f, h, b);
                ph(f, F);
                break a;
              }
          }
          f = f.return;
        } while (f !== null);
      }
      Sk(c);
    } catch (na) {
      b = na;
      Y === c && c !== null && (Y = c = c.return);
      continue;
    }
    break;
  } while (1);
}
function Jk() {
  var a = mk.current;
  mk.current = Rh;
  return a === null ? Rh : a;
}
function tj() {
  if (T2 === 0 || T2 === 3 || T2 === 2)
    T2 = 4;
  Q2 === null || (rh & 268435455) === 0 && (qk & 268435455) === 0 || Ck(Q2, Z);
}
function Ik(a, b) {
  var c = K2;
  K2 |= 2;
  var d = Jk();
  if (Q2 !== a || Z !== b)
    uk = null, Kk(a, b);
  do
    try {
      Tk();
      break;
    } catch (e) {
      Mk(a, e);
    }
  while (1);
  $g();
  K2 = c;
  mk.current = d;
  if (Y !== null)
    throw Error(p2(261));
  Q2 = null;
  Z = 0;
  return T2;
}
function Tk() {
  for (;Y !== null; )
    Uk(Y);
}
function Lk() {
  for (;Y !== null && !cc(); )
    Uk(Y);
}
function Uk(a) {
  var b = Vk(a.alternate, a, fj);
  a.memoizedProps = a.pendingProps;
  b === null ? Sk(a) : Y = b;
  nk.current = null;
}
function Sk(a) {
  var b = a;
  do {
    var c = b.alternate;
    a = b.return;
    if ((b.flags & 32768) === 0) {
      if (c = Ej(c, b, fj), c !== null) {
        Y = c;
        return;
      }
    } else {
      c = Ij(c, b);
      if (c !== null) {
        c.flags &= 32767;
        Y = c;
        return;
      }
      if (a !== null)
        a.flags |= 32768, a.subtreeFlags = 0, a.deletions = null;
      else {
        T2 = 6;
        Y = null;
        return;
      }
    }
    b = b.sibling;
    if (b !== null) {
      Y = b;
      return;
    }
    Y = b = a;
  } while (b !== null);
  T2 === 0 && (T2 = 5);
}
function Pk(a, b, c) {
  var d = C2, e = ok.transition;
  try {
    ok.transition = null, C2 = 1, Wk(a, b, c, d);
  } finally {
    ok.transition = e, C2 = d;
  }
  return null;
}
function Wk(a, b, c, d) {
  do
    Hk();
  while (wk !== null);
  if ((K2 & 6) !== 0)
    throw Error(p2(327));
  c = a.finishedWork;
  var e = a.finishedLanes;
  if (c === null)
    return null;
  a.finishedWork = null;
  a.finishedLanes = 0;
  if (c === a.current)
    throw Error(p2(177));
  a.callbackNode = null;
  a.callbackPriority = 0;
  var f = c.lanes | c.childLanes;
  Bc(a, f);
  a === Q2 && (Y = Q2 = null, Z = 0);
  (c.subtreeFlags & 2064) === 0 && (c.flags & 2064) === 0 || vk || (vk = true, Fk(hc, function() {
    Hk();
    return null;
  }));
  f = (c.flags & 15990) !== 0;
  if ((c.subtreeFlags & 15990) !== 0 || f) {
    f = ok.transition;
    ok.transition = null;
    var g = C2;
    C2 = 1;
    var h = K2;
    K2 |= 4;
    nk.current = null;
    Oj(a, c);
    dk(c, a);
    Oe(Df);
    dd = !!Cf;
    Df = Cf = null;
    a.current = c;
    hk(c, a, e);
    dc();
    K2 = h;
    C2 = g;
    ok.transition = f;
  } else
    a.current = c;
  vk && (vk = false, wk = a, xk = e);
  f = a.pendingLanes;
  f === 0 && (Ri = null);
  mc(c.stateNode, d);
  Dk(a, B2());
  if (b !== null)
    for (d = a.onRecoverableError, c = 0;c < b.length; c++)
      e = b[c], d(e.value, { componentStack: e.stack, digest: e.digest });
  if (Oi)
    throw Oi = false, a = Pi, Pi = null, a;
  (xk & 1) !== 0 && a.tag !== 0 && Hk();
  f = a.pendingLanes;
  (f & 1) !== 0 ? a === zk ? yk++ : (yk = 0, zk = a) : yk = 0;
  jg();
  return null;
}
function Hk() {
  if (wk !== null) {
    var a = Dc(xk), b = ok.transition, c = C2;
    try {
      ok.transition = null;
      C2 = 16 > a ? 16 : a;
      if (wk === null)
        var d = false;
      else {
        a = wk;
        wk = null;
        xk = 0;
        if ((K2 & 6) !== 0)
          throw Error(p2(331));
        var e = K2;
        K2 |= 4;
        for (V2 = a.current;V2 !== null; ) {
          var f = V2, g = f.child;
          if ((V2.flags & 16) !== 0) {
            var h = f.deletions;
            if (h !== null) {
              for (var k = 0;k < h.length; k++) {
                var l = h[k];
                for (V2 = l;V2 !== null; ) {
                  var m = V2;
                  switch (m.tag) {
                    case 0:
                    case 11:
                    case 15:
                      Pj(8, m, f);
                  }
                  var q = m.child;
                  if (q !== null)
                    q.return = m, V2 = q;
                  else
                    for (;V2 !== null; ) {
                      m = V2;
                      var r = m.sibling, y = m.return;
                      Sj(m);
                      if (m === l) {
                        V2 = null;
                        break;
                      }
                      if (r !== null) {
                        r.return = y;
                        V2 = r;
                        break;
                      }
                      V2 = y;
                    }
                }
              }
              var n = f.alternate;
              if (n !== null) {
                var t = n.child;
                if (t !== null) {
                  n.child = null;
                  do {
                    var J = t.sibling;
                    t.sibling = null;
                    t = J;
                  } while (t !== null);
                }
              }
              V2 = f;
            }
          }
          if ((f.subtreeFlags & 2064) !== 0 && g !== null)
            g.return = f, V2 = g;
          else
            b:
              for (;V2 !== null; ) {
                f = V2;
                if ((f.flags & 2048) !== 0)
                  switch (f.tag) {
                    case 0:
                    case 11:
                    case 15:
                      Pj(9, f, f.return);
                  }
                var x = f.sibling;
                if (x !== null) {
                  x.return = f.return;
                  V2 = x;
                  break b;
                }
                V2 = f.return;
              }
        }
        var w = a.current;
        for (V2 = w;V2 !== null; ) {
          g = V2;
          var u = g.child;
          if ((g.subtreeFlags & 2064) !== 0 && u !== null)
            u.return = g, V2 = u;
          else
            b:
              for (g = w;V2 !== null; ) {
                h = V2;
                if ((h.flags & 2048) !== 0)
                  try {
                    switch (h.tag) {
                      case 0:
                      case 11:
                      case 15:
                        Qj(9, h);
                    }
                  } catch (na) {
                    W2(h, h.return, na);
                  }
                if (h === g) {
                  V2 = null;
                  break b;
                }
                var F = h.sibling;
                if (F !== null) {
                  F.return = h.return;
                  V2 = F;
                  break b;
                }
                V2 = h.return;
              }
        }
        K2 = e;
        jg();
        if (lc && typeof lc.onPostCommitFiberRoot === "function")
          try {
            lc.onPostCommitFiberRoot(kc, a);
          } catch (na) {}
        d = true;
      }
      return d;
    } finally {
      C2 = c, ok.transition = b;
    }
  }
  return false;
}
function Xk(a, b, c) {
  b = Ji(c, b);
  b = Ni(a, b, 1);
  a = nh(a, b, 1);
  b = R2();
  a !== null && (Ac(a, 1, b), Dk(a, b));
}
function W2(a, b, c) {
  if (a.tag === 3)
    Xk(a, a, c);
  else
    for (;b !== null; ) {
      if (b.tag === 3) {
        Xk(b, a, c);
        break;
      } else if (b.tag === 1) {
        var d = b.stateNode;
        if (typeof b.type.getDerivedStateFromError === "function" || typeof d.componentDidCatch === "function" && (Ri === null || !Ri.has(d))) {
          a = Ji(c, a);
          a = Qi(b, a, 1);
          b = nh(b, a, 1);
          a = R2();
          b !== null && (Ac(b, 1, a), Dk(b, a));
          break;
        }
      }
      b = b.return;
    }
}
function Ti(a, b, c) {
  var d = a.pingCache;
  d !== null && d.delete(b);
  b = R2();
  a.pingedLanes |= a.suspendedLanes & c;
  Q2 === a && (Z & c) === c && (T2 === 4 || T2 === 3 && (Z & 130023424) === Z && 500 > B2() - fk ? Kk(a, 0) : rk |= c);
  Dk(a, b);
}
function Yk(a, b) {
  b === 0 && ((a.mode & 1) === 0 ? b = 1 : (b = sc, sc <<= 1, (sc & 130023424) === 0 && (sc = 4194304)));
  var c = R2();
  a = ih(a, b);
  a !== null && (Ac(a, b, c), Dk(a, c));
}
function uj(a) {
  var b = a.memoizedState, c = 0;
  b !== null && (c = b.retryLane);
  Yk(a, c);
}
function bk(a, b) {
  var c = 0;
  switch (a.tag) {
    case 13:
      var d = a.stateNode;
      var e = a.memoizedState;
      e !== null && (c = e.retryLane);
      break;
    case 19:
      d = a.stateNode;
      break;
    default:
      throw Error(p2(314));
  }
  d !== null && d.delete(b);
  Yk(a, c);
}
function Fk(a, b) {
  return ac(a, b);
}
function $k(a, b, c, d) {
  this.tag = a;
  this.key = c;
  this.sibling = this.child = this.return = this.stateNode = this.type = this.elementType = null;
  this.index = 0;
  this.ref = null;
  this.pendingProps = b;
  this.dependencies = this.memoizedState = this.updateQueue = this.memoizedProps = null;
  this.mode = d;
  this.subtreeFlags = this.flags = 0;
  this.deletions = null;
  this.childLanes = this.lanes = 0;
  this.alternate = null;
}
function Bg(a, b, c, d) {
  return new $k(a, b, c, d);
}
function aj(a) {
  a = a.prototype;
  return !(!a || !a.isReactComponent);
}
function Zk(a) {
  if (typeof a === "function")
    return aj(a) ? 1 : 0;
  if (a !== undefined && a !== null) {
    a = a.$$typeof;
    if (a === Da)
      return 11;
    if (a === Ga)
      return 14;
  }
  return 2;
}
function Pg(a, b) {
  var c = a.alternate;
  c === null ? (c = Bg(a.tag, b, a.key, a.mode), c.elementType = a.elementType, c.type = a.type, c.stateNode = a.stateNode, c.alternate = a, a.alternate = c) : (c.pendingProps = b, c.type = a.type, c.flags = 0, c.subtreeFlags = 0, c.deletions = null);
  c.flags = a.flags & 14680064;
  c.childLanes = a.childLanes;
  c.lanes = a.lanes;
  c.child = a.child;
  c.memoizedProps = a.memoizedProps;
  c.memoizedState = a.memoizedState;
  c.updateQueue = a.updateQueue;
  b = a.dependencies;
  c.dependencies = b === null ? null : { lanes: b.lanes, firstContext: b.firstContext };
  c.sibling = a.sibling;
  c.index = a.index;
  c.ref = a.ref;
  return c;
}
function Rg(a, b, c, d, e, f) {
  var g = 2;
  d = a;
  if (typeof a === "function")
    aj(a) && (g = 1);
  else if (typeof a === "string")
    g = 5;
  else
    a:
      switch (a) {
        case ya:
          return Tg(c.children, e, f, b);
        case za:
          g = 8;
          e |= 8;
          break;
        case Aa:
          return a = Bg(12, c, b, e | 2), a.elementType = Aa, a.lanes = f, a;
        case Ea:
          return a = Bg(13, c, b, e), a.elementType = Ea, a.lanes = f, a;
        case Fa:
          return a = Bg(19, c, b, e), a.elementType = Fa, a.lanes = f, a;
        case Ia:
          return pj(c, e, f, b);
        default:
          if (typeof a === "object" && a !== null)
            switch (a.$$typeof) {
              case Ba:
                g = 10;
                break a;
              case Ca:
                g = 9;
                break a;
              case Da:
                g = 11;
                break a;
              case Ga:
                g = 14;
                break a;
              case Ha:
                g = 16;
                d = null;
                break a;
            }
          throw Error(p2(130, a == null ? a : typeof a, ""));
      }
  b = Bg(g, c, b, e);
  b.elementType = a;
  b.type = d;
  b.lanes = f;
  return b;
}
function Tg(a, b, c, d) {
  a = Bg(7, a, d, b);
  a.lanes = c;
  return a;
}
function pj(a, b, c, d) {
  a = Bg(22, a, d, b);
  a.elementType = Ia;
  a.lanes = c;
  a.stateNode = { isHidden: false };
  return a;
}
function Qg(a, b, c) {
  a = Bg(6, a, null, b);
  a.lanes = c;
  return a;
}
function Sg(a, b, c) {
  b = Bg(4, a.children !== null ? a.children : [], a.key, b);
  b.lanes = c;
  b.stateNode = { containerInfo: a.containerInfo, pendingChildren: null, implementation: a.implementation };
  return b;
}
function al(a, b, c, d, e) {
  this.tag = b;
  this.containerInfo = a;
  this.finishedWork = this.pingCache = this.current = this.pendingChildren = null;
  this.timeoutHandle = -1;
  this.callbackNode = this.pendingContext = this.context = null;
  this.callbackPriority = 0;
  this.eventTimes = zc(0);
  this.expirationTimes = zc(-1);
  this.entangledLanes = this.finishedLanes = this.mutableReadLanes = this.expiredLanes = this.pingedLanes = this.suspendedLanes = this.pendingLanes = 0;
  this.entanglements = zc(0);
  this.identifierPrefix = d;
  this.onRecoverableError = e;
  this.mutableSourceEagerHydrationData = null;
}
function bl(a, b, c, d, e, f, g, h, k) {
  a = new al(a, b, c, h, k);
  b === 1 ? (b = 1, f === true && (b |= 8)) : b = 0;
  f = Bg(3, null, null, b);
  a.current = f;
  f.stateNode = a;
  f.memoizedState = { element: d, isDehydrated: c, cache: null, transitions: null, pendingSuspenseBoundaries: null };
  kh(f);
  return a;
}
function cl(a, b, c) {
  var d = 3 < arguments.length && arguments[3] !== undefined ? arguments[3] : null;
  return { $$typeof: wa, key: d == null ? null : "" + d, children: a, containerInfo: b, implementation: c };
}
function dl(a) {
  if (!a)
    return Vf;
  a = a._reactInternals;
  a: {
    if (Vb(a) !== a || a.tag !== 1)
      throw Error(p2(170));
    var b = a;
    do {
      switch (b.tag) {
        case 3:
          b = b.stateNode.context;
          break a;
        case 1:
          if (Zf(b.type)) {
            b = b.stateNode.__reactInternalMemoizedMergedChildContext;
            break a;
          }
      }
      b = b.return;
    } while (b !== null);
    throw Error(p2(171));
  }
  if (a.tag === 1) {
    var c = a.type;
    if (Zf(c))
      return bg(a, c, b);
  }
  return b;
}
function el(a, b, c, d, e, f, g, h, k) {
  a = bl(c, d, true, a, e, f, g, h, k);
  a.context = dl(null);
  c = a.current;
  d = R2();
  e = yi(c);
  f = mh(d, e);
  f.callback = b !== undefined && b !== null ? b : null;
  nh(c, f, e);
  a.current.lanes = e;
  Ac(a, e, d);
  Dk(a, d);
  return a;
}
function fl(a, b, c, d) {
  var e = b.current, f = R2(), g = yi(e);
  c = dl(c);
  b.context === null ? b.context = c : b.pendingContext = c;
  b = mh(f, g);
  b.payload = { element: a };
  d = d === undefined ? null : d;
  d !== null && (b.callback = d);
  a = nh(e, b, g);
  a !== null && (gi(a, e, g, f), oh(a, e, g));
  return g;
}
function gl(a) {
  a = a.current;
  if (!a.child)
    return null;
  switch (a.child.tag) {
    case 5:
      return a.child.stateNode;
    default:
      return a.child.stateNode;
  }
}
function hl(a, b) {
  a = a.memoizedState;
  if (a !== null && a.dehydrated !== null) {
    var c = a.retryLane;
    a.retryLane = c !== 0 && c < b ? c : b;
  }
}
function il(a, b) {
  hl(a, b);
  (a = a.alternate) && hl(a, b);
}
function jl() {
  return null;
}
function ll(a) {
  this._internalRoot = a;
}
function ml(a) {
  this._internalRoot = a;
}
function nl(a) {
  return !(!a || a.nodeType !== 1 && a.nodeType !== 9 && a.nodeType !== 11);
}
function ol(a) {
  return !(!a || a.nodeType !== 1 && a.nodeType !== 9 && a.nodeType !== 11 && (a.nodeType !== 8 || a.nodeValue !== " react-mount-point-unstable "));
}
function pl() {}
function ql(a, b, c, d, e) {
  if (e) {
    if (typeof d === "function") {
      var f = d;
      d = function() {
        var a = gl(g);
        f.call(a);
      };
    }
    var g = el(b, d, a, 0, null, false, false, "", pl);
    a._reactRootContainer = g;
    a[uf] = g.current;
    sf(a.nodeType === 8 ? a.parentNode : a);
    Rk();
    return g;
  }
  for (;e = a.lastChild; )
    a.removeChild(e);
  if (typeof d === "function") {
    var h = d;
    d = function() {
      var a = gl(k);
      h.call(a);
    };
  }
  var k = bl(a, 0, false, null, null, false, false, "", pl);
  a._reactRootContainer = k;
  a[uf] = k.current;
  sf(a.nodeType === 8 ? a.parentNode : a);
  Rk(function() {
    fl(b, k, c, d);
  });
  return k;
}
function rl(a, b, c, d, e) {
  var f = c._reactRootContainer;
  if (f) {
    var g = f;
    if (typeof e === "function") {
      var h = e;
      e = function() {
        var a = gl(g);
        h.call(a);
      };
    }
    fl(b, g, a, e);
  } else
    g = ql(c, b, a, e, d);
  return gl(g);
}
var aa, ca, da, ea, ia, ja, ka, la, ma, z2, ra, ua, va, wa, ya, za, Aa, Ba, Ca, Da, Ea, Fa, Ga, Ha, Ia, Ja, A2, La, Na = false, eb, mb, nb, pb, qb, tb, wb = null, yb = null, zb = null, Ab = null, Ib = false, Lb = false, Mb, Ob = false, Pb = null, Qb = false, Rb = null, Sb, ac, bc, cc, dc, B2, ec, fc, gc, hc, ic, jc, kc = null, lc = null, oc, pc, qc, rc = 64, sc = 4194304, C2 = 0, Ec, Fc, Gc, Hc, Ic, Jc = false, Kc, Lc = null, Mc = null, Nc = null, Oc, Pc, Qc, Rc, cd, dd = true, id = null, kd = null, ld = null, md = null, sd, td, ud, vd, wd, xd, yd, Ad, Bd, Cd, Dd, Ed, Fd, Gd, Hd, Id, Jd, Kd, Ld, Md, Nd, Od, Qd, Rd, Sd, Td, Ud, Vd, Wd, Xd, Yd, Zd, $d, ae, be = null, ce, de, ee, fe = false, ie = false, le, pe = null, qe = null, we = false, xe, ye, ze, He, Pe, Qe = null, Re = null, Se = null, Te = false, We, Xe, Ye, $e, af, bf, cf, df, ef, hf, jf, kf, gf, lf, mf, rf, xf, yf, Cf = null, Df = null, Ff, Gf, Hf, Jf, Nf, Of, Pf, uf, of, Qf, Rf, Sf, Tf = -1, Vf, H2, Wf, Xf, eg = null, fg = false, gg = false, kg, lg = 0, mg = null, ng = 0, og, pg = 0, qg = null, rg = 1, sg = "", xg = null, yg = null, I2 = false, zg = null, Kg, Ug, Vg, Wg, Xg = null, Yg = null, Zg = null, fh = null, jh = false, th, uh, vh, wh, L2, Dh, Fh, Gh, Hh = 0, M2 = null, N2 = null, O2 = null, Ih = false, Jh = false, Kh = 0, Lh = 0, Rh, Oh, Ph, Qh, Ei, Mi, Wi, dh = false, mj, zj, Aj, Bj, Cj, Jj = false, U2 = false, Kj, V2 = null, Nj = false, X2 = null, Xj = false, lk, mk, nk, ok, K2 = 0, Q2 = null, Y = null, Z = 0, fj = 0, ej, T2 = 0, pk = null, rh = 0, qk = 0, rk = 0, sk = null, tk = null, fk = 0, Gj = Infinity, uk = null, Oi = false, Pi = null, Ri = null, vk = false, wk = null, xk = 0, yk = 0, zk = null, Ak = -1, Bk = 0, Vk, kl, sl, tl, ul, vl, $__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED2, $createPortal = function(a, b) {
  var c = 2 < arguments.length && arguments[2] !== undefined ? arguments[2] : null;
  if (!nl(b))
    throw Error(p2(200));
  return cl(a, b, null, c);
}, $createRoot = function(a, b) {
  if (!nl(a))
    throw Error(p2(299));
  var c = false, d = "", e = kl;
  b !== null && b !== undefined && (b.unstable_strictMode === true && (c = true), b.identifierPrefix !== undefined && (d = b.identifierPrefix), b.onRecoverableError !== undefined && (e = b.onRecoverableError));
  b = bl(a, 1, false, null, null, c, false, d, e);
  a[uf] = b.current;
  sf(a.nodeType === 8 ? a.parentNode : a);
  return new ll(b);
}, $findDOMNode = function(a) {
  if (a == null)
    return null;
  if (a.nodeType === 1)
    return a;
  var b = a._reactInternals;
  if (b === undefined) {
    if (typeof a.render === "function")
      throw Error(p2(188));
    a = Object.keys(a).join(",");
    throw Error(p2(268, a));
  }
  a = Zb(b);
  a = a === null ? null : a.stateNode;
  return a;
}, $flushSync = function(a) {
  return Rk(a);
}, $hydrate = function(a, b, c) {
  if (!ol(b))
    throw Error(p2(200));
  return rl(null, a, b, true, c);
}, $hydrateRoot = function(a, b, c) {
  if (!nl(a))
    throw Error(p2(405));
  var d = c != null && c.hydratedSources || null, e = false, f = "", g = kl;
  c !== null && c !== undefined && (c.unstable_strictMode === true && (e = true), c.identifierPrefix !== undefined && (f = c.identifierPrefix), c.onRecoverableError !== undefined && (g = c.onRecoverableError));
  b = el(b, null, a, 1, c != null ? c : null, e, false, f, g);
  a[uf] = b.current;
  sf(a);
  if (d)
    for (a = 0;a < d.length; a++)
      c = d[a], e = c._getVersion, e = e(c._source), b.mutableSourceEagerHydrationData == null ? b.mutableSourceEagerHydrationData = [c, e] : b.mutableSourceEagerHydrationData.push(c, e);
  return new ml(b);
}, $render = function(a, b, c) {
  if (!ol(b))
    throw Error(p2(200));
  return rl(null, a, b, false, c);
}, $unmountComponentAtNode = function(a) {
  if (!ol(a))
    throw Error(p2(40));
  return a._reactRootContainer ? (Rk(function() {
    rl(null, null, a, false, function() {
      a._reactRootContainer = null;
      a[uf] = null;
    });
  }), true) : false;
}, $unstable_batchedUpdates, $unstable_renderSubtreeIntoContainer = function(a, b, c, d) {
  if (!ol(c))
    throw Error(p2(200));
  if (a == null || a._reactInternals === undefined)
    throw Error(p2(38));
  return rl(a, b, c, false, d);
}, $version2 = "18.3.1-next-f1338f8080-20240426";
var init_react_dom_production_min = __esm(() => {
  aa = __toESM(require_react());
  ca = __toESM(require_scheduler());
  da = new Set;
  ea = {};
  ia = !(typeof window === "undefined" || typeof window.document === "undefined" || typeof window.document.createElement === "undefined");
  ja = Object.prototype.hasOwnProperty;
  ka = /^[:A-Z_a-z\u00C0-\u00D6\u00D8-\u00F6\u00F8-\u02FF\u0370-\u037D\u037F-\u1FFF\u200C-\u200D\u2070-\u218F\u2C00-\u2FEF\u3001-\uD7FF\uF900-\uFDCF\uFDF0-\uFFFD][:A-Z_a-z\u00C0-\u00D6\u00D8-\u00F6\u00F8-\u02FF\u0370-\u037D\u037F-\u1FFF\u200C-\u200D\u2070-\u218F\u2C00-\u2FEF\u3001-\uD7FF\uF900-\uFDCF\uFDF0-\uFFFD\-.0-9\u00B7\u0300-\u036F\u203F-\u2040]*$/;
  la = {};
  ma = {};
  z2 = {};
  "children dangerouslySetInnerHTML defaultValue defaultChecked innerHTML suppressContentEditableWarning suppressHydrationWarning style".split(" ").forEach(function(a) {
    z2[a] = new v2(a, 0, false, a, null, false, false);
  });
  [["acceptCharset", "accept-charset"], ["className", "class"], ["htmlFor", "for"], ["httpEquiv", "http-equiv"]].forEach(function(a) {
    var b = a[0];
    z2[b] = new v2(b, 1, false, a[1], null, false, false);
  });
  ["contentEditable", "draggable", "spellCheck", "value"].forEach(function(a) {
    z2[a] = new v2(a, 2, false, a.toLowerCase(), null, false, false);
  });
  ["autoReverse", "externalResourcesRequired", "focusable", "preserveAlpha"].forEach(function(a) {
    z2[a] = new v2(a, 2, false, a, null, false, false);
  });
  "allowFullScreen async autoFocus autoPlay controls default defer disabled disablePictureInPicture disableRemotePlayback formNoValidate hidden loop noModule noValidate open playsInline readOnly required reversed scoped seamless itemScope".split(" ").forEach(function(a) {
    z2[a] = new v2(a, 3, false, a.toLowerCase(), null, false, false);
  });
  ["checked", "multiple", "muted", "selected"].forEach(function(a) {
    z2[a] = new v2(a, 3, true, a, null, false, false);
  });
  ["capture", "download"].forEach(function(a) {
    z2[a] = new v2(a, 4, false, a, null, false, false);
  });
  ["cols", "rows", "size", "span"].forEach(function(a) {
    z2[a] = new v2(a, 6, false, a, null, false, false);
  });
  ["rowSpan", "start"].forEach(function(a) {
    z2[a] = new v2(a, 5, false, a.toLowerCase(), null, false, false);
  });
  ra = /[\-:]([a-z])/g;
  "accent-height alignment-baseline arabic-form baseline-shift cap-height clip-path clip-rule color-interpolation color-interpolation-filters color-profile color-rendering dominant-baseline enable-background fill-opacity fill-rule flood-color flood-opacity font-family font-size font-size-adjust font-stretch font-style font-variant font-weight glyph-name glyph-orientation-horizontal glyph-orientation-vertical horiz-adv-x horiz-origin-x image-rendering letter-spacing lighting-color marker-end marker-mid marker-start overline-position overline-thickness paint-order panose-1 pointer-events rendering-intent shape-rendering stop-color stop-opacity strikethrough-position strikethrough-thickness stroke-dasharray stroke-dashoffset stroke-linecap stroke-linejoin stroke-miterlimit stroke-opacity stroke-width text-anchor text-decoration text-rendering underline-position underline-thickness unicode-bidi unicode-range units-per-em v-alphabetic v-hanging v-ideographic v-mathematical vector-effect vert-adv-y vert-origin-x vert-origin-y word-spacing writing-mode xmlns:xlink x-height".split(" ").forEach(function(a) {
    var b = a.replace(ra, sa);
    z2[b] = new v2(b, 1, false, a, null, false, false);
  });
  "xlink:actuate xlink:arcrole xlink:role xlink:show xlink:title xlink:type".split(" ").forEach(function(a) {
    var b = a.replace(ra, sa);
    z2[b] = new v2(b, 1, false, a, "http://www.w3.org/1999/xlink", false, false);
  });
  ["xml:base", "xml:lang", "xml:space"].forEach(function(a) {
    var b = a.replace(ra, sa);
    z2[b] = new v2(b, 1, false, a, "http://www.w3.org/XML/1998/namespace", false, false);
  });
  ["tabIndex", "crossOrigin"].forEach(function(a) {
    z2[a] = new v2(a, 1, false, a.toLowerCase(), null, false, false);
  });
  z2.xlinkHref = new v2("xlinkHref", 1, false, "xlink:href", "http://www.w3.org/1999/xlink", true, false);
  ["src", "href", "action", "formAction"].forEach(function(a) {
    z2[a] = new v2(a, 1, false, a.toLowerCase(), null, true, true);
  });
  ua = aa.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED;
  va = Symbol.for("react.element");
  wa = Symbol.for("react.portal");
  ya = Symbol.for("react.fragment");
  za = Symbol.for("react.strict_mode");
  Aa = Symbol.for("react.profiler");
  Ba = Symbol.for("react.provider");
  Ca = Symbol.for("react.context");
  Da = Symbol.for("react.forward_ref");
  Ea = Symbol.for("react.suspense");
  Fa = Symbol.for("react.suspense_list");
  Ga = Symbol.for("react.memo");
  Ha = Symbol.for("react.lazy");
  Symbol.for("react.scope");
  Symbol.for("react.debug_trace_mode");
  Ia = Symbol.for("react.offscreen");
  Symbol.for("react.legacy_hidden");
  Symbol.for("react.cache");
  Symbol.for("react.tracing_marker");
  Ja = Symbol.iterator;
  A2 = Object.assign;
  eb = Array.isArray;
  nb = function(a) {
    return typeof MSApp !== "undefined" && MSApp.execUnsafeLocalFunction ? function(b, c, d, e) {
      MSApp.execUnsafeLocalFunction(function() {
        return a(b, c, d, e);
      });
    } : a;
  }(function(a, b) {
    if (a.namespaceURI !== "http://www.w3.org/2000/svg" || "innerHTML" in a)
      a.innerHTML = b;
    else {
      mb = mb || document.createElement("div");
      mb.innerHTML = "<svg>" + b.valueOf().toString() + "</svg>";
      for (b = mb.firstChild;a.firstChild; )
        a.removeChild(a.firstChild);
      for (;b.firstChild; )
        a.appendChild(b.firstChild);
    }
  });
  pb = {
    animationIterationCount: true,
    aspectRatio: true,
    borderImageOutset: true,
    borderImageSlice: true,
    borderImageWidth: true,
    boxFlex: true,
    boxFlexGroup: true,
    boxOrdinalGroup: true,
    columnCount: true,
    columns: true,
    flex: true,
    flexGrow: true,
    flexPositive: true,
    flexShrink: true,
    flexNegative: true,
    flexOrder: true,
    gridArea: true,
    gridRow: true,
    gridRowEnd: true,
    gridRowSpan: true,
    gridRowStart: true,
    gridColumn: true,
    gridColumnEnd: true,
    gridColumnSpan: true,
    gridColumnStart: true,
    fontWeight: true,
    lineClamp: true,
    lineHeight: true,
    opacity: true,
    order: true,
    orphans: true,
    tabSize: true,
    widows: true,
    zIndex: true,
    zoom: true,
    fillOpacity: true,
    floodOpacity: true,
    stopOpacity: true,
    strokeDasharray: true,
    strokeDashoffset: true,
    strokeMiterlimit: true,
    strokeOpacity: true,
    strokeWidth: true
  };
  qb = ["Webkit", "ms", "Moz", "O"];
  Object.keys(pb).forEach(function(a) {
    qb.forEach(function(b) {
      b = b + a.charAt(0).toUpperCase() + a.substring(1);
      pb[b] = pb[a];
    });
  });
  tb = A2({ menuitem: true }, { area: true, base: true, br: true, col: true, embed: true, hr: true, img: true, input: true, keygen: true, link: true, meta: true, param: true, source: true, track: true, wbr: true });
  if (ia)
    try {
      Mb = {};
      Object.defineProperty(Mb, "passive", { get: function() {
        Lb = true;
      } });
      window.addEventListener("test", Mb, Mb);
      window.removeEventListener("test", Mb, Mb);
    } catch (a) {
      Lb = false;
    }
  Sb = { onError: function(a) {
    Ob = true;
    Pb = a;
  } };
  ac = ca.unstable_scheduleCallback;
  bc = ca.unstable_cancelCallback;
  cc = ca.unstable_shouldYield;
  dc = ca.unstable_requestPaint;
  B2 = ca.unstable_now;
  ec = ca.unstable_getCurrentPriorityLevel;
  fc = ca.unstable_ImmediatePriority;
  gc = ca.unstable_UserBlockingPriority;
  hc = ca.unstable_NormalPriority;
  ic = ca.unstable_LowPriority;
  jc = ca.unstable_IdlePriority;
  oc = Math.clz32 ? Math.clz32 : nc;
  pc = Math.log;
  qc = Math.LN2;
  Kc = [];
  Oc = new Map;
  Pc = new Map;
  Qc = [];
  Rc = "mousedown mouseup touchcancel touchend touchstart auxclick dblclick pointercancel pointerdown pointerup dragend dragstart drop compositionend compositionstart keydown keypress keyup input textInput copy cut paste click change contextmenu reset submit".split(" ");
  cd = ua.ReactCurrentBatchConfig;
  sd = { eventPhase: 0, bubbles: 0, cancelable: 0, timeStamp: function(a) {
    return a.timeStamp || Date.now();
  }, defaultPrevented: 0, isTrusted: 0 };
  td = rd(sd);
  ud = A2({}, sd, { view: 0, detail: 0 });
  vd = rd(ud);
  Ad = A2({}, ud, { screenX: 0, screenY: 0, clientX: 0, clientY: 0, pageX: 0, pageY: 0, ctrlKey: 0, shiftKey: 0, altKey: 0, metaKey: 0, getModifierState: zd, button: 0, buttons: 0, relatedTarget: function(a) {
    return a.relatedTarget === undefined ? a.fromElement === a.srcElement ? a.toElement : a.fromElement : a.relatedTarget;
  }, movementX: function(a) {
    if ("movementX" in a)
      return a.movementX;
    a !== yd && (yd && a.type === "mousemove" ? (wd = a.screenX - yd.screenX, xd = a.screenY - yd.screenY) : xd = wd = 0, yd = a);
    return wd;
  }, movementY: function(a) {
    return "movementY" in a ? a.movementY : xd;
  } });
  Bd = rd(Ad);
  Cd = A2({}, Ad, { dataTransfer: 0 });
  Dd = rd(Cd);
  Ed = A2({}, ud, { relatedTarget: 0 });
  Fd = rd(Ed);
  Gd = A2({}, sd, { animationName: 0, elapsedTime: 0, pseudoElement: 0 });
  Hd = rd(Gd);
  Id = A2({}, sd, { clipboardData: function(a) {
    return "clipboardData" in a ? a.clipboardData : window.clipboardData;
  } });
  Jd = rd(Id);
  Kd = A2({}, sd, { data: 0 });
  Ld = rd(Kd);
  Md = {
    Esc: "Escape",
    Spacebar: " ",
    Left: "ArrowLeft",
    Up: "ArrowUp",
    Right: "ArrowRight",
    Down: "ArrowDown",
    Del: "Delete",
    Win: "OS",
    Menu: "ContextMenu",
    Apps: "ContextMenu",
    Scroll: "ScrollLock",
    MozPrintableKey: "Unidentified"
  };
  Nd = {
    8: "Backspace",
    9: "Tab",
    12: "Clear",
    13: "Enter",
    16: "Shift",
    17: "Control",
    18: "Alt",
    19: "Pause",
    20: "CapsLock",
    27: "Escape",
    32: " ",
    33: "PageUp",
    34: "PageDown",
    35: "End",
    36: "Home",
    37: "ArrowLeft",
    38: "ArrowUp",
    39: "ArrowRight",
    40: "ArrowDown",
    45: "Insert",
    46: "Delete",
    112: "F1",
    113: "F2",
    114: "F3",
    115: "F4",
    116: "F5",
    117: "F6",
    118: "F7",
    119: "F8",
    120: "F9",
    121: "F10",
    122: "F11",
    123: "F12",
    144: "NumLock",
    145: "ScrollLock",
    224: "Meta"
  };
  Od = { Alt: "altKey", Control: "ctrlKey", Meta: "metaKey", Shift: "shiftKey" };
  Qd = A2({}, ud, { key: function(a) {
    if (a.key) {
      var b = Md[a.key] || a.key;
      if (b !== "Unidentified")
        return b;
    }
    return a.type === "keypress" ? (a = od(a), a === 13 ? "Enter" : String.fromCharCode(a)) : a.type === "keydown" || a.type === "keyup" ? Nd[a.keyCode] || "Unidentified" : "";
  }, code: 0, location: 0, ctrlKey: 0, shiftKey: 0, altKey: 0, metaKey: 0, repeat: 0, locale: 0, getModifierState: zd, charCode: function(a) {
    return a.type === "keypress" ? od(a) : 0;
  }, keyCode: function(a) {
    return a.type === "keydown" || a.type === "keyup" ? a.keyCode : 0;
  }, which: function(a) {
    return a.type === "keypress" ? od(a) : a.type === "keydown" || a.type === "keyup" ? a.keyCode : 0;
  } });
  Rd = rd(Qd);
  Sd = A2({}, Ad, { pointerId: 0, width: 0, height: 0, pressure: 0, tangentialPressure: 0, tiltX: 0, tiltY: 0, twist: 0, pointerType: 0, isPrimary: 0 });
  Td = rd(Sd);
  Ud = A2({}, ud, { touches: 0, targetTouches: 0, changedTouches: 0, altKey: 0, metaKey: 0, ctrlKey: 0, shiftKey: 0, getModifierState: zd });
  Vd = rd(Ud);
  Wd = A2({}, sd, { propertyName: 0, elapsedTime: 0, pseudoElement: 0 });
  Xd = rd(Wd);
  Yd = A2({}, Ad, {
    deltaX: function(a) {
      return "deltaX" in a ? a.deltaX : ("wheelDeltaX" in a) ? -a.wheelDeltaX : 0;
    },
    deltaY: function(a) {
      return "deltaY" in a ? a.deltaY : ("wheelDeltaY" in a) ? -a.wheelDeltaY : ("wheelDelta" in a) ? -a.wheelDelta : 0;
    },
    deltaZ: 0,
    deltaMode: 0
  });
  Zd = rd(Yd);
  $d = [9, 13, 27, 32];
  ae = ia && "CompositionEvent" in window;
  ia && "documentMode" in document && (be = document.documentMode);
  ce = ia && "TextEvent" in window && !be;
  de = ia && (!ae || be && 8 < be && 11 >= be);
  ee = String.fromCharCode(32);
  le = { color: true, date: true, datetime: true, "datetime-local": true, email: true, month: true, number: true, password: true, range: true, search: true, tel: true, text: true, time: true, url: true, week: true };
  if (ia) {
    if (ia) {
      ye = "oninput" in document;
      if (!ye) {
        ze = document.createElement("div");
        ze.setAttribute("oninput", "return;");
        ye = typeof ze.oninput === "function";
      }
      xe = ye;
    } else
      xe = false;
    we = xe && (!document.documentMode || 9 < document.documentMode);
  }
  He = typeof Object.is === "function" ? Object.is : Ge;
  Pe = ia && "documentMode" in document && 11 >= document.documentMode;
  We = { animationend: Ve("Animation", "AnimationEnd"), animationiteration: Ve("Animation", "AnimationIteration"), animationstart: Ve("Animation", "AnimationStart"), transitionend: Ve("Transition", "TransitionEnd") };
  Xe = {};
  Ye = {};
  ia && (Ye = document.createElement("div").style, ("AnimationEvent" in window) || (delete We.animationend.animation, delete We.animationiteration.animation, delete We.animationstart.animation), ("TransitionEvent" in window) || delete We.transitionend.transition);
  $e = Ze("animationend");
  af = Ze("animationiteration");
  bf = Ze("animationstart");
  cf = Ze("transitionend");
  df = new Map;
  ef = "abort auxClick cancel canPlay canPlayThrough click close contextMenu copy cut drag dragEnd dragEnter dragExit dragLeave dragOver dragStart drop durationChange emptied encrypted ended error gotPointerCapture input invalid keyDown keyPress keyUp load loadedData loadedMetadata loadStart lostPointerCapture mouseDown mouseMove mouseOut mouseOver mouseUp paste pause play playing pointerCancel pointerDown pointerMove pointerOut pointerOver pointerUp progress rateChange reset resize seeked seeking stalled submit suspend timeUpdate touchCancel touchEnd touchStart volumeChange scroll toggle touchMove waiting wheel".split(" ");
  for (gf = 0;gf < ef.length; gf++) {
    hf = ef[gf], jf = hf.toLowerCase(), kf = hf[0].toUpperCase() + hf.slice(1);
    ff(jf, "on" + kf);
  }
  ff($e, "onAnimationEnd");
  ff(af, "onAnimationIteration");
  ff(bf, "onAnimationStart");
  ff("dblclick", "onDoubleClick");
  ff("focusin", "onFocus");
  ff("focusout", "onBlur");
  ff(cf, "onTransitionEnd");
  ha("onMouseEnter", ["mouseout", "mouseover"]);
  ha("onMouseLeave", ["mouseout", "mouseover"]);
  ha("onPointerEnter", ["pointerout", "pointerover"]);
  ha("onPointerLeave", ["pointerout", "pointerover"]);
  fa("onChange", "change click focusin focusout input keydown keyup selectionchange".split(" "));
  fa("onSelect", "focusout contextmenu dragend focusin keydown keyup mousedown mouseup selectionchange".split(" "));
  fa("onBeforeInput", ["compositionend", "keypress", "textInput", "paste"]);
  fa("onCompositionEnd", "compositionend focusout keydown keypress keyup mousedown".split(" "));
  fa("onCompositionStart", "compositionstart focusout keydown keypress keyup mousedown".split(" "));
  fa("onCompositionUpdate", "compositionupdate focusout keydown keypress keyup mousedown".split(" "));
  lf = "abort canplay canplaythrough durationchange emptied encrypted ended error loadeddata loadedmetadata loadstart pause play playing progress ratechange resize seeked seeking stalled suspend timeupdate volumechange waiting".split(" ");
  mf = new Set("cancel close invalid load scroll toggle".split(" ").concat(lf));
  rf = "_reactListening" + Math.random().toString(36).slice(2);
  xf = /\r\n?/g;
  yf = /\u0000|\uFFFD/g;
  Ff = typeof setTimeout === "function" ? setTimeout : undefined;
  Gf = typeof clearTimeout === "function" ? clearTimeout : undefined;
  Hf = typeof Promise === "function" ? Promise : undefined;
  Jf = typeof queueMicrotask === "function" ? queueMicrotask : typeof Hf !== "undefined" ? function(a) {
    return Hf.resolve(null).then(a).catch(If);
  } : Ff;
  Nf = Math.random().toString(36).slice(2);
  Of = "__reactFiber$" + Nf;
  Pf = "__reactProps$" + Nf;
  uf = "__reactContainer$" + Nf;
  of = "__reactEvents$" + Nf;
  Qf = "__reactListeners$" + Nf;
  Rf = "__reactHandles$" + Nf;
  Sf = [];
  Vf = {};
  H2 = Uf(Vf);
  Wf = Uf(false);
  Xf = Vf;
  kg = [];
  og = [];
  Kg = ua.ReactCurrentBatchConfig;
  Ug = Og(true);
  Vg = Og(false);
  Wg = Uf(null);
  th = {};
  uh = Uf(th);
  vh = Uf(th);
  wh = Uf(th);
  L2 = Uf(0);
  Dh = [];
  Fh = ua.ReactCurrentDispatcher;
  Gh = ua.ReactCurrentBatchConfig;
  Rh = { readContext: eh, useCallback: P2, useContext: P2, useEffect: P2, useImperativeHandle: P2, useInsertionEffect: P2, useLayoutEffect: P2, useMemo: P2, useReducer: P2, useRef: P2, useState: P2, useDebugValue: P2, useDeferredValue: P2, useTransition: P2, useMutableSource: P2, useSyncExternalStore: P2, useId: P2, unstable_isNewReconciler: false };
  Oh = { readContext: eh, useCallback: function(a, b) {
    Th().memoizedState = [a, b === undefined ? null : b];
    return a;
  }, useContext: eh, useEffect: mi, useImperativeHandle: function(a, b, c) {
    c = c !== null && c !== undefined ? c.concat([a]) : null;
    return ki(4194308, 4, pi.bind(null, b, a), c);
  }, useLayoutEffect: function(a, b) {
    return ki(4194308, 4, a, b);
  }, useInsertionEffect: function(a, b) {
    return ki(4, 2, a, b);
  }, useMemo: function(a, b) {
    var c = Th();
    b = b === undefined ? null : b;
    a = a();
    c.memoizedState = [a, b];
    return a;
  }, useReducer: function(a, b, c) {
    var d = Th();
    b = c !== undefined ? c(b) : b;
    d.memoizedState = d.baseState = b;
    a = { pending: null, interleaved: null, lanes: 0, dispatch: null, lastRenderedReducer: a, lastRenderedState: b };
    d.queue = a;
    a = a.dispatch = xi.bind(null, M2, a);
    return [d.memoizedState, a];
  }, useRef: function(a) {
    var b = Th();
    a = { current: a };
    return b.memoizedState = a;
  }, useState: hi, useDebugValue: ri, useDeferredValue: function(a) {
    return Th().memoizedState = a;
  }, useTransition: function() {
    var a = hi(false), b = a[0];
    a = vi.bind(null, a[1]);
    Th().memoizedState = a;
    return [b, a];
  }, useMutableSource: function() {}, useSyncExternalStore: function(a, b, c) {
    var d = M2, e = Th();
    if (I2) {
      if (c === undefined)
        throw Error(p2(407));
      c = c();
    } else {
      c = b();
      if (Q2 === null)
        throw Error(p2(349));
      (Hh & 30) !== 0 || di(d, b, c);
    }
    e.memoizedState = c;
    var f = { value: c, getSnapshot: b };
    e.queue = f;
    mi(ai.bind(null, d, f, a), [a]);
    d.flags |= 2048;
    bi(9, ci.bind(null, d, f, c, b), undefined, null);
    return c;
  }, useId: function() {
    var a = Th(), b = Q2.identifierPrefix;
    if (I2) {
      var c = sg;
      var d = rg;
      c = (d & ~(1 << 32 - oc(d) - 1)).toString(32) + c;
      b = ":" + b + "R" + c;
      c = Kh++;
      0 < c && (b += "H" + c.toString(32));
      b += ":";
    } else
      c = Lh++, b = ":" + b + "r" + c.toString(32) + ":";
    return a.memoizedState = b;
  }, unstable_isNewReconciler: false };
  Ph = {
    readContext: eh,
    useCallback: si,
    useContext: eh,
    useEffect: $h,
    useImperativeHandle: qi,
    useInsertionEffect: ni,
    useLayoutEffect: oi,
    useMemo: ti,
    useReducer: Wh,
    useRef: ji,
    useState: function() {
      return Wh(Vh);
    },
    useDebugValue: ri,
    useDeferredValue: function(a) {
      var b = Uh();
      return ui(b, N2.memoizedState, a);
    },
    useTransition: function() {
      var a = Wh(Vh)[0], b = Uh().memoizedState;
      return [a, b];
    },
    useMutableSource: Yh,
    useSyncExternalStore: Zh,
    useId: wi,
    unstable_isNewReconciler: false
  };
  Qh = { readContext: eh, useCallback: si, useContext: eh, useEffect: $h, useImperativeHandle: qi, useInsertionEffect: ni, useLayoutEffect: oi, useMemo: ti, useReducer: Xh, useRef: ji, useState: function() {
    return Xh(Vh);
  }, useDebugValue: ri, useDeferredValue: function(a) {
    var b = Uh();
    return N2 === null ? b.memoizedState = a : ui(b, N2.memoizedState, a);
  }, useTransition: function() {
    var a = Xh(Vh)[0], b = Uh().memoizedState;
    return [a, b];
  }, useMutableSource: Yh, useSyncExternalStore: Zh, useId: wi, unstable_isNewReconciler: false };
  Ei = { isMounted: function(a) {
    return (a = a._reactInternals) ? Vb(a) === a : false;
  }, enqueueSetState: function(a, b, c) {
    a = a._reactInternals;
    var d = R2(), e = yi(a), f = mh(d, e);
    f.payload = b;
    c !== undefined && c !== null && (f.callback = c);
    b = nh(a, f, e);
    b !== null && (gi(b, a, e, d), oh(b, a, e));
  }, enqueueReplaceState: function(a, b, c) {
    a = a._reactInternals;
    var d = R2(), e = yi(a), f = mh(d, e);
    f.tag = 1;
    f.payload = b;
    c !== undefined && c !== null && (f.callback = c);
    b = nh(a, f, e);
    b !== null && (gi(b, a, e, d), oh(b, a, e));
  }, enqueueForceUpdate: function(a, b) {
    a = a._reactInternals;
    var c = R2(), d = yi(a), e = mh(c, d);
    e.tag = 2;
    b !== undefined && b !== null && (e.callback = b);
    b = nh(a, e, d);
    b !== null && (gi(b, a, d, c), oh(b, a, d));
  } };
  Mi = typeof WeakMap === "function" ? WeakMap : Map;
  Wi = ua.ReactCurrentOwner;
  mj = { dehydrated: null, treeContext: null, retryLane: 0 };
  zj = function(a, b) {
    for (var c = b.child;c !== null; ) {
      if (c.tag === 5 || c.tag === 6)
        a.appendChild(c.stateNode);
      else if (c.tag !== 4 && c.child !== null) {
        c.child.return = c;
        c = c.child;
        continue;
      }
      if (c === b)
        break;
      for (;c.sibling === null; ) {
        if (c.return === null || c.return === b)
          return;
        c = c.return;
      }
      c.sibling.return = c.return;
      c = c.sibling;
    }
  };
  Aj = function() {};
  Bj = function(a, b, c, d) {
    var e = a.memoizedProps;
    if (e !== d) {
      a = b.stateNode;
      xh(uh.current);
      var f = null;
      switch (c) {
        case "input":
          e = Ya(a, e);
          d = Ya(a, d);
          f = [];
          break;
        case "select":
          e = A2({}, e, { value: undefined });
          d = A2({}, d, { value: undefined });
          f = [];
          break;
        case "textarea":
          e = gb(a, e);
          d = gb(a, d);
          f = [];
          break;
        default:
          typeof e.onClick !== "function" && typeof d.onClick === "function" && (a.onclick = Bf);
      }
      ub(c, d);
      var g;
      c = null;
      for (l in e)
        if (!d.hasOwnProperty(l) && e.hasOwnProperty(l) && e[l] != null)
          if (l === "style") {
            var h = e[l];
            for (g in h)
              h.hasOwnProperty(g) && (c || (c = {}), c[g] = "");
          } else
            l !== "dangerouslySetInnerHTML" && l !== "children" && l !== "suppressContentEditableWarning" && l !== "suppressHydrationWarning" && l !== "autoFocus" && (ea.hasOwnProperty(l) ? f || (f = []) : (f = f || []).push(l, null));
      for (l in d) {
        var k = d[l];
        h = e != null ? e[l] : undefined;
        if (d.hasOwnProperty(l) && k !== h && (k != null || h != null))
          if (l === "style")
            if (h) {
              for (g in h)
                !h.hasOwnProperty(g) || k && k.hasOwnProperty(g) || (c || (c = {}), c[g] = "");
              for (g in k)
                k.hasOwnProperty(g) && h[g] !== k[g] && (c || (c = {}), c[g] = k[g]);
            } else
              c || (f || (f = []), f.push(l, c)), c = k;
          else
            l === "dangerouslySetInnerHTML" ? (k = k ? k.__html : undefined, h = h ? h.__html : undefined, k != null && h !== k && (f = f || []).push(l, k)) : l === "children" ? typeof k !== "string" && typeof k !== "number" || (f = f || []).push(l, "" + k) : l !== "suppressContentEditableWarning" && l !== "suppressHydrationWarning" && (ea.hasOwnProperty(l) ? (k != null && l === "onScroll" && D2("scroll", a), f || h === k || (f = [])) : (f = f || []).push(l, k));
      }
      c && (f = f || []).push("style", c);
      var l = f;
      if (b.updateQueue = l)
        b.flags |= 4;
    }
  };
  Cj = function(a, b, c, d) {
    c !== d && (b.flags |= 4);
  };
  Kj = typeof WeakSet === "function" ? WeakSet : Set;
  lk = Math.ceil;
  mk = ua.ReactCurrentDispatcher;
  nk = ua.ReactCurrentOwner;
  ok = ua.ReactCurrentBatchConfig;
  ej = Uf(0);
  Vk = function(a, b, c) {
    if (a !== null)
      if (a.memoizedProps !== b.pendingProps || Wf.current)
        dh = true;
      else {
        if ((a.lanes & c) === 0 && (b.flags & 128) === 0)
          return dh = false, yj(a, b, c);
        dh = (a.flags & 131072) !== 0 ? true : false;
      }
    else
      dh = false, I2 && (b.flags & 1048576) !== 0 && ug(b, ng, b.index);
    b.lanes = 0;
    switch (b.tag) {
      case 2:
        var d = b.type;
        ij(a, b);
        a = b.pendingProps;
        var e = Yf(b, H2.current);
        ch(b, c);
        e = Nh(null, b, d, a, e, c);
        var f = Sh();
        b.flags |= 1;
        typeof e === "object" && e !== null && typeof e.render === "function" && e.$$typeof === undefined ? (b.tag = 1, b.memoizedState = null, b.updateQueue = null, Zf(d) ? (f = true, cg(b)) : f = false, b.memoizedState = e.state !== null && e.state !== undefined ? e.state : null, kh(b), e.updater = Ei, b.stateNode = e, e._reactInternals = b, Ii(b, d, a, c), b = jj(null, b, d, true, f, c)) : (b.tag = 0, I2 && f && vg(b), Xi(null, b, e, c), b = b.child);
        return b;
      case 16:
        d = b.elementType;
        a: {
          ij(a, b);
          a = b.pendingProps;
          e = d._init;
          d = e(d._payload);
          b.type = d;
          e = b.tag = Zk(d);
          a = Ci(d, a);
          switch (e) {
            case 0:
              b = cj(null, b, d, a, c);
              break a;
            case 1:
              b = hj(null, b, d, a, c);
              break a;
            case 11:
              b = Yi(null, b, d, a, c);
              break a;
            case 14:
              b = $i(null, b, d, Ci(d.type, a), c);
              break a;
          }
          throw Error(p2(306, d, ""));
        }
        return b;
      case 0:
        return d = b.type, e = b.pendingProps, e = b.elementType === d ? e : Ci(d, e), cj(a, b, d, e, c);
      case 1:
        return d = b.type, e = b.pendingProps, e = b.elementType === d ? e : Ci(d, e), hj(a, b, d, e, c);
      case 3:
        a: {
          kj(b);
          if (a === null)
            throw Error(p2(387));
          d = b.pendingProps;
          f = b.memoizedState;
          e = f.element;
          lh(a, b);
          qh(b, d, null, c);
          var g = b.memoizedState;
          d = g.element;
          if (f.isDehydrated)
            if (f = { element: d, isDehydrated: false, cache: g.cache, pendingSuspenseBoundaries: g.pendingSuspenseBoundaries, transitions: g.transitions }, b.updateQueue.baseState = f, b.memoizedState = f, b.flags & 256) {
              e = Ji(Error(p2(423)), b);
              b = lj(a, b, d, c, e);
              break a;
            } else if (d !== e) {
              e = Ji(Error(p2(424)), b);
              b = lj(a, b, d, c, e);
              break a;
            } else
              for (yg = Lf(b.stateNode.containerInfo.firstChild), xg = b, I2 = true, zg = null, c = Vg(b, null, d, c), b.child = c;c; )
                c.flags = c.flags & -3 | 4096, c = c.sibling;
          else {
            Ig();
            if (d === e) {
              b = Zi(a, b, c);
              break a;
            }
            Xi(a, b, d, c);
          }
          b = b.child;
        }
        return b;
      case 5:
        return Ah(b), a === null && Eg(b), d = b.type, e = b.pendingProps, f = a !== null ? a.memoizedProps : null, g = e.children, Ef(d, e) ? g = null : f !== null && Ef(d, f) && (b.flags |= 32), gj(a, b), Xi(a, b, g, c), b.child;
      case 6:
        return a === null && Eg(b), null;
      case 13:
        return oj(a, b, c);
      case 4:
        return yh(b, b.stateNode.containerInfo), d = b.pendingProps, a === null ? b.child = Ug(b, null, d, c) : Xi(a, b, d, c), b.child;
      case 11:
        return d = b.type, e = b.pendingProps, e = b.elementType === d ? e : Ci(d, e), Yi(a, b, d, e, c);
      case 7:
        return Xi(a, b, b.pendingProps, c), b.child;
      case 8:
        return Xi(a, b, b.pendingProps.children, c), b.child;
      case 12:
        return Xi(a, b, b.pendingProps.children, c), b.child;
      case 10:
        a: {
          d = b.type._context;
          e = b.pendingProps;
          f = b.memoizedProps;
          g = e.value;
          G2(Wg, d._currentValue);
          d._currentValue = g;
          if (f !== null)
            if (He(f.value, g)) {
              if (f.children === e.children && !Wf.current) {
                b = Zi(a, b, c);
                break a;
              }
            } else
              for (f = b.child, f !== null && (f.return = b);f !== null; ) {
                var h = f.dependencies;
                if (h !== null) {
                  g = f.child;
                  for (var k = h.firstContext;k !== null; ) {
                    if (k.context === d) {
                      if (f.tag === 1) {
                        k = mh(-1, c & -c);
                        k.tag = 2;
                        var l = f.updateQueue;
                        if (l !== null) {
                          l = l.shared;
                          var m = l.pending;
                          m === null ? k.next = k : (k.next = m.next, m.next = k);
                          l.pending = k;
                        }
                      }
                      f.lanes |= c;
                      k = f.alternate;
                      k !== null && (k.lanes |= c);
                      bh(f.return, c, b);
                      h.lanes |= c;
                      break;
                    }
                    k = k.next;
                  }
                } else if (f.tag === 10)
                  g = f.type === b.type ? null : f.child;
                else if (f.tag === 18) {
                  g = f.return;
                  if (g === null)
                    throw Error(p2(341));
                  g.lanes |= c;
                  h = g.alternate;
                  h !== null && (h.lanes |= c);
                  bh(g, c, b);
                  g = f.sibling;
                } else
                  g = f.child;
                if (g !== null)
                  g.return = f;
                else
                  for (g = f;g !== null; ) {
                    if (g === b) {
                      g = null;
                      break;
                    }
                    f = g.sibling;
                    if (f !== null) {
                      f.return = g.return;
                      g = f;
                      break;
                    }
                    g = g.return;
                  }
                f = g;
              }
          Xi(a, b, e.children, c);
          b = b.child;
        }
        return b;
      case 9:
        return e = b.type, d = b.pendingProps.children, ch(b, c), e = eh(e), d = d(e), b.flags |= 1, Xi(a, b, d, c), b.child;
      case 14:
        return d = b.type, e = Ci(d, b.pendingProps), e = Ci(d.type, e), $i(a, b, d, e, c);
      case 15:
        return bj(a, b, b.type, b.pendingProps, c);
      case 17:
        return d = b.type, e = b.pendingProps, e = b.elementType === d ? e : Ci(d, e), ij(a, b), b.tag = 1, Zf(d) ? (a = true, cg(b)) : a = false, ch(b, c), Gi(b, d, e), Ii(b, d, e, c), jj(null, b, d, true, a, c);
      case 19:
        return xj(a, b, c);
      case 22:
        return dj(a, b, c);
    }
    throw Error(p2(156, b.tag));
  };
  kl = typeof reportError === "function" ? reportError : function(a) {
    console.error(a);
  };
  ml.prototype.render = ll.prototype.render = function(a) {
    var b = this._internalRoot;
    if (b === null)
      throw Error(p2(409));
    fl(a, b, null, null);
  };
  ml.prototype.unmount = ll.prototype.unmount = function() {
    var a = this._internalRoot;
    if (a !== null) {
      this._internalRoot = null;
      var b = a.containerInfo;
      Rk(function() {
        fl(null, a, null, null);
      });
      b[uf] = null;
    }
  };
  ml.prototype.unstable_scheduleHydration = function(a) {
    if (a) {
      var b = Hc();
      a = { blockedOn: null, target: a, priority: b };
      for (var c = 0;c < Qc.length && b !== 0 && b < Qc[c].priority; c++)
        ;
      Qc.splice(c, 0, a);
      c === 0 && Vc(a);
    }
  };
  Ec = function(a) {
    switch (a.tag) {
      case 3:
        var b = a.stateNode;
        if (b.current.memoizedState.isDehydrated) {
          var c = tc(b.pendingLanes);
          c !== 0 && (Cc(b, c | 1), Dk(b, B2()), (K2 & 6) === 0 && (Gj = B2() + 500, jg()));
        }
        break;
      case 13:
        Rk(function() {
          var b = ih(a, 1);
          if (b !== null) {
            var c = R2();
            gi(b, a, 1, c);
          }
        }), il(a, 1);
    }
  };
  Fc = function(a) {
    if (a.tag === 13) {
      var b = ih(a, 134217728);
      if (b !== null) {
        var c = R2();
        gi(b, a, 134217728, c);
      }
      il(a, 134217728);
    }
  };
  Gc = function(a) {
    if (a.tag === 13) {
      var b = yi(a), c = ih(a, b);
      if (c !== null) {
        var d = R2();
        gi(c, a, b, d);
      }
      il(a, b);
    }
  };
  Hc = function() {
    return C2;
  };
  Ic = function(a, b) {
    var c = C2;
    try {
      return C2 = a, b();
    } finally {
      C2 = c;
    }
  };
  yb = function(a, b, c) {
    switch (b) {
      case "input":
        bb(a, c);
        b = c.name;
        if (c.type === "radio" && b != null) {
          for (c = a;c.parentNode; )
            c = c.parentNode;
          c = c.querySelectorAll("input[name=" + JSON.stringify("" + b) + '][type="radio"]');
          for (b = 0;b < c.length; b++) {
            var d = c[b];
            if (d !== a && d.form === a.form) {
              var e = Db(d);
              if (!e)
                throw Error(p2(90));
              Wa(d);
              bb(d, e);
            }
          }
        }
        break;
      case "textarea":
        ib(a, c);
        break;
      case "select":
        b = c.value, b != null && fb(a, !!c.multiple, b, false);
    }
  };
  Gb = Qk;
  Hb = Rk;
  sl = { usingClientEntryPoint: false, Events: [Cb, ue, Db, Eb, Fb, Qk] };
  tl = { findFiberByHostInstance: Wc, bundleType: 0, version: "18.3.1", rendererPackageName: "react-dom" };
  ul = { bundleType: tl.bundleType, version: tl.version, rendererPackageName: tl.rendererPackageName, rendererConfig: tl.rendererConfig, overrideHookState: null, overrideHookStateDeletePath: null, overrideHookStateRenamePath: null, overrideProps: null, overridePropsDeletePath: null, overridePropsRenamePath: null, setErrorHandler: null, setSuspenseHandler: null, scheduleUpdate: null, currentDispatcherRef: ua.ReactCurrentDispatcher, findHostInstanceByFiber: function(a) {
    a = Zb(a);
    return a === null ? null : a.stateNode;
  }, findFiberByHostInstance: tl.findFiberByHostInstance || jl, findHostInstancesForRefresh: null, scheduleRefresh: null, scheduleRoot: null, setRefreshHandler: null, getCurrentFiber: null, reconcilerVersion: "18.3.1-next-f1338f8080-20240426" };
  if (typeof __REACT_DEVTOOLS_GLOBAL_HOOK__ !== "undefined") {
    vl = __REACT_DEVTOOLS_GLOBAL_HOOK__;
    if (!vl.isDisabled && vl.supportsFiber)
      try {
        kc = vl.inject(ul), lc = vl;
      } catch (a) {}
  }
  $__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED2 = sl;
  $unstable_batchedUpdates = Qk;
});

// node_modules/react-dom/index.js
var require_react_dom = __commonJS(function(exports, module) {
  init_react_dom_production_min();
  function checkDCE() {
    if (typeof __REACT_DEVTOOLS_GLOBAL_HOOK__ === "undefined" || typeof __REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE !== "function") {
      return;
    }
    if (false) {}
    try {
      __REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE(checkDCE);
    } catch (err) {
      console.error(err);
    }
  }
  if (true) {
    checkDCE();
    module.exports = exports_react_dom_production_min;
  }
});

// node_modules/react-dom/client.js
var require_client = __commonJS(function(exports) {
  var m = __toESM(require_react_dom());
  if (true) {
    exports.createRoot = m.createRoot;
    exports.hydrateRoot = m.hydrateRoot;
  }
  var i;
});

// node_modules/react/cjs/react-jsx-runtime.production.min.js
var exports_react_jsx_runtime_production_min = {};
__exportCjs(exports_react_jsx_runtime_production_min, {
  Fragment: () => $Fragment2,
  jsx: () => $jsx,
  jsxs: () => $jsxs
}, {
  Fragment: (value3) => $Fragment2 = value3,
  jsx: (value3) => $jsx = value3,
  jsxs: (value3) => $jsxs = value3
});
function q2(c, a, g) {
  var b, d = {}, e = null, h = null;
  g !== undefined && (e = "" + g);
  a.key !== undefined && (e = "" + a.key);
  a.ref !== undefined && (h = a.ref);
  for (b in a)
    m.call(a, b) && !p3.hasOwnProperty(b) && (d[b] = a[b]);
  if (c && c.defaultProps)
    for (b in a = c.defaultProps, a)
      d[b] === undefined && (d[b] = a[b]);
  return { $$typeof: k, type: c, key: e, ref: h, props: d, _owner: n2.current };
}
var f, k, l2, m, n2, p3, $Fragment2, $jsx, $jsxs;
var init_react_jsx_runtime_production_min = __esm(() => {
  f = __toESM(require_react());
  k = Symbol.for("react.element");
  l2 = Symbol.for("react.fragment");
  m = Object.prototype.hasOwnProperty;
  n2 = f.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED.ReactCurrentOwner;
  p3 = { key: true, ref: true, __self: true, __source: true };
  $Fragment2 = l2;
  $jsx = q2;
  $jsxs = q2;
});

// node_modules/react/jsx-runtime.js
var require_jsx_runtime = __commonJS(function(exports, module) {
  init_react_jsx_runtime_production_min();
  if (true) {
    module.exports = exports_react_jsx_runtime_production_min;
  }
});

// node_modules/inline-style-parser/cjs/index.js
var require_cjs = __commonJS(function(exports, module) {
  var COMMENT_REGEX = /\/\*[^*]*\*+([^/*][^*]*\*+)*\//g;
  var NEWLINE_REGEX = /\n/g;
  var WHITESPACE_REGEX = /^\s*/;
  var PROPERTY_REGEX = /^(\*?[-#/*\\\w]+(\[[0-9a-z_-]+\])?)\s*/;
  var COLON_REGEX = /^:\s*/;
  var VALUE_REGEX = /^((?:'(?:\\'|.)*?'|"(?:\\"|.)*?"|\([^)]*?\)|[^};])+)/;
  var SEMICOLON_REGEX = /^[;\s]*/;
  var TRIM_REGEX = /^\s+|\s+$/g;
  var NEWLINE = `
`;
  var FORWARD_SLASH = "/";
  var ASTERISK = "*";
  var EMPTY_STRING = "";
  var TYPE_COMMENT = "comment";
  var TYPE_DECLARATION = "declaration";
  function index(style, options) {
    if (typeof style !== "string") {
      throw new TypeError("First argument must be a string");
    }
    if (!style)
      return [];
    options = options || {};
    var lineno = 1;
    var column = 1;
    function updatePosition(str) {
      var lines = str.match(NEWLINE_REGEX);
      if (lines)
        lineno += lines.length;
      var i = str.lastIndexOf(NEWLINE);
      column = ~i ? str.length - i : column + str.length;
    }
    function position() {
      var start = { line: lineno, column };
      return function(node) {
        node.position = new Position(start);
        whitespace();
        return node;
      };
    }
    function Position(start) {
      this.start = start;
      this.end = { line: lineno, column };
      this.source = options.source;
    }
    Position.prototype.content = style;
    function error(msg) {
      var err = new Error(options.source + ":" + lineno + ":" + column + ": " + msg);
      err.reason = msg;
      err.filename = options.source;
      err.line = lineno;
      err.column = column;
      err.source = style;
      if (options.silent)
        ;
      else {
        throw err;
      }
    }
    function match(re) {
      var m = re.exec(style);
      if (!m)
        return;
      var str = m[0];
      updatePosition(str);
      style = style.slice(str.length);
      return m;
    }
    function whitespace() {
      match(WHITESPACE_REGEX);
    }
    function comments(rules) {
      var c;
      rules = rules || [];
      while (c = comment()) {
        if (c !== false) {
          rules.push(c);
        }
      }
      return rules;
    }
    function comment() {
      var pos = position();
      if (FORWARD_SLASH != style.charAt(0) || ASTERISK != style.charAt(1))
        return;
      var i = 2;
      while (EMPTY_STRING != style.charAt(i) && (ASTERISK != style.charAt(i) || FORWARD_SLASH != style.charAt(i + 1))) {
        ++i;
      }
      i += 2;
      if (EMPTY_STRING === style.charAt(i - 1)) {
        return error("End of comment missing");
      }
      var str = style.slice(2, i - 2);
      column += 2;
      updatePosition(str);
      style = style.slice(i);
      column += 2;
      return pos({
        type: TYPE_COMMENT,
        comment: str
      });
    }
    function declaration() {
      var pos = position();
      var prop = match(PROPERTY_REGEX);
      if (!prop)
        return;
      comment();
      if (!match(COLON_REGEX))
        return error("property missing ':'");
      var val = match(VALUE_REGEX);
      var ret = pos({
        type: TYPE_DECLARATION,
        property: trim(prop[0].replace(COMMENT_REGEX, EMPTY_STRING)),
        value: val ? trim(val[0].replace(COMMENT_REGEX, EMPTY_STRING)) : EMPTY_STRING
      });
      match(SEMICOLON_REGEX);
      return ret;
    }
    function declarations() {
      var decls = [];
      comments(decls);
      var decl;
      while (decl = declaration()) {
        if (decl !== false) {
          decls.push(decl);
          comments(decls);
        }
      }
      return decls;
    }
    whitespace();
    return declarations();
  }
  function trim(str) {
    return str ? str.replace(TRIM_REGEX, EMPTY_STRING) : EMPTY_STRING;
  }
  module.exports = index;
});

// node_modules/style-to-object/cjs/index.js
var require_cjs2 = __commonJS(function(exports) {
  var __importDefault = exports && exports.__importDefault || function(mod) {
    return mod && mod.__esModule ? mod : { default: mod };
  };
  Object.defineProperty(exports, "__esModule", { value: true });
  exports.default = StyleToObject;
  var inline_style_parser_1 = __importDefault(require_cjs());
  function StyleToObject(style, iterator) {
    let styleObject = null;
    if (!style || typeof style !== "string") {
      return styleObject;
    }
    const declarations = (0, inline_style_parser_1.default)(style);
    const hasIterator = typeof iterator === "function";
    declarations.forEach((declaration) => {
      if (declaration.type !== "declaration") {
        return;
      }
      const { property, value } = declaration;
      if (hasIterator) {
        iterator(property, value, declaration);
      } else if (value) {
        styleObject = styleObject || {};
        styleObject[property] = value;
      }
    });
    return styleObject;
  }
});

// node_modules/style-to-js/cjs/utilities.js
var require_utilities = __commonJS(function(exports) {
  Object.defineProperty(exports, "__esModule", { value: true });
  exports.camelCase = undefined;
  var CUSTOM_PROPERTY_REGEX = /^--[a-zA-Z0-9_-]+$/;
  var HYPHEN_REGEX = /-([a-z])/g;
  var NO_HYPHEN_REGEX = /^[^-]+$/;
  var VENDOR_PREFIX_REGEX = /^-(webkit|moz|ms|o|khtml)-/;
  var MS_VENDOR_PREFIX_REGEX = /^-(ms)-/;
  var skipCamelCase = function(property) {
    return !property || NO_HYPHEN_REGEX.test(property) || CUSTOM_PROPERTY_REGEX.test(property);
  };
  var capitalize = function(match, character) {
    return character.toUpperCase();
  };
  var trimHyphen = function(match, prefix) {
    return "".concat(prefix, "-");
  };
  var camelCase = function(property, options) {
    if (options === undefined) {
      options = {};
    }
    if (skipCamelCase(property)) {
      return property;
    }
    property = property.toLowerCase();
    if (options.reactCompat) {
      property = property.replace(MS_VENDOR_PREFIX_REGEX, trimHyphen);
    } else {
      property = property.replace(VENDOR_PREFIX_REGEX, trimHyphen);
    }
    return property.replace(HYPHEN_REGEX, capitalize);
  };
  exports.camelCase = camelCase;
});

// node_modules/style-to-js/cjs/index.js
var require_cjs3 = __commonJS(function(exports, module) {
  var __importDefault = exports && exports.__importDefault || function(mod) {
    return mod && mod.__esModule ? mod : { default: mod };
  };
  var style_to_object_1 = __importDefault(require_cjs2());
  var utilities_1 = require_utilities();
  function StyleToJS(style, options) {
    var output = {};
    if (!style || typeof style !== "string") {
      return output;
    }
    (0, style_to_object_1.default)(style, function(property, value) {
      if (property && value) {
        output[(0, utilities_1.camelCase)(property, options)] = value;
      }
    });
    return output;
  }
  StyleToJS.default = StyleToJS;
  module.exports = StyleToJS;
});

// node_modules/extend/index.js
var require_extend = __commonJS(function(exports, module) {
  var hasOwn = Object.prototype.hasOwnProperty;
  var toStr = Object.prototype.toString;
  var defineProperty = Object.defineProperty;
  var gOPD = Object.getOwnPropertyDescriptor;
  var isArray = function isArray(arr) {
    if (typeof Array.isArray === "function") {
      return Array.isArray(arr);
    }
    return toStr.call(arr) === "[object Array]";
  };
  var isPlainObject = function isPlainObject(obj) {
    if (!obj || toStr.call(obj) !== "[object Object]") {
      return false;
    }
    var hasOwnConstructor = hasOwn.call(obj, "constructor");
    var hasIsPrototypeOf = obj.constructor && obj.constructor.prototype && hasOwn.call(obj.constructor.prototype, "isPrototypeOf");
    if (obj.constructor && !hasOwnConstructor && !hasIsPrototypeOf) {
      return false;
    }
    var key;
    for (key in obj) {}
    return typeof key === "undefined" || hasOwn.call(obj, key);
  };
  var setProperty = function setProperty(target, options) {
    if (defineProperty && options.name === "__proto__") {
      defineProperty(target, options.name, {
        enumerable: true,
        configurable: true,
        value: options.newValue,
        writable: true
      });
    } else {
      target[options.name] = options.newValue;
    }
  };
  var getProperty = function getProperty(obj, name) {
    if (name === "__proto__") {
      if (!hasOwn.call(obj, name)) {
        return;
      } else if (gOPD) {
        return gOPD(obj, name).value;
      }
    }
    return obj[name];
  };
  module.exports = function extend() {
    var options, name, src, copy, copyIsArray, clone;
    var target = arguments[0];
    var i = 1;
    var length = arguments.length;
    var deep = false;
    if (typeof target === "boolean") {
      deep = target;
      target = arguments[1] || {};
      i = 2;
    }
    if (target == null || typeof target !== "object" && typeof target !== "function") {
      target = {};
    }
    for (;i < length; ++i) {
      options = arguments[i];
      if (options != null) {
        for (name in options) {
          src = getProperty(target, name);
          copy = getProperty(options, name);
          if (target !== copy) {
            if (deep && copy && (isPlainObject(copy) || (copyIsArray = isArray(copy)))) {
              if (copyIsArray) {
                copyIsArray = false;
                clone = src && isArray(src) ? src : [];
              } else {
                clone = src && isPlainObject(src) ? src : {};
              }
              setProperty(target, { name, newValue: extend(deep, clone, copy) });
            } else if (typeof copy !== "undefined") {
              setProperty(target, { name, newValue: copy });
            }
          }
        }
      }
    }
    return target;
  };
});

// src/sidepanel/main.tsx
var import_client = __toESM(require_client(), 1);

// src/sidepanel/app.tsx
var import_react12 = __toESM(require_react(), 1);

// src/sidepanel/i18n.ts
var CS = {
  "Connect this browser to AYETO": "Připojte tento prohlížeč k AYETO",
  "Your assistant will be able to read and use the tabs you give it.": "Asistent bude moct číst a používat záložky, které mu dáte.",
  Server: "Server",
  "Browser name": "Název prohlížeče",
  "Shown in AYETO next to your connectors": "Zobrazí se v AYETO u vašich konektorů",
  "Connect to AYETO": "Připojit k AYETO",
  "Confirm this code in AYETO": "Potvrďte tento kód v AYETO",
  "The approval page opened in a new tab. Log in if needed and confirm the code.": "Stránka pro schválení se otevřela v nové záložce. Případně se přihlaste a kód potvrďte.",
  "Open the approval page": "Otevřít stránku pro schválení",
  Cancel: "Zrušit",
  Connected: "Připojeno",
  "Connecting…": "Připojování…",
  Disconnected: "Odpojeno",
  "Waiting for approval": "Čeká na schválení",
  "Not connected": "Nepřipojeno",
  Error: "Chyba",
  Connect: "Připojit",
  Disconnect: "Odpojit",
  "Forget this browser": "Zapomenout tento prohlížeč",
  "Agent tabs": "Záložky agenta",
  "The agent works only in these tabs (the AYETO tab group). Drag a tab out of the group to take it back.": "Agent pracuje jen v těchto záložkách (skupina AYETO). Záložku mu vezmete přetažením ze skupiny.",
  "No tabs yet. Give the agent the tab you are looking at, or let it open one.": "Zatím žádné záložky. Dejte agentovi záložku, kterou máte otevřenou, nebo ať si nějakou otevře.",
  "Give this tab to the agent": "Dát tuto záložku agentovi",
  "Take back": "Vzít zpět",
  current: "aktuální",
  Stop: "Zastavit",
  "Stop the agent": "Zastavit agenta",
  "The assistant is still answering here. Send your message once it is done.": "Asistent tu ještě odpovídá. Zprávu pošlete, až domluví.",
  "The connection to AYETO was lost.": "Spojení s AYETO se přerušilo.",
  "AYETO is waiting for your confirmation": "AYETO čeká na vaše potvrzení",
  "Search conversations": "Hledat konverzace",
  "No conversation matches.": "Žádná konverzace neodpovídá.",
  "Load more": "Načíst další",
  "Opening {0}": "Otevírám {0}",
  "Clicking {0}": "Klikám na {0}",
  "Typing into {0}": "Píšu do {0}",
  "Pressing {0}": "Mačkám {0}",
  "Choosing {0}": "Vybírám {0}",
  'Waiting for "{0}"': "Čekám na „{0}“",
  "Waiting for the page": "Čekám na stránku",
  "Waiting {0} s": "Čekám {0} s",
  "Waiting for your confirmation": "Čekám na vaše potvrzení",
  "Reading the page": "Čtu stránku",
  'Looking for "{0}"': "Hledám „{0}“",
  "Reading the page text": "Čtu text stránky",
  "Taking a screenshot": "Pořizuji snímek obrazovky",
  "Click {0}": "Kliknout na {0}",
  "Click at {0}": "Kliknout na místo {0}",
  "Type into {0}": "Napsat do {0}",
  "Type into {0} and press Enter": "Napsat do {0} a stisknout Enter",
  "Press {0}": "Stisknout {0}",
  "Press {0} in {1}": "Stisknout {0} v {1}",
  "Choose {0} in {1}": "Vybrat {0} v {1}",
  "Go to {0}": "Přejít na {0}",
  "Open {0} in a new tab": "Otevřít {0} v nové záložce",
  "The address is not valid": "Adresa není platná",
  "Browser and extension pages are off limits": "Stránky prohlížeče a rozšíření jsou pro agenta zakázané",
  "The extension store is off limits": "Obchod s rozšířeními je pro agenta zakázaný",
  "The agent does not work in AYETO itself": "Agent nepracuje přímo v AYETO",
  "The user blocked this site for the agent": "Tento web jste agentovi zablokovali",
  "AYETO does not accept the API key of this browser any more. Connect the browser again.": "AYETO už API klíč tohoto prohlížeče nepřijímá. Připojte prohlížeč znovu.",
  "The browser is offline. AYETO connects again when the network is back.": "Prohlížeč je offline. AYETO se znovu připojí, až bude síť zpět.",
  "The agent cannot work on this page.": "Na této stránce agent pracovat nemůže.",
  "Open the AYETO side panel to allow or deny it.": "Povolíte nebo zamítnete to v postranním panelu AYETO.",
  "The API key of this browser was deleted in AYETO. Connect the browser again.": "API klíč tohoto prohlížeče byl v AYETO smazán. Připojte prohlížeč znovu.",
  "AYETO could not be reached, so the API key of this browser still works. Delete it in AYETO under API keys.": "AYETO nebylo dostupné, takže API klíč tohoto prohlížeče stále platí. Smažte ho v AYETO v sekci API klíče.",
  "Forget this browser? Its API key is deleted in AYETO and stops working.": "Zapomenout tento prohlížeč? Jeho API klíč se v AYETO smaže a přestane fungovat.",
  Working: "Pracuje",
  Settings: "Nastavení",
  Back: "Zpět",
  "API key": "API klíč",
  "Choose an assistant": "Vyberte asistenta",
  Assistants: "Asistenti",
  "Models without an assistant": "Modely bez asistenta",
  Search: "Hledat",
  "Nothing found": "Nic nenalezeno",
  "File is too large": "Soubor je příliš velký",
  "See the attached files.": "Viz přiložené soubory.",
  Remove: "Odebrat",
  "Attach files": "Přiložit soubory",
  "The assistant wants to use a tool": "Asistent chce použít nástroj",
  "The agent wants to act": "Agent chce provést akci",
  on: "na",
  Allow: "Povolit",
  Deny: "Zamítnout",
  "It submits a form": "Odešle formulář",
  "It may pay, send, delete or confirm something": "Může něco zaplatit, odeslat, smazat nebo potvrdit",
  "It clicks a point of the page the agent cannot describe": "Klikne na místo stránky, které agent neumí popsat",
  "You asked to confirm every action": "Nastavili jste potvrzování každé akce",
  "It can send data out of AYETO": "Může poslat data mimo AYETO",
  "The page may contain instructions aimed at the assistant": "Stránka možná obsahuje pokyny pro asistenta",
  Connection: "Připojení",
  Confirmations: "Potvrzování",
  "Ask before submitting forms, paying, sending or deleting": "Ptát se před odesláním formuláře, platbou, odesláním nebo smazáním",
  "Ask before every action": "Ptát se před každou akcí",
  "Never ask (not recommended)": "Nikdy se neptat (nedoporučeno)",
  "Tools of the assistant that send data out of AYETO (e-mail, web requests) always ask in conversations from this browser. Passwords and card numbers are never typed by the agent.": "Nástroje asistenta, které posílají data mimo AYETO (e-mail, webové požadavky), se v konverzacích z tohoto prohlížeče vždy zeptají. Hesla a čísla karet agent nikdy nevyplňuje.",
  "Blocked sites": "Blokované weby",
  "The agent never reads or uses these sites (one domain per line, subdomains included), e.g. your bank.": "Tyto weby agent nikdy nečte ani nepoužívá (jedna doména na řádek, včetně subdomén), např. vaše banka.",
  "Block the current site": "Zablokovat aktuální web",
  "Preparing…": "Připravuji…",
  "Thinking…": "Přemýšlím…",
  Using: "Používám",
  "Using a tool…": "Používám nástroj…",
  "AI tool": "AI nástroj",
  Assistant: "Asistent",
  "Loading…": "Načítání…",
  "You have no assistants yet": "Zatím nemáte žádné asistenty",
  "New chat": "Nový chat",
  History: "Historie",
  Chat: "Chat",
  "Ask about the pages you give the agent, or let it open and read new ones.": "Ptejte se na stránky, které agentovi dáte, nebo ho nechte otevřít a přečíst nové.",
  "The browser is not connected to AYETO: the assistant cannot see your tabs now.": "Prohlížeč není připojený k AYETO: asistent teď vaše záložky nevidí.",
  "The agent has no tab yet.": "Agent zatím nemá žádnou záložku.",
  "The agent does not see this tab.": "Agent tuto záložku nevidí.",
  "Give it": "Dát mu ji",
  Message: "Zpráva pro",
  Send: "Odeslat",
  "Delete this conversation?": "Smazat tuto konverzaci?",
  "No conversations from this browser yet.": "Z tohoto prohlížeče zatím nejsou žádné konverzace.",
  Delete: "Smazat"
};
var FR = {
  "Connect this browser to AYETO": "Connectez ce navigateur à AYETO",
  "Your assistant will be able to read and use the tabs you give it.": "Votre assistant pourra lire et utiliser les onglets que vous lui confiez.",
  Server: "Serveur",
  "Browser name": "Nom du navigateur",
  "Shown in AYETO next to your connectors": "Affiché dans AYETO à côté de vos connecteurs",
  "Connect to AYETO": "Se connecter à AYETO",
  "Confirm this code in AYETO": "Confirmez ce code dans AYETO",
  "The approval page opened in a new tab. Log in if needed and confirm the code.": "La page d'approbation s'est ouverte dans un nouvel onglet. Connectez-vous si besoin et confirmez le code.",
  "Open the approval page": "Ouvrir la page d'approbation",
  Cancel: "Annuler",
  Connected: "Connecté",
  "Connecting…": "Connexion…",
  Disconnected: "Déconnecté",
  "Waiting for approval": "En attente d'approbation",
  "Not connected": "Non connecté",
  Error: "Erreur",
  Connect: "Connecter",
  Disconnect: "Déconnecter",
  "Forget this browser": "Oublier ce navigateur",
  "Agent tabs": "Onglets de l'agent",
  "The agent works only in these tabs (the AYETO tab group). Drag a tab out of the group to take it back.": "L'agent travaille uniquement dans ces onglets (le groupe AYETO). Sortez un onglet du groupe pour le reprendre.",
  "No tabs yet. Give the agent the tab you are looking at, or let it open one.": "Aucun onglet pour l'instant. Confiez à l'agent l'onglet que vous regardez, ou laissez-le en ouvrir un.",
  "Give this tab to the agent": "Confier cet onglet à l'agent",
  "Take back": "Reprendre",
  current: "actuel",
  Stop: "Arrêter",
  "Stop the agent": "Arrêter l'agent",
  "The assistant is still answering here. Send your message once it is done.": "L'assistant répond encore ici. Envoyez votre message quand il aura fini.",
  "The connection to AYETO was lost.": "La connexion à AYETO a été perdue.",
  "AYETO is waiting for your confirmation": "AYETO attend votre confirmation",
  "Search conversations": "Rechercher des conversations",
  "No conversation matches.": "Aucune conversation ne correspond.",
  "Load more": "Charger plus",
  "Opening {0}": "Ouverture de {0}",
  "Clicking {0}": "Clic sur {0}",
  "Typing into {0}": "Saisie dans {0}",
  "Pressing {0}": "Appui sur {0}",
  "Choosing {0}": "Choix de {0}",
  'Waiting for "{0}"': "Attente de « {0} »",
  "Waiting for the page": "Attente de la page",
  "Waiting {0} s": "Attente de {0} s",
  "Waiting for your confirmation": "En attente de votre confirmation",
  "Reading the page": "Lecture de la page",
  'Looking for "{0}"': "Recherche de « {0} »",
  "Reading the page text": "Lecture du texte de la page",
  "Taking a screenshot": "Capture d'écran",
  "Click {0}": "Cliquer sur {0}",
  "Click at {0}": "Cliquer à {0}",
  "Type into {0}": "Saisir dans {0}",
  "Type into {0} and press Enter": "Saisir dans {0} et appuyer sur Entrée",
  "Press {0}": "Appuyer sur {0}",
  "Press {0} in {1}": "Appuyer sur {0} dans {1}",
  "Choose {0} in {1}": "Choisir {0} dans {1}",
  "Go to {0}": "Aller à {0}",
  "Open {0} in a new tab": "Ouvrir {0} dans un nouvel onglet",
  "The address is not valid": "L'adresse n'est pas valide",
  "Browser and extension pages are off limits": "Les pages du navigateur et des extensions sont interdites à l'agent",
  "The extension store is off limits": "La boutique d'extensions est interdite à l'agent",
  "The agent does not work in AYETO itself": "L'agent ne travaille pas dans AYETO lui-même",
  "The user blocked this site for the agent": "Vous avez bloqué ce site pour l'agent",
  "AYETO does not accept the API key of this browser any more. Connect the browser again.": "AYETO n'accepte plus la clé API de ce navigateur. Connectez à nouveau le navigateur.",
  "The browser is offline. AYETO connects again when the network is back.": "Le navigateur est hors ligne. AYETO se reconnectera au retour du réseau.",
  "The agent cannot work on this page.": "L'agent ne peut pas travailler sur cette page.",
  "Open the AYETO side panel to allow or deny it.": "Ouvrez le panneau latéral AYETO pour l'autoriser ou le refuser.",
  "The API key of this browser was deleted in AYETO. Connect the browser again.": "La clé API de ce navigateur a été supprimée dans AYETO. Connectez à nouveau le navigateur.",
  "AYETO could not be reached, so the API key of this browser still works. Delete it in AYETO under API keys.": "AYETO est injoignable, la clé API de ce navigateur reste donc valide. Supprimez-la dans AYETO, rubrique Clés API.",
  "Forget this browser? Its API key is deleted in AYETO and stops working.": "Oublier ce navigateur ? Sa clé API est supprimée dans AYETO et cesse de fonctionner.",
  Working: "En cours",
  Settings: "Paramètres",
  Back: "Retour",
  "API key": "Clé API",
  "Choose an assistant": "Choisissez un assistant",
  Assistants: "Assistants",
  "Models without an assistant": "Modèles sans assistant",
  Search: "Rechercher",
  "Nothing found": "Aucun résultat",
  "File is too large": "Fichier trop volumineux",
  "See the attached files.": "Voir les fichiers joints.",
  Remove: "Retirer",
  "Attach files": "Joindre des fichiers",
  "The assistant wants to use a tool": "L'assistant veut utiliser un outil",
  "The agent wants to act": "L'agent veut agir",
  on: "sur",
  Allow: "Autoriser",
  Deny: "Refuser",
  "It submits a form": "Cela envoie un formulaire",
  "It may pay, send, delete or confirm something": "Cela peut payer, envoyer, supprimer ou confirmer quelque chose",
  "It clicks a point of the page the agent cannot describe": "Cela clique sur un point de la page que l'agent ne sait pas décrire",
  "You asked to confirm every action": "Vous avez demandé de confirmer chaque action",
  "It can send data out of AYETO": "Cela peut envoyer des données hors d'AYETO",
  "The page may contain instructions aimed at the assistant": "La page contient peut-être des instructions destinées à l'assistant",
  Connection: "Connexion",
  Confirmations: "Confirmations",
  "Ask before submitting forms, paying, sending or deleting": "Demander avant d'envoyer un formulaire, de payer, d'envoyer ou de supprimer",
  "Ask before every action": "Demander avant chaque action",
  "Never ask (not recommended)": "Ne jamais demander (déconseillé)",
  "Tools of the assistant that send data out of AYETO (e-mail, web requests) always ask in conversations from this browser. Passwords and card numbers are never typed by the agent.": "Les outils de l'assistant qui envoient des données hors d'AYETO (e-mail, requêtes web) demandent toujours dans les conversations de ce navigateur. L'agent ne saisit jamais de mots de passe ni de numéros de carte.",
  "Blocked sites": "Sites bloqués",
  "The agent never reads or uses these sites (one domain per line, subdomains included), e.g. your bank.": "L'agent ne lit ni n'utilise jamais ces sites (un domaine par ligne, sous-domaines compris), par exemple votre banque.",
  "Block the current site": "Bloquer le site actuel",
  "Preparing…": "Préparation…",
  "Thinking…": "Réflexion…",
  Using: "Utilise",
  "Using a tool…": "Utilise un outil…",
  "AI tool": "Outil IA",
  Assistant: "Assistant",
  "Loading…": "Chargement…",
  "You have no assistants yet": "Vous n'avez pas encore d'assistant",
  "New chat": "Nouveau chat",
  History: "Historique",
  Chat: "Chat",
  "Ask about the pages you give the agent, or let it open and read new ones.": "Posez des questions sur les pages confiées à l'agent, ou laissez-le en ouvrir et en lire de nouvelles.",
  "The browser is not connected to AYETO: the assistant cannot see your tabs now.": "Le navigateur n'est pas connecté à AYETO : l'assistant ne voit pas vos onglets pour l'instant.",
  "The agent has no tab yet.": "L'agent n'a pas encore d'onglet.",
  "The agent does not see this tab.": "L'agent ne voit pas cet onglet.",
  "Give it": "Le lui confier",
  Message: "Message à",
  Send: "Envoyer",
  "Delete this conversation?": "Supprimer cette conversation ?",
  "No conversations from this browser yet.": "Aucune conversation depuis ce navigateur pour l'instant.",
  Delete: "Supprimer"
};
var DICTIONARIES = { cs: CS, fr: FR };
function language() {
  const ui = (chrome.i18n?.getUILanguage?.() ?? navigator.language ?? "en").toLowerCase();
  return ui.split("-")[0];
}
var dictionary = DICTIONARIES[language()] ?? {};
function t2(text) {
  return dictionary[text] ?? text;
}
function tf2(template, ...values) {
  return t2(template).replace(/\{(\d+)\}/g, (_, i) => String(values[Number(i)] ?? ""));
}
function uiLanguage() {
  return language() === "cs" ? "cz" : language();
}

// src/sidepanel/worker.ts
var import_react = __toESM(require_react(), 1);

// src/shared/protocol.ts
class BrowserError extends Error {
  code;
  constructor(message, code = "internal") {
    super(message);
    this.code = code;
    this.name = "BrowserError";
  }
}

// src/shared/state.ts
var SERVER_URL = { mode: "production", serverUrl: "https://ayeto.ai", appUrl: "https://ayeto.ai/app" }.serverUrl.replace(/\/+$/, "");
var APP_URL = { mode: "production", serverUrl: "https://ayeto.ai", appUrl: "https://ayeto.ai/app" }.appUrl.replace(/\/+$/, "");
var DEFAULT_SETTINGS = {
  api_key: null,
  api_key_name: "",
  api_key_id: null,
  device_name: "",
  enabled: true,
  confirm_mode: "risky",
  blocked_domains: []
};
var PANEL_PORT = "sidepanel";
function apiV1(serverUrl) {
  return `${serverUrl.replace(/\/+$/, "")}/api/v1`;
}
function apiV3(serverUrl) {
  return `${serverUrl.replace(/\/+$/, "")}/api/v3`;
}
function wsEndpoint(serverUrl) {
  return `${apiV1(serverUrl).replace(/^http/, "ws")}/browser_connector/ws`;
}

// src/background/policy.ts
var RESTRICTED_SCHEMES = ["chrome:", "chrome-extension:", "chrome-untrusted:", "devtools:", "edge:", "brave:", "opera:", "vivaldi:", "about:", "view-source:", "file:", "javascript:", "data:"];
var RESTRICTED_HOSTS = ["chromewebstore.google.com", "chrome.google.com", "microsoftedge.microsoft.com"];
var AYETO_HOSTS = ["ayeto.ai"];
var AYETO_PANEL_PATHS = ["/ayeto-booster-panel/", "/ayeto-booster-preview/"];
function hostMatches(host, domain) {
  return host === domain || host.endsWith(`.${domain}`);
}
var blockedDomains = [];
function setBlockedDomains(domains) {
  blockedDomains = domains.map(normalizeDomain).filter(Boolean);
}
function normalizeDomain(value) {
  let host = value.trim().toLowerCase();
  if (!host)
    return "";
  try {
    host = new URL(host.includes("://") ? host : `https://${host}`).hostname;
  } catch {
    return "";
  }
  return host.replace(/^www\./, "");
}
function restrictionOf(url, serverUrl) {
  if (!url)
    return null;
  let parsed;
  try {
    parsed = new URL(url);
  } catch {
    return "The address is not valid";
  }
  if (RESTRICTED_SCHEMES.includes(parsed.protocol))
    return "Browser and extension pages are off limits";
  const host = parsed.hostname.toLowerCase();
  if (RESTRICTED_HOSTS.some((d) => hostMatches(host, d)))
    return "The extension store is off limits";
  const isAyeto = AYETO_HOSTS.some((d) => hostMatches(host, d)) || ayetoHosts(serverUrl).includes(parsed.host.toLowerCase());
  if (isAyeto && !AYETO_PANEL_PATHS.some((p) => parsed.pathname.startsWith(p))) {
    return "The agent does not work in AYETO itself";
  }
  if (blockedDomains.some((d) => hostMatches(host, d)))
    return "The user blocked this site for the agent";
  return null;
}
function ayetoHosts(serverUrl) {
  const hosts = [];
  for (const url of [serverUrl, APP_URL]) {
    try {
      hosts.push(new URL(url).host.toLowerCase());
    } catch {}
  }
  return hosts;
}
function assertAllowedUrl(url, serverUrl) {
  const reason = restrictionOf(url, serverUrl);
  if (reason)
    throw new BrowserError(reason, "forbidden");
}
function assertOpenableUrl(url, serverUrl) {
  let parsed;
  try {
    parsed = new URL(url);
  } catch {
    throw new BrowserError(`Not a valid address: ${url}`, "invalid_request");
  }
  if (parsed.protocol !== "http:" && parsed.protocol !== "https:") {
    throw new BrowserError("Only http and https addresses can be opened", "forbidden");
  }
  assertAllowedUrl(parsed.toString(), serverUrl);
  return parsed.toString();
}

// src/sidepanel/worker.ts
function useWorker() {
  const [state, setState] = import_react.default.useState(null);
  const portRef = import_react.default.useRef(null);
  import_react.default.useEffect(() => {
    let disposed = false;
    let port;
    const connect = () => {
      port = chrome.runtime.connect({ name: PANEL_PORT });
      portRef.current = port;
      port.onMessage.addListener((message) => {
        if (message.type === "state")
          setState(message.state);
      });
      port.onDisconnect.addListener(() => {
        if (!disposed)
          setTimeout(connect, 200);
      });
      port.postMessage({ type: "get_state" });
    };
    connect();
    return () => {
      disposed = true;
      port?.disconnect();
    };
  }, []);
  const send = import_react.default.useCallback((message) => {
    portRef.current?.postMessage(message);
  }, []);
  return { state, send };
}
function useCurrentTab() {
  const [current, setCurrent] = import_react.default.useState({ id: null, url: "" });
  import_react.default.useEffect(() => {
    let windowId;
    let tabId = null;
    const show = (tab) => {
      tabId = tab?.id ?? null;
      setCurrent({ id: tabId, url: tab?.url ?? tab?.pendingUrl ?? "" });
    };
    const refresh = async () => {
      const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
      windowId = tab?.windowId;
      show(tab);
    };
    const onActivated = (info) => {
      if (windowId === undefined || info.windowId === windowId)
        chrome.tabs.get(info.tabId).then(show).catch(() => {
          return;
        });
    };
    const onUpdated = (id, info, tab) => {
      if (id === tabId && info.url !== undefined)
        show(tab);
    };
    refresh();
    chrome.tabs.onActivated.addListener(onActivated);
    chrome.tabs.onUpdated.addListener(onUpdated);
    return () => {
      chrome.tabs.onActivated.removeListener(onActivated);
      chrome.tabs.onUpdated.removeListener(onUpdated);
    };
  }, []);
  return current;
}
function useCurrentTabId() {
  return useCurrentTab().id;
}
function tabRestriction(url, state) {
  setBlockedDomains(state.blocked_domains);
  return restrictionOf(url, SERVER_URL);
}

// src/sidepanel/agent-tabs.tsx
var jsx_runtime = __toESM(require_jsx_runtime(), 1);
function AgentTabs(props) {
  const { state, send } = props;
  const current = useCurrentTab();
  const currentTabId = current.id;
  const currentIsGiven = state.tabs.some((tab) => tab.tab_id === currentTabId);
  const restriction = tabRestriction(current.url, state);
  return /* @__PURE__ */ jsx_runtime.jsxs("div", {
    className: "card",
    children: [
      /* @__PURE__ */ jsx_runtime.jsxs("div", {
        className: "row",
        children: [
          /* @__PURE__ */ jsx_runtime.jsx("h2", {
            className: "grow",
            children: t2("Agent tabs")
          }),
          currentTabId !== null && !currentIsGiven && !restriction && /* @__PURE__ */ jsx_runtime.jsx("button", {
            className: "btn primary",
            onClick: () => send({ type: "give_tab", tab_id: currentTabId }),
            children: t2("Give this tab to the agent")
          })
        ]
      }),
      currentTabId !== null && !currentIsGiven && restriction && /* @__PURE__ */ jsx_runtime.jsxs("div", {
        className: "muted",
        children: [
          t2("The agent cannot work on this page."),
          " ",
          t2(restriction)
        ]
      }),
      state.tabs.length === 0 ? /* @__PURE__ */ jsx_runtime.jsx("div", {
        className: "muted",
        children: t2("No tabs yet. Give the agent the tab you are looking at, or let it open one.")
      }) : /* @__PURE__ */ jsx_runtime.jsxs(jsx_runtime.Fragment, {
        children: [
          state.tabs.map((tab) => /* @__PURE__ */ jsx_runtime.jsxs("div", {
            className: `tab-item${tab.tab_id === state.agent_tab_id ? " agent" : ""}`,
            children: [
              tab.favicon ? /* @__PURE__ */ jsx_runtime.jsx("img", {
                src: tab.favicon,
                alt: ""
              }) : /* @__PURE__ */ jsx_runtime.jsx("span", {
                style: { width: 16 }
              }),
              /* @__PURE__ */ jsx_runtime.jsxs("div", {
                className: "grow",
                children: [
                  /* @__PURE__ */ jsx_runtime.jsx("div", {
                    className: "tab-title",
                    children: tab.title || tab.url
                  }),
                  /* @__PURE__ */ jsx_runtime.jsx("div", {
                    className: "tab-url",
                    children: tab.url
                  })
                ]
              }),
              tab.tab_id === state.agent_tab_id && /* @__PURE__ */ jsx_runtime.jsx("span", {
                className: "badge",
                children: t2("current")
              }),
              /* @__PURE__ */ jsx_runtime.jsx("button", {
                className: "btn plain",
                onClick: () => send({ type: "release_tab", tab_id: tab.tab_id }),
                children: t2("Take back")
              })
            ]
          }, tab.tab_id)),
          /* @__PURE__ */ jsx_runtime.jsx("div", {
            className: "muted",
            children: t2("The agent works only in these tabs (the AYETO tab group). Drag a tab out of the group to take it back.")
          })
        ]
      }),
      state.error && /* @__PURE__ */ jsx_runtime.jsx("div", {
        className: "error",
        children: t2(state.error)
      })
    ]
  });
}

// src/sidepanel/chat-view.tsx
var import_react7 = __toESM(require_react(), 1);

// ../frontend/src/data/stream.ts
var TOOL_CALL_MARKER_START = "### calling AI tool";
var TOOL_CALL_MARKER_END = "***";

// ../frontend/src/context/chat-stream-events.ts
function createStreamAccumulator() {
  return {
    content: "",
    reasoning: "",
    activity: {
      phase: "context_building",
      silentTools: [],
      contextCompacted: false,
      modelCalls: 0,
      completedTools: [],
      confirmations: []
    },
    toolNames: {},
    toolCallIds: [],
    nested: {}
  };
}
function applyStreamEvent(acc, event) {
  const activity = acc.activity;
  switch (event.type) {
    case "text":
      acc.content += event.delta;
      activity.phase = "generating";
      activity.toolDisplayName = undefined;
      return;
    case "reasoning":
      acc.reasoning += event.delta;
      activity.phase = "reasoning";
      activity.toolDisplayName = undefined;
      return;
    case "status": {
      const phase = event.phase;
      if (!phase)
        return;
      const toolLabel = event.tool_display_name || event.tool_name || undefined;
      if (phase === "model_selected") {
        activity.model = event.data?.model || activity.model;
        activity.modelName = event.data?.model_name || activity.modelName;
        activity.autoModel = event.data?.auto_model || undefined;
        return;
      }
      if (phase === "tool_confirm") {
        const confirmation = toolConfirmationFromEvent(event);
        if (!confirmation)
          return;
        const pending = activity.confirmations || [];
        if (!pending.some((c) => c.confirm_id === confirmation.confirm_id)) {
          activity.confirmations = [...pending, confirmation];
        }
        activity.phase = phase;
        activity.toolDisplayName = toolLabel;
        return;
      }
      if (phase === "tool_confirm_resolved") {
        const confirmId = event.data?.confirm_id;
        activity.confirmations = (activity.confirmations || []).filter((c) => c.confirm_id !== confirmId);
        if (activity.phase === "tool_confirm" && activity.confirmations.length === 0)
          activity.phase = "tool_call";
        return;
      }
      if (phase === "open_assistant") {
        if (event.data?.assistant_id)
          activity.openAssistant = { assistant_id: event.data.assistant_id, prompt: event.data.prompt || "" };
        return;
      }
      if (phase === "conversation_named") {
        return;
      }
      if (phase === "context_compacted") {
        activity.contextCompacted = true;
        return;
      }
      if (phase === "silent_tool") {
        if (toolLabel)
          activity.silentTools = [...activity.silentTools, toolLabel];
        activity.phase = phase;
        activity.toolDisplayName = toolLabel;
        return;
      }
      if (phase === "model_call")
        activity.modelCalls += 1;
      activity.phase = phase;
      activity.toolDisplayName = phase === "tool_call_pending" ? toolLabel : undefined;
      activity.toolArgumentsChars = phase === "tool_call_pending" ? event.data?.arguments_chars || undefined : undefined;
      return;
    }
    case "tool_call_start": {
      const toolLabel = event.tool_display_name || event.tool_name || "";
      acc.content += `

${TOOL_CALL_MARKER_START}: ${toolLabel}
`;
      if (event.call_id && event.tool_name)
        acc.toolNames[event.call_id] = event.tool_name;
      acc.toolCallIds.push(event.call_id || "");
      activity.phase = "tool_call";
      activity.toolDisplayName = toolLabel || undefined;
      activity.toolArgumentsChars = undefined;
      return;
    }
    case "tool_call_output":
      acc.content += event.delta;
      return;
    case "tool_call_end": {
      acc.content += `
${TOOL_CALL_MARKER_END}
`;
      const toolName = event.call_id ? acc.toolNames[event.call_id] : undefined;
      if (toolName)
        activity.completedTools = [...activity.completedTools, toolName];
      if (event.call_id && activity.confirmations?.some((c) => c.call_id === event.call_id)) {
        activity.confirmations = activity.confirmations.filter((c) => c.call_id !== event.call_id);
      }
      const nestedRun = event.call_id ? acc.nested[event.call_id] : undefined;
      if (nestedRun)
        dropConfirmations(nestedRun);
      return;
    }
    case "nested": {
      if (!event.call_id || !event.chunk)
        return;
      const nested = acc.nested[event.call_id] || (acc.nested[event.call_id] = createStreamAccumulator());
      applyStreamEvent(nested, event.chunk);
      return;
    }
    case "done":
    default:
      return;
  }
}
function toolConfirmationFromEvent(event) {
  const data = event.data || {};
  if (!data.confirm_id)
    return null;
  return {
    confirm_id: String(data.confirm_id),
    call_id: event.call_id ?? null,
    title: data.title || "",
    details: data.details || "",
    reason: data.reason || "",
    context: data.context || "",
    allow_session: data.allow_session === true,
    tool_display_name: event.tool_display_name || event.tool_name || null
  };
}
function dropConfirmations(acc) {
  if (acc.activity.confirmations?.length)
    acc.activity.confirmations = [];
  if (acc.activity.phase === "tool_confirm")
    acc.activity.phase = "tool_call";
  Object.values(acc.nested).forEach(dropConfirmations);
}
function collectConfirmations(acc) {
  const nested = Object.values(acc.nested).flatMap(collectConfirmations);
  return [...acc.activity.confirmations || [], ...nested];
}
function snapshotActivity(acc) {
  return {
    ...acc.activity,
    silentTools: [...acc.activity.silentTools],
    completedTools: [...acc.activity.completedTools],
    confirmations: collectConfirmations(acc)
  };
}
// ../frontend/src/components/markdown/tool-call-segments.ts
function parseToolCallSegments(text) {
  const startMarker = TOOL_CALL_MARKER_START;
  const endMarker = TOOL_CALL_MARKER_END;
  const segments = [];
  let currentIndex = 0;
  while (currentIndex < text.length) {
    const startIndex = text.toLowerCase().indexOf(startMarker.toLowerCase(), currentIndex);
    if (startIndex === -1) {
      segments.push({ type: "text", value: text.slice(currentIndex) });
      break;
    }
    segments.push({ type: "text", value: text.slice(currentIndex, startIndex) });
    const startLineEnd = text.indexOf(`
`, startIndex);
    if (startLineEnd === -1) {
      const partialLine = text.slice(startIndex);
      const colonIdx = partialLine.indexOf(":");
      segments.push({
        type: "tool",
        title: colonIdx !== -1 ? partialLine.slice(colonIdx + 1).trim() : "",
        content: "",
        streaming: true
      });
      break;
    }
    const startLine = text.slice(startIndex, startLineEnd);
    const colonIndex = startLine.indexOf(":");
    const title = colonIndex !== -1 ? startLine.slice(colonIndex + 1).trim() : "";
    const endIndex = text.indexOf(endMarker, startLineEnd);
    if (endIndex === -1) {
      segments.push({ type: "tool", title, content: text.slice(startLineEnd + 1).trim(), streaming: true });
      break;
    }
    segments.push({ type: "tool", title, content: text.slice(startLineEnd + 1, endIndex).trim(), streaming: false });
    currentIndex = endIndex + endMarker.length;
    if (text[currentIndex] === `
`) {
      currentIndex++;
    }
  }
  return segments;
}
// ../frontend/src/uni/api/stream-parser.ts
function createParserState() {
  return {
    buffer: "",
    braceCount: 0,
    inString: false,
    escapeNext: false,
    objectStart: -1,
    corruptedSegments: 0
  };
}
function resetParserState(state, keepBufferFrom = 0) {
  state.buffer = state.buffer.substring(keepBufferFrom);
  state.braceCount = 0;
  state.inString = false;
  state.escapeNext = false;
  state.objectStart = -1;
}
function findNextObjectStart(buffer, fromIndex = 0) {
  for (let i = fromIndex;i < buffer.length; i++) {
    if (buffer[i] === "{") {
      return i;
    }
  }
  return -1;
}
function tryParseSingleChunk(jsonStr) {
  try {
    const parsed = JSON.parse(jsonStr);
    if (typeof parsed === "object" && parsed !== null) {
      return parsed;
    }
    return null;
  } catch {
    return null;
  }
}
function parseStreamChunks(state, newData) {
  state.buffer += newData;
  const results = [];
  let i = 0;
  let lastProcessedEnd = 0;
  const maxIterations = state.buffer.length * 2;
  let iterations = 0;
  while (i < state.buffer.length && iterations < maxIterations) {
    iterations++;
    const char = state.buffer[i];
    if (state.escapeNext) {
      state.escapeNext = false;
      i++;
      continue;
    }
    if (char === "\\" && state.inString) {
      state.escapeNext = true;
      i++;
      continue;
    }
    if (char === '"') {
      state.inString = !state.inString;
      i++;
      continue;
    }
    if (state.inString) {
      i++;
      continue;
    }
    if (char === "{") {
      if (state.braceCount === 0) {
        state.objectStart = i;
      }
      state.braceCount++;
      i++;
      continue;
    }
    if (char === "}") {
      state.braceCount--;
      if (state.braceCount < 0) {
        state.corruptedSegments++;
        console.warn(`[StreamParser] Recovery: negative brace count at position ${i}, discarding corrupted segment #${state.corruptedSegments}`);
        const nextStart = findNextObjectStart(state.buffer, i + 1);
        if (nextStart !== -1) {
          lastProcessedEnd = nextStart;
          state.braceCount = 0;
          state.inString = false;
          state.escapeNext = false;
          state.objectStart = -1;
          i = nextStart;
          continue;
        } else {
          lastProcessedEnd = state.buffer.length;
          resetParserState(state, lastProcessedEnd);
          break;
        }
      }
      if (state.braceCount === 0 && state.objectStart !== -1) {
        const jsonStr = state.buffer.substring(state.objectStart, i + 1);
        const parsed = tryParseSingleChunk(jsonStr);
        if (parsed) {
          results.push(parsed);
        } else {
          state.corruptedSegments++;
          console.warn(`[StreamParser] Failed to parse JSON object #${state.corruptedSegments}:`, jsonStr.length > 200 ? jsonStr.substring(0, 200) + "..." : jsonStr);
        }
        lastProcessedEnd = i + 1;
        state.objectStart = -1;
      }
      i++;
      continue;
    }
    i++;
  }
  if (iterations >= maxIterations) {
    console.error("[StreamParser] Max iterations reached, resetting parser state");
    state.corruptedSegments++;
    resetParserState(state, state.buffer.length);
    return results;
  }
  if (lastProcessedEnd > 0) {
    state.buffer = state.buffer.substring(lastProcessedEnd);
    if (state.objectStart !== -1) {
      state.objectStart = state.objectStart - lastProcessedEnd;
      if (state.objectStart < 0) {
        state.objectStart = -1;
      }
    }
  }
  const MAX_BUFFER_SIZE = 1024 * 1024;
  if (state.buffer.length > MAX_BUFFER_SIZE) {
    console.warn(`[StreamParser] Buffer exceeded ${MAX_BUFFER_SIZE} bytes, attempting recovery`);
    state.corruptedSegments++;
    const keepSize = MAX_BUFFER_SIZE / 2;
    const trimPoint = state.buffer.length - keepSize;
    const nextStart = findNextObjectStart(state.buffer, trimPoint);
    if (nextStart !== -1) {
      resetParserState(state, nextStart);
    } else {
      resetParserState(state, trimPoint);
    }
  }
  return results;
}
function finalizeParser(state) {
  const results = [];
  if (!state.buffer.trim()) {
    return results;
  }
  const remaining = state.buffer.trim();
  if (remaining.startsWith("{") && remaining.endsWith("}")) {
    const parsed = tryParseSingleChunk(remaining);
    if (parsed) {
      results.push(parsed);
      return results;
    }
  }
  try {
    const normalized = remaining.replace(/\}\s*\{/g, "},{");
    const asArray = JSON.parse("[" + normalized + "]");
    if (Array.isArray(asArray)) {
      for (const item of asArray) {
        if (typeof item === "object" && item !== null) {
          results.push(item);
        }
      }
    }
  } catch {
    if (remaining.length > 0) {
      console.warn("[StreamParser] Could not parse remaining buffer on finalize:", remaining.length > 200 ? remaining.substring(0, 200) + "..." : remaining);
    }
  }
  return results;
}
// ../frontend/src/utils.ts
var IS_APPLE_PLATFORM = typeof navigator !== "undefined" && /Mac|iPhone|iPad|iPod/i.test(navigator.platform || navigator.userAgent);
var IS_COARSE_POINTER = typeof window !== "undefined" && !!window.matchMedia && window.matchMedia("(pointer: coarse)").matches;
function timeDuration(startTime, endTime) {
  const difference = Math.abs(endTime.getTime() - startTime.getTime()) / 1000;
  const hours = Math.floor(difference / 3600);
  const minutes = Math.floor(difference % 3600 / 60);
  const seconds = Math.floor(difference % 60);
  if (difference < 60) {
    return `${seconds}s`;
  } else if (difference < 3600) {
    return `${minutes}m ${seconds}s`;
  } else {
    return `${hours}h ${minutes}m ${seconds}s`;
  }
}

// ../frontend/src/uni/api/utils.tsx
var uniEndpoints = {
  auth: "/auth",
  googleOAuth: "/google_oauth",
  googleSignUp: "/user/signup/google",
  authWithRoot: "/auth_with_root",
  user: {
    get_self: "/user/get_self"
  },
  stream: {
    resume: "/stream/resume",
    cancel: "/stream/cancel",
    active: "/stream/active"
  },
  kvStore: {
    get: "/kvstore/get",
    getList: "/kvstore/get_list",
    set: "/kvstore/set",
    delete: "/kvstore/delete"
  }
};
function _get(url, token, headers, abort) {
  if (!headers)
    headers = new Headers;
  if (token)
    headers.set("token", token.token);
  return fetch(url, {
    headers,
    method: "GET",
    signal: abort?.signal
  });
}
function get(endpoint, token, params, abort, headers) {
  var _params = "";
  if (params) {
    _params += "?";
    var first = false;
    for (let p in params) {
      if (!first)
        _params += "&";
      _params += p + "=" + params[p];
    }
  }
  return _get(endpoint + encodeURI(_params), token, headers, abort).then((r) => {
    if (!r.ok)
      throw r;
    return r.json();
  });
}
function processStreamChunks(chunks, result, onData, onChunk, onError, onMeta) {
  for (const chunk of chunks) {
    if (chunk.stream && onMeta)
      onMeta(chunk.stream);
    if (chunk.error) {
      if (onError)
        onError(chunk.error);
      return { stop: true, error: true };
    }
    if (chunk.data === "" || chunk.data === null || chunk.data === undefined) {
      continue;
    }
    if (typeof chunk.data === "string") {
      result.value += chunk.data;
      if (onData)
        onData(result.value);
    }
    if (onChunk) {
      const stop = onChunk(chunk);
      if (stop) {
        return { stop: true, error: false };
      }
    }
  }
  return { stop: false, error: false };
}
async function post_stream(url, body, token, headers, onData, onDone, onError, onChunk, abort, onAbort, onMeta) {
  if (!headers)
    headers = new Headers;
  if (token)
    headers.set("token", token.token);
  headers.set("Content-type", "application/json");
  try {
    const startTime = new Date;
    const response = await fetch(url, {
      headers,
      method: "POST",
      body: JSON.stringify(body),
      mode: "cors",
      signal: abort?.signal
    });
    if (!response.ok) {
      if (onError)
        onError(response);
      else
        console.error("[post_stream] Response not OK:", response);
      return;
    }
    const reader = response.body?.getReader();
    if (!reader) {
      if (onError)
        onError(response);
      else
        console.error("[post_stream] No response body reader");
      return;
    }
    const parserState = createParserState();
    const result = { value: "" };
    const decoder = new TextDecoder;
    let done = false;
    while (!done) {
      const readResult = await reader.read();
      done = readResult.done;
      if (readResult.value) {
        const decoded = decoder.decode(readResult.value, { stream: true });
        const chunks = parseStreamChunks(parserState, decoded);
        const processResult = processStreamChunks(chunks, result, onData, onChunk, onError, onMeta);
        if (processResult.stop) {
          return;
        }
      }
    }
    const finalChunks = finalizeParser(parserState);
    const finalResult = processStreamChunks(finalChunks, result, onData, onChunk, onError, onMeta);
    if (finalResult.error) {
      return;
    }
    if (parserState.corruptedSegments > 0) {
      console.warn(`[post_stream] Stream completed with ${parserState.corruptedSegments} corrupted segment(s) recovered`);
    }
    if (onDone)
      onDone(result.value, timeDuration(startTime, new Date));
  } catch (error) {
    if (error?.name === "AbortError") {
      if (onAbort)
        onAbort();
      return;
    }
    if (onError)
      onError(error);
    else
      console.error("[post_stream] Error:", error);
  }
}
function _post(url, body, token, headers, abort) {
  if (!headers)
    headers = new Headers;
  if (token)
    headers.set("token", token.token);
  headers.set("Content-type", "application/json");
  return fetch(url, {
    headers,
    method: "POST",
    body: JSON.stringify(body),
    mode: "cors",
    signal: abort?.signal
  });
}
function post(endpoint, body, token, headers, blob, abort) {
  return _post(endpoint, body, token, headers, abort).then((r) => {
    if (!r.ok)
      throw r;
    if (blob)
      return r.blob();
    return r.json();
  });
}
function _post_file(url, file, token, headers, options) {
  if (!headers)
    headers = new Headers;
  if (token)
    headers.set("token", token.token);
  headers.set("Accept", "application/json");
  const data = new FormData;
  data.append(options?.fileField || "f", file);
  Object.entries(options?.fields || {}).forEach(([name, value]) => data.append(name, value));
  return fetch(url, {
    headers,
    method: "POST",
    body: data,
    mode: "cors"
  });
}
function post_file(endpoint, file, token, options) {
  return _post_file(endpoint, file, token, undefined, options).then((r) => {
    if (!r.ok)
      throw r;
    return r.json();
  });
}
function auth(serverUrl, username, password) {
  const headers = new Headers;
  headers.set("Authorization", "Basic " + btoa(username + ":" + password));
  return _get(serverUrl + uniEndpoints.auth, undefined, headers).then((r) => {
    if (!r.ok)
      throw r;
    return r.json();
  });
}
function googleOAuth(serverUrl, googleToken) {
  return post(serverUrl + uniEndpoints.googleOAuth, { token: googleToken });
}
function googleSignUp(serverUrl, googleToken, signupData) {
  return post(serverUrl + uniEndpoints.googleSignUp, { token: googleToken, signup_data: signupData || {} });
}
function authWithRoot(serverUrl, userId) {
  return post(serverUrl + uniEndpoints.authWithRoot, { user_id: userId });
}
function get_user(serverUrl, token) {
  return _get(serverUrl + uniEndpoints.user.get_self, token).then((r) => {
    if (!r.ok)
      throw r;
    return r.json();
  });
}
function uniErrorHandler(error, callback) {
  const unknownError = {
    status: 500,
    text: "error",
    detail: "unknown server error"
  };
  try {
    if (error?.name === "AbortError") {
      return;
    }
    if (error?.detail) {
      callback({
        status: error.status,
        text: error.text || error.statusText,
        detail: error.detail
      });
      return;
    }
    error.json().then((e) => {
      callback({
        status: error.status,
        text: error.statusText,
        detail: e.detail
      });
    }).catch(() => {
      callback(unknownError);
    });
  } catch (_error) {
    callback(unknownError);
  }
}
var UniApiUtils = {
  get,
  post,
  post_file,
  auth,
  googleOAuth,
  googleSignUp,
  authWithRoot,
  get_user,
  uniErrorHandler
};

// ../frontend/src/uni/api/resumable-stream.ts
var UNI_STREAM_ID_HEADER = "stream-id";
var RECONNECT_DELAYS_MS = [500, 1000, 2000, 4000, 8000, 15000, 30000];
var RECONNECT_GIVE_UP_MS = 5 * 60 * 1000;
var NOT_STARTED_GIVE_UP_MS = 20 * 1000;
var UNI_STREAM_CONNECTION_LOST = {
  status: 0,
  text: "Connection lost",
  detail: "the connection to the server was lost"
};
function newStreamId() {
  const b = crypto.getRandomValues(new Uint8Array(16));
  b[6] = b[6] & 15 | 64;
  b[8] = b[8] & 63 | 128;
  const h = Array.from(b, (x) => x.toString(16).padStart(2, "0")).join("");
  return `${h.slice(0, 8)}-${h.slice(8, 12)}-${h.slice(12, 16)}-${h.slice(16, 20)}-${h.slice(20)}`;
}

class UniResumableStream {
  cfg;
  streamId;
  lastSeq = 0;
  text = "";
  closed = false;
  seen = false;
  controller = null;
  timer = null;
  lostAt = null;
  attempt = 0;
  startedAt;
  endpoints;
  onOnline = () => this.retryNow();
  constructor(cfg) {
    this.cfg = cfg;
    this.streamId = cfg.streamId || newStreamId();
    this.startedAt = new Date(cfg.startedAt || Date.now());
    this.endpoints = cfg.endpoints || uniEndpoints.stream;
  }
  get id() {
    return this.streamId;
  }
  start() {
    window.addEventListener("online", this.onOnline);
    if (this.cfg.start)
      this.connect(this.cfg.start.url, this.cfg.start.body, true);
    else
      this.resume();
    return this;
  }
  abort() {
    if (this.closed)
      return;
    this.close();
    this.cancelOnServer();
  }
  stop() {
    if (this.closed)
      return;
    this.cancelOnServer();
  }
  cancelOnServer() {
    UniApiUtils.post(this.cfg.serverUrl + this.endpoints.cancel, { stream_id: this.streamId }, this.cfg.token(), this.cfg.headers()).catch(() => {});
  }
  detach() {
    this.close();
  }
  close() {
    this.closed = true;
    window.removeEventListener("online", this.onOnline);
    if (this.timer)
      clearTimeout(this.timer);
    this.timer = null;
    this.controller?.abort();
  }
  resume() {
    this.connect(this.cfg.serverUrl + this.endpoints.resume, { stream_id: this.streamId, after_seq: this.lastSeq }, false);
  }
  connect(url, body, first) {
    const controller = new AbortController;
    this.controller = controller;
    let ended = false;
    const current = () => !this.closed && controller === this.controller;
    const headers = this.cfg.headers();
    if (first)
      headers.set(UNI_STREAM_ID_HEADER, this.streamId);
    post_stream(url, body, this.cfg.token(), headers, undefined, () => {
      if (!current())
        return;
      if (ended || first && !this.seen)
        this.finish();
      else
        this.lost();
    }, (e) => {
      if (!current())
        return;
      if (e instanceof Response) {
        if (first)
          this.fail(e);
        else if (e.status === 404 && this.seen)
          this.finish();
        else if (e.status === 404 || e.status >= 500)
          this.lost();
        else
          this.fail(e);
      } else if (e instanceof Error) {
        this.lost();
      } else {
        this.fail(e);
      }
    }, (chunk) => this.handleChunk(chunk), controller, undefined, (meta) => {
      this.streamId = meta.id;
      if (!this.seen && this.cfg.onOpen)
        this.cfg.onOpen();
      this.seen = true;
      this.lostAt = null;
      this.attempt = 0;
      if (meta.reset) {
        this.text = "";
        this.lastSeq = 0;
        if (this.cfg.onReset)
          this.cfg.onReset();
      }
      if (meta.done)
        ended = true;
    });
  }
  handleChunk(chunk) {
    if (chunk.seq !== undefined && chunk.seq !== null) {
      if (chunk.seq <= this.lastSeq)
        return false;
      this.lastSeq = chunk.seq;
    }
    if (typeof chunk.data === "string") {
      this.text += chunk.data;
      if (this.cfg.onData)
        this.cfg.onData(this.text);
    }
    if (this.cfg.onChunk && this.cfg.onChunk(chunk)) {
      this.detach();
      return true;
    }
    return false;
  }
  lost() {
    if (this.lostAt === null)
      this.lostAt = Date.now();
    const limit = this.seen ? RECONNECT_GIVE_UP_MS : NOT_STARTED_GIVE_UP_MS;
    if (Date.now() - this.lostAt > limit) {
      this.fail({ ...UNI_STREAM_CONNECTION_LOST });
      return;
    }
    const delay = RECONNECT_DELAYS_MS[Math.min(this.attempt, RECONNECT_DELAYS_MS.length - 1)];
    this.attempt += 1;
    this.timer = setTimeout(() => {
      this.timer = null;
      if (!this.closed)
        this.resume();
    }, delay);
  }
  retryNow() {
    if (this.closed || !this.timer)
      return;
    clearTimeout(this.timer);
    this.timer = null;
    this.resume();
  }
  finish() {
    this.close();
    if (this.cfg.onDone)
      this.cfg.onDone(this.text, timeDuration(this.startedAt, new Date));
  }
  fail(error) {
    this.close();
    if (this.cfg.onError)
      this.cfg.onError(error);
  }
}
// src/sidepanel/api.ts
var conversationResource = (conversationId) => `conversation:${conversationId}`;
function escapeRegex(text) {
  return text.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
}

class ApiError extends Error {
  status;
  constructor(message, status = 0) {
    super(message);
    this.status = status;
    this.name = "ApiError";
  }
}
async function streamError(e) {
  if (e instanceof Response) {
    let detail = e.statusText;
    try {
      const json = await e.json();
      detail = typeof json.detail === "string" ? json.detail : JSON.stringify(json.detail);
    } catch {}
    return new ApiError(detail || `HTTP ${e.status}`, e.status);
  }
  if (e && typeof e === "object" && "detail" in e) {
    if (!e.status)
      return new ApiError(t2("The connection to AYETO was lost."), 0);
    return new ApiError(String(e.detail || e.text), e.status);
  }
  return new ApiError(String(e?.message ?? e));
}

class AyetoApi {
  serverUrl;
  apiKey;
  constructor(serverUrl, apiKey) {
    this.serverUrl = serverUrl;
    this.apiKey = apiKey;
  }
  headers() {
    return {
      "Content-Type": "application/json",
      "uni-api-key": this.apiKey,
      language: uiLanguage()
    };
  }
  async fetch(path, body, signal) {
    const response = await fetch(`${apiV3(this.serverUrl)}${path}`, {
      method: "POST",
      headers: this.headers(),
      body: JSON.stringify(body),
      signal
    });
    if (!response.ok) {
      let detail = response.statusText;
      try {
        const json = await response.json();
        detail = typeof json.detail === "string" ? json.detail : JSON.stringify(json.detail);
      } catch {}
      throw new ApiError(detail || `HTTP ${response.status}`, response.status);
    }
    return response;
  }
  async post(path, body, signal) {
    return (await this.fetch(path, body, signal)).json();
  }
  assistants(signal) {
    return this.post("/assistant/find", {
      filters: [["booster_panel_id", "==", null], ["workflow_id", "==", null]],
      sort_key: "accessed.timestamp",
      sort_order: 1
    }, signal);
  }
  conversations(apiKeyId, options = {}, signal) {
    const offset = options.offset ?? 0;
    const query = options.query?.trim();
    return this.post("/conversation/find", {
      filters: [["browser_api_key_id", "==", apiKeyId], ...query ? [["name", "regex", escapeRegex(query)]] : []],
      sort_key: "updated.timestamp",
      sort_order: 1,
      limit_from: offset,
      limit_to: offset + (options.limit ?? 30)
    }, signal);
  }
  async models(signal) {
    const all = await this.post("/ai_model/get_all", { model_type: "llm" }, signal);
    const needed = ["chat", "assistant", "tools"];
    return all.filter((m) => m.is_enabled && !m.is_deprecated && needed.every((c) => m.capabilities.includes(c))).sort((a, b) => a.display_name.localeCompare(b.display_name));
  }
  avatarUrl(assistantId, signal) {
    return this.post("/assistant/avatar/get", { assistant_id: assistantId }, signal);
  }
  conversation(id, signal) {
    return this.post("/conversation/get", { id }, signal);
  }
  deleteConversation(id) {
    return this.post("/conversation/delete", { id });
  }
  chatStream(request, handlers) {
    return this.resumable({
      start: { url: `${apiV3(this.serverUrl)}/browser_connector/chat`, body: { ...request, stream: true, runner_version: "2", use_vision: true, resumable: true } }
    }, handlers);
  }
  followStream(stream, handlers) {
    return this.resumable({ streamId: stream.id, startedAt: stream.created }, handlers);
  }
  async activeStream(conversationId, signal) {
    const streams = await this.post("/browser_connector/stream/active", { resource_key: conversationResource(conversationId) }, signal);
    return streams.find((s) => s.status === "running") ?? null;
  }
  resumable(stream, handlers) {
    return new UniResumableStream({
      serverUrl: apiV3(this.serverUrl),
      endpoints: { resume: "/browser_connector/stream/resume", cancel: "/browser_connector/stream/cancel" },
      token: () => {
        return;
      },
      headers: () => new Headers(this.headers()),
      ...stream,
      onChunk: (chunk) => {
        if (chunk.data && typeof chunk.data === "object")
          handlers.onEvent(chunk.data);
        return false;
      },
      onReset: handlers.onReset,
      onDone: () => handlers.onDone(),
      onError: (e) => void streamError(e).then(handlers.onError)
    }).start();
  }
}

// src/sidepanel/assistant-picker.tsx
var import_react2 = __toESM(require_react(), 1);
var jsx_runtime2 = __toESM(require_jsx_runtime(), 1);
function targetKey(target) {
  return target ? `${target.kind}:${target.id}` : "";
}
function parseTargetKey(key) {
  const m = /^(assistant|model):(.+)$/.exec(key ?? "");
  return m ? { kind: m[1], id: m[2] } : null;
}
var avatarCache = new Map;
function useAvatar(api, assistant) {
  const [url, setUrl] = import_react2.default.useState("");
  import_react2.default.useEffect(() => {
    setUrl("");
    if (!assistant?.avatar_id)
      return;
    let alive = true;
    let pending = avatarCache.get(assistant.id);
    if (!pending) {
      pending = api.avatarUrl(assistant.id).catch(() => "");
      avatarCache.set(assistant.id, pending);
    }
    pending.then((u) => alive && setUrl(u));
    return () => {
      alive = false;
    };
  }, [api, assistant?.id, assistant?.avatar_id]);
  return url;
}
function AssistantAvatar(props) {
  const url = useAvatar(props.api, props.assistant);
  const size = props.size ?? 22;
  const letter = (props.assistant?.name ?? props.label ?? "?").trim().charAt(0).toUpperCase() || "?";
  return url ? /* @__PURE__ */ jsx_runtime2.jsx("img", {
    className: "avatar",
    src: url,
    alt: "",
    style: { width: size, height: size }
  }) : /* @__PURE__ */ jsx_runtime2.jsx("span", {
    className: `avatar letter${props.assistant ? "" : " model"}`,
    style: { width: size, height: size, fontSize: size * 0.5 },
    children: letter
  });
}
function AssistantPicker(props) {
  const { api, assistants, models, value } = props;
  const [open, setOpen] = import_react2.default.useState(false);
  const [query, setQuery] = import_react2.default.useState("");
  const ref = import_react2.default.useRef(null);
  const assistant = value?.kind === "assistant" ? assistants?.find((a) => a.id === value.id) ?? null : null;
  const model = value?.kind === "model" ? models.find((m) => m.model_id === value.id) ?? null : null;
  import_react2.default.useEffect(() => {
    if (!open)
      return;
    const close = (e) => {
      if (ref.current && !ref.current.contains(e.target))
        setOpen(false);
    };
    document.addEventListener("mousedown", close);
    return () => document.removeEventListener("mousedown", close);
  }, [open]);
  const q = query.trim().toLowerCase();
  const shownAssistants = (assistants ?? []).filter((a) => !q || `${a.name} ${a.description}`.toLowerCase().includes(q));
  const shownModels = models.filter((m) => !q || `${m.display_name} ${m.model_id}`.toLowerCase().includes(q));
  const pick = (target) => {
    props.onChange(target);
    setOpen(false);
    setQuery("");
  };
  const label = !assistants ? t2("Loading…") : assistant?.name ?? model?.display_name ?? (value?.kind === "model" ? value.id : t2("Choose an assistant"));
  return /* @__PURE__ */ jsx_runtime2.jsxs("div", {
    className: "picker grow",
    ref,
    children: [
      /* @__PURE__ */ jsx_runtime2.jsxs("button", {
        className: "picker-button",
        disabled: props.disabled || !assistants,
        onClick: () => setOpen(!open),
        title: t2("Assistant"),
        children: [
          /* @__PURE__ */ jsx_runtime2.jsx(AssistantAvatar, {
            api,
            assistant,
            label
          }),
          /* @__PURE__ */ jsx_runtime2.jsx("span", {
            className: "grow picker-name",
            children: label
          }),
          /* @__PURE__ */ jsx_runtime2.jsx("span", {
            className: "muted",
            children: "▾"
          })
        ]
      }),
      open && /* @__PURE__ */ jsx_runtime2.jsxs("div", {
        className: "picker-list",
        children: [
          (assistants?.length ?? 0) + models.length > 8 && /* @__PURE__ */ jsx_runtime2.jsx("input", {
            className: "input",
            autoFocus: true,
            placeholder: t2("Search"),
            value: query,
            onChange: (e) => setQuery(e.target.value)
          }),
          shownAssistants.length > 0 && /* @__PURE__ */ jsx_runtime2.jsx("div", {
            className: "picker-section",
            children: t2("Assistants")
          }),
          shownAssistants.map((a) => /* @__PURE__ */ jsx_runtime2.jsxs("button", {
            className: `picker-item${assistant?.id === a.id ? " active" : ""}`,
            onClick: () => pick({ kind: "assistant", id: a.id }),
            children: [
              /* @__PURE__ */ jsx_runtime2.jsx(AssistantAvatar, {
                api,
                assistant: a,
                size: 28
              }),
              /* @__PURE__ */ jsx_runtime2.jsxs("span", {
                className: "grow",
                children: [
                  /* @__PURE__ */ jsx_runtime2.jsx("span", {
                    className: "picker-name",
                    children: a.name
                  }),
                  a.description && /* @__PURE__ */ jsx_runtime2.jsx("span", {
                    className: "picker-desc",
                    children: a.description
                  })
                ]
              })
            ]
          }, a.id)),
          shownModels.length > 0 && /* @__PURE__ */ jsx_runtime2.jsx("div", {
            className: "picker-section",
            children: t2("Models without an assistant")
          }),
          shownModels.map((m) => /* @__PURE__ */ jsx_runtime2.jsxs("button", {
            className: `picker-item${model?.model_id === m.model_id ? " active" : ""}`,
            onClick: () => pick({ kind: "model", id: m.model_id }),
            children: [
              /* @__PURE__ */ jsx_runtime2.jsx(AssistantAvatar, {
                api,
                assistant: null,
                label: m.display_name,
                size: 28
              }),
              /* @__PURE__ */ jsx_runtime2.jsxs("span", {
                className: "grow",
                children: [
                  /* @__PURE__ */ jsx_runtime2.jsx("span", {
                    className: "picker-name",
                    children: m.display_name
                  }),
                  m.description && /* @__PURE__ */ jsx_runtime2.jsx("span", {
                    className: "picker-desc",
                    children: m.description
                  })
                ]
              })
            ]
          }, m.model_id)),
          shownAssistants.length === 0 && shownModels.length === 0 && /* @__PURE__ */ jsx_runtime2.jsx("div", {
            className: "muted",
            children: t2("Nothing found")
          })
        ]
      })
    ]
  });
}

// src/sidepanel/composer.tsx
var import_react3 = __toESM(require_react(), 1);
var jsx_runtime3 = __toESM(require_jsx_runtime(), 1);
var MAX_FILE_BYTES = 20 * 1024 * 1024;
var MAX_FILES = 10;
function readFile(file) {
  return new Promise((resolve, reject) => {
    const reader = new FileReader;
    reader.onload = () => resolve({ filename: file.name || "pasted-image.png", data: String(reader.result), mime_type: file.type || "application/octet-stream" });
    reader.onerror = () => reject(reader.error);
    reader.readAsDataURL(file);
  });
}
function Composer(props) {
  const [text, setText] = import_react3.default.useState("");
  const [files, setFiles] = import_react3.default.useState([]);
  const [dragging, setDragging] = import_react3.default.useState(false);
  const fileInput = import_react3.default.useRef(null);
  const addFiles = async (list) => {
    const incoming = Array.from(list);
    const tooBig = incoming.filter((f) => f.size > MAX_FILE_BYTES);
    if (tooBig.length)
      props.onError(`${t2("File is too large")}: ${tooBig.map((f) => f.name).join(", ")}`);
    const encoded = await Promise.all(incoming.filter((f) => f.size <= MAX_FILE_BYTES).map(readFile));
    setFiles((prev) => [...prev, ...encoded].slice(0, MAX_FILES));
  };
  const send = () => {
    const message = text.trim();
    if (!message && files.length === 0 || props.disabled || props.streaming)
      return;
    props.onSend(message || t2("See the attached files."), files);
    setText("");
    setFiles([]);
  };
  const onKeyDown = (e) => {
    if (e.key === "Enter" && !e.shiftKey && !e.nativeEvent.isComposing) {
      e.preventDefault();
      send();
    }
  };
  const onPaste = (e) => {
    const pasted = Array.from(e.clipboardData.files);
    if (pasted.length) {
      e.preventDefault();
      addFiles(pasted);
    }
  };
  return /* @__PURE__ */ jsx_runtime3.jsxs("div", {
    className: `composer-wrap${dragging ? " dragging" : ""}`,
    onDragOver: (e) => {
      e.preventDefault();
      setDragging(true);
    },
    onDragLeave: () => setDragging(false),
    onDrop: (e) => {
      e.preventDefault();
      setDragging(false);
      addFiles(e.dataTransfer.files);
    },
    children: [
      files.length > 0 && /* @__PURE__ */ jsx_runtime3.jsx("div", {
        className: "composer-files",
        children: files.map((f, i) => /* @__PURE__ */ jsx_runtime3.jsxs("span", {
          className: "file-chip",
          children: [
            f.mime_type.startsWith("image/") ? /* @__PURE__ */ jsx_runtime3.jsx("img", {
              src: f.data,
              alt: ""
            }) : /* @__PURE__ */ jsx_runtime3.jsx("span", {
              children: "\uD83D\uDCC4"
            }),
            /* @__PURE__ */ jsx_runtime3.jsx("span", {
              className: "file-name",
              children: f.filename
            }),
            /* @__PURE__ */ jsx_runtime3.jsx("button", {
              className: "btn plain icon",
              title: t2("Remove"),
              onClick: () => setFiles(files.filter((_, j) => j !== i)),
              children: "✕"
            })
          ]
        }, i))
      }),
      /* @__PURE__ */ jsx_runtime3.jsxs("div", {
        className: "composer",
        children: [
          /* @__PURE__ */ jsx_runtime3.jsx("button", {
            className: "btn plain icon",
            title: t2("Attach files"),
            disabled: props.disabled || props.streaming,
            onClick: () => fileInput.current?.click(),
            children: "\uD83D\uDCCE"
          }),
          /* @__PURE__ */ jsx_runtime3.jsx("input", {
            ref: fileInput,
            type: "file",
            multiple: true,
            hidden: true,
            onChange: (e) => {
              if (e.target.files)
                addFiles(e.target.files);
              e.target.value = "";
            }
          }),
          /* @__PURE__ */ jsx_runtime3.jsx("textarea", {
            className: "input",
            rows: 2,
            value: text,
            placeholder: props.placeholder,
            onChange: (e) => setText(e.target.value),
            onKeyDown,
            onPaste,
            disabled: props.disabled
          }),
          props.streaming ? /* @__PURE__ */ jsx_runtime3.jsx("button", {
            className: "btn danger",
            onClick: props.onStop,
            children: t2("Stop")
          }) : /* @__PURE__ */ jsx_runtime3.jsx("button", {
            className: "btn primary",
            disabled: props.disabled || !text.trim() && files.length === 0,
            onClick: send,
            children: t2("Send")
          })
        ]
      })
    ]
  });
}

// src/sidepanel/history-view.tsx
var import_react4 = __toESM(require_react(), 1);
var jsx_runtime4 = __toESM(require_jsx_runtime(), 1);
function when(conversation) {
  const ts = conversation.updated?.timestamp || conversation.created?.timestamp;
  if (!ts)
    return "";
  const locale = uiLanguage() === "cz" ? "cs" : uiLanguage();
  return new Date(ts).toLocaleString(locale, { dateStyle: "short", timeStyle: "short" });
}
var PAGE_SIZE = 30;
var SEARCH_DELAY_MS = 300;
function HistoryView(props) {
  const { api, apiKeyId } = props;
  const [conversations, setConversations] = import_react4.default.useState(null);
  const [hasMore, setHasMore] = import_react4.default.useState(false);
  const [loadingMore, setLoadingMore] = import_react4.default.useState(false);
  const [search, setSearch] = import_react4.default.useState("");
  const [query, setQuery] = import_react4.default.useState("");
  const [error, setError] = import_react4.default.useState("");
  import_react4.default.useEffect(() => {
    const timer = setTimeout(() => setQuery(search.trim()), SEARCH_DELAY_MS);
    return () => clearTimeout(timer);
  }, [search]);
  import_react4.default.useEffect(() => {
    const abort = new AbortController;
    setConversations(null);
    setError("");
    api.conversations(apiKeyId, { query, limit: PAGE_SIZE }, abort.signal).then((page) => {
      setConversations(page);
      setHasMore(page.length === PAGE_SIZE);
    }).catch((e) => {
      if (e?.name !== "AbortError")
        setError(String(e?.message ?? e));
    });
    return () => abort.abort();
  }, [api, apiKeyId, query]);
  const loadMore = async () => {
    if (!conversations || loadingMore)
      return;
    setLoadingMore(true);
    try {
      const page = await api.conversations(apiKeyId, { query, offset: conversations.length, limit: PAGE_SIZE });
      const known = new Set(conversations.map((c) => c.id));
      setConversations([...conversations, ...page.filter((c) => !known.has(c.id))]);
      setHasMore(page.length === PAGE_SIZE);
    } catch (e) {
      setError(String(e?.message ?? e));
    } finally {
      setLoadingMore(false);
    }
  };
  const remove = async (conversation) => {
    if (!window.confirm(t2("Delete this conversation?")))
      return;
    try {
      await api.deleteConversation(conversation.id);
      setConversations((list) => list?.filter((c) => c.id !== conversation.id) ?? null);
    } catch (e) {
      setError(String(e?.message ?? e));
    }
  };
  const targetName = (c) => c.assistant_id ? props.assistants.find((a) => a.id === c.assistant_id)?.name ?? "" : props.models.find((m) => m.model_id === c.model)?.display_name ?? c.model;
  return /* @__PURE__ */ jsx_runtime4.jsxs("div", {
    className: "chat",
    children: [
      /* @__PURE__ */ jsx_runtime4.jsxs("div", {
        className: "chat-toolbar",
        children: [
          /* @__PURE__ */ jsx_runtime4.jsxs("button", {
            className: "btn plain",
            onClick: props.onClose,
            children: [
              "← ",
              t2("Back")
            ]
          }),
          /* @__PURE__ */ jsx_runtime4.jsx("span", {
            className: "grow"
          }),
          /* @__PURE__ */ jsx_runtime4.jsx("span", {
            className: "label",
            children: t2("History")
          })
        ]
      }),
      /* @__PURE__ */ jsx_runtime4.jsx("div", {
        className: "history-search",
        children: /* @__PURE__ */ jsx_runtime4.jsx("input", {
          className: "input",
          type: "search",
          value: search,
          placeholder: t2("Search conversations"),
          onChange: (e) => setSearch(e.target.value)
        })
      }),
      /* @__PURE__ */ jsx_runtime4.jsxs("div", {
        className: "chat-messages",
        children: [
          error && /* @__PURE__ */ jsx_runtime4.jsx("div", {
            className: "error",
            children: error
          }),
          conversations === null && !error && /* @__PURE__ */ jsx_runtime4.jsx("div", {
            className: "muted",
            children: t2("Loading…")
          }),
          conversations?.length === 0 && /* @__PURE__ */ jsx_runtime4.jsx("div", {
            className: "muted",
            children: query ? t2("No conversation matches.") : t2("No conversations from this browser yet.")
          }),
          conversations?.map((c) => /* @__PURE__ */ jsx_runtime4.jsxs("div", {
            className: `history-item${c.id === props.activeId ? " active" : ""}`,
            children: [
              /* @__PURE__ */ jsx_runtime4.jsxs("button", {
                className: "history-open grow",
                onClick: () => props.onOpen(c),
                children: [
                  /* @__PURE__ */ jsx_runtime4.jsx("div", {
                    className: "tab-title",
                    children: c.name
                  }),
                  /* @__PURE__ */ jsx_runtime4.jsx("div", {
                    className: "tab-url",
                    children: [targetName(c), when(c)].filter(Boolean).join(" · ")
                  })
                ]
              }),
              /* @__PURE__ */ jsx_runtime4.jsx("button", {
                className: "btn plain icon",
                title: t2("Delete"),
                onClick: () => void remove(c),
                children: "\uD83D\uDDD1"
              })
            ]
          }, c.id)),
          hasMore && /* @__PURE__ */ jsx_runtime4.jsx("button", {
            className: "btn plain",
            disabled: loadingMore,
            onClick: () => void loadMore(),
            children: loadingMore ? t2("Loading…") : t2("Load more")
          })
        ]
      })
    ]
  });
}

// src/sidepanel/markdown.tsx
var import_react6 = __toESM(require_react(), 1);

// node_modules/devlop/lib/default.js
function ok2() {}
function unreachable() {}

// node_modules/comma-separated-tokens/index.js
function stringify(values, options) {
  const settings = options || {};
  const input = values[values.length - 1] === "" ? [...values, ""] : values;
  return input.join((settings.padRight ? " " : "") + "," + (settings.padLeft === false ? "" : " ")).trim();
}

// node_modules/estree-util-is-identifier-name/lib/index.js
var nameRe = /^[$_\p{ID_Start}][$_\u{200C}\u{200D}\p{ID_Continue}]*$/u;
var nameReJsx = /^[$_\p{ID_Start}][-$_\u{200C}\u{200D}\p{ID_Continue}]*$/u;
var emptyOptions = {};
function name(name, options) {
  const settings = options || emptyOptions;
  const re = settings.jsx ? nameReJsx : nameRe;
  return re.test(name);
}
// node_modules/hast-util-whitespace/lib/index.js
var re2 = /[ \t\n\f\r]/g;
function whitespace(thing) {
  return typeof thing === "object" ? thing.type === "text" ? empty(thing.value) : false : empty(thing);
}
function empty(value) {
  return value.replace(re2, "") === "";
}
// node_modules/property-information/lib/util/schema.js
class Schema {
  constructor(property, normal, space) {
    this.normal = normal;
    this.property = property;
    if (space) {
      this.space = space;
    }
  }
}
Schema.prototype.normal = {};
Schema.prototype.property = {};
Schema.prototype.space = undefined;

// node_modules/property-information/lib/util/merge.js
function merge(definitions, space) {
  const property = {};
  const normal = {};
  for (const definition of definitions) {
    Object.assign(property, definition.property);
    Object.assign(normal, definition.normal);
  }
  return new Schema(property, normal, space);
}

// node_modules/property-information/lib/normalize.js
function normalize(value) {
  return value.toLowerCase();
}

// node_modules/property-information/lib/util/info.js
class Info {
  constructor(property, attribute) {
    this.attribute = attribute;
    this.property = property;
  }
}
Info.prototype.attribute = "";
Info.prototype.booleanish = false;
Info.prototype.boolean = false;
Info.prototype.commaOrSpaceSeparated = false;
Info.prototype.commaSeparated = false;
Info.prototype.defined = false;
Info.prototype.mustUseProperty = false;
Info.prototype.number = false;
Info.prototype.overloadedBoolean = false;
Info.prototype.property = "";
Info.prototype.spaceSeparated = false;
Info.prototype.space = undefined;

// node_modules/property-information/lib/util/types.js
var exports_types = {};
__export(exports_types, {
  boolean: () => boolean,
  booleanish: () => booleanish,
  commaOrSpaceSeparated: () => commaOrSpaceSeparated,
  commaSeparated: () => commaSeparated,
  number: () => number,
  overloadedBoolean: () => overloadedBoolean,
  spaceSeparated: () => spaceSeparated
});
var powers = 0;
var boolean = increment();
var booleanish = increment();
var overloadedBoolean = increment();
var number = increment();
var spaceSeparated = increment();
var commaSeparated = increment();
var commaOrSpaceSeparated = increment();
function increment() {
  return 2 ** ++powers;
}

// node_modules/property-information/lib/util/defined-info.js
var checks = Object.keys(exports_types);

class DefinedInfo extends Info {
  constructor(property, attribute, mask, space) {
    let index = -1;
    super(property, attribute);
    mark(this, "space", space);
    if (typeof mask === "number") {
      while (++index < checks.length) {
        const check = checks[index];
        mark(this, checks[index], (mask & exports_types[check]) === exports_types[check]);
      }
    }
  }
}
DefinedInfo.prototype.defined = true;
function mark(values, key, value) {
  if (value) {
    values[key] = value;
  }
}

// node_modules/property-information/lib/util/create.js
function create(definition) {
  const properties = {};
  const normals = {};
  for (const [property, value] of Object.entries(definition.properties)) {
    const info = new DefinedInfo(property, definition.transform(definition.attributes || {}, property), value, definition.space);
    if (definition.mustUseProperty && definition.mustUseProperty.includes(property)) {
      info.mustUseProperty = true;
    }
    properties[property] = info;
    normals[normalize(property)] = property;
    normals[normalize(info.attribute)] = property;
  }
  return new Schema(properties, normals, definition.space);
}

// node_modules/property-information/lib/aria.js
var aria = create({
  properties: {
    ariaActiveDescendant: null,
    ariaAtomic: booleanish,
    ariaAutoComplete: null,
    ariaBusy: booleanish,
    ariaChecked: booleanish,
    ariaColCount: number,
    ariaColIndex: number,
    ariaColSpan: number,
    ariaControls: spaceSeparated,
    ariaCurrent: null,
    ariaDescribedBy: spaceSeparated,
    ariaDetails: null,
    ariaDisabled: booleanish,
    ariaDropEffect: spaceSeparated,
    ariaErrorMessage: null,
    ariaExpanded: booleanish,
    ariaFlowTo: spaceSeparated,
    ariaGrabbed: booleanish,
    ariaHasPopup: null,
    ariaHidden: booleanish,
    ariaInvalid: null,
    ariaKeyShortcuts: null,
    ariaLabel: null,
    ariaLabelledBy: spaceSeparated,
    ariaLevel: number,
    ariaLive: null,
    ariaModal: booleanish,
    ariaMultiLine: booleanish,
    ariaMultiSelectable: booleanish,
    ariaOrientation: null,
    ariaOwns: spaceSeparated,
    ariaPlaceholder: null,
    ariaPosInSet: number,
    ariaPressed: booleanish,
    ariaReadOnly: booleanish,
    ariaRelevant: null,
    ariaRequired: booleanish,
    ariaRoleDescription: spaceSeparated,
    ariaRowCount: number,
    ariaRowIndex: number,
    ariaRowSpan: number,
    ariaSelected: booleanish,
    ariaSetSize: number,
    ariaSort: null,
    ariaValueMax: number,
    ariaValueMin: number,
    ariaValueNow: number,
    ariaValueText: null,
    role: null
  },
  transform(_, property) {
    return property === "role" ? property : "aria-" + property.slice(4).toLowerCase();
  }
});

// node_modules/property-information/lib/util/case-sensitive-transform.js
function caseSensitiveTransform(attributes, attribute) {
  return attribute in attributes ? attributes[attribute] : attribute;
}

// node_modules/property-information/lib/util/case-insensitive-transform.js
function caseInsensitiveTransform(attributes, property) {
  return caseSensitiveTransform(attributes, property.toLowerCase());
}

// node_modules/property-information/lib/html.js
var html = create({
  attributes: {
    acceptcharset: "accept-charset",
    classname: "class",
    htmlfor: "for",
    httpequiv: "http-equiv"
  },
  mustUseProperty: ["checked", "multiple", "muted", "selected"],
  properties: {
    abbr: null,
    accept: commaSeparated,
    acceptCharset: spaceSeparated,
    accessKey: spaceSeparated,
    action: null,
    allow: null,
    allowFullScreen: boolean,
    allowPaymentRequest: boolean,
    allowUserMedia: boolean,
    alpha: boolean,
    alt: null,
    as: null,
    async: boolean,
    autoCapitalize: null,
    autoComplete: spaceSeparated,
    autoFocus: boolean,
    autoPlay: boolean,
    blocking: spaceSeparated,
    capture: null,
    charSet: null,
    checked: boolean,
    cite: null,
    className: spaceSeparated,
    closedBy: null,
    colorSpace: null,
    cols: number,
    colSpan: number,
    command: null,
    commandFor: null,
    content: null,
    contentEditable: booleanish,
    controls: boolean,
    controlsList: spaceSeparated,
    coords: number | commaSeparated,
    crossOrigin: null,
    data: null,
    dateTime: null,
    decoding: null,
    default: boolean,
    defer: boolean,
    dir: null,
    dirName: null,
    disabled: boolean,
    download: overloadedBoolean,
    draggable: booleanish,
    encType: null,
    enterKeyHint: null,
    fetchPriority: null,
    form: null,
    formAction: null,
    formEncType: null,
    formMethod: null,
    formNoValidate: boolean,
    formTarget: null,
    headers: spaceSeparated,
    height: number,
    hidden: overloadedBoolean,
    high: number,
    href: null,
    hrefLang: null,
    htmlFor: spaceSeparated,
    httpEquiv: spaceSeparated,
    id: null,
    imageSizes: null,
    imageSrcSet: null,
    inert: boolean,
    inputMode: null,
    integrity: null,
    is: null,
    isMap: boolean,
    itemId: null,
    itemProp: spaceSeparated,
    itemRef: spaceSeparated,
    itemScope: boolean,
    itemType: spaceSeparated,
    kind: null,
    label: null,
    lang: null,
    language: null,
    list: null,
    loading: null,
    loop: boolean,
    low: number,
    manifest: null,
    max: null,
    maxLength: number,
    media: null,
    method: null,
    min: null,
    minLength: number,
    multiple: boolean,
    muted: boolean,
    name: null,
    nonce: null,
    noModule: boolean,
    noValidate: boolean,
    onAbort: null,
    onAfterPrint: null,
    onAuxClick: null,
    onBeforeMatch: null,
    onBeforePrint: null,
    onBeforeToggle: null,
    onBeforeUnload: null,
    onBlur: null,
    onCancel: null,
    onCanPlay: null,
    onCanPlayThrough: null,
    onChange: null,
    onClick: null,
    onClose: null,
    onContextLost: null,
    onContextMenu: null,
    onContextRestored: null,
    onCopy: null,
    onCueChange: null,
    onCut: null,
    onDblClick: null,
    onDrag: null,
    onDragEnd: null,
    onDragEnter: null,
    onDragExit: null,
    onDragLeave: null,
    onDragOver: null,
    onDragStart: null,
    onDrop: null,
    onDurationChange: null,
    onEmptied: null,
    onEnded: null,
    onError: null,
    onFocus: null,
    onFormData: null,
    onHashChange: null,
    onInput: null,
    onInvalid: null,
    onKeyDown: null,
    onKeyPress: null,
    onKeyUp: null,
    onLanguageChange: null,
    onLoad: null,
    onLoadedData: null,
    onLoadedMetadata: null,
    onLoadEnd: null,
    onLoadStart: null,
    onMessage: null,
    onMessageError: null,
    onMouseDown: null,
    onMouseEnter: null,
    onMouseLeave: null,
    onMouseMove: null,
    onMouseOut: null,
    onMouseOver: null,
    onMouseUp: null,
    onOffline: null,
    onOnline: null,
    onPageHide: null,
    onPageShow: null,
    onPaste: null,
    onPause: null,
    onPlay: null,
    onPlaying: null,
    onPopState: null,
    onProgress: null,
    onRateChange: null,
    onRejectionHandled: null,
    onReset: null,
    onResize: null,
    onScroll: null,
    onScrollEnd: null,
    onSecurityPolicyViolation: null,
    onSeeked: null,
    onSeeking: null,
    onSelect: null,
    onSlotChange: null,
    onStalled: null,
    onStorage: null,
    onSubmit: null,
    onSuspend: null,
    onTimeUpdate: null,
    onToggle: null,
    onUnhandledRejection: null,
    onUnload: null,
    onVolumeChange: null,
    onWaiting: null,
    onWheel: null,
    open: boolean,
    optimum: number,
    pattern: null,
    ping: spaceSeparated,
    placeholder: null,
    playsInline: boolean,
    popover: null,
    popoverTarget: null,
    popoverTargetAction: null,
    poster: null,
    preload: null,
    readOnly: boolean,
    referrerPolicy: null,
    rel: spaceSeparated,
    required: boolean,
    reversed: boolean,
    rows: number,
    rowSpan: number,
    sandbox: spaceSeparated,
    scope: null,
    scoped: boolean,
    seamless: boolean,
    selected: boolean,
    shadowRootClonable: boolean,
    shadowRootCustomElementRegistry: boolean,
    shadowRootDelegatesFocus: boolean,
    shadowRootMode: null,
    shadowRootSerializable: boolean,
    shape: null,
    size: number,
    sizes: null,
    slot: null,
    span: number,
    spellCheck: booleanish,
    src: null,
    srcDoc: null,
    srcLang: null,
    srcSet: null,
    start: number,
    step: null,
    style: null,
    tabIndex: number,
    target: null,
    title: null,
    translate: null,
    type: null,
    typeMustMatch: boolean,
    useMap: null,
    value: booleanish,
    width: number,
    wrap: null,
    writingSuggestions: null,
    align: null,
    aLink: null,
    archive: spaceSeparated,
    axis: null,
    background: null,
    bgColor: null,
    border: number,
    borderColor: null,
    bottomMargin: number,
    cellPadding: null,
    cellSpacing: null,
    char: null,
    charOff: null,
    classId: null,
    clear: null,
    code: null,
    codeBase: null,
    codeType: null,
    color: null,
    compact: boolean,
    declare: boolean,
    event: null,
    face: null,
    frame: null,
    frameBorder: null,
    hSpace: number,
    leftMargin: number,
    link: null,
    longDesc: null,
    lowSrc: null,
    marginHeight: number,
    marginWidth: number,
    noResize: boolean,
    noHref: boolean,
    noShade: boolean,
    noWrap: boolean,
    object: null,
    profile: null,
    prompt: null,
    rev: null,
    rightMargin: number,
    rules: null,
    scheme: null,
    scrolling: booleanish,
    standby: null,
    summary: null,
    text: null,
    topMargin: number,
    valueType: null,
    version: null,
    vAlign: null,
    vLink: null,
    vSpace: number,
    allowTransparency: null,
    autoCorrect: null,
    autoSave: null,
    credentialless: boolean,
    disablePictureInPicture: boolean,
    disableRemotePlayback: boolean,
    exportParts: commaSeparated,
    part: spaceSeparated,
    prefix: null,
    property: null,
    results: number,
    security: null,
    unselectable: null
  },
  space: "html",
  transform: caseInsensitiveTransform
});

// node_modules/property-information/lib/svg.js
var svg = create({
  attributes: {
    accentHeight: "accent-height",
    alignmentBaseline: "alignment-baseline",
    arabicForm: "arabic-form",
    baselineShift: "baseline-shift",
    capHeight: "cap-height",
    className: "class",
    clipPath: "clip-path",
    clipRule: "clip-rule",
    colorInterpolation: "color-interpolation",
    colorInterpolationFilters: "color-interpolation-filters",
    colorProfile: "color-profile",
    colorRendering: "color-rendering",
    crossOrigin: "crossorigin",
    dataType: "datatype",
    dominantBaseline: "dominant-baseline",
    enableBackground: "enable-background",
    fillOpacity: "fill-opacity",
    fillRule: "fill-rule",
    floodColor: "flood-color",
    floodOpacity: "flood-opacity",
    fontFamily: "font-family",
    fontSize: "font-size",
    fontSizeAdjust: "font-size-adjust",
    fontStretch: "font-stretch",
    fontStyle: "font-style",
    fontVariant: "font-variant",
    fontWeight: "font-weight",
    glyphName: "glyph-name",
    glyphOrientationHorizontal: "glyph-orientation-horizontal",
    glyphOrientationVertical: "glyph-orientation-vertical",
    hrefLang: "hreflang",
    horizAdvX: "horiz-adv-x",
    horizOriginX: "horiz-origin-x",
    horizOriginY: "horiz-origin-y",
    imageRendering: "image-rendering",
    letterSpacing: "letter-spacing",
    lightingColor: "lighting-color",
    markerEnd: "marker-end",
    markerMid: "marker-mid",
    markerStart: "marker-start",
    maskType: "mask-type",
    navDown: "nav-down",
    navDownLeft: "nav-down-left",
    navDownRight: "nav-down-right",
    navLeft: "nav-left",
    navNext: "nav-next",
    navPrev: "nav-prev",
    navRight: "nav-right",
    navUp: "nav-up",
    navUpLeft: "nav-up-left",
    navUpRight: "nav-up-right",
    onAbort: "onabort",
    onActivate: "onactivate",
    onAfterPrint: "onafterprint",
    onBeforePrint: "onbeforeprint",
    onBegin: "onbegin",
    onCancel: "oncancel",
    onCanPlay: "oncanplay",
    onCanPlayThrough: "oncanplaythrough",
    onChange: "onchange",
    onClick: "onclick",
    onClose: "onclose",
    onCopy: "oncopy",
    onCueChange: "oncuechange",
    onCut: "oncut",
    onDblClick: "ondblclick",
    onDrag: "ondrag",
    onDragEnd: "ondragend",
    onDragEnter: "ondragenter",
    onDragExit: "ondragexit",
    onDragLeave: "ondragleave",
    onDragOver: "ondragover",
    onDragStart: "ondragstart",
    onDrop: "ondrop",
    onDurationChange: "ondurationchange",
    onEmptied: "onemptied",
    onEnd: "onend",
    onEnded: "onended",
    onError: "onerror",
    onFocus: "onfocus",
    onFocusIn: "onfocusin",
    onFocusOut: "onfocusout",
    onHashChange: "onhashchange",
    onInput: "oninput",
    onInvalid: "oninvalid",
    onKeyDown: "onkeydown",
    onKeyPress: "onkeypress",
    onKeyUp: "onkeyup",
    onLoad: "onload",
    onLoadedData: "onloadeddata",
    onLoadedMetadata: "onloadedmetadata",
    onLoadStart: "onloadstart",
    onMessage: "onmessage",
    onMouseDown: "onmousedown",
    onMouseEnter: "onmouseenter",
    onMouseLeave: "onmouseleave",
    onMouseMove: "onmousemove",
    onMouseOut: "onmouseout",
    onMouseOver: "onmouseover",
    onMouseUp: "onmouseup",
    onMouseWheel: "onmousewheel",
    onOffline: "onoffline",
    onOnline: "ononline",
    onPageHide: "onpagehide",
    onPageShow: "onpageshow",
    onPaste: "onpaste",
    onPause: "onpause",
    onPlay: "onplay",
    onPlaying: "onplaying",
    onPopState: "onpopstate",
    onProgress: "onprogress",
    onRateChange: "onratechange",
    onRepeat: "onrepeat",
    onReset: "onreset",
    onResize: "onresize",
    onScroll: "onscroll",
    onSeeked: "onseeked",
    onSeeking: "onseeking",
    onSelect: "onselect",
    onShow: "onshow",
    onStalled: "onstalled",
    onStorage: "onstorage",
    onSubmit: "onsubmit",
    onSuspend: "onsuspend",
    onTimeUpdate: "ontimeupdate",
    onToggle: "ontoggle",
    onUnload: "onunload",
    onVolumeChange: "onvolumechange",
    onWaiting: "onwaiting",
    onZoom: "onzoom",
    overlinePosition: "overline-position",
    overlineThickness: "overline-thickness",
    paintOrder: "paint-order",
    panose1: "panose-1",
    pointerEvents: "pointer-events",
    referrerPolicy: "referrerpolicy",
    renderingIntent: "rendering-intent",
    shapeRendering: "shape-rendering",
    stopColor: "stop-color",
    stopOpacity: "stop-opacity",
    strikethroughPosition: "strikethrough-position",
    strikethroughThickness: "strikethrough-thickness",
    strokeDashArray: "stroke-dasharray",
    strokeDashOffset: "stroke-dashoffset",
    strokeLineCap: "stroke-linecap",
    strokeLineJoin: "stroke-linejoin",
    strokeMiterLimit: "stroke-miterlimit",
    strokeOpacity: "stroke-opacity",
    strokeWidth: "stroke-width",
    tabIndex: "tabindex",
    textAnchor: "text-anchor",
    textDecoration: "text-decoration",
    textRendering: "text-rendering",
    transformOrigin: "transform-origin",
    typeOf: "typeof",
    underlinePosition: "underline-position",
    underlineThickness: "underline-thickness",
    unicodeBidi: "unicode-bidi",
    unicodeRange: "unicode-range",
    unitsPerEm: "units-per-em",
    vAlphabetic: "v-alphabetic",
    vHanging: "v-hanging",
    vIdeographic: "v-ideographic",
    vMathematical: "v-mathematical",
    vectorEffect: "vector-effect",
    vertAdvY: "vert-adv-y",
    vertOriginX: "vert-origin-x",
    vertOriginY: "vert-origin-y",
    wordSpacing: "word-spacing",
    writingMode: "writing-mode",
    xHeight: "x-height",
    playbackOrder: "playbackorder",
    timelineBegin: "timelinebegin"
  },
  properties: {
    about: commaOrSpaceSeparated,
    accentHeight: number,
    accumulate: null,
    additive: null,
    alignmentBaseline: null,
    alphabetic: number,
    amplitude: number,
    arabicForm: null,
    ascent: number,
    attributeName: null,
    attributeType: null,
    azimuth: number,
    bandwidth: null,
    baselineShift: null,
    baseFrequency: null,
    baseProfile: null,
    bbox: null,
    begin: null,
    bias: number,
    by: null,
    calcMode: null,
    capHeight: number,
    className: spaceSeparated,
    clip: null,
    clipPath: null,
    clipPathUnits: null,
    clipRule: null,
    color: null,
    colorInterpolation: null,
    colorInterpolationFilters: null,
    colorProfile: null,
    colorRendering: null,
    content: null,
    contentScriptType: null,
    contentStyleType: null,
    crossOrigin: null,
    cursor: null,
    cx: null,
    cy: null,
    d: null,
    dataType: null,
    defaultAction: null,
    descent: number,
    diffuseConstant: number,
    direction: null,
    display: null,
    dur: null,
    divisor: number,
    dominantBaseline: null,
    download: boolean,
    dx: null,
    dy: null,
    edgeMode: null,
    editable: null,
    elevation: number,
    enableBackground: null,
    end: null,
    event: null,
    exponent: number,
    externalResourcesRequired: null,
    fill: null,
    fillOpacity: number,
    fillRule: null,
    filter: null,
    filterRes: null,
    filterUnits: null,
    floodColor: null,
    floodOpacity: null,
    focusable: null,
    focusHighlight: null,
    fontFamily: null,
    fontSize: null,
    fontSizeAdjust: null,
    fontStretch: null,
    fontStyle: null,
    fontVariant: null,
    fontWeight: null,
    format: null,
    fr: null,
    from: null,
    fx: null,
    fy: null,
    g1: commaSeparated,
    g2: commaSeparated,
    glyphName: commaSeparated,
    glyphOrientationHorizontal: null,
    glyphOrientationVertical: null,
    glyphRef: null,
    gradientTransform: null,
    gradientUnits: null,
    handler: null,
    hanging: number,
    hatchContentUnits: null,
    hatchUnits: null,
    height: null,
    href: null,
    hrefLang: null,
    horizAdvX: number,
    horizOriginX: number,
    horizOriginY: number,
    id: null,
    ideographic: number,
    imageRendering: null,
    initialVisibility: null,
    in: null,
    in2: null,
    intercept: number,
    k: number,
    k1: number,
    k2: number,
    k3: number,
    k4: number,
    kernelMatrix: commaOrSpaceSeparated,
    kernelUnitLength: null,
    keyPoints: null,
    keySplines: null,
    keyTimes: null,
    kerning: null,
    lang: null,
    lengthAdjust: null,
    letterSpacing: null,
    lightingColor: null,
    limitingConeAngle: number,
    local: null,
    markerEnd: null,
    markerMid: null,
    markerStart: null,
    markerHeight: null,
    markerUnits: null,
    markerWidth: null,
    mask: null,
    maskContentUnits: null,
    maskType: null,
    maskUnits: null,
    mathematical: null,
    max: null,
    media: null,
    mediaCharacterEncoding: null,
    mediaContentEncodings: null,
    mediaSize: number,
    mediaTime: null,
    method: null,
    min: null,
    mode: null,
    name: null,
    navDown: null,
    navDownLeft: null,
    navDownRight: null,
    navLeft: null,
    navNext: null,
    navPrev: null,
    navRight: null,
    navUp: null,
    navUpLeft: null,
    navUpRight: null,
    numOctaves: null,
    observer: null,
    offset: null,
    onAbort: null,
    onActivate: null,
    onAfterPrint: null,
    onBeforePrint: null,
    onBegin: null,
    onCancel: null,
    onCanPlay: null,
    onCanPlayThrough: null,
    onChange: null,
    onClick: null,
    onClose: null,
    onCopy: null,
    onCueChange: null,
    onCut: null,
    onDblClick: null,
    onDrag: null,
    onDragEnd: null,
    onDragEnter: null,
    onDragExit: null,
    onDragLeave: null,
    onDragOver: null,
    onDragStart: null,
    onDrop: null,
    onDurationChange: null,
    onEmptied: null,
    onEnd: null,
    onEnded: null,
    onError: null,
    onFocus: null,
    onFocusIn: null,
    onFocusOut: null,
    onHashChange: null,
    onInput: null,
    onInvalid: null,
    onKeyDown: null,
    onKeyPress: null,
    onKeyUp: null,
    onLoad: null,
    onLoadedData: null,
    onLoadedMetadata: null,
    onLoadStart: null,
    onMessage: null,
    onMouseDown: null,
    onMouseEnter: null,
    onMouseLeave: null,
    onMouseMove: null,
    onMouseOut: null,
    onMouseOver: null,
    onMouseUp: null,
    onMouseWheel: null,
    onOffline: null,
    onOnline: null,
    onPageHide: null,
    onPageShow: null,
    onPaste: null,
    onPause: null,
    onPlay: null,
    onPlaying: null,
    onPopState: null,
    onProgress: null,
    onRateChange: null,
    onRepeat: null,
    onReset: null,
    onResize: null,
    onScroll: null,
    onSeeked: null,
    onSeeking: null,
    onSelect: null,
    onShow: null,
    onStalled: null,
    onStorage: null,
    onSubmit: null,
    onSuspend: null,
    onTimeUpdate: null,
    onToggle: null,
    onUnload: null,
    onVolumeChange: null,
    onWaiting: null,
    onZoom: null,
    opacity: null,
    operator: null,
    order: null,
    orient: null,
    orientation: null,
    origin: null,
    overflow: null,
    overlay: null,
    overlinePosition: number,
    overlineThickness: number,
    paintOrder: null,
    panose1: null,
    path: null,
    pathLength: number,
    patternContentUnits: null,
    patternTransform: null,
    patternUnits: null,
    phase: null,
    ping: spaceSeparated,
    pitch: null,
    playbackOrder: null,
    pointerEvents: null,
    points: null,
    pointsAtX: number,
    pointsAtY: number,
    pointsAtZ: number,
    preserveAlpha: null,
    preserveAspectRatio: null,
    primitiveUnits: null,
    propagate: null,
    property: commaOrSpaceSeparated,
    r: null,
    radius: null,
    referrerPolicy: null,
    refX: null,
    refY: null,
    rel: commaOrSpaceSeparated,
    rev: commaOrSpaceSeparated,
    renderingIntent: null,
    repeatCount: null,
    repeatDur: null,
    requiredExtensions: commaOrSpaceSeparated,
    requiredFeatures: commaOrSpaceSeparated,
    requiredFonts: commaOrSpaceSeparated,
    requiredFormats: commaOrSpaceSeparated,
    resource: null,
    restart: null,
    result: null,
    rotate: null,
    rx: null,
    ry: null,
    scale: null,
    seed: null,
    shapeRendering: null,
    side: null,
    slope: null,
    snapshotTime: null,
    specularConstant: number,
    specularExponent: number,
    spreadMethod: null,
    spacing: null,
    startOffset: null,
    stdDeviation: null,
    stemh: null,
    stemv: null,
    stitchTiles: null,
    stopColor: null,
    stopOpacity: null,
    strikethroughPosition: number,
    strikethroughThickness: number,
    string: null,
    stroke: null,
    strokeDashArray: commaOrSpaceSeparated,
    strokeDashOffset: null,
    strokeLineCap: null,
    strokeLineJoin: null,
    strokeMiterLimit: number,
    strokeOpacity: number,
    strokeWidth: null,
    style: null,
    surfaceScale: number,
    syncBehavior: null,
    syncBehaviorDefault: null,
    syncMaster: null,
    syncTolerance: null,
    syncToleranceDefault: null,
    systemLanguage: commaOrSpaceSeparated,
    tabIndex: number,
    tableValues: null,
    target: null,
    targetX: number,
    targetY: number,
    textAnchor: null,
    textDecoration: null,
    textRendering: null,
    textLength: null,
    timelineBegin: null,
    title: null,
    transformBehavior: null,
    type: null,
    typeOf: commaOrSpaceSeparated,
    to: null,
    transform: null,
    transformOrigin: null,
    u1: null,
    u2: null,
    underlinePosition: number,
    underlineThickness: number,
    unicode: null,
    unicodeBidi: null,
    unicodeRange: null,
    unitsPerEm: number,
    values: null,
    vAlphabetic: number,
    vMathematical: number,
    vectorEffect: null,
    vHanging: number,
    vIdeographic: number,
    version: null,
    vertAdvY: number,
    vertOriginX: number,
    vertOriginY: number,
    viewBox: null,
    viewTarget: null,
    visibility: null,
    width: null,
    widths: null,
    wordSpacing: null,
    writingMode: null,
    x: null,
    x1: null,
    x2: null,
    xChannelSelector: null,
    xHeight: number,
    y: null,
    y1: null,
    y2: null,
    yChannelSelector: null,
    z: null,
    zoomAndPan: null
  },
  space: "svg",
  transform: caseSensitiveTransform
});

// node_modules/property-information/lib/xlink.js
var xlink = create({
  properties: {
    xLinkActuate: null,
    xLinkArcRole: null,
    xLinkHref: null,
    xLinkRole: null,
    xLinkShow: null,
    xLinkTitle: null,
    xLinkType: null
  },
  space: "xlink",
  transform(_, property) {
    return "xlink:" + property.slice(5).toLowerCase();
  }
});

// node_modules/property-information/lib/xmlns.js
var xmlns = create({
  attributes: { xmlnsxlink: "xmlns:xlink" },
  properties: { xmlnsXLink: null, xmlns: null },
  space: "xmlns",
  transform: caseInsensitiveTransform
});

// node_modules/property-information/lib/xml.js
var xml = create({
  properties: { xmlBase: null, xmlLang: null, xmlSpace: null },
  space: "xml",
  transform(_, property) {
    return "xml:" + property.slice(3).toLowerCase();
  }
});

// node_modules/property-information/lib/hast-to-react.js
var hastToReact = {
  classId: "classID",
  dataType: "datatype",
  itemId: "itemID",
  strokeDashArray: "strokeDasharray",
  strokeDashOffset: "strokeDashoffset",
  strokeLineCap: "strokeLinecap",
  strokeLineJoin: "strokeLinejoin",
  strokeMiterLimit: "strokeMiterlimit",
  typeOf: "typeof",
  xLinkActuate: "xlinkActuate",
  xLinkArcRole: "xlinkArcrole",
  xLinkHref: "xlinkHref",
  xLinkRole: "xlinkRole",
  xLinkShow: "xlinkShow",
  xLinkTitle: "xlinkTitle",
  xLinkType: "xlinkType",
  xmlnsXLink: "xmlnsXlink"
};
// node_modules/property-information/lib/find.js
var cap = /[A-Z]/g;
var dash = /-[a-z]/g;
var valid = /^data[-\w.:]+$/i;
function find(schema, value) {
  const normal = normalize(value);
  let property = value;
  let Type = Info;
  if (normal in schema.normal) {
    return schema.property[schema.normal[normal]];
  }
  if (normal.length > 4 && normal.slice(0, 4) === "data" && valid.test(value)) {
    if (value.charAt(4) === "-") {
      const rest = value.slice(5).replace(dash, camelcase);
      property = "data" + rest.charAt(0).toUpperCase() + rest.slice(1);
    } else {
      const rest = value.slice(4);
      if (!dash.test(rest)) {
        let dashes = rest.replace(cap, kebab);
        if (dashes.charAt(0) !== "-") {
          dashes = "-" + dashes;
        }
        value = "data" + dashes;
      }
    }
    Type = DefinedInfo;
  }
  return new Type(property, value);
}
function kebab($0) {
  return "-" + $0.toLowerCase();
}
function camelcase($0) {
  return $0.charAt(1).toUpperCase();
}
// node_modules/property-information/index.js
var html2 = merge([aria, html, xlink, xmlns, xml], "html");
var svg2 = merge([aria, svg, xlink, xmlns, xml], "svg");

// node_modules/space-separated-tokens/index.js
function stringify2(values) {
  return values.join(" ").trim();
}

// node_modules/hast-util-to-jsx-runtime/lib/index.js
var import_style_to_js = __toESM(require_cjs3(), 1);

// node_modules/unist-util-position/lib/index.js
var pointEnd = point("end");
var pointStart = point("start");
function point(type) {
  return point;
  function point(node) {
    const point = node && node.position && node.position[type] || {};
    if (typeof point.line === "number" && point.line > 0 && typeof point.column === "number" && point.column > 0) {
      return {
        line: point.line,
        column: point.column,
        offset: typeof point.offset === "number" && point.offset > -1 ? point.offset : undefined
      };
    }
  }
}
function position(node) {
  const start = pointStart(node);
  const end = pointEnd(node);
  if (start && end) {
    return { start, end };
  }
}
// node_modules/unist-util-stringify-position/lib/index.js
function stringifyPosition(value) {
  if (!value || typeof value !== "object") {
    return "";
  }
  if ("position" in value || "type" in value) {
    return position2(value.position);
  }
  if ("start" in value || "end" in value) {
    return position2(value);
  }
  if ("line" in value || "column" in value) {
    return point2(value);
  }
  return "";
}
function point2(point) {
  return index(point && point.line) + ":" + index(point && point.column);
}
function position2(pos) {
  return point2(pos && pos.start) + "-" + point2(pos && pos.end);
}
function index(value) {
  return value && typeof value === "number" ? value : 1;
}
// node_modules/vfile-message/lib/index.js
class VFileMessage extends Error {
  constructor(causeOrReason, optionsOrParentOrPlace, origin) {
    super();
    if (typeof optionsOrParentOrPlace === "string") {
      origin = optionsOrParentOrPlace;
      optionsOrParentOrPlace = undefined;
    }
    let reason = "";
    let options = {};
    let legacyCause = false;
    if (optionsOrParentOrPlace) {
      if ("line" in optionsOrParentOrPlace && "column" in optionsOrParentOrPlace) {
        options = { place: optionsOrParentOrPlace };
      } else if ("start" in optionsOrParentOrPlace && "end" in optionsOrParentOrPlace) {
        options = { place: optionsOrParentOrPlace };
      } else if ("type" in optionsOrParentOrPlace) {
        options = {
          ancestors: [optionsOrParentOrPlace],
          place: optionsOrParentOrPlace.position
        };
      } else {
        options = { ...optionsOrParentOrPlace };
      }
    }
    if (typeof causeOrReason === "string") {
      reason = causeOrReason;
    } else if (!options.cause && causeOrReason) {
      legacyCause = true;
      reason = causeOrReason.message;
      options.cause = causeOrReason;
    }
    if (!options.ruleId && !options.source && typeof origin === "string") {
      const index = origin.indexOf(":");
      if (index === -1) {
        options.ruleId = origin;
      } else {
        options.source = origin.slice(0, index);
        options.ruleId = origin.slice(index + 1);
      }
    }
    if (!options.place && options.ancestors && options.ancestors) {
      const parent = options.ancestors[options.ancestors.length - 1];
      if (parent) {
        options.place = parent.position;
      }
    }
    const start = options.place && "start" in options.place ? options.place.start : options.place;
    this.ancestors = options.ancestors || undefined;
    this.cause = options.cause || undefined;
    this.column = start ? start.column : undefined;
    this.fatal = undefined;
    this.file = "";
    this.message = reason;
    this.line = start ? start.line : undefined;
    this.name = stringifyPosition(options.place) || "1:1";
    this.place = options.place || undefined;
    this.reason = this.message;
    this.ruleId = options.ruleId || undefined;
    this.source = options.source || undefined;
    this.stack = legacyCause && options.cause && typeof options.cause.stack === "string" ? options.cause.stack : "";
    this.actual = undefined;
    this.expected = undefined;
    this.note = undefined;
    this.url = undefined;
  }
}
VFileMessage.prototype.file = "";
VFileMessage.prototype.name = "";
VFileMessage.prototype.reason = "";
VFileMessage.prototype.message = "";
VFileMessage.prototype.stack = "";
VFileMessage.prototype.column = undefined;
VFileMessage.prototype.line = undefined;
VFileMessage.prototype.ancestors = undefined;
VFileMessage.prototype.cause = undefined;
VFileMessage.prototype.fatal = undefined;
VFileMessage.prototype.place = undefined;
VFileMessage.prototype.ruleId = undefined;
VFileMessage.prototype.source = undefined;
// node_modules/hast-util-to-jsx-runtime/lib/index.js
var own = {}.hasOwnProperty;
var emptyMap = new Map;
var cap2 = /[A-Z]/g;
var tableElements = new Set(["table", "tbody", "thead", "tfoot", "tr"]);
var tableCellElement = new Set(["td", "th"]);
var docs = "https://github.com/syntax-tree/hast-util-to-jsx-runtime";
function toJsxRuntime(tree, options) {
  if (!options || options.Fragment === undefined) {
    throw new TypeError("Expected `Fragment` in options");
  }
  const filePath = options.filePath || undefined;
  let create;
  if (options.development) {
    if (typeof options.jsxDEV !== "function") {
      throw new TypeError("Expected `jsxDEV` in options when `development: true`");
    }
    create = developmentCreate(filePath, options.jsxDEV);
  } else {
    if (typeof options.jsx !== "function") {
      throw new TypeError("Expected `jsx` in production options");
    }
    if (typeof options.jsxs !== "function") {
      throw new TypeError("Expected `jsxs` in production options");
    }
    create = productionCreate(filePath, options.jsx, options.jsxs);
  }
  const state = {
    Fragment: options.Fragment,
    ancestors: [],
    components: options.components || {},
    create,
    elementAttributeNameCase: options.elementAttributeNameCase || "react",
    evaluater: options.createEvaluater ? options.createEvaluater() : undefined,
    filePath,
    ignoreInvalidStyle: options.ignoreInvalidStyle || false,
    passKeys: options.passKeys !== false,
    passNode: options.passNode || false,
    schema: options.space === "svg" ? svg2 : html2,
    stylePropertyNameCase: options.stylePropertyNameCase || "dom",
    tableCellAlignToStyle: options.tableCellAlignToStyle !== false
  };
  const result = one(state, tree, undefined);
  if (result && typeof result !== "string") {
    return result;
  }
  return state.create(tree, state.Fragment, { children: result || undefined }, undefined);
}
function one(state, node, key) {
  if (node.type === "element") {
    return element(state, node, key);
  }
  if (node.type === "mdxFlowExpression" || node.type === "mdxTextExpression") {
    return mdxExpression(state, node);
  }
  if (node.type === "mdxJsxFlowElement" || node.type === "mdxJsxTextElement") {
    return mdxJsxElement(state, node, key);
  }
  if (node.type === "mdxjsEsm") {
    return mdxEsm(state, node);
  }
  if (node.type === "root") {
    return root(state, node, key);
  }
  if (node.type === "text") {
    return text(state, node);
  }
}
function element(state, node, key) {
  const parentSchema = state.schema;
  let schema = parentSchema;
  if (node.tagName.toLowerCase() === "svg" && parentSchema.space === "html") {
    schema = svg2;
    state.schema = schema;
  }
  state.ancestors.push(node);
  const type = findComponentFromName(state, node.tagName, false);
  const props = createElementProps(state, node);
  let children = createChildren(state, node);
  if (tableElements.has(node.tagName)) {
    children = children.filter(function(child) {
      return typeof child === "string" ? !whitespace(child) : true;
    });
  }
  addNode(state, props, type, node);
  addChildren(props, children);
  state.ancestors.pop();
  state.schema = parentSchema;
  return state.create(node, type, props, key);
}
function mdxExpression(state, node) {
  if (node.data && node.data.estree && state.evaluater) {
    const program = node.data.estree;
    const expression = program.body[0];
    ok2(expression.type === "ExpressionStatement");
    return state.evaluater.evaluateExpression(expression.expression);
  }
  crashEstree(state, node.position);
}
function mdxEsm(state, node) {
  if (node.data && node.data.estree && state.evaluater) {
    return state.evaluater.evaluateProgram(node.data.estree);
  }
  crashEstree(state, node.position);
}
function mdxJsxElement(state, node, key) {
  const parentSchema = state.schema;
  let schema = parentSchema;
  if (node.name === "svg" && parentSchema.space === "html") {
    schema = svg2;
    state.schema = schema;
  }
  state.ancestors.push(node);
  const type = node.name === null ? state.Fragment : findComponentFromName(state, node.name, true);
  const props = createJsxElementProps(state, node);
  const children = createChildren(state, node);
  addNode(state, props, type, node);
  addChildren(props, children);
  state.ancestors.pop();
  state.schema = parentSchema;
  return state.create(node, type, props, key);
}
function root(state, node, key) {
  const props = {};
  addChildren(props, createChildren(state, node));
  return state.create(node, state.Fragment, props, key);
}
function text(_, node) {
  return node.value;
}
function addNode(state, props, type, node) {
  if (typeof type !== "string" && type !== state.Fragment && state.passNode) {
    props.node = node;
  }
}
function addChildren(props, children) {
  if (children.length > 0) {
    const value = children.length > 1 ? children : children[0];
    if (value) {
      props.children = value;
    }
  }
}
function productionCreate(_, jsx, jsxs) {
  return create;
  function create(_, type, props, key) {
    const isStaticChildren = Array.isArray(props.children);
    const fn = isStaticChildren ? jsxs : jsx;
    return key ? fn(type, props, key) : fn(type, props);
  }
}
function developmentCreate(filePath, jsxDEV) {
  return create;
  function create(node, type, props, key) {
    const isStaticChildren = Array.isArray(props.children);
    const point = pointStart(node);
    return jsxDEV(type, props, key, isStaticChildren, {
      columnNumber: point ? point.column - 1 : undefined,
      fileName: filePath,
      lineNumber: point ? point.line : undefined
    }, undefined);
  }
}
function createElementProps(state, node) {
  const props = {};
  let alignValue;
  let prop;
  for (prop in node.properties) {
    if (prop !== "children" && own.call(node.properties, prop)) {
      const result = createProperty(state, prop, node.properties[prop]);
      if (result) {
        const [key, value] = result;
        if (state.tableCellAlignToStyle && key === "align" && typeof value === "string" && tableCellElement.has(node.tagName)) {
          alignValue = value;
        } else {
          props[key] = value;
        }
      }
    }
  }
  if (alignValue) {
    const style = props.style || (props.style = {});
    style[state.stylePropertyNameCase === "css" ? "text-align" : "textAlign"] = alignValue;
  }
  return props;
}
function createJsxElementProps(state, node) {
  const props = {};
  for (const attribute of node.attributes) {
    if (attribute.type === "mdxJsxExpressionAttribute") {
      if (attribute.data && attribute.data.estree && state.evaluater) {
        const program = attribute.data.estree;
        const expression = program.body[0];
        ok2(expression.type === "ExpressionStatement");
        const objectExpression = expression.expression;
        ok2(objectExpression.type === "ObjectExpression");
        const property = objectExpression.properties[0];
        ok2(property.type === "SpreadElement");
        Object.assign(props, state.evaluater.evaluateExpression(property.argument));
      } else {
        crashEstree(state, node.position);
      }
    } else {
      const name = attribute.name;
      let value;
      if (attribute.value && typeof attribute.value === "object") {
        if (attribute.value.data && attribute.value.data.estree && state.evaluater) {
          const program = attribute.value.data.estree;
          const expression = program.body[0];
          ok2(expression.type === "ExpressionStatement");
          value = state.evaluater.evaluateExpression(expression.expression);
        } else {
          crashEstree(state, node.position);
        }
      } else {
        value = attribute.value === null ? true : attribute.value;
      }
      props[name] = value;
    }
  }
  return props;
}
function createChildren(state, node) {
  const children = [];
  let index = -1;
  const countsByName = state.passKeys ? new Map : emptyMap;
  while (++index < node.children.length) {
    const child = node.children[index];
    let key;
    if (state.passKeys) {
      const name = child.type === "element" ? child.tagName : child.type === "mdxJsxFlowElement" || child.type === "mdxJsxTextElement" ? child.name : undefined;
      if (name) {
        const count = countsByName.get(name) || 0;
        key = name + "-" + count;
        countsByName.set(name, count + 1);
      }
    }
    const result = one(state, child, key);
    if (result !== undefined)
      children.push(result);
  }
  return children;
}
function createProperty(state, prop, value) {
  const info = find(state.schema, prop);
  if (value === null || value === undefined || typeof value === "number" && Number.isNaN(value)) {
    return;
  }
  if (Array.isArray(value)) {
    value = info.commaSeparated ? stringify(value) : stringify2(value);
  }
  if (info.property === "style") {
    let styleObject = typeof value === "object" ? value : parseStyle(state, String(value));
    if (state.stylePropertyNameCase === "css") {
      styleObject = transformStylesToCssCasing(styleObject);
    }
    return ["style", styleObject];
  }
  return [
    state.elementAttributeNameCase === "react" && info.space ? hastToReact[info.property] || info.property : info.attribute,
    value
  ];
}
function parseStyle(state, value) {
  try {
    return import_style_to_js.default(value, { reactCompat: true });
  } catch (error) {
    if (state.ignoreInvalidStyle) {
      return {};
    }
    const cause = error;
    const message = new VFileMessage("Cannot parse `style` attribute", {
      ancestors: state.ancestors,
      cause,
      ruleId: "style",
      source: "hast-util-to-jsx-runtime"
    });
    message.file = state.filePath || undefined;
    message.url = docs + "#cannot-parse-style-attribute";
    throw message;
  }
}
function findComponentFromName(state, name2, allowExpression) {
  let result;
  if (!allowExpression) {
    result = { type: "Literal", value: name2 };
  } else if (name2.includes(".")) {
    const identifiers = name2.split(".");
    let index = -1;
    let node;
    while (++index < identifiers.length) {
      const prop = name(identifiers[index]) ? { type: "Identifier", name: identifiers[index] } : { type: "Literal", value: identifiers[index] };
      node = node ? {
        type: "MemberExpression",
        object: node,
        property: prop,
        computed: Boolean(index && prop.type === "Literal"),
        optional: false
      } : prop;
    }
    ok2(node, "always a result");
    result = node;
  } else {
    result = name(name2) && !/^[a-z]/.test(name2) ? { type: "Identifier", name: name2 } : { type: "Literal", value: name2 };
  }
  if (result.type === "Literal") {
    const name2 = result.value;
    return own.call(state.components, name2) ? state.components[name2] : name2;
  }
  if (state.evaluater) {
    return state.evaluater.evaluateExpression(result);
  }
  crashEstree(state);
}
function crashEstree(state, place) {
  const message = new VFileMessage("Cannot handle MDX estrees without `createEvaluater`", {
    ancestors: state.ancestors,
    place,
    ruleId: "mdx-estree",
    source: "hast-util-to-jsx-runtime"
  });
  message.file = state.filePath || undefined;
  message.url = docs + "#cannot-handle-mdx-estrees-without-createevaluater";
  throw message;
}
function transformStylesToCssCasing(domCasing) {
  const cssCasing = {};
  let from;
  for (from in domCasing) {
    if (own.call(domCasing, from)) {
      cssCasing[transformStyleToCssCasing(from)] = domCasing[from];
    }
  }
  return cssCasing;
}
function transformStyleToCssCasing(from) {
  let to = from.replace(cap2, toDash);
  if (to.slice(0, 3) === "ms-")
    to = "-" + to;
  return to;
}
function toDash($0) {
  return "-" + $0.toLowerCase();
}
// node_modules/html-url-attributes/lib/index.js
var urlAttributes = {
  action: ["form"],
  cite: ["blockquote", "del", "ins", "q"],
  data: ["object"],
  formAction: ["button", "input"],
  href: ["a", "area", "base", "link"],
  icon: ["menuitem"],
  itemId: null,
  manifest: ["html"],
  ping: ["a", "area"],
  poster: ["video"],
  src: [
    "audio",
    "embed",
    "iframe",
    "img",
    "input",
    "script",
    "source",
    "track",
    "video"
  ]
};
// node_modules/react-markdown/lib/index.js
var import_jsx_runtime = __toESM(require_jsx_runtime(), 1);
var import_react5 = __toESM(require_react(), 1);

// node_modules/mdast-util-to-string/lib/index.js
var emptyOptions2 = {};
function toString(value, options) {
  const settings = options || emptyOptions2;
  const includeImageAlt = typeof settings.includeImageAlt === "boolean" ? settings.includeImageAlt : true;
  const includeHtml = typeof settings.includeHtml === "boolean" ? settings.includeHtml : true;
  return one2(value, includeImageAlt, includeHtml);
}
function one2(value, includeImageAlt, includeHtml) {
  if (node(value)) {
    if ("value" in value) {
      return value.type === "html" && !includeHtml ? "" : value.value;
    }
    if (includeImageAlt && "alt" in value && value.alt) {
      return value.alt;
    }
    if ("children" in value) {
      return all(value.children, includeImageAlt, includeHtml);
    }
  }
  if (Array.isArray(value)) {
    return all(value, includeImageAlt, includeHtml);
  }
  return "";
}
function all(values, includeImageAlt, includeHtml) {
  const result = [];
  let index = -1;
  while (++index < values.length) {
    result[index] = one2(values[index], includeImageAlt, includeHtml);
  }
  return result.join("");
}
function node(value) {
  return Boolean(value && typeof value === "object");
}
// node_modules/decode-named-character-reference/index.dom.js
var element2 = document.createElement("i");
function decodeNamedCharacterReference(value) {
  const characterReference = "&" + value + ";";
  element2.innerHTML = characterReference;
  const character = element2.textContent;
  if (character.charCodeAt(character.length - 1) === 59 && value !== "semi") {
    return false;
  }
  return character === characterReference ? false : character;
}

// node_modules/micromark-util-chunked/index.js
function splice(list, start, remove, items) {
  const end = list.length;
  let chunkStart = 0;
  let parameters;
  if (start < 0) {
    start = -start > end ? 0 : end + start;
  } else {
    start = start > end ? end : start;
  }
  remove = remove > 0 ? remove : 0;
  if (items.length < 1e4) {
    parameters = Array.from(items);
    parameters.unshift(start, remove);
    list.splice(...parameters);
  } else {
    if (remove)
      list.splice(start, remove);
    while (chunkStart < items.length) {
      parameters = items.slice(chunkStart, chunkStart + 1e4);
      parameters.unshift(start, 0);
      list.splice(...parameters);
      chunkStart += 1e4;
      start += 1e4;
    }
  }
}
function push(list, items) {
  if (list.length > 0) {
    splice(list, list.length, 0, items);
    return list;
  }
  return items;
}

// node_modules/micromark-util-combine-extensions/index.js
var hasOwnProperty = {}.hasOwnProperty;
function combineExtensions(extensions) {
  const all = {};
  let index = -1;
  while (++index < extensions.length) {
    syntaxExtension(all, extensions[index]);
  }
  return all;
}
function syntaxExtension(all, extension) {
  let hook;
  for (hook in extension) {
    const maybe = hasOwnProperty.call(all, hook) ? all[hook] : undefined;
    const left = maybe || (all[hook] = {});
    const right = extension[hook];
    let code;
    if (right) {
      for (code in right) {
        if (!hasOwnProperty.call(left, code))
          left[code] = [];
        const value = right[code];
        constructs(left[code], Array.isArray(value) ? value : value ? [value] : []);
      }
    }
  }
}
function constructs(existing, list) {
  let index = -1;
  const before = [];
  while (++index < list.length) {
    (list[index].add === "after" ? existing : before).push(list[index]);
  }
  splice(existing, 0, 0, before);
}

// node_modules/micromark-util-decode-numeric-character-reference/index.js
function decodeNumericCharacterReference(value, base) {
  const code = Number.parseInt(value, base);
  if (code < 9 || code === 11 || code > 13 && code < 32 || code > 126 && code < 160 || code > 55295 && code < 57344 || code > 64975 && code < 65008 || (code & 65535) === 65535 || (code & 65535) === 65534 || code > 1114111) {
    return "�";
  }
  return String.fromCodePoint(code);
}

// node_modules/micromark-util-normalize-identifier/index.js
function normalizeIdentifier(value) {
  return value.replace(/[\t\n\r ]+/g, " ").replace(/^ | $/g, "").toLowerCase().toUpperCase();
}

// node_modules/micromark-util-character/index.js
var asciiAlpha = regexCheck(/[A-Za-z]/);
var asciiAlphanumeric = regexCheck(/[\dA-Za-z]/);
var asciiAtext = regexCheck(/[#-'*+\--9=?A-Z^-~]/);
function asciiControl(code) {
  return code !== null && (code < 32 || code === 127);
}
var asciiDigit = regexCheck(/\d/);
var asciiHexDigit = regexCheck(/[\dA-Fa-f]/);
var asciiPunctuation = regexCheck(/[!-/:-@[-`{-~]/);
function markdownLineEnding(code) {
  return code !== null && code < -2;
}
function markdownLineEndingOrSpace(code) {
  return code !== null && (code < 0 || code === 32);
}
function markdownSpace(code) {
  return code === -2 || code === -1 || code === 32;
}
var unicodePunctuation = regexCheck(/\p{P}|\p{S}/u);
var unicodeWhitespace = regexCheck(/\s/);
function regexCheck(regex) {
  return check;
  function check(code) {
    return code !== null && code > -1 && regex.test(String.fromCharCode(code));
  }
}

// node_modules/micromark-util-sanitize-uri/index.js
function normalizeUri(value) {
  const result = [];
  let index = -1;
  let start = 0;
  let skip = 0;
  while (++index < value.length) {
    const code = value.charCodeAt(index);
    let replace = "";
    if (code === 37 && asciiAlphanumeric(value.charCodeAt(index + 1)) && asciiAlphanumeric(value.charCodeAt(index + 2))) {
      skip = 2;
    } else if (code < 128) {
      if (!/[!#$&-;=?-Z_a-z~]/.test(String.fromCharCode(code))) {
        replace = String.fromCharCode(code);
      }
    } else if (code > 55295 && code < 57344) {
      const next = value.charCodeAt(index + 1);
      if (code < 56320 && next > 56319 && next < 57344) {
        replace = String.fromCharCode(code, next);
        skip = 1;
      } else {
        replace = "�";
      }
    } else {
      replace = String.fromCharCode(code);
    }
    if (replace) {
      result.push(value.slice(start, index), encodeURIComponent(replace));
      start = index + skip + 1;
      replace = "";
    }
    if (skip) {
      index += skip;
      skip = 0;
    }
  }
  return result.join("") + value.slice(start);
}

// node_modules/micromark-factory-space/index.js
function factorySpace(effects, ok, type, max) {
  const limit = max ? max - 1 : Infinity;
  let size = 0;
  return start;
  function start(code) {
    if (markdownSpace(code)) {
      effects.enter(type);
      return prefix(code);
    }
    return ok(code);
  }
  function prefix(code) {
    if (markdownSpace(code) && size++ < limit) {
      effects.consume(code);
      return prefix;
    }
    effects.exit(type);
    return ok(code);
  }
}
function factorySpaceMinMax(effects, ok, nok, type, min, max) {
  let size = 0;
  return start;
  function start(code) {
    if (max > 0 && markdownSpace(code)) {
      effects.enter(type);
      return prefix(code);
    }
    return after(code);
  }
  function prefix(code) {
    if (markdownSpace(code) && size < max) {
      effects.consume(code);
      size++;
      return prefix;
    }
    effects.exit(type);
    return after(code);
  }
  function after(code) {
    return size >= min ? ok(code) : nok(code);
  }
}

// node_modules/micromark/lib/initialize/content.js
var content = {
  tokenize: initializeContent
};
function initializeContent(effects) {
  const contentStart = effects.attempt(this.parser.constructs.contentInitial, afterContentStartConstruct, paragraphInitial);
  let previous;
  return contentStart;
  function afterContentStartConstruct(code) {
    if (code === null) {
      effects.consume(code);
      return;
    }
    effects.enter("lineEnding");
    effects.consume(code);
    effects.exit("lineEnding");
    return factorySpace(effects, contentStart, "linePrefix");
  }
  function paragraphInitial(code) {
    effects.enter("paragraph");
    return lineStart(code);
  }
  function lineStart(code) {
    const token = effects.enter("chunkText", {
      contentType: "text",
      previous
    });
    if (previous) {
      previous.next = token;
    }
    previous = token;
    return data(code);
  }
  function data(code) {
    if (code === null) {
      effects.exit("chunkText");
      effects.exit("paragraph");
      effects.consume(code);
      return;
    }
    if (markdownLineEnding(code)) {
      effects.consume(code);
      effects.exit("chunkText");
      return lineStart;
    }
    effects.consume(code);
    return data;
  }
}

// node_modules/micromark-util-edit-map/index.js
class EditMap {
  constructor() {
    this.index = new Map;
    this.map = [];
  }
  add(index, remove, add) {
    addImplementation(this, index, remove, add, false);
  }
  addBefore(index, remove, add) {
    addImplementation(this, index, remove, add, true);
  }
  consume(events) {
    this.map.sort(function(a, b) {
      return a[0] - b[0];
    });
    if (this.map.length === 0) {
      return;
    }
    let index = this.map.length;
    const vecs = [];
    while (index > 0) {
      index -= 1;
      vecs.push(events.slice(this.map[index][0] + this.map[index][1]), this.map[index][2]);
      events.length = this.map[index][0];
    }
    vecs.push(events.slice());
    events.length = 0;
    let slice = vecs.pop();
    while (slice) {
      for (const element of slice) {
        events.push(element);
      }
      slice = vecs.pop();
    }
    this.map.length = 0;
    this.index.clear();
  }
}
function addImplementation(editMap, at, remove, add, before) {
  if (remove === 0 && add.length === 0) {
    return;
  }
  const existing = editMap.index.get(at);
  if (existing) {
    existing[1] += remove;
    if (before) {
      add.push(...existing[2]);
      existing[2] = add;
    } else {
      existing[2].push(...add);
    }
    return;
  }
  const change = [at, remove, add];
  editMap.map.push(change);
  editMap.index.set(at, change);
}

// node_modules/micromark/lib/initialize/document.js
var document2 = {
  tokenize: initializeDocument
};
var containerConstruct = {
  tokenize: tokenizeContainer
};
function initializeDocument(effects) {
  const self2 = this;
  const stack = [];
  let continued = 0;
  let childFlow;
  let childToken;
  let lineStartOffset;
  return start;
  function start(code) {
    if (continued < stack.length) {
      const item = stack[continued];
      self2.containerState = item[1];
      return effects.attempt(item[0].continuation, documentContinue, checkNewContainers)(code);
    }
    return checkNewContainers(code);
  }
  function documentContinue(code) {
    continued++;
    if (self2.containerState._closeFlow) {
      self2.containerState._closeFlow = undefined;
      if (childFlow) {
        closeFlow();
      }
      const indexBeforeExits = self2.events.length;
      let indexBeforeFlow = indexBeforeExits;
      let point;
      while (indexBeforeFlow--) {
        if (self2.events[indexBeforeFlow][0] === "exit" && self2.events[indexBeforeFlow][1].type === "chunkFlow") {
          point = self2.events[indexBeforeFlow][1].end;
          break;
        }
      }
      exitContainers(continued);
      let index = indexBeforeExits;
      while (index < self2.events.length) {
        self2.events[index][1].end = {
          ...point
        };
        index++;
      }
      const editMap = new EditMap;
      editMap.add(indexBeforeFlow + 1, 0, self2.events.slice(indexBeforeExits));
      editMap.add(indexBeforeExits, index - indexBeforeExits, []);
      editMap.consume(self2.events);
      return checkNewContainers(code);
    }
    return start(code);
  }
  function checkNewContainers(code) {
    if (continued === stack.length) {
      if (!childFlow) {
        return documentContinued(code);
      }
      if (childFlow.currentConstruct && childFlow.currentConstruct.concrete) {
        return flowStart(code);
      }
      self2.interrupt = Boolean(childFlow.currentConstruct && !childFlow._gfmTableDynamicInterruptHack);
    }
    self2.containerState = {};
    return effects.check(containerConstruct, thereIsANewContainer, thereIsNoNewContainer)(code);
  }
  function thereIsANewContainer(code) {
    if (childFlow) {
      closeFlow();
    }
    exitContainers(continued);
    return documentContinued(code);
  }
  function thereIsNoNewContainer(code) {
    self2.parser.lazy[self2.now().line] = continued !== stack.length;
    lineStartOffset = self2.now().offset;
    return flowStart(code);
  }
  function documentContinued(code) {
    self2.containerState = {};
    return effects.attempt(containerConstruct, containerContinue, flowStart)(code);
  }
  function containerContinue(code) {
    continued++;
    stack.push([self2.currentConstruct, self2.containerState]);
    return documentContinued(code);
  }
  function flowStart(code) {
    if (code === null) {
      if (childFlow) {
        closeFlow();
      }
      exitContainers(0);
      effects.consume(code);
      return;
    }
    childFlow = childFlow || self2.parser.flow(self2.now());
    effects.enter("chunkFlow", {
      _tokenizer: childFlow,
      contentType: "flow",
      previous: childToken
    });
    return flowContinue(code);
  }
  function flowContinue(code) {
    if (code === null) {
      writeToChild(effects.exit("chunkFlow"), true);
      exitContainers(0);
      effects.consume(code);
      return;
    }
    if (markdownLineEnding(code)) {
      effects.consume(code);
      writeToChild(effects.exit("chunkFlow"));
      continued = 0;
      self2.interrupt = undefined;
      return start;
    }
    effects.consume(code);
    return flowContinue;
  }
  function writeToChild(token, endOfFile) {
    const stream = self2.sliceStream(token);
    if (endOfFile) {
      stream.push(null);
    }
    token.previous = childToken;
    if (childToken) {
      childToken.next = token;
    }
    childToken = token;
    childFlow.defineSkip(token.start);
    childFlow.write(stream);
    if (self2.parser.lazy[token.start.line]) {
      let index = childFlow.events.length;
      while (index--) {
        if (childFlow.events[index][1].start.offset < lineStartOffset && (!childFlow.events[index][1].end || childFlow.events[index][1].end.offset > lineStartOffset)) {
          return;
        }
      }
      const indexBeforeExits = self2.events.length;
      let indexBeforeFlow = indexBeforeExits;
      let seen;
      let point;
      while (indexBeforeFlow--) {
        if (self2.events[indexBeforeFlow][0] === "exit" && self2.events[indexBeforeFlow][1].type === "chunkFlow") {
          if (seen) {
            point = self2.events[indexBeforeFlow][1].end;
            break;
          }
          seen = true;
        }
      }
      exitContainers(continued);
      index = indexBeforeExits;
      while (index < self2.events.length) {
        self2.events[index][1].end = {
          ...point
        };
        index++;
      }
      const editMap = new EditMap;
      editMap.add(indexBeforeFlow + 1, 0, self2.events.slice(indexBeforeExits));
      editMap.add(indexBeforeExits, index - indexBeforeExits, []);
      editMap.consume(self2.events);
    }
  }
  function exitContainers(size) {
    let index = stack.length;
    while (index-- > size) {
      const entry = stack[index];
      self2.containerState = entry[1];
      entry[0].exit.call(self2, effects);
    }
    stack.length = size;
  }
  function closeFlow() {
    childFlow.write([null]);
    childToken = undefined;
    childFlow = undefined;
    self2.containerState._closeFlow = undefined;
  }
}
function tokenizeContainer(effects, ok, nok) {
  return factorySpace(effects, effects.attempt(this.parser.constructs.document, ok, nok), "linePrefix", this.parser.constructs.disable.null.includes("codeIndented") ? undefined : 4);
}

// node_modules/micromark-util-classify-character/index.js
function classifyCharacter(code) {
  if (code === null || markdownLineEndingOrSpace(code) || unicodeWhitespace(code)) {
    return 1;
  }
  if (unicodePunctuation(code)) {
    return 2;
  }
}

// node_modules/micromark-util-resolve-all/index.js
function resolveAll(constructs, events, context) {
  const called = [];
  let index = -1;
  while (++index < constructs.length) {
    const resolve = constructs[index].resolveAll;
    if (resolve && !called.includes(resolve)) {
      events = resolve(events, context);
      called.push(resolve);
    }
  }
  return events;
}

// node_modules/micromark-core-commonmark/lib/attention.js
var attention = {
  name: "attention",
  resolveAll: resolveAllAttention,
  tokenize: tokenizeAttention
};
function resolveAllAttention(events, context) {
  let index = -1;
  let nextEvents;
  while (++index < events.length) {
    if (events[index][0] === "enter" && events[index][1].type === "attentionSequence" && events[index][1]._close) {
      let open = index;
      while (open--) {
        if (events[open][0] === "exit" && events[open][1].type === "attentionSequence" && events[open][1]._open && context.sliceSerialize(events[open][1]).charCodeAt(0) === context.sliceSerialize(events[index][1]).charCodeAt(0)) {
          if ((events[open][1]._close || events[index][1]._open) && (events[index][1].end.offset - events[index][1].start.offset) % 3 && !((events[open][1].end.offset - events[open][1].start.offset + events[index][1].end.offset - events[index][1].start.offset) % 3)) {
            continue;
          }
          const use = events[open][1].end.offset - events[open][1].start.offset > 1 && events[index][1].end.offset - events[index][1].start.offset > 1 ? 2 : 1;
          const start = {
            ...events[open][1].end
          };
          const end = {
            ...events[index][1].start
          };
          movePoint(start, -use);
          movePoint(end, use);
          const openingSequence = {
            type: use > 1 ? "strongSequence" : "emphasisSequence",
            start,
            end: {
              ...events[open][1].end
            }
          };
          const closingSequence = {
            type: use > 1 ? "strongSequence" : "emphasisSequence",
            start: {
              ...events[index][1].start
            },
            end
          };
          const text = {
            type: use > 1 ? "strongText" : "emphasisText",
            start: {
              ...events[open][1].end
            },
            end: {
              ...events[index][1].start
            }
          };
          const group = {
            type: use > 1 ? "strong" : "emphasis",
            start: {
              ...openingSequence.start
            },
            end: {
              ...closingSequence.end
            }
          };
          events[open][1].end = {
            ...openingSequence.start
          };
          events[index][1].start = {
            ...closingSequence.end
          };
          nextEvents = [];
          if (events[open][1].end.offset - events[open][1].start.offset) {
            nextEvents = push(nextEvents, [["enter", events[open][1], context], ["exit", events[open][1], context]]);
          }
          nextEvents = push(nextEvents, [["enter", group, context], ["enter", openingSequence, context], ["exit", openingSequence, context], ["enter", text, context]]);
          nextEvents = push(nextEvents, resolveAll(context.parser.constructs.insideSpan.null, events.slice(open + 1, index), context));
          nextEvents = push(nextEvents, [["exit", text, context], ["enter", closingSequence, context], ["exit", closingSequence, context], ["exit", group, context]]);
          let offset = 0;
          if (events[index][1].end.offset - events[index][1].start.offset) {
            offset = 2;
            nextEvents = push(nextEvents, [["enter", events[index][1], context], ["exit", events[index][1], context]]);
          }
          splice(events, open - 1, index - open + 3, nextEvents);
          index = open + nextEvents.length - offset - 2;
          break;
        }
      }
    }
  }
  index = -1;
  while (++index < events.length) {
    if (events[index][1].type === "attentionSequence") {
      events[index][1].type = "data";
    }
  }
  return events;
}
function tokenizeAttention(effects, ok) {
  const attentionMarkers = this.parser.constructs.attentionMarkers.null;
  const previous = this.previous;
  const before = classifyCharacter(previous);
  let marker;
  return start;
  function start(code) {
    marker = code;
    effects.enter("attentionSequence");
    return inside(code);
  }
  function inside(code) {
    if (code === marker) {
      effects.consume(code);
      return inside;
    }
    const token = effects.exit("attentionSequence");
    const after = classifyCharacter(code);
    const open = !after || after === 2 && before || attentionMarkers.includes(code) && code !== 42 && code !== 95;
    const close = !before || before === 2 && after || attentionMarkers.includes(previous) && previous !== 42 && previous !== 95;
    token._open = Boolean(marker === 42 ? open : open && (before || !close));
    token._close = Boolean(marker === 42 ? close : close && (after || !open));
    return ok(code);
  }
}
function movePoint(point, offset) {
  point.column += offset;
  point.offset += offset;
  point._bufferIndex += offset;
}
// node_modules/micromark-core-commonmark/lib/autolink.js
var autolink = {
  name: "autolink",
  tokenize: tokenizeAutolink
};
function tokenizeAutolink(effects, ok, nok) {
  let size = 0;
  return start;
  function start(code) {
    effects.enter("autolink");
    effects.enter("autolinkMarker");
    effects.consume(code);
    effects.exit("autolinkMarker");
    effects.enter("autolinkProtocol");
    return open;
  }
  function open(code) {
    if (asciiAlpha(code)) {
      effects.consume(code);
      return schemeOrEmailAtext;
    }
    if (code === 64) {
      return nok(code);
    }
    return emailAtext(code);
  }
  function schemeOrEmailAtext(code) {
    if (code === 43 || code === 45 || code === 46 || asciiAlphanumeric(code)) {
      size = 1;
      return schemeInsideOrEmailAtext(code);
    }
    return emailAtext(code);
  }
  function schemeInsideOrEmailAtext(code) {
    if (code === 58) {
      effects.consume(code);
      size = 0;
      return urlInside;
    }
    if ((code === 43 || code === 45 || code === 46 || asciiAlphanumeric(code)) && size++ < 32) {
      effects.consume(code);
      return schemeInsideOrEmailAtext;
    }
    size = 0;
    return emailAtext(code);
  }
  function urlInside(code) {
    if (code === 62) {
      effects.exit("autolinkProtocol");
      effects.enter("autolinkMarker");
      effects.consume(code);
      effects.exit("autolinkMarker");
      effects.exit("autolink");
      return ok;
    }
    if (code === null || code === 32 || code === 60 || asciiControl(code)) {
      return nok(code);
    }
    effects.consume(code);
    return urlInside;
  }
  function emailAtext(code) {
    if (code === 64) {
      effects.consume(code);
      return emailAtSignOrDot;
    }
    if (asciiAtext(code)) {
      effects.consume(code);
      return emailAtext;
    }
    return nok(code);
  }
  function emailAtSignOrDot(code) {
    return asciiAlphanumeric(code) ? emailLabel(code) : nok(code);
  }
  function emailLabel(code) {
    if (code === 46) {
      effects.consume(code);
      size = 0;
      return emailAtSignOrDot;
    }
    if (code === 62) {
      effects.exit("autolinkProtocol").type = "autolinkEmail";
      effects.enter("autolinkMarker");
      effects.consume(code);
      effects.exit("autolinkMarker");
      effects.exit("autolink");
      return ok;
    }
    return emailValue(code);
  }
  function emailValue(code) {
    if ((code === 45 || asciiAlphanumeric(code)) && size++ < 63) {
      const next = code === 45 ? emailValue : emailLabel;
      effects.consume(code);
      return next;
    }
    return nok(code);
  }
}
// node_modules/micromark-core-commonmark/lib/blank-line.js
var blankLine = {
  partial: true,
  tokenize: tokenizeBlankLine
};
function tokenizeBlankLine(effects, ok, nok) {
  return start;
  function start(code) {
    return markdownSpace(code) ? factorySpace(effects, after, "linePrefix")(code) : after(code);
  }
  function after(code) {
    return code === null || markdownLineEnding(code) ? ok(code) : nok(code);
  }
}
// node_modules/micromark-core-commonmark/lib/block-quote.js
var blockQuote = {
  continuation: {
    tokenize: tokenizeBlockQuoteContinuation
  },
  exit,
  name: "blockQuote",
  tokenize: tokenizeBlockQuoteStart
};
function tokenizeBlockQuoteStart(effects, ok, nok) {
  const self2 = this;
  return start;
  function start(code) {
    if (code === 62) {
      const state = self2.containerState;
      if (!state.open) {
        effects.enter("blockQuote", {
          _container: true
        });
        state.open = true;
      }
      effects.enter("blockQuotePrefix");
      effects.enter("blockQuoteMarker");
      effects.consume(code);
      effects.exit("blockQuoteMarker");
      return after;
    }
    return nok(code);
  }
  function after(code) {
    if (markdownSpace(code)) {
      effects.enter("blockQuotePrefixWhitespace");
      effects.consume(code);
      effects.exit("blockQuotePrefixWhitespace");
      effects.exit("blockQuotePrefix");
      return ok;
    }
    effects.exit("blockQuotePrefix");
    return ok(code);
  }
}
function tokenizeBlockQuoteContinuation(effects, ok, nok) {
  const self2 = this;
  return contStart;
  function contStart(code) {
    if (markdownSpace(code)) {
      return factorySpace(effects, contBefore, "linePrefix", self2.parser.constructs.disable.null.includes("codeIndented") ? undefined : 4)(code);
    }
    return contBefore(code);
  }
  function contBefore(code) {
    return effects.attempt(blockQuote, ok, nok)(code);
  }
}
function exit(effects) {
  effects.exit("blockQuote");
}
// node_modules/micromark-core-commonmark/lib/character-escape.js
var characterEscape = {
  name: "characterEscape",
  tokenize: tokenizeCharacterEscape
};
function tokenizeCharacterEscape(effects, ok, nok) {
  return start;
  function start(code) {
    effects.enter("characterEscape");
    effects.enter("escapeMarker");
    effects.consume(code);
    effects.exit("escapeMarker");
    return inside;
  }
  function inside(code) {
    if (asciiPunctuation(code)) {
      effects.enter("characterEscapeValue");
      effects.consume(code);
      effects.exit("characterEscapeValue");
      effects.exit("characterEscape");
      return ok;
    }
    return nok(code);
  }
}
// node_modules/micromark-core-commonmark/lib/character-reference.js
var characterReference = {
  name: "characterReference",
  tokenize: tokenizeCharacterReference
};
function tokenizeCharacterReference(effects, ok, nok) {
  const self2 = this;
  let size = 0;
  let max;
  let test;
  return start;
  function start(code) {
    effects.enter("characterReference");
    effects.enter("characterReferenceMarker");
    effects.consume(code);
    effects.exit("characterReferenceMarker");
    return open;
  }
  function open(code) {
    if (code === 35) {
      effects.enter("characterReferenceMarkerNumeric");
      effects.consume(code);
      effects.exit("characterReferenceMarkerNumeric");
      return numeric;
    }
    effects.enter("characterReferenceValue");
    max = 31;
    test = asciiAlphanumeric;
    return value(code);
  }
  function numeric(code) {
    if (code === 88 || code === 120) {
      effects.enter("characterReferenceMarkerHexadecimal");
      effects.consume(code);
      effects.exit("characterReferenceMarkerHexadecimal");
      effects.enter("characterReferenceValue");
      max = 6;
      test = asciiHexDigit;
      return value;
    }
    effects.enter("characterReferenceValue");
    max = 7;
    test = asciiDigit;
    return value(code);
  }
  function value(code) {
    if (code === 59 && size) {
      const token = effects.exit("characterReferenceValue");
      if (test === asciiAlphanumeric && !decodeNamedCharacterReference(self2.sliceSerialize(token))) {
        return nok(code);
      }
      effects.enter("characterReferenceMarker");
      effects.consume(code);
      effects.exit("characterReferenceMarker");
      effects.exit("characterReference");
      return ok;
    }
    if (test(code) && size++ < max) {
      effects.consume(code);
      return value;
    }
    return nok(code);
  }
}
// node_modules/micromark-core-commonmark/lib/partial-non-lazy-continuation.js
var nonLazyContinuation = {
  partial: true,
  tokenize: tokenizeNonLazyContinuation
};
function tokenizeNonLazyContinuation(effects, ok, nok) {
  const self2 = this;
  return start;
  function start(code) {
    if (code === null) {
      return nok(code);
    }
    effects.enter("lineEnding");
    effects.consume(code);
    effects.exit("lineEnding");
    return after;
  }
  function after(code) {
    return self2.parser.lazy[self2.now().line] ? nok(code) : ok(code);
  }
}

// node_modules/micromark-core-commonmark/lib/code-fenced.js
var codeFenced = {
  concrete: true,
  name: "codeFenced",
  tokenize: tokenizeCodeFenced
};
function tokenizeCodeFenced(effects, ok, nok) {
  const self2 = this;
  const closeStart = {
    partial: true,
    tokenize: tokenizeCloseStart
  };
  let initialPrefix = 0;
  let sizeOpen = 0;
  let marker;
  return start;
  function start(code) {
    return beforeSequenceOpen(code);
  }
  function beforeSequenceOpen(code) {
    const tail = self2.events[self2.events.length - 1];
    initialPrefix = tail && tail[1].type === "linePrefix" ? tail[2].sliceSerialize(tail[1], true).length : 0;
    marker = code;
    effects.enter("codeFenced");
    effects.enter("codeFencedFence");
    effects.enter("codeFencedFenceSequence");
    return sequenceOpen(code);
  }
  function sequenceOpen(code) {
    if (code === marker) {
      sizeOpen++;
      effects.consume(code);
      return sequenceOpen;
    }
    if (sizeOpen < 3) {
      return nok(code);
    }
    effects.exit("codeFencedFenceSequence");
    return markdownSpace(code) ? factorySpace(effects, infoBefore, "whitespace")(code) : infoBefore(code);
  }
  function infoBefore(code) {
    if (code === null || markdownLineEnding(code)) {
      effects.exit("codeFencedFence");
      return self2.interrupt ? ok(code) : effects.check(nonLazyContinuation, atNonLazyBreak, after)(code);
    }
    effects.enter("codeFencedFenceInfo");
    effects.enter("chunkString", {
      contentType: "string"
    });
    return info(code);
  }
  function info(code) {
    if (code === null || markdownLineEnding(code)) {
      effects.exit("chunkString");
      effects.exit("codeFencedFenceInfo");
      return infoBefore(code);
    }
    if (markdownSpace(code)) {
      effects.exit("chunkString");
      effects.exit("codeFencedFenceInfo");
      return factorySpace(effects, metaBefore, "whitespace")(code);
    }
    if (code === 96 && code === marker) {
      return nok(code);
    }
    effects.consume(code);
    return info;
  }
  function metaBefore(code) {
    if (code === null || markdownLineEnding(code)) {
      return infoBefore(code);
    }
    effects.enter("codeFencedFenceMeta");
    effects.enter("chunkString", {
      contentType: "string"
    });
    return meta(code);
  }
  function meta(code) {
    if (code === null || markdownLineEnding(code)) {
      effects.exit("chunkString");
      effects.exit("codeFencedFenceMeta");
      return infoBefore(code);
    }
    if (code === 96 && code === marker) {
      return nok(code);
    }
    effects.consume(code);
    return meta;
  }
  function atNonLazyBreak(code) {
    return effects.attempt(closeStart, after, contentBefore)(code);
  }
  function contentBefore(code) {
    effects.enter("lineEnding");
    effects.consume(code);
    effects.exit("lineEnding");
    return contentStart;
  }
  function contentStart(code) {
    return initialPrefix > 0 && markdownSpace(code) ? factorySpace(effects, beforeContentChunk, "linePrefix", initialPrefix + 1)(code) : beforeContentChunk(code);
  }
  function beforeContentChunk(code) {
    if (code === null || markdownLineEnding(code)) {
      return effects.check(nonLazyContinuation, atNonLazyBreak, after)(code);
    }
    effects.enter("codeFlowValue");
    return contentChunk(code);
  }
  function contentChunk(code) {
    if (code === null || markdownLineEnding(code)) {
      effects.exit("codeFlowValue");
      return beforeContentChunk(code);
    }
    effects.consume(code);
    return contentChunk;
  }
  function after(code) {
    effects.exit("codeFenced");
    return ok(code);
  }
  function tokenizeCloseStart(effects, ok, nok) {
    let size = 0;
    return startBefore;
    function startBefore(code) {
      effects.enter("lineEnding");
      effects.consume(code);
      effects.exit("lineEnding");
      return start;
    }
    function start(code) {
      effects.enter("codeFencedFence");
      return markdownSpace(code) ? factorySpace(effects, beforeSequenceClose, "linePrefix", self2.parser.constructs.disable.null.includes("codeIndented") ? undefined : 4)(code) : beforeSequenceClose(code);
    }
    function beforeSequenceClose(code) {
      if (code === marker) {
        effects.enter("codeFencedFenceSequence");
        return sequenceClose(code);
      }
      return nok(code);
    }
    function sequenceClose(code) {
      if (code === marker) {
        size++;
        effects.consume(code);
        return sequenceClose;
      }
      if (size >= sizeOpen) {
        effects.exit("codeFencedFenceSequence");
        return markdownSpace(code) ? factorySpace(effects, sequenceCloseAfter, "whitespace")(code) : sequenceCloseAfter(code);
      }
      return nok(code);
    }
    function sequenceCloseAfter(code) {
      if (code === null || markdownLineEnding(code)) {
        effects.exit("codeFencedFence");
        return ok(code);
      }
      return nok(code);
    }
  }
}
// node_modules/micromark-core-commonmark/lib/code-indented.js
var codeIndented = {
  name: "codeIndented",
  tokenize: tokenizeCodeIndented
};
var furtherStart = {
  partial: true,
  tokenize: tokenizeFurtherStart
};
function tokenizeCodeIndented(effects, ok, nok) {
  return start;
  function start(code) {
    effects.enter("codeIndented");
    return factorySpaceMinMax(effects, atBreak, nok, "linePrefix", 4, 4)(code);
  }
  function atBreak(code) {
    if (code === null) {
      return after(code);
    }
    if (markdownLineEnding(code)) {
      return effects.attempt(furtherStart, atBreak, after)(code);
    }
    effects.enter("codeFlowValue");
    return inside(code);
  }
  function inside(code) {
    if (code === null || markdownLineEnding(code)) {
      effects.exit("codeFlowValue");
      return atBreak(code);
    }
    effects.consume(code);
    return inside;
  }
  function after(code) {
    effects.exit("codeIndented");
    return ok(code);
  }
}
function tokenizeFurtherStart(effects, ok, nok) {
  const self2 = this;
  return furtherStart;
  function furtherStart(code) {
    if (self2.parser.lazy[self2.now().line]) {
      return nok(code);
    }
    if (markdownLineEnding(code)) {
      effects.enter("lineEnding");
      effects.consume(code);
      effects.exit("lineEnding");
      return furtherStart;
    }
    return factorySpaceMinMax(effects, ok, onNotEnoughPrefix, "linePrefix", 4, 4)(code);
  }
  function onNotEnoughPrefix(code) {
    return markdownLineEnding(code) ? furtherStart(code) : nok(code);
  }
}
// node_modules/micromark-core-commonmark/lib/code-text.js
var codeText = {
  name: "codeText",
  previous,
  resolve: resolveCodeText,
  tokenize: tokenizeCodeText
};
function resolveCodeText(events) {
  let tailExitIndex = events.length - 4;
  let headEnterIndex = 3;
  let index;
  let enter;
  if ((events[headEnterIndex][1].type === "lineEnding" || events[headEnterIndex][1].type === "space") && (events[tailExitIndex][1].type === "lineEnding" || events[tailExitIndex][1].type === "space")) {
    index = headEnterIndex;
    while (++index < tailExitIndex) {
      if (events[index][1].type === "codeTextData") {
        events[headEnterIndex][1].type = "codeTextPadding";
        events[tailExitIndex][1].type = "codeTextPadding";
        headEnterIndex += 2;
        tailExitIndex -= 2;
        break;
      }
    }
  }
  index = headEnterIndex - 1;
  tailExitIndex++;
  while (++index <= tailExitIndex) {
    if (enter === undefined) {
      if (index !== tailExitIndex && events[index][1].type !== "lineEnding") {
        enter = index;
      }
    } else if (index === tailExitIndex || events[index][1].type === "lineEnding") {
      events[enter][1].type = "codeTextData";
      if (index !== enter + 2) {
        events[enter][1].end = events[index - 1][1].end;
        events.splice(enter + 2, index - enter - 2);
        tailExitIndex -= index - enter - 2;
        index = enter + 2;
      }
      enter = undefined;
    }
  }
  return events;
}
function previous(code) {
  return code !== 96 || this.events[this.events.length - 1][1].type === "characterEscape";
}
function tokenizeCodeText(effects, ok, nok) {
  const self2 = this;
  let sizeOpen = 0;
  let size;
  let token;
  return start;
  function start(code) {
    effects.enter("codeText");
    effects.enter("codeTextSequence");
    return sequenceOpen(code);
  }
  function sequenceOpen(code) {
    if (code === 96) {
      effects.consume(code);
      sizeOpen++;
      return sequenceOpen;
    }
    effects.exit("codeTextSequence");
    return between(code);
  }
  function between(code) {
    if (code === null) {
      return nok(code);
    }
    if (code === 32) {
      effects.enter("space");
      effects.consume(code);
      effects.exit("space");
      return between;
    }
    if (code === 96) {
      token = effects.enter("codeTextSequence");
      size = 0;
      return sequenceClose(code);
    }
    if (markdownLineEnding(code)) {
      effects.enter("lineEnding");
      effects.consume(code);
      effects.exit("lineEnding");
      return between;
    }
    effects.enter("codeTextData");
    return data(code);
  }
  function data(code) {
    if (code === null || code === 32 || code === 96 || markdownLineEnding(code)) {
      effects.exit("codeTextData");
      return between(code);
    }
    effects.consume(code);
    return data;
  }
  function sequenceClose(code) {
    if (code === 96) {
      effects.consume(code);
      size++;
      return sequenceClose;
    }
    if (size === sizeOpen) {
      effects.exit("codeTextSequence");
      effects.exit("codeText");
      return ok(code);
    }
    token.type = "codeTextData";
    return data(code);
  }
}
// node_modules/micromark-util-subtokenize/lib/splice-buffer.js
class SpliceBuffer {
  constructor(initial) {
    this.left = initial ? [...initial] : [];
    this.right = [];
  }
  get(index) {
    if (index < 0 || index >= this.left.length + this.right.length) {
      throw new RangeError("Cannot access index `" + index + "` in a splice buffer of size `" + (this.left.length + this.right.length) + "`");
    }
    if (index < this.left.length)
      return this.left[index];
    return this.right[this.right.length - index + this.left.length - 1];
  }
  get length() {
    return this.left.length + this.right.length;
  }
  shift() {
    this.setCursor(0);
    return this.right.pop();
  }
  slice(start, end) {
    const stop = end === null || end === undefined ? Number.POSITIVE_INFINITY : end;
    if (stop < this.left.length) {
      return this.left.slice(start, stop);
    }
    if (start > this.left.length) {
      return this.right.slice(this.right.length - stop + this.left.length, this.right.length - start + this.left.length).reverse();
    }
    return this.left.slice(start).concat(this.right.slice(this.right.length - stop + this.left.length).reverse());
  }
  splice(start, deleteCount, items) {
    const count = deleteCount || 0;
    this.setCursor(Math.trunc(start));
    const removed = this.right.splice(this.right.length - count, Number.POSITIVE_INFINITY);
    if (items)
      chunkedPush(this.left, items);
    return removed.reverse();
  }
  pop() {
    this.setCursor(Number.POSITIVE_INFINITY);
    return this.left.pop();
  }
  push(item) {
    this.setCursor(Number.POSITIVE_INFINITY);
    this.left.push(item);
  }
  pushMany(items) {
    this.setCursor(Number.POSITIVE_INFINITY);
    chunkedPush(this.left, items);
  }
  unshift(item) {
    this.setCursor(0);
    this.right.push(item);
  }
  unshiftMany(items) {
    this.setCursor(0);
    chunkedPush(this.right, items.reverse());
  }
  setCursor(n) {
    if (n === this.left.length || n > this.left.length && this.right.length === 0 || n < 0 && this.left.length === 0)
      return;
    if (n < this.left.length) {
      const removed = this.left.splice(n, Number.POSITIVE_INFINITY);
      chunkedPush(this.right, removed.reverse());
    } else {
      const removed = this.right.splice(this.left.length + this.right.length - n, Number.POSITIVE_INFINITY);
      chunkedPush(this.left, removed.reverse());
    }
  }
}
function chunkedPush(list, right) {
  let chunkStart = 0;
  if (right.length < 1e4) {
    list.push(...right);
  } else {
    while (chunkStart < right.length) {
      list.push(...right.slice(chunkStart, chunkStart + 1e4));
      chunkStart += 1e4;
    }
  }
}

// node_modules/micromark-util-subtokenize/index.js
function subtokenize(eventsArray) {
  const jumps = {};
  let index = -1;
  let event;
  let lineIndex;
  let otherIndex;
  let otherEvent;
  let parameters;
  let subevents;
  let more;
  const events = new SpliceBuffer(eventsArray);
  while (++index < events.length) {
    while (index in jumps) {
      index = jumps[index];
    }
    event = events.get(index);
    if (index && event[1].type === "chunkFlow" && events.get(index - 1)[1].type === "listItemPrefix") {
      subevents = event[1]._tokenizer.events;
      otherIndex = 0;
      if (otherIndex < subevents.length && subevents[otherIndex][1].type === "lineEndingBlank") {
        otherIndex += 2;
      }
      if (otherIndex < subevents.length && subevents[otherIndex][1].type === "content") {
        while (++otherIndex < subevents.length) {
          if (subevents[otherIndex][1].type === "content") {
            break;
          }
          if (subevents[otherIndex][1].type === "chunkText") {
            subevents[otherIndex][1]._isInFirstContentOfListItem = true;
            otherIndex++;
          }
        }
      }
    }
    if (event[0] === "enter") {
      if (event[1].contentType) {
        Object.assign(jumps, subcontent(events, index));
        index = jumps[index];
        more = true;
      }
    } else if (event[1]._container) {
      otherIndex = index;
      lineIndex = undefined;
      while (otherIndex--) {
        otherEvent = events.get(otherIndex);
        if (otherEvent[1].type === "lineEnding" || otherEvent[1].type === "lineEndingBlank") {
          if (otherEvent[0] === "enter") {
            if (lineIndex) {
              events.get(lineIndex)[1].type = "lineEndingBlank";
            }
            otherEvent[1].type = "lineEnding";
            lineIndex = otherIndex;
          }
        } else if (otherEvent[1].type === "linePrefix" || otherEvent[1].type === "listItemIndent") {} else {
          break;
        }
      }
      if (lineIndex) {
        event[1].end = {
          ...events.get(lineIndex)[1].start
        };
        parameters = events.slice(lineIndex, index);
        parameters.unshift(event);
        events.splice(lineIndex, index - lineIndex + 1, parameters);
      }
    }
  }
  splice(eventsArray, 0, Number.POSITIVE_INFINITY, events.slice(0));
  return !more;
}
function subcontent(events, eventIndex) {
  const token = events.get(eventIndex)[1];
  const context = events.get(eventIndex)[2];
  let startPosition = eventIndex - 1;
  const startPositions = [];
  let tokenizer = token._tokenizer;
  if (!tokenizer) {
    tokenizer = context.parser[token.contentType](token.start);
    if (token._contentTypeTextTrailing) {
      tokenizer._contentTypeTextTrailing = true;
    }
  }
  const childEvents = tokenizer.events;
  const jumps = [];
  const gaps = {};
  let stream;
  let previous;
  let index = -1;
  let current = token;
  let adjust = 0;
  let start = 0;
  const breaks = [start];
  while (current) {
    while (events.get(++startPosition)[1] !== current) {}
    startPositions.push(startPosition);
    if (!current._tokenizer) {
      stream = context.sliceStream(current);
      if (!current.next) {
        stream.push(null);
      }
      if (previous) {
        tokenizer.defineSkip(current.start);
      }
      if (current._isInFirstContentOfListItem) {
        tokenizer._gfmTasklistFirstContentOfListItem = true;
      }
      tokenizer.write(stream);
      if (current._isInFirstContentOfListItem) {
        tokenizer._gfmTasklistFirstContentOfListItem = undefined;
      }
    }
    previous = current;
    current = current.next;
  }
  current = token;
  while (++index < childEvents.length) {
    if (childEvents[index][0] === "exit" && childEvents[index - 1][0] === "enter" && childEvents[index][1].type === childEvents[index - 1][1].type && childEvents[index][1].start.line !== childEvents[index][1].end.line) {
      start = index + 1;
      breaks.push(start);
      current._tokenizer = undefined;
      current.previous = undefined;
      current = current.next;
    }
  }
  tokenizer.events = [];
  if (current) {
    current._tokenizer = undefined;
    current.previous = undefined;
  } else {
    breaks.pop();
  }
  index = breaks.length;
  while (index--) {
    const slice = childEvents.slice(breaks[index], breaks[index + 1]);
    const start = startPositions.pop();
    jumps.push([start, start + slice.length - 1]);
    events.splice(start, 2, slice);
  }
  jumps.reverse();
  index = -1;
  while (++index < jumps.length) {
    gaps[adjust + jumps[index][0]] = adjust + jumps[index][1];
    adjust += jumps[index][1] - jumps[index][0] - 1;
  }
  return gaps;
}

// node_modules/micromark-core-commonmark/lib/content.js
var content2 = {
  resolve: resolveContent,
  tokenize: tokenizeContent
};
var continuationConstruct = {
  partial: true,
  tokenize: tokenizeContinuation
};
function resolveContent(events) {
  subtokenize(events);
  return events;
}
function tokenizeContent(effects, ok) {
  let previous;
  return chunkStart;
  function chunkStart(code) {
    effects.enter("content");
    previous = effects.enter("chunkContent", {
      contentType: "content"
    });
    return chunkInside(code);
  }
  function chunkInside(code) {
    if (code === null) {
      return contentEnd(code);
    }
    if (markdownLineEnding(code)) {
      return effects.check(continuationConstruct, contentContinue, contentEnd)(code);
    }
    effects.consume(code);
    return chunkInside;
  }
  function contentEnd(code) {
    effects.exit("chunkContent");
    effects.exit("content");
    return ok(code);
  }
  function contentContinue(code) {
    effects.consume(code);
    effects.exit("chunkContent");
    previous.next = effects.enter("chunkContent", {
      contentType: "content",
      previous
    });
    previous = previous.next;
    return chunkInside;
  }
}
function tokenizeContinuation(effects, ok, nok) {
  const self2 = this;
  return startLookahead;
  function startLookahead(code) {
    effects.exit("chunkContent");
    effects.enter("lineEnding");
    effects.consume(code);
    effects.exit("lineEnding");
    return factorySpace(effects, prefixed, "linePrefix");
  }
  function prefixed(code) {
    if (code === null || markdownLineEnding(code)) {
      return nok(code);
    }
    const tail = self2.events[self2.events.length - 1];
    if (!self2.parser.constructs.disable.null.includes("codeIndented") && tail && tail[1].type === "linePrefix" && tail[2].sliceSerialize(tail[1], true).length >= 4) {
      return ok(code);
    }
    return effects.interrupt(self2.parser.constructs.flow, nok, ok)(code);
  }
}
// node_modules/micromark-factory-destination/index.js
function factoryDestination(effects, ok, nok, type, literalType, literalMarkerType, rawType, stringType, max) {
  const limit = max || Number.POSITIVE_INFINITY;
  let balance = 0;
  return start;
  function start(code) {
    if (code === 60) {
      effects.enter(type);
      effects.enter(literalType);
      effects.enter(literalMarkerType);
      effects.consume(code);
      effects.exit(literalMarkerType);
      return enclosedBefore;
    }
    if (code === null || code === 32 || code === 41 || asciiControl(code)) {
      return nok(code);
    }
    effects.enter(type);
    effects.enter(rawType);
    effects.enter(stringType);
    effects.enter("chunkString", {
      contentType: "string"
    });
    return raw(code);
  }
  function enclosedBefore(code) {
    if (code === 62) {
      effects.enter(literalMarkerType);
      effects.consume(code);
      effects.exit(literalMarkerType);
      effects.exit(literalType);
      effects.exit(type);
      return ok;
    }
    effects.enter(stringType);
    effects.enter("chunkString", {
      contentType: "string"
    });
    return enclosed(code);
  }
  function enclosed(code) {
    if (code === 62) {
      effects.exit("chunkString");
      effects.exit(stringType);
      return enclosedBefore(code);
    }
    if (code === null || code === 60 || markdownLineEnding(code)) {
      return nok(code);
    }
    effects.consume(code);
    return code === 92 ? enclosedEscape : enclosed;
  }
  function enclosedEscape(code) {
    if (code === 60 || code === 62 || code === 92) {
      effects.consume(code);
      return enclosed;
    }
    return enclosed(code);
  }
  function raw(code) {
    if (!balance && (code === null || code === 41 || markdownLineEndingOrSpace(code))) {
      effects.exit("chunkString");
      effects.exit(stringType);
      effects.exit(rawType);
      effects.exit(type);
      return ok(code);
    }
    if (balance < limit && code === 40) {
      effects.consume(code);
      balance++;
      return raw;
    }
    if (code === 41) {
      effects.consume(code);
      balance--;
      return raw;
    }
    if (code === null || code === 32 || code === 40 || asciiControl(code)) {
      return nok(code);
    }
    effects.consume(code);
    return code === 92 ? rawEscape : raw;
  }
  function rawEscape(code) {
    if (code === 40 || code === 41 || code === 92) {
      effects.consume(code);
      return raw;
    }
    return raw(code);
  }
}

// node_modules/micromark-factory-label/index.js
function factoryLabel(effects, ok, nok, type, markerType, stringType) {
  const self2 = this;
  let size = 0;
  let seen;
  return start;
  function start(code) {
    effects.enter(type);
    effects.enter(markerType);
    effects.consume(code);
    effects.exit(markerType);
    effects.enter(stringType);
    return atBreak;
  }
  function atBreak(code) {
    if (size > 999 || code === null || code === 91 || code === 93 && !seen || code === 94 && !size && "_hiddenFootnoteSupport" in self2.parser.constructs) {
      return nok(code);
    }
    if (code === 93) {
      effects.exit(stringType);
      effects.enter(markerType);
      effects.consume(code);
      effects.exit(markerType);
      effects.exit(type);
      return ok;
    }
    if (markdownLineEnding(code)) {
      effects.enter("lineEnding");
      effects.consume(code);
      effects.exit("lineEnding");
      return atBreak;
    }
    effects.enter("chunkString", {
      contentType: "string"
    });
    return labelInside(code);
  }
  function labelInside(code) {
    if (code === null || code === 91 || code === 93 || markdownLineEnding(code) || size++ > 999) {
      effects.exit("chunkString");
      return atBreak(code);
    }
    effects.consume(code);
    if (!seen)
      seen = !markdownSpace(code);
    return code === 92 ? labelEscape : labelInside;
  }
  function labelEscape(code) {
    if (code === 91 || code === 92 || code === 93) {
      effects.consume(code);
      size++;
      return labelInside;
    }
    return labelInside(code);
  }
}

// node_modules/micromark-factory-title/index.js
function factoryTitle(effects, ok, nok, type, markerType, stringType) {
  let marker;
  return start;
  function start(code) {
    if (code === 34 || code === 39 || code === 40) {
      effects.enter(type);
      effects.enter(markerType);
      effects.consume(code);
      effects.exit(markerType);
      marker = code === 40 ? 41 : code;
      return begin;
    }
    return nok(code);
  }
  function begin(code) {
    if (code === marker) {
      effects.enter(markerType);
      effects.consume(code);
      effects.exit(markerType);
      effects.exit(type);
      return ok;
    }
    effects.enter(stringType);
    return atBreak(code);
  }
  function atBreak(code) {
    if (code === marker) {
      effects.exit(stringType);
      return begin(marker);
    }
    if (code === null) {
      return nok(code);
    }
    if (markdownLineEnding(code)) {
      effects.enter("lineEnding");
      effects.consume(code);
      effects.exit("lineEnding");
      return factorySpace(effects, atBreak, "linePrefix");
    }
    effects.enter("chunkString", {
      contentType: "string"
    });
    return inside(code);
  }
  function inside(code) {
    if (code === marker || code === null || markdownLineEnding(code)) {
      effects.exit("chunkString");
      return atBreak(code);
    }
    effects.consume(code);
    return code === 92 ? escape : inside;
  }
  function escape(code) {
    if (code === marker || code === 92) {
      effects.consume(code);
      return inside;
    }
    return inside(code);
  }
}

// node_modules/micromark-factory-whitespace/index.js
function factoryWhitespace(effects, ok) {
  let seen;
  return start;
  function start(code) {
    if (markdownLineEnding(code)) {
      effects.enter("lineEnding");
      effects.consume(code);
      effects.exit("lineEnding");
      seen = true;
      return start;
    }
    if (markdownSpace(code)) {
      return factorySpace(effects, start, seen ? "linePrefix" : "lineSuffix")(code);
    }
    return ok(code);
  }
}

// node_modules/micromark-core-commonmark/lib/definition.js
var definition = {
  name: "definition",
  tokenize: tokenizeDefinition
};
var titleBefore = {
  partial: true,
  tokenize: tokenizeTitleBefore
};
function tokenizeDefinition(effects, ok, nok) {
  const self2 = this;
  let identifier;
  return start;
  function start(code) {
    effects.enter("definition");
    return before(code);
  }
  function before(code) {
    return factoryLabel.call(self2, effects, labelAfter, nok, "definitionLabel", "definitionLabelMarker", "definitionLabelString")(code);
  }
  function labelAfter(code) {
    identifier = normalizeIdentifier(self2.sliceSerialize(self2.events[self2.events.length - 1][1]).slice(1, -1));
    if (code === 58) {
      effects.enter("definitionMarker");
      effects.consume(code);
      effects.exit("definitionMarker");
      return markerAfter;
    }
    return nok(code);
  }
  function markerAfter(code) {
    return markdownLineEndingOrSpace(code) ? factoryWhitespace(effects, destinationBefore)(code) : destinationBefore(code);
  }
  function destinationBefore(code) {
    return factoryDestination(effects, destinationAfter, nok, "definitionDestination", "definitionDestinationLiteral", "definitionDestinationLiteralMarker", "definitionDestinationRaw", "definitionDestinationString")(code);
  }
  function destinationAfter(code) {
    return effects.attempt(titleBefore, after, after)(code);
  }
  function after(code) {
    return markdownSpace(code) ? factorySpace(effects, afterWhitespace, "whitespace")(code) : afterWhitespace(code);
  }
  function afterWhitespace(code) {
    if (code === null || markdownLineEnding(code)) {
      effects.exit("definition");
      self2.parser.defined.push(identifier);
      return ok(code);
    }
    return nok(code);
  }
}
function tokenizeTitleBefore(effects, ok, nok) {
  return titleBefore;
  function titleBefore(code) {
    return markdownLineEndingOrSpace(code) ? factoryWhitespace(effects, beforeMarker)(code) : nok(code);
  }
  function beforeMarker(code) {
    return factoryTitle(effects, titleAfter, nok, "definitionTitle", "definitionTitleMarker", "definitionTitleString")(code);
  }
  function titleAfter(code) {
    return markdownSpace(code) ? factorySpace(effects, titleAfterOptionalWhitespace, "whitespace")(code) : titleAfterOptionalWhitespace(code);
  }
  function titleAfterOptionalWhitespace(code) {
    return code === null || markdownLineEnding(code) ? ok(code) : nok(code);
  }
}
// node_modules/micromark-core-commonmark/lib/hard-break-escape.js
var hardBreakEscape = {
  name: "hardBreakEscape",
  tokenize: tokenizeHardBreakEscape
};
function tokenizeHardBreakEscape(effects, ok, nok) {
  return start;
  function start(code) {
    effects.enter("hardBreakEscape");
    effects.consume(code);
    return after;
  }
  function after(code) {
    if (markdownLineEnding(code)) {
      effects.exit("hardBreakEscape");
      return ok(code);
    }
    return nok(code);
  }
}
// node_modules/micromark-core-commonmark/lib/heading-atx.js
var headingAtx = {
  name: "headingAtx",
  resolve: resolveHeadingAtx,
  tokenize: tokenizeHeadingAtx
};
function resolveHeadingAtx(events, context) {
  let contentEnd = events.length - 2;
  let contentStart = 3;
  if (events[contentStart][1].type === "whitespace") {
    contentStart += 2;
  }
  if (contentEnd - 2 > contentStart && events[contentEnd][1].type === "whitespace") {
    contentEnd -= 2;
  }
  if (events[contentEnd][1].type === "atxHeadingSequence" && (contentStart === contentEnd - 1 || contentEnd - 4 > contentStart && events[contentEnd - 2][1].type === "whitespace")) {
    contentEnd -= contentStart + 1 === contentEnd ? 2 : 4;
  }
  if (contentEnd > contentStart) {
    const content = {
      type: "atxHeadingText",
      start: events[contentStart][1].start,
      end: events[contentEnd][1].end
    };
    const text = {
      type: "chunkText",
      start: events[contentStart][1].start,
      end: events[contentEnd][1].end,
      contentType: "text"
    };
    splice(events, contentStart, contentEnd - contentStart + 1, [["enter", content, context], ["enter", text, context], ["exit", text, context], ["exit", content, context]]);
  }
  return events;
}
function tokenizeHeadingAtx(effects, ok, nok) {
  let size = 0;
  return start;
  function start(code) {
    effects.enter("atxHeading");
    return before(code);
  }
  function before(code) {
    effects.enter("atxHeadingSequence");
    return sequenceOpen(code);
  }
  function sequenceOpen(code) {
    if (code === 35 && size++ < 6) {
      effects.consume(code);
      return sequenceOpen;
    }
    if (code === null || markdownLineEndingOrSpace(code)) {
      effects.exit("atxHeadingSequence");
      return atBreak(code);
    }
    return nok(code);
  }
  function atBreak(code) {
    if (code === 35) {
      effects.enter("atxHeadingSequence");
      return sequenceFurther(code);
    }
    if (code === null || markdownLineEnding(code)) {
      effects.exit("atxHeading");
      return ok(code);
    }
    if (markdownSpace(code)) {
      return factorySpace(effects, atBreak, "whitespace")(code);
    }
    effects.enter("atxHeadingText");
    return data(code);
  }
  function sequenceFurther(code) {
    if (code === 35) {
      effects.consume(code);
      return sequenceFurther;
    }
    effects.exit("atxHeadingSequence");
    return atBreak(code);
  }
  function data(code) {
    if (code === null || code === 35 || markdownLineEndingOrSpace(code)) {
      effects.exit("atxHeadingText");
      return atBreak(code);
    }
    effects.consume(code);
    return data;
  }
}
// node_modules/micromark-util-html-tag-name/index.js
var htmlBlockNames = [
  "address",
  "article",
  "aside",
  "base",
  "basefont",
  "blockquote",
  "body",
  "caption",
  "center",
  "col",
  "colgroup",
  "dd",
  "details",
  "dialog",
  "dir",
  "div",
  "dl",
  "dt",
  "fieldset",
  "figcaption",
  "figure",
  "footer",
  "form",
  "frame",
  "frameset",
  "h1",
  "h2",
  "h3",
  "h4",
  "h5",
  "h6",
  "head",
  "header",
  "hr",
  "html",
  "iframe",
  "legend",
  "li",
  "link",
  "main",
  "menu",
  "menuitem",
  "nav",
  "noframes",
  "ol",
  "optgroup",
  "option",
  "p",
  "param",
  "search",
  "section",
  "summary",
  "table",
  "tbody",
  "td",
  "tfoot",
  "th",
  "thead",
  "title",
  "tr",
  "track",
  "ul"
];
var htmlRawNames = ["pre", "script", "style", "textarea"];

// node_modules/micromark-core-commonmark/lib/html-flow.js
var htmlFlow = {
  concrete: true,
  name: "htmlFlow",
  resolveTo: resolveToHtmlFlow,
  tokenize: tokenizeHtmlFlow
};
var blankLineBefore = {
  partial: true,
  tokenize: tokenizeBlankLineBefore
};
function resolveToHtmlFlow(events) {
  let index = events.length;
  while (index--) {
    if (events[index][0] === "enter" && events[index][1].type === "htmlFlow") {
      break;
    }
  }
  if (index > 1 && events[index - 2][1].type === "linePrefix") {
    events[index][1].start = events[index - 2][1].start;
    events[index + 1][1].start = events[index - 2][1].start;
    events.splice(index - 2, 2);
  }
  return events;
}
function tokenizeHtmlFlow(effects, ok, nok) {
  const self2 = this;
  let marker;
  let closingTag;
  let buffer;
  let index;
  let markerB;
  return start;
  function start(code) {
    return before(code);
  }
  function before(code) {
    effects.enter("htmlFlow");
    effects.enter("htmlFlowData");
    effects.consume(code);
    return open;
  }
  function open(code) {
    if (code === 33) {
      effects.consume(code);
      return declarationOpen;
    }
    if (code === 47) {
      effects.consume(code);
      closingTag = true;
      return tagCloseStart;
    }
    if (code === 63) {
      effects.consume(code);
      marker = 3;
      return self2.interrupt ? ok : continuationDeclarationInside;
    }
    if (asciiAlpha(code)) {
      effects.consume(code);
      buffer = String.fromCharCode(code);
      return tagName;
    }
    return nok(code);
  }
  function declarationOpen(code) {
    if (code === 45) {
      effects.consume(code);
      marker = 2;
      return commentOpenInside;
    }
    if (code === 91) {
      effects.consume(code);
      marker = 5;
      index = 0;
      return cdataOpenInside;
    }
    if (asciiAlpha(code)) {
      effects.consume(code);
      marker = 4;
      return self2.interrupt ? ok : continuationDeclarationInside;
    }
    return nok(code);
  }
  function commentOpenInside(code) {
    if (code === 45) {
      effects.consume(code);
      return self2.interrupt ? ok : continuationDeclarationInside;
    }
    return nok(code);
  }
  function cdataOpenInside(code) {
    const value = "CDATA[";
    if (code === value.charCodeAt(index++)) {
      effects.consume(code);
      if (index === value.length) {
        return self2.interrupt ? ok : continuation;
      }
      return cdataOpenInside;
    }
    return nok(code);
  }
  function tagCloseStart(code) {
    if (asciiAlpha(code)) {
      effects.consume(code);
      buffer = String.fromCharCode(code);
      return tagName;
    }
    return nok(code);
  }
  function tagName(code) {
    if (code === null || code === 47 || code === 62 || markdownLineEndingOrSpace(code)) {
      const slash = code === 47;
      const name = buffer.toLowerCase();
      if (!slash && !closingTag && htmlRawNames.includes(name)) {
        marker = 1;
        return self2.interrupt ? ok(code) : continuation(code);
      }
      if (htmlBlockNames.includes(buffer.toLowerCase())) {
        marker = 6;
        if (slash) {
          effects.consume(code);
          return basicSelfClosing;
        }
        return self2.interrupt ? ok(code) : continuation(code);
      }
      marker = 7;
      return self2.interrupt && !self2.parser.lazy[self2.now().line] ? nok(code) : closingTag ? completeClosingTagAfter(code) : completeAttributeNameBefore(code);
    }
    if (code === 45 || asciiAlphanumeric(code)) {
      effects.consume(code);
      buffer += String.fromCharCode(code);
      return tagName;
    }
    return nok(code);
  }
  function basicSelfClosing(code) {
    if (code === 62) {
      effects.consume(code);
      return self2.interrupt ? ok : continuation;
    }
    return nok(code);
  }
  function completeClosingTagAfter(code) {
    if (markdownSpace(code)) {
      effects.consume(code);
      return completeClosingTagAfter;
    }
    return completeEnd(code);
  }
  function completeAttributeNameBefore(code) {
    if (code === 47) {
      effects.consume(code);
      return completeEnd;
    }
    if (code === 58 || code === 95 || asciiAlpha(code)) {
      effects.consume(code);
      return completeAttributeName;
    }
    if (markdownSpace(code)) {
      effects.consume(code);
      return completeAttributeNameBefore;
    }
    return completeEnd(code);
  }
  function completeAttributeName(code) {
    if (code === 45 || code === 46 || code === 58 || code === 95 || asciiAlphanumeric(code)) {
      effects.consume(code);
      return completeAttributeName;
    }
    return completeAttributeNameAfter(code);
  }
  function completeAttributeNameAfter(code) {
    if (code === 61) {
      effects.consume(code);
      return completeAttributeValueBefore;
    }
    if (markdownSpace(code)) {
      effects.consume(code);
      return completeAttributeNameAfter;
    }
    return completeAttributeNameBefore(code);
  }
  function completeAttributeValueBefore(code) {
    if (code === null || code === 60 || code === 61 || code === 62 || code === 96) {
      return nok(code);
    }
    if (code === 34 || code === 39) {
      effects.consume(code);
      markerB = code;
      return completeAttributeValueQuoted;
    }
    if (markdownSpace(code)) {
      effects.consume(code);
      return completeAttributeValueBefore;
    }
    return completeAttributeValueUnquoted(code);
  }
  function completeAttributeValueQuoted(code) {
    if (code === markerB) {
      effects.consume(code);
      markerB = null;
      return completeAttributeValueQuotedAfter;
    }
    if (code === null || markdownLineEnding(code)) {
      return nok(code);
    }
    effects.consume(code);
    return completeAttributeValueQuoted;
  }
  function completeAttributeValueUnquoted(code) {
    if (code === null || code === 34 || code === 39 || code === 47 || code === 60 || code === 61 || code === 62 || code === 96 || markdownLineEndingOrSpace(code)) {
      return completeAttributeNameAfter(code);
    }
    effects.consume(code);
    return completeAttributeValueUnquoted;
  }
  function completeAttributeValueQuotedAfter(code) {
    if (code === 47 || code === 62 || markdownSpace(code)) {
      return completeAttributeNameBefore(code);
    }
    return nok(code);
  }
  function completeEnd(code) {
    if (code === 62) {
      effects.consume(code);
      return completeAfter;
    }
    return nok(code);
  }
  function completeAfter(code) {
    if (code === null || markdownLineEnding(code)) {
      return continuation(code);
    }
    if (markdownSpace(code)) {
      effects.consume(code);
      return completeAfter;
    }
    return nok(code);
  }
  function continuation(code) {
    if (code === 45 && marker === 2) {
      effects.consume(code);
      return continuationCommentInside;
    }
    if (code === 60 && marker === 1) {
      effects.consume(code);
      return continuationRawTagOpen;
    }
    if (code === 62 && marker === 4) {
      effects.consume(code);
      return continuationClose;
    }
    if (code === 63 && marker === 3) {
      effects.consume(code);
      return continuationDeclarationInside;
    }
    if (code === 93 && marker === 5) {
      effects.consume(code);
      return continuationCdataInside;
    }
    if (markdownLineEnding(code) && (marker === 6 || marker === 7)) {
      effects.exit("htmlFlowData");
      return effects.check(blankLineBefore, continuationAfter, continuationStart)(code);
    }
    if (code === null || markdownLineEnding(code)) {
      effects.exit("htmlFlowData");
      return continuationStart(code);
    }
    effects.consume(code);
    return continuation;
  }
  function continuationStart(code) {
    return effects.check(nonLazyContinuation, continuationStartNonLazy, continuationAfter)(code);
  }
  function continuationStartNonLazy(code) {
    effects.enter("lineEnding");
    effects.consume(code);
    effects.exit("lineEnding");
    return continuationBefore;
  }
  function continuationBefore(code) {
    if (code === null || markdownLineEnding(code)) {
      return continuationStart(code);
    }
    effects.enter("htmlFlowData");
    return continuation(code);
  }
  function continuationCommentInside(code) {
    if (code === 45) {
      effects.consume(code);
      return continuationDeclarationInside;
    }
    return continuation(code);
  }
  function continuationRawTagOpen(code) {
    if (code === 47) {
      effects.consume(code);
      buffer = "";
      return continuationRawEndTag;
    }
    return continuation(code);
  }
  function continuationRawEndTag(code) {
    if (code === 62) {
      const name = buffer.toLowerCase();
      if (htmlRawNames.includes(name)) {
        effects.consume(code);
        return continuationClose;
      }
      return continuation(code);
    }
    if (asciiAlpha(code) && buffer.length < 8) {
      effects.consume(code);
      buffer += String.fromCharCode(code);
      return continuationRawEndTag;
    }
    return continuation(code);
  }
  function continuationCdataInside(code) {
    if (code === 93) {
      effects.consume(code);
      return continuationDeclarationInside;
    }
    return continuation(code);
  }
  function continuationDeclarationInside(code) {
    if (code === 62) {
      effects.consume(code);
      return continuationClose;
    }
    if (code === 45 && marker === 2) {
      effects.consume(code);
      return continuationDeclarationInside;
    }
    return continuation(code);
  }
  function continuationClose(code) {
    if (code === null || markdownLineEnding(code)) {
      effects.exit("htmlFlowData");
      return continuationAfter(code);
    }
    effects.consume(code);
    return continuationClose;
  }
  function continuationAfter(code) {
    effects.exit("htmlFlow");
    return ok(code);
  }
}
function tokenizeBlankLineBefore(effects, ok, nok) {
  return start;
  function start(code) {
    effects.enter("lineEnding");
    effects.consume(code);
    effects.exit("lineEnding");
    return effects.attempt(blankLine, ok, nok);
  }
}
// node_modules/micromark-core-commonmark/lib/html-text.js
var htmlText = {
  name: "htmlText",
  tokenize: tokenizeHtmlText
};
function tokenizeHtmlText(effects, ok, nok) {
  const self2 = this;
  let marker;
  let index;
  let returnState;
  return start;
  function start(code) {
    effects.enter("htmlText");
    effects.enter("htmlTextData");
    effects.consume(code);
    return open;
  }
  function open(code) {
    if (code === 33) {
      effects.consume(code);
      return declarationOpen;
    }
    if (code === 47) {
      effects.consume(code);
      return tagCloseStart;
    }
    if (code === 63) {
      effects.consume(code);
      return instruction;
    }
    if (asciiAlpha(code)) {
      effects.consume(code);
      return tagOpen;
    }
    return nok(code);
  }
  function declarationOpen(code) {
    if (code === 45) {
      effects.consume(code);
      return commentOpenInside;
    }
    if (code === 91) {
      effects.consume(code);
      index = 0;
      return cdataOpenInside;
    }
    if (asciiAlpha(code)) {
      effects.consume(code);
      return declaration;
    }
    return nok(code);
  }
  function commentOpenInside(code) {
    if (code === 45) {
      effects.consume(code);
      return commentEnd;
    }
    return nok(code);
  }
  function comment(code) {
    if (code === null) {
      return nok(code);
    }
    if (code === 45) {
      effects.consume(code);
      return commentClose;
    }
    if (markdownLineEnding(code)) {
      returnState = comment;
      return lineEndingBefore(code);
    }
    effects.consume(code);
    return comment;
  }
  function commentClose(code) {
    if (code === 45) {
      effects.consume(code);
      return commentEnd;
    }
    return comment(code);
  }
  function commentEnd(code) {
    return code === 62 ? end(code) : code === 45 ? commentClose(code) : comment(code);
  }
  function cdataOpenInside(code) {
    const value = "CDATA[";
    if (code === value.charCodeAt(index++)) {
      effects.consume(code);
      return index === value.length ? cdata : cdataOpenInside;
    }
    return nok(code);
  }
  function cdata(code) {
    if (code === null) {
      return nok(code);
    }
    if (code === 93) {
      effects.consume(code);
      return cdataClose;
    }
    if (markdownLineEnding(code)) {
      returnState = cdata;
      return lineEndingBefore(code);
    }
    effects.consume(code);
    return cdata;
  }
  function cdataClose(code) {
    if (code === 93) {
      effects.consume(code);
      return cdataEnd;
    }
    return cdata(code);
  }
  function cdataEnd(code) {
    if (code === 62) {
      return end(code);
    }
    if (code === 93) {
      effects.consume(code);
      return cdataEnd;
    }
    return cdata(code);
  }
  function declaration(code) {
    if (code === null || code === 62) {
      return end(code);
    }
    if (markdownLineEnding(code)) {
      returnState = declaration;
      return lineEndingBefore(code);
    }
    effects.consume(code);
    return declaration;
  }
  function instruction(code) {
    if (code === null) {
      return nok(code);
    }
    if (code === 63) {
      effects.consume(code);
      return instructionClose;
    }
    if (markdownLineEnding(code)) {
      returnState = instruction;
      return lineEndingBefore(code);
    }
    effects.consume(code);
    return instruction;
  }
  function instructionClose(code) {
    return code === 62 ? end(code) : instruction(code);
  }
  function tagCloseStart(code) {
    if (asciiAlpha(code)) {
      effects.consume(code);
      return tagClose;
    }
    return nok(code);
  }
  function tagClose(code) {
    if (code === 45 || asciiAlphanumeric(code)) {
      effects.consume(code);
      return tagClose;
    }
    return tagCloseBetween(code);
  }
  function tagCloseBetween(code) {
    if (markdownLineEnding(code)) {
      returnState = tagCloseBetween;
      return lineEndingBefore(code);
    }
    if (markdownSpace(code)) {
      effects.consume(code);
      return tagCloseBetween;
    }
    return end(code);
  }
  function tagOpen(code) {
    if (code === 45 || asciiAlphanumeric(code)) {
      effects.consume(code);
      return tagOpen;
    }
    if (code === 47 || code === 62 || markdownLineEndingOrSpace(code)) {
      return tagOpenBetween(code);
    }
    return nok(code);
  }
  function tagOpenBetween(code) {
    if (code === 47) {
      effects.consume(code);
      return end;
    }
    if (code === 58 || code === 95 || asciiAlpha(code)) {
      effects.consume(code);
      return tagOpenAttributeName;
    }
    if (markdownLineEnding(code)) {
      returnState = tagOpenBetween;
      return lineEndingBefore(code);
    }
    if (markdownSpace(code)) {
      effects.consume(code);
      return tagOpenBetween;
    }
    return end(code);
  }
  function tagOpenAttributeName(code) {
    if (code === 45 || code === 46 || code === 58 || code === 95 || asciiAlphanumeric(code)) {
      effects.consume(code);
      return tagOpenAttributeName;
    }
    return tagOpenAttributeNameAfter(code);
  }
  function tagOpenAttributeNameAfter(code) {
    if (code === 61) {
      effects.consume(code);
      return tagOpenAttributeValueBefore;
    }
    if (markdownLineEnding(code)) {
      returnState = tagOpenAttributeNameAfter;
      return lineEndingBefore(code);
    }
    if (markdownSpace(code)) {
      effects.consume(code);
      return tagOpenAttributeNameAfter;
    }
    return tagOpenBetween(code);
  }
  function tagOpenAttributeValueBefore(code) {
    if (code === null || code === 60 || code === 61 || code === 62 || code === 96) {
      return nok(code);
    }
    if (code === 34 || code === 39) {
      effects.consume(code);
      marker = code;
      return tagOpenAttributeValueQuoted;
    }
    if (markdownLineEnding(code)) {
      returnState = tagOpenAttributeValueBefore;
      return lineEndingBefore(code);
    }
    if (markdownSpace(code)) {
      effects.consume(code);
      return tagOpenAttributeValueBefore;
    }
    effects.consume(code);
    return tagOpenAttributeValueUnquoted;
  }
  function tagOpenAttributeValueQuoted(code) {
    if (code === marker) {
      effects.consume(code);
      marker = undefined;
      return tagOpenAttributeValueQuotedAfter;
    }
    if (code === null) {
      return nok(code);
    }
    if (markdownLineEnding(code)) {
      returnState = tagOpenAttributeValueQuoted;
      return lineEndingBefore(code);
    }
    effects.consume(code);
    return tagOpenAttributeValueQuoted;
  }
  function tagOpenAttributeValueUnquoted(code) {
    if (code === null || code === 34 || code === 39 || code === 60 || code === 61 || code === 96) {
      return nok(code);
    }
    if (code === 47 || code === 62 || markdownLineEndingOrSpace(code)) {
      return tagOpenBetween(code);
    }
    effects.consume(code);
    return tagOpenAttributeValueUnquoted;
  }
  function tagOpenAttributeValueQuotedAfter(code) {
    if (code === 47 || code === 62 || markdownLineEndingOrSpace(code)) {
      return tagOpenBetween(code);
    }
    return nok(code);
  }
  function end(code) {
    if (code === 62) {
      effects.consume(code);
      effects.exit("htmlTextData");
      effects.exit("htmlText");
      return ok;
    }
    return nok(code);
  }
  function lineEndingBefore(code) {
    effects.exit("htmlTextData");
    effects.enter("lineEnding");
    effects.consume(code);
    effects.exit("lineEnding");
    return lineEndingAfter;
  }
  function lineEndingAfter(code) {
    return markdownSpace(code) ? factorySpace(effects, lineEndingAfterPrefix, "linePrefix", self2.parser.constructs.disable.null.includes("codeIndented") ? undefined : 4)(code) : lineEndingAfterPrefix(code);
  }
  function lineEndingAfterPrefix(code) {
    effects.enter("htmlTextData");
    return returnState(code);
  }
}
// node_modules/micromark-core-commonmark/lib/label-end.js
var labelEnd = {
  name: "labelEnd",
  resolveAll: resolveAllLabelEnd,
  resolveTo: resolveToLabelEnd,
  tokenize: tokenizeLabelEnd
};
var resourceConstruct = {
  tokenize: tokenizeResource
};
var referenceFullConstruct = {
  tokenize: tokenizeReferenceFull
};
var referenceCollapsedConstruct = {
  tokenize: tokenizeReferenceCollapsed
};
function resolveAllLabelEnd(events) {
  let index = -1;
  const newEvents = [];
  while (++index < events.length) {
    const token = events[index][1];
    newEvents.push(events[index]);
    if (token.type === "labelImage" || token.type === "labelLink" || token.type === "labelEnd") {
      const offset = token.type === "labelImage" ? 4 : 2;
      token.type = "data";
      index += offset;
    }
  }
  if (events.length !== newEvents.length) {
    splice(events, 0, events.length, newEvents);
  }
  return events;
}
function resolveToLabelEnd(events, context) {
  let index = events.length;
  let offset = 0;
  let open;
  let close;
  let media;
  while (index--) {
    const token = events[index][1];
    if (open) {
      if (token.type === "link" || token.type === "labelLink" && token._inactive) {
        break;
      }
      if (events[index][0] === "enter" && token.type === "labelLink") {
        token._inactive = true;
      }
    } else if (close) {
      if (events[index][0] === "enter" && (token.type === "labelImage" || token.type === "labelLink") && !token._balanced) {
        open = index;
        if (token.type !== "labelLink") {
          offset = 2;
          break;
        }
      }
    } else if (token.type === "labelEnd") {
      close = index;
    }
  }
  const group = {
    type: events[open][1].type === "labelLink" ? "link" : "image",
    start: {
      ...events[open][1].start
    },
    end: {
      ...events[events.length - 1][1].end
    }
  };
  const label = {
    type: "label",
    start: {
      ...events[open][1].start
    },
    end: {
      ...events[close][1].end
    }
  };
  const text = {
    type: "labelText",
    start: {
      ...events[open + offset + 2][1].end
    },
    end: {
      ...events[close - 2][1].start
    }
  };
  media = [["enter", group, context], ["enter", label, context]];
  media = push(media, events.slice(open + 1, open + offset + 3));
  media = push(media, [["enter", text, context]]);
  media = push(media, resolveAll(context.parser.constructs.insideSpan.null, events.slice(open + offset + 4, close - 3), context));
  media = push(media, [["exit", text, context], events[close - 2], events[close - 1], ["exit", label, context]]);
  media = push(media, events.slice(close + 1));
  media = push(media, [["exit", group, context]]);
  splice(events, open, events.length, media);
  return events;
}
function tokenizeLabelEnd(effects, ok, nok) {
  const self2 = this;
  const labelStarts = self2._labelStarts;
  let labelStart;
  let defined;
  if (labelStarts) {
    while (labelStarts.length > 0 && labelStarts[labelStarts.length - 1]._balanced) {
      labelStarts.pop();
    }
    labelStart = labelStarts[labelStarts.length - 1];
  }
  return start;
  function start(code) {
    if (!labelStart) {
      return nok(code);
    }
    if (labelStart._inactive) {
      return labelEndNok(code);
    }
    defined = self2.parser.defined.includes(normalizeIdentifier(self2.sliceSerialize({
      start: labelStart.end,
      end: self2.now()
    })));
    effects.enter("labelEnd");
    effects.enter("labelMarker");
    effects.consume(code);
    effects.exit("labelMarker");
    effects.exit("labelEnd");
    return after;
  }
  function after(code) {
    if (code === 40) {
      return effects.attempt(resourceConstruct, labelEndOk, defined ? labelEndOk : labelEndNok)(code);
    }
    if (code === 91) {
      return effects.attempt(referenceFullConstruct, labelEndOk, defined ? referenceNotFull : labelEndNok)(code);
    }
    return defined ? labelEndOk(code) : labelEndNok(code);
  }
  function referenceNotFull(code) {
    return effects.attempt(referenceCollapsedConstruct, labelEndOk, labelEndNok)(code);
  }
  function labelEndOk(code) {
    labelStarts.pop();
    return ok(code);
  }
  function labelEndNok(code) {
    labelStart._balanced = true;
    return nok(code);
  }
}
function tokenizeResource(effects, ok, nok) {
  return resourceStart;
  function resourceStart(code) {
    effects.enter("resource");
    effects.enter("resourceMarker");
    effects.consume(code);
    effects.exit("resourceMarker");
    return resourceBefore;
  }
  function resourceBefore(code) {
    return markdownLineEndingOrSpace(code) ? factoryWhitespace(effects, resourceOpen)(code) : resourceOpen(code);
  }
  function resourceOpen(code) {
    if (code === 41) {
      return resourceEnd(code);
    }
    return factoryDestination(effects, resourceDestinationAfter, resourceDestinationMissing, "resourceDestination", "resourceDestinationLiteral", "resourceDestinationLiteralMarker", "resourceDestinationRaw", "resourceDestinationString", 32)(code);
  }
  function resourceDestinationAfter(code) {
    return markdownLineEndingOrSpace(code) ? factoryWhitespace(effects, resourceBetween)(code) : resourceEnd(code);
  }
  function resourceDestinationMissing(code) {
    return nok(code);
  }
  function resourceBetween(code) {
    if (code === 34 || code === 39 || code === 40) {
      return factoryTitle(effects, resourceTitleAfter, nok, "resourceTitle", "resourceTitleMarker", "resourceTitleString")(code);
    }
    return resourceEnd(code);
  }
  function resourceTitleAfter(code) {
    return markdownLineEndingOrSpace(code) ? factoryWhitespace(effects, resourceEnd)(code) : resourceEnd(code);
  }
  function resourceEnd(code) {
    if (code === 41) {
      effects.enter("resourceMarker");
      effects.consume(code);
      effects.exit("resourceMarker");
      effects.exit("resource");
      return ok;
    }
    return nok(code);
  }
}
function tokenizeReferenceFull(effects, ok, nok) {
  const self2 = this;
  return referenceFull;
  function referenceFull(code) {
    return factoryLabel.call(self2, effects, referenceFullAfter, referenceFullMissing, "reference", "referenceMarker", "referenceString")(code);
  }
  function referenceFullAfter(code) {
    return self2.parser.defined.includes(normalizeIdentifier(self2.sliceSerialize(self2.events[self2.events.length - 1][1]).slice(1, -1))) ? ok(code) : nok(code);
  }
  function referenceFullMissing(code) {
    return nok(code);
  }
}
function tokenizeReferenceCollapsed(effects, ok, nok) {
  return referenceCollapsedStart;
  function referenceCollapsedStart(code) {
    effects.enter("reference");
    effects.enter("referenceMarker");
    effects.consume(code);
    effects.exit("referenceMarker");
    return referenceCollapsedOpen;
  }
  function referenceCollapsedOpen(code) {
    if (code === 93) {
      effects.enter("referenceMarker");
      effects.consume(code);
      effects.exit("referenceMarker");
      effects.exit("reference");
      return ok;
    }
    return nok(code);
  }
}
// node_modules/micromark-core-commonmark/lib/label-start-image.js
var labelStartImage = {
  name: "labelStartImage",
  resolveAll: labelEnd.resolveAll,
  tokenize: tokenizeLabelStartImage
};
function tokenizeLabelStartImage(effects, ok, nok) {
  const self2 = this;
  let labelImage;
  return start;
  function start(code) {
    effects.enter("labelImage");
    effects.enter("labelImageMarker");
    effects.consume(code);
    effects.exit("labelImageMarker");
    return open;
  }
  function open(code) {
    if (code === 91) {
      effects.enter("labelMarker");
      effects.consume(code);
      effects.exit("labelMarker");
      labelImage = effects.exit("labelImage");
      return after;
    }
    return nok(code);
  }
  function after(code) {
    if (code === 94 && "_hiddenFootnoteSupport" in self2.parser.constructs) {
      return nok(code);
    }
    self2._labelStarts = self2._labelStarts || [];
    self2._labelStarts.push(labelImage);
    return ok(code);
  }
}
// node_modules/micromark-core-commonmark/lib/label-start-link.js
var labelStartLink = {
  name: "labelStartLink",
  resolveAll: labelEnd.resolveAll,
  tokenize: tokenizeLabelStartLink
};
function tokenizeLabelStartLink(effects, ok, nok) {
  const self2 = this;
  let labelLink;
  return start;
  function start(code) {
    effects.enter("labelLink");
    effects.enter("labelMarker");
    effects.consume(code);
    effects.exit("labelMarker");
    labelLink = effects.exit("labelLink");
    return after;
  }
  function after(code) {
    if (code === 94 && "_hiddenFootnoteSupport" in self2.parser.constructs) {
      return nok(code);
    }
    self2._labelStarts = self2._labelStarts || [];
    self2._labelStarts.push(labelLink);
    return ok(code);
  }
}
// node_modules/micromark-core-commonmark/lib/line-ending.js
var lineEnding = {
  name: "lineEnding",
  tokenize: tokenizeLineEnding
};
function tokenizeLineEnding(effects, ok) {
  return start;
  function start(code) {
    effects.enter("lineEnding");
    effects.consume(code);
    effects.exit("lineEnding");
    return factorySpace(effects, ok, "linePrefix");
  }
}
// node_modules/micromark-core-commonmark/lib/thematic-break.js
var thematicBreak = {
  name: "thematicBreak",
  tokenize: tokenizeThematicBreak
};
function tokenizeThematicBreak(effects, ok, nok) {
  let size = 0;
  let marker;
  return start;
  function start(code) {
    effects.enter("thematicBreak");
    return before(code);
  }
  function before(code) {
    marker = code;
    return atBreak(code);
  }
  function atBreak(code) {
    if (code === marker) {
      effects.enter("thematicBreakSequence");
      return sequence(code);
    }
    if (size >= 3 && (code === null || markdownLineEnding(code))) {
      effects.exit("thematicBreak");
      return ok(code);
    }
    return nok(code);
  }
  function sequence(code) {
    if (code === marker) {
      effects.consume(code);
      size++;
      return sequence;
    }
    effects.exit("thematicBreakSequence");
    return markdownSpace(code) ? factorySpace(effects, atBreak, "whitespace")(code) : atBreak(code);
  }
}

// node_modules/micromark-core-commonmark/lib/list.js
var list = {
  continuation: {
    tokenize: tokenizeListContinuation
  },
  exit: tokenizeListEnd,
  name: "list",
  tokenize: tokenizeListStart
};
var listItemPrefixWhitespaceConstruct = {
  partial: true,
  tokenize: tokenizeListItemPrefixWhitespace
};
var indentConstruct = {
  partial: true,
  tokenize: tokenizeIndent
};
function tokenizeListStart(effects, ok, nok) {
  const self2 = this;
  const tail = self2.events[self2.events.length - 1];
  let initialSize = tail && tail[1].type === "linePrefix" ? tail[2].sliceSerialize(tail[1], true).length : 0;
  let size = 0;
  return start;
  function start(code) {
    const kind = self2.containerState.type || (code === 42 || code === 43 || code === 45 ? "listUnordered" : "listOrdered");
    if (kind === "listUnordered" ? !self2.containerState.marker || code === self2.containerState.marker : asciiDigit(code)) {
      if (!self2.containerState.type) {
        self2.containerState.type = kind;
        effects.enter(kind, {
          _container: true
        });
      }
      if (kind === "listUnordered") {
        effects.enter("listItemPrefix");
        return code === 42 || code === 45 ? effects.check(thematicBreak, nok, atMarker)(code) : atMarker(code);
      }
      if (!self2.interrupt || code === 49) {
        effects.enter("listItemPrefix");
        effects.enter("listItemValue");
        return inside(code);
      }
    }
    return nok(code);
  }
  function inside(code) {
    if (asciiDigit(code) && ++size < 10) {
      effects.consume(code);
      return inside;
    }
    if ((!self2.interrupt || size < 2) && (self2.containerState.marker ? code === self2.containerState.marker : code === 41 || code === 46)) {
      effects.exit("listItemValue");
      return atMarker(code);
    }
    return nok(code);
  }
  function atMarker(code) {
    effects.enter("listItemMarker");
    effects.consume(code);
    effects.exit("listItemMarker");
    self2.containerState.marker = self2.containerState.marker || code;
    return effects.check(blankLine, self2.interrupt ? nok : onBlank, effects.attempt(listItemPrefixWhitespaceConstruct, endOfPrefix, otherPrefix));
  }
  function onBlank(code) {
    self2.containerState.initialBlankLine = true;
    initialSize++;
    return endOfPrefix(code);
  }
  function otherPrefix(code) {
    if (markdownSpace(code)) {
      effects.enter("listItemPrefixWhitespace");
      effects.consume(code);
      effects.exit("listItemPrefixWhitespace");
      return endOfPrefix;
    }
    return nok(code);
  }
  function endOfPrefix(code) {
    self2.containerState.size = initialSize + self2.sliceSerialize(effects.exit("listItemPrefix"), true).length;
    return ok(code);
  }
}
function tokenizeListContinuation(effects, ok, nok) {
  const self2 = this;
  self2.containerState._closeFlow = undefined;
  return effects.check(blankLine, onBlank, notBlank);
  function onBlank(code) {
    self2.containerState.furtherBlankLines = self2.containerState.furtherBlankLines || self2.containerState.initialBlankLine;
    return factorySpace(effects, ok, "listItemIndent", self2.containerState.size + 1)(code);
  }
  function notBlank(code) {
    if (self2.containerState.furtherBlankLines || !markdownSpace(code)) {
      self2.containerState.furtherBlankLines = undefined;
      self2.containerState.initialBlankLine = undefined;
      return notInCurrentItem(code);
    }
    self2.containerState.furtherBlankLines = undefined;
    self2.containerState.initialBlankLine = undefined;
    return effects.attempt(indentConstruct, ok, notInCurrentItem)(code);
  }
  function notInCurrentItem(code) {
    self2.containerState._closeFlow = true;
    self2.interrupt = undefined;
    return factorySpace(effects, effects.attempt(list, ok, nok), "linePrefix", self2.parser.constructs.disable.null.includes("codeIndented") ? undefined : 4)(code);
  }
}
function tokenizeIndent(effects, ok, nok) {
  const self2 = this;
  return factorySpace(effects, afterPrefix, "listItemIndent", self2.containerState.size + 1);
  function afterPrefix(code) {
    const tail = self2.events[self2.events.length - 1];
    return tail && tail[1].type === "listItemIndent" && tail[2].sliceSerialize(tail[1], true).length === self2.containerState.size ? ok(code) : nok(code);
  }
}
function tokenizeListEnd(effects) {
  effects.exit(this.containerState.type);
}
function tokenizeListItemPrefixWhitespace(effects, ok, nok) {
  const self2 = this;
  return factorySpace(effects, afterPrefix, "listItemPrefixWhitespace", self2.parser.constructs.disable.null.includes("codeIndented") ? undefined : 4 + 1);
  function afterPrefix(code) {
    const tail = self2.events[self2.events.length - 1];
    return !markdownSpace(code) && tail && tail[1].type === "listItemPrefixWhitespace" ? ok(code) : nok(code);
  }
}
// node_modules/micromark-core-commonmark/lib/setext-underline.js
var setextUnderline = {
  name: "setextUnderline",
  resolveTo: resolveToSetextUnderline,
  tokenize: tokenizeSetextUnderline
};
function resolveToSetextUnderline(events, context) {
  const editMap = new EditMap;
  let index = events.length;
  let content;
  let text;
  let definition;
  while (index--) {
    if (events[index][0] === "enter") {
      if (events[index][1].type === "content") {
        content = index;
        break;
      }
      if (events[index][1].type === "paragraph") {
        text = index;
      }
    } else {
      if (events[index][1].type === "content") {
        editMap.add(index, 1, []);
      }
      if (!definition && events[index][1].type === "definition") {
        definition = index;
      }
    }
  }
  const heading = {
    type: "setextHeading",
    start: {
      ...events[content][1].start
    },
    end: {
      ...events[events.length - 1][1].end
    }
  };
  events[text][1].type = "setextHeadingText";
  if (definition) {
    editMap.add(text, 0, [["enter", heading, context]]);
    editMap.add(definition + 1, 0, [["exit", events[content][1], context]]);
    events[content][1].end = {
      ...events[definition][1].end
    };
  } else {
    events[content][1] = heading;
  }
  editMap.add(events.length, 0, [["exit", heading, context]]);
  editMap.consume(events);
  return events;
}
function tokenizeSetextUnderline(effects, ok, nok) {
  const self2 = this;
  let marker;
  return start;
  function start(code) {
    let index = self2.events.length;
    let paragraph;
    while (index--) {
      if (self2.events[index][1].type !== "lineEnding" && self2.events[index][1].type !== "linePrefix" && self2.events[index][1].type !== "content") {
        paragraph = self2.events[index][1].type === "paragraph";
        break;
      }
    }
    if (!self2.parser.lazy[self2.now().line] && (self2.interrupt || paragraph)) {
      effects.enter("setextHeadingLine");
      marker = code;
      return before(code);
    }
    return nok(code);
  }
  function before(code) {
    effects.enter("setextHeadingLineSequence");
    return inside(code);
  }
  function inside(code) {
    if (code === marker) {
      effects.consume(code);
      return inside;
    }
    effects.exit("setextHeadingLineSequence");
    return markdownSpace(code) ? factorySpace(effects, after, "lineSuffix")(code) : after(code);
  }
  function after(code) {
    if (code === null || markdownLineEnding(code)) {
      effects.exit("setextHeadingLine");
      return ok(code);
    }
    return nok(code);
  }
}
// node_modules/micromark/lib/initialize/flow.js
var flow = {
  tokenize: initializeFlow
};
function initializeFlow(effects) {
  const self2 = this;
  const initial = effects.attempt(blankLine, atBlankEnding, effects.attempt(this.parser.constructs.flowInitial, afterConstruct, factorySpace(effects, effects.attempt(this.parser.constructs.flow, afterConstruct, effects.attempt(content2, afterConstruct)), "linePrefix")));
  return initial;
  function atBlankEnding(code) {
    if (code === null) {
      effects.consume(code);
      return;
    }
    effects.enter("lineEndingBlank");
    effects.consume(code);
    effects.exit("lineEndingBlank");
    self2.currentConstruct = undefined;
    return initial;
  }
  function afterConstruct(code) {
    if (code === null) {
      effects.consume(code);
      return;
    }
    effects.enter("lineEnding");
    effects.consume(code);
    effects.exit("lineEnding");
    self2.currentConstruct = undefined;
    return initial;
  }
}

// node_modules/micromark/lib/initialize/text.js
var resolver = {
  resolveAll: createResolver()
};
var string = initializeFactory("string");
var text2 = initializeFactory("text");
function initializeFactory(field) {
  return {
    resolveAll: createResolver(field === "text" ? resolveAllLineSuffixes : undefined),
    tokenize: initializeText
  };
  function initializeText(effects) {
    const self2 = this;
    const constructs = this.parser.constructs[field];
    const text = effects.attempt(constructs, start, notText);
    return start;
    function start(code) {
      return atBreak(code) ? text(code) : notText(code);
    }
    function notText(code) {
      if (code === null) {
        effects.consume(code);
        return;
      }
      effects.enter("data");
      effects.consume(code);
      return data;
    }
    function data(code) {
      if (atBreak(code)) {
        effects.exit("data");
        return text(code);
      }
      effects.consume(code);
      return data;
    }
    function atBreak(code) {
      if (code === null) {
        return true;
      }
      const list = constructs[code];
      let index = -1;
      if (list) {
        while (++index < list.length) {
          const item = list[index];
          if (!item.previous || item.previous.call(self2, self2.previous)) {
            return true;
          }
        }
      }
      return false;
    }
  }
}
function createResolver(extraResolver) {
  return resolveAllText;
  function resolveAllText(events, context) {
    let index = -1;
    let enter;
    while (++index <= events.length) {
      if (enter === undefined) {
        if (events[index] && events[index][1].type === "data") {
          enter = index;
          index++;
        }
      } else if (!events[index] || events[index][1].type !== "data") {
        if (index !== enter + 2) {
          events[enter][1].end = events[index - 1][1].end;
          events.splice(enter + 2, index - enter - 2);
          index = enter + 2;
        }
        enter = undefined;
      }
    }
    return extraResolver ? extraResolver(events, context) : events;
  }
}
function resolveAllLineSuffixes(events, context) {
  const editMap = new EditMap;
  let eventIndex = 0;
  while (++eventIndex <= events.length) {
    if ((eventIndex === events.length || events[eventIndex][1].type === "lineEnding") && events[eventIndex - 1][1].type === "data") {
      const data = events[eventIndex - 1][1];
      const chunks = context.sliceStream(data);
      let index = chunks.length;
      let bufferIndex = -1;
      let size = 0;
      let tabs;
      while (index--) {
        const chunk = chunks[index];
        if (typeof chunk === "string") {
          bufferIndex = chunk.length;
          while (chunk.charCodeAt(bufferIndex - 1) === 32) {
            size++;
            bufferIndex--;
          }
          if (bufferIndex) {
            break;
          }
          bufferIndex = -1;
        } else if (chunk === -2) {
          tabs = true;
          size++;
        } else if (chunk === -1) {} else {
          index++;
          break;
        }
      }
      if (context._contentTypeTextTrailing && eventIndex === events.length) {
        size = 0;
      }
      if (size) {
        const token = {
          type: eventIndex === events.length || tabs || size < 2 ? "lineSuffix" : "hardBreakTrailing",
          start: {
            _bufferIndex: index ? bufferIndex : data.start._bufferIndex + bufferIndex,
            _index: data.start._index + index,
            line: data.end.line,
            column: data.end.column - size,
            offset: data.end.offset - size
          },
          end: {
            ...data.end
          }
        };
        data.end = {
          ...token.start
        };
        if (data.start.offset === data.end.offset) {
          Object.assign(data, token);
        } else {
          editMap.add(eventIndex, 0, [["enter", token, context], ["exit", token, context]]);
        }
      }
      eventIndex++;
    }
  }
  editMap.consume(events);
  return events;
}

// node_modules/micromark/lib/constructs.js
var exports_constructs = {};
__export(exports_constructs, {
  attentionMarkers: () => attentionMarkers,
  contentInitial: () => contentInitial,
  disable: () => disable,
  document: () => document3,
  flow: () => flow2,
  flowInitial: () => flowInitial,
  insideSpan: () => insideSpan,
  string: () => string2,
  text: () => text3
});
var document3 = {
  [42]: list,
  [43]: list,
  [45]: list,
  [48]: list,
  [49]: list,
  [50]: list,
  [51]: list,
  [52]: list,
  [53]: list,
  [54]: list,
  [55]: list,
  [56]: list,
  [57]: list,
  [62]: blockQuote
};
var contentInitial = {
  [91]: definition
};
var flowInitial = {
  [-2]: codeIndented,
  [-1]: codeIndented,
  [32]: codeIndented
};
var flow2 = {
  [35]: headingAtx,
  [42]: thematicBreak,
  [45]: [setextUnderline, thematicBreak],
  [60]: htmlFlow,
  [61]: setextUnderline,
  [95]: thematicBreak,
  [96]: codeFenced,
  [126]: codeFenced
};
var string2 = {
  [38]: characterReference,
  [92]: characterEscape
};
var text3 = {
  [-5]: lineEnding,
  [-4]: lineEnding,
  [-3]: lineEnding,
  [33]: labelStartImage,
  [38]: characterReference,
  [42]: attention,
  [60]: [autolink, htmlText],
  [91]: labelStartLink,
  [92]: [hardBreakEscape, characterEscape],
  [93]: labelEnd,
  [95]: attention,
  [96]: codeText
};
var insideSpan = {
  null: [attention, resolver]
};
var attentionMarkers = {
  null: [42, 95]
};
var disable = {
  null: []
};

// node_modules/micromark/lib/create-tokenizer.js
function createTokenizer(parser, initialize, from) {
  let point = {
    _bufferIndex: -1,
    _index: 0,
    line: from && from.line || 1,
    column: from && from.column || 1,
    offset: from && from.offset || 0
  };
  const columnStart = {};
  const resolveAllConstructs = [];
  let chunks = [];
  let stack = [];
  let consumed = true;
  const effects = {
    attempt: constructFactory(onsuccessfulconstruct),
    check: constructFactory(onsuccessfulcheck),
    consume,
    enter,
    exit,
    interrupt: constructFactory(onsuccessfulcheck, {
      interrupt: true
    })
  };
  const context = {
    code: null,
    containerState: {},
    defineSkip,
    events: [],
    now,
    parser,
    previous: null,
    sliceSerialize,
    sliceStream,
    write
  };
  let state = initialize.tokenize.call(context, effects);
  let expectedCode;
  if (initialize.resolveAll) {
    resolveAllConstructs.push(initialize);
  }
  return context;
  function write(slice) {
    chunks = push(chunks, slice);
    main();
    if (chunks[chunks.length - 1] !== null) {
      return [];
    }
    addResult(initialize, 0);
    context.events = resolveAll(resolveAllConstructs, context.events, context);
    return context.events;
  }
  function sliceSerialize(token, expandTabs) {
    return serializeChunks(sliceStream(token), expandTabs);
  }
  function sliceStream(token) {
    return sliceChunks(chunks, token);
  }
  function now() {
    const {
      _bufferIndex,
      _index,
      line,
      column,
      offset
    } = point;
    return {
      _bufferIndex,
      _index,
      line,
      column,
      offset
    };
  }
  function defineSkip(value) {
    columnStart[value.line] = value.column;
    accountForPotentialSkip();
  }
  function main() {
    while (point._index < chunks.length) {
      const chunk = chunks[point._index];
      if (typeof chunk === "string") {
        const chunkIndex = point._index;
        if (point._bufferIndex < 0) {
          point._bufferIndex = 0;
        }
        while (point._index === chunkIndex && point._bufferIndex < chunk.length) {
          go(chunk.charCodeAt(point._bufferIndex));
        }
      } else {
        go(chunk);
      }
    }
  }
  function go(code) {
    consumed = undefined;
    expectedCode = code;
    state = state(code);
  }
  function consume(code) {
    if (markdownLineEnding(code)) {
      point.line++;
      point.column = 1;
      point.offset += code === -3 ? 2 : 1;
      accountForPotentialSkip();
    } else if (code !== -1) {
      point.column++;
      point.offset++;
    }
    if (point._bufferIndex < 0) {
      point._index++;
    } else {
      point._bufferIndex++;
      if (point._bufferIndex === chunks[point._index].length) {
        point._bufferIndex = -1;
        point._index++;
      }
    }
    context.previous = code;
    consumed = true;
  }
  function enter(type, fields) {
    const token = fields || {};
    token.type = type;
    token.start = now();
    context.events.push(["enter", token, context]);
    stack.push(token);
    return token;
  }
  function exit(type) {
    const token = stack.pop();
    token.end = now();
    context.events.push(["exit", token, context]);
    return token;
  }
  function onsuccessfulconstruct(construct, info) {
    addResult(construct, info.from);
  }
  function onsuccessfulcheck(_, info) {
    info.restore();
  }
  function constructFactory(onreturn, fields) {
    return hook;
    function hook(constructs, returnState, bogusState) {
      let listOfConstructs;
      let constructIndex;
      let currentConstruct;
      let info;
      return Array.isArray(constructs) ? handleListOfConstructs(constructs) : ("tokenize" in constructs) ? handleListOfConstructs([constructs]) : handleMapOfConstructs(constructs);
      function handleMapOfConstructs(map) {
        return start;
        function start(code) {
          const left = code !== null && map[code];
          const all = code !== null && map.null;
          const list = [
            ...Array.isArray(left) ? left : left ? [left] : [],
            ...Array.isArray(all) ? all : all ? [all] : []
          ];
          return handleListOfConstructs(list)(code);
        }
      }
      function handleListOfConstructs(list) {
        listOfConstructs = list;
        constructIndex = 0;
        if (list.length === 0) {
          return bogusState;
        }
        return handleConstruct(list[constructIndex]);
      }
      function handleConstruct(construct) {
        return start;
        function start(code) {
          info = store();
          currentConstruct = construct;
          if (!construct.partial) {
            context.currentConstruct = construct;
          }
          if (construct.name && context.parser.constructs.disable.null.includes(construct.name)) {
            return nok(code);
          }
          return construct.tokenize.call(fields ? Object.assign(Object.create(context), fields) : context, effects, ok, nok)(code);
        }
      }
      function ok(code) {
        consumed = true;
        onreturn(currentConstruct, info);
        return returnState;
      }
      function nok(code) {
        consumed = true;
        info.restore();
        if (++constructIndex < listOfConstructs.length) {
          return handleConstruct(listOfConstructs[constructIndex]);
        }
        return bogusState;
      }
    }
  }
  function addResult(construct, from) {
    if (construct.resolveAll && !resolveAllConstructs.includes(construct)) {
      resolveAllConstructs.push(construct);
    }
    if (construct.resolve) {
      splice(context.events, from, context.events.length - from, construct.resolve(context.events.slice(from), context));
    }
    if (construct.resolveTo) {
      context.events = construct.resolveTo(context.events, context);
    }
  }
  function store() {
    const startPoint = now();
    const startPrevious = context.previous;
    const startCurrentConstruct = context.currentConstruct;
    const startEventsIndex = context.events.length;
    const startStack = Array.from(stack);
    return {
      from: startEventsIndex,
      restore
    };
    function restore() {
      point = startPoint;
      context.previous = startPrevious;
      context.currentConstruct = startCurrentConstruct;
      context.events.length = startEventsIndex;
      stack = startStack;
      accountForPotentialSkip();
    }
  }
  function accountForPotentialSkip() {
    if (point.line in columnStart && point.column < 2) {
      point.column = columnStart[point.line];
      point.offset += columnStart[point.line] - 1;
    }
  }
}
function sliceChunks(chunks, token) {
  const startIndex = token.start._index;
  const startBufferIndex = token.start._bufferIndex;
  const endIndex = token.end._index;
  const endBufferIndex = token.end._bufferIndex;
  let view;
  if (startIndex === endIndex) {
    view = [chunks[startIndex].slice(startBufferIndex, endBufferIndex)];
  } else {
    view = chunks.slice(startIndex, endIndex);
    if (startBufferIndex > -1) {
      const head = view[0];
      if (typeof head === "string") {
        view[0] = head.slice(startBufferIndex);
      } else {
        view.shift();
      }
    }
    if (endBufferIndex > 0) {
      view.push(chunks[endIndex].slice(0, endBufferIndex));
    }
  }
  return view;
}
function serializeChunks(chunks, expandTabs) {
  let index = -1;
  const result = [];
  let atTab;
  while (++index < chunks.length) {
    const chunk = chunks[index];
    let value;
    if (typeof chunk === "string") {
      value = chunk;
    } else {
      switch (chunk) {
        case -5: {
          value = "\r";
          break;
        }
        case -4: {
          value = `
`;
          break;
        }
        case -3: {
          value = "\r" + `
`;
          break;
        }
        case -2: {
          value = expandTabs ? " " : "\t";
          break;
        }
        case -1: {
          if (!expandTabs && atTab) {
            continue;
          }
          value = " ";
          break;
        }
        default: {
          value = String.fromCharCode(chunk);
        }
      }
    }
    atTab = chunk === -2;
    result.push(value);
  }
  return result.join("");
}

// node_modules/micromark/lib/parse.js
function parse(options) {
  const settings = options || {};
  const constructs = combineExtensions([exports_constructs, ...settings.extensions || []]);
  const parser = {
    constructs,
    content: create(content),
    defined: [],
    document: create(document2),
    flow: create(flow),
    lazy: {},
    string: create(string),
    text: create(text2)
  };
  return parser;
  function create(initial) {
    return creator;
    function creator(from) {
      return createTokenizer(parser, initial, from);
    }
  }
}

// node_modules/micromark/lib/postprocess.js
function postprocess(events) {
  while (!subtokenize(events)) {}
  return events;
}

// node_modules/micromark/lib/preprocess.js
var search = /[\0\t\n\r]/g;
function preprocess() {
  let column = 1;
  let buffer = "";
  let start = true;
  let atCarriageReturn;
  return preprocessor;
  function preprocessor(value, encoding, end) {
    value = buffer + (typeof value === "string" ? value.toString() : new TextDecoder(encoding || undefined).decode(value));
    const chunks = [];
    let startPosition = 0;
    buffer = "";
    if (start) {
      if (value.charCodeAt(0) === 65279) {
        startPosition++;
      }
      start = undefined;
    }
    while (startPosition < value.length) {
      search.lastIndex = startPosition;
      const match = search.exec(value);
      const endPosition = match && match.index !== undefined ? match.index : value.length;
      const code = value.charCodeAt(endPosition);
      if (!match) {
        buffer = value.slice(startPosition);
        break;
      }
      if (code === 10 && startPosition === endPosition && atCarriageReturn) {
        chunks.push(-3);
        atCarriageReturn = undefined;
      } else {
        if (atCarriageReturn) {
          chunks.push(-5);
          atCarriageReturn = undefined;
        }
        if (startPosition < endPosition) {
          chunks.push(value.slice(startPosition, endPosition));
          column += endPosition - startPosition;
        }
        switch (code) {
          case 0: {
            chunks.push(65533);
            column++;
            break;
          }
          case 9: {
            const next = Math.ceil(column / 4) * 4;
            chunks.push(-2);
            while (column++ < next) {
              chunks.push(-1);
            }
            break;
          }
          case 10: {
            chunks.push(-4);
            column = 1;
            break;
          }
          default: {
            atCarriageReturn = true;
            column = 1;
          }
        }
      }
      startPosition = endPosition + 1;
    }
    if (end) {
      if (atCarriageReturn) {
        chunks.push(-5);
      }
      if (buffer) {
        chunks.push(buffer);
      }
      chunks.push(null);
    }
    return chunks;
  }
}
// node_modules/micromark-util-decode-string/index.js
var characterEscapeOrReference = /\\([!-/:-@[-`{-~])|&(#(?:\d{1,7}|x[\da-f]{1,6})|[\da-z]{1,31});/gi;
function decodeString(value) {
  return value.replace(characterEscapeOrReference, decode);
}
function decode($0, $1, $2) {
  if ($1) {
    return $1;
  }
  const head = $2.charCodeAt(0);
  if (head === 35) {
    const head = $2.charCodeAt(1);
    const hex = head === 120 || head === 88;
    return decodeNumericCharacterReference($2.slice(hex ? 2 : 1), hex ? 16 : 10);
  }
  return decodeNamedCharacterReference($2) || $0;
}

// node_modules/mdast-util-from-markdown/lib/index.js
var own2 = {}.hasOwnProperty;
function fromMarkdown(value, encoding, options) {
  if (encoding && typeof encoding === "object") {
    options = encoding;
    encoding = undefined;
  }
  return compiler(options)(postprocess(parse(options).document().write(preprocess()(value, encoding, true))));
}
function compiler(options) {
  const config = {
    afterExit: [],
    beforeEnter: [],
    transforms: [],
    canContainEols: ["emphasis", "fragment", "heading", "paragraph", "strong"],
    enter: {
      autolink: opener(link),
      autolinkProtocol: onenterdata,
      autolinkEmail: onenterdata,
      atxHeading: opener(heading),
      blockQuote: opener(blockQuote),
      characterEscape: onenterdata,
      characterReference: onenterdata,
      codeFenced: opener(codeFlow),
      codeFencedFenceInfo: buffer,
      codeFencedFenceMeta: buffer,
      codeIndented: opener(codeFlow, buffer),
      codeText: opener(codeText, buffer),
      codeTextData: onenterdata,
      data: onenterdata,
      codeFlowValue: onenterdata,
      definition: opener(definition),
      definitionDestinationString: buffer,
      definitionLabelString: buffer,
      definitionTitleString: buffer,
      emphasis: opener(emphasis),
      hardBreakEscape: opener(hardBreak),
      hardBreakTrailing: opener(hardBreak),
      htmlFlow: opener(html, buffer),
      htmlFlowData: onenterdata,
      htmlText: opener(html, buffer),
      htmlTextData: onenterdata,
      image: opener(image),
      label: buffer,
      link: opener(link),
      listItem: opener(listItem),
      listItemValue: onenterlistitemvalue,
      listOrdered: opener(list, onenterlistordered),
      listUnordered: opener(list),
      paragraph: opener(paragraph),
      reference: onenterreference,
      referenceString: buffer,
      resourceDestinationString: buffer,
      resourceTitleString: buffer,
      setextHeading: opener(heading),
      strong: opener(strong),
      thematicBreak: opener(thematicBreak)
    },
    exit: {
      atxHeading: closer(),
      atxHeadingSequence: onexitatxheadingsequence,
      autolink: closer(),
      autolinkEmail: onexitautolinkemail,
      autolinkProtocol: onexitautolinkprotocol,
      blockQuote: closer(),
      characterEscapeValue: onexitdata,
      characterReferenceMarkerHexadecimal: onexitcharacterreferencemarker,
      characterReferenceMarkerNumeric: onexitcharacterreferencemarker,
      characterReferenceValue: onexitcharacterreferencevalue,
      characterReference: onexitcharacterreference,
      codeFenced: closer(onexitcodefenced),
      codeFencedFence: onexitcodefencedfence,
      codeFencedFenceInfo: onexitcodefencedfenceinfo,
      codeFencedFenceMeta: onexitcodefencedfencemeta,
      codeFlowValue: onexitdata,
      codeIndented: closer(onexitcodeindented),
      codeText: closer(onexitcodetext),
      codeTextData: onexitdata,
      data: onexitdata,
      definition: closer(),
      definitionDestinationString: onexitdefinitiondestinationstring,
      definitionLabelString: onexitdefinitionlabelstring,
      definitionTitleString: onexitdefinitiontitlestring,
      emphasis: closer(),
      hardBreakEscape: closer(onexithardbreak),
      hardBreakTrailing: closer(onexithardbreak),
      htmlFlow: closer(onexithtmlflow),
      htmlFlowData: onexitdata,
      htmlText: closer(onexithtmltext),
      htmlTextData: onexitdata,
      image: closer(onexitimage),
      label: onexitlabel,
      labelText: onexitlabeltext,
      lineEnding: onexitlineending,
      link: closer(onexitlink),
      listItem: closer(),
      listOrdered: closer(),
      listUnordered: closer(),
      paragraph: closer(),
      referenceString: onexitreferencestring,
      resourceDestinationString: onexitresourcedestinationstring,
      resourceTitleString: onexitresourcetitlestring,
      resource: onexitresource,
      setextHeading: closer(onexitsetextheading),
      setextHeadingLineSequence: onexitsetextheadinglinesequence,
      setextHeadingText: onexitsetextheadingtext,
      strong: closer(),
      thematicBreak: closer()
    }
  };
  configure(config, (options || {}).mdastExtensions || []);
  const data = {};
  return compile;
  function compile(events) {
    let tree = {
      type: "root",
      children: [],
      position: undefined
    };
    const context = {
      stack: [tree],
      tokenStack: [],
      config,
      enter,
      exit,
      buffer,
      resume,
      data
    };
    const listStack = [];
    const prepared = [];
    let index = -1;
    while (++index < events.length) {
      prepared.push(events[index]);
      if (events[index][1].type === "listOrdered" || events[index][1].type === "listUnordered") {
        if (events[index][0] === "enter") {
          listStack.push(prepared.length - 1);
        } else {
          const tail = listStack.pop();
          prepareList(prepared, tail);
        }
      }
    }
    events = prepared;
    index = -1;
    while (++index < events.length) {
      const handler = config[events[index][0]];
      if (events[index][0] === "enter" && config.beforeEnter.length > 0) {
        callListeners(config.beforeEnter, {
          ...context,
          sliceSerialize: events[index][2].sliceSerialize
        }, events[index][1]);
      }
      if (own2.call(handler, events[index][1].type)) {
        handler[events[index][1].type].call({
          ...context,
          sliceSerialize: events[index][2].sliceSerialize
        }, events[index][1]);
      }
      if (events[index][0] === "exit" && config.afterExit.length > 0) {
        callListeners(config.afterExit, {
          ...context,
          sliceSerialize: events[index][2].sliceSerialize
        }, events[index][1]);
      }
    }
    if (context.tokenStack.length > 0) {
      const tail = context.tokenStack[context.tokenStack.length - 1];
      const handler = tail[1] || defaultOnError;
      handler.call(context, undefined, tail[0]);
    }
    tree.position = {
      start: point3(events.length > 0 ? events[0][1].start : {
        line: 1,
        column: 1,
        offset: 0
      }),
      end: point3(events.length > 0 ? events[events.length - 2][1].end : {
        line: 1,
        column: 1,
        offset: 0
      })
    };
    index = -1;
    while (++index < config.transforms.length) {
      tree = config.transforms[index](tree) || tree;
    }
    return tree;
  }
  function callListeners(listeners, context, token) {
    let index = -1;
    while (++index < listeners.length) {
      listeners[index].call(context, token);
    }
  }
  function prepareList(events, start) {
    const end = events.length - 1;
    let index = start - 1;
    let containerBalance = -1;
    let listSpread = false;
    let listItem;
    let lineIndex;
    let firstBlankLineIndex;
    let atMarker;
    const insertions = [];
    while (++index <= end) {
      const event = events[index];
      switch (event[1].type) {
        case "listUnordered":
        case "listOrdered":
        case "blockQuote": {
          if (event[0] === "enter") {
            containerBalance++;
          } else {
            containerBalance--;
          }
          atMarker = undefined;
          break;
        }
        case "lineEndingBlank": {
          if (event[0] === "enter") {
            if (listItem && !atMarker && !containerBalance && !firstBlankLineIndex) {
              firstBlankLineIndex = index;
            }
            atMarker = undefined;
          }
          break;
        }
        case "linePrefix":
        case "listItemValue":
        case "listItemMarker":
        case "listItemPrefix":
        case "listItemPrefixWhitespace": {
          break;
        }
        default: {
          atMarker = undefined;
        }
      }
      if (!containerBalance && event[0] === "enter" && event[1].type === "listItemPrefix" || containerBalance === -1 && event[0] === "exit" && (event[1].type === "listUnordered" || event[1].type === "listOrdered")) {
        if (listItem) {
          let tailIndex = index;
          lineIndex = undefined;
          while (tailIndex--) {
            const tailEvent = events[tailIndex];
            if (tailEvent[1].type === "lineEnding" || tailEvent[1].type === "lineEndingBlank") {
              if (tailEvent[0] === "exit")
                continue;
              if (lineIndex) {
                events[lineIndex][1].type = "lineEndingBlank";
                listSpread = true;
              }
              tailEvent[1].type = "lineEnding";
              lineIndex = tailIndex;
            } else if (tailEvent[1].type === "linePrefix" || tailEvent[1].type === "blockQuotePrefix" || tailEvent[1].type === "blockQuotePrefixWhitespace" || tailEvent[1].type === "blockQuoteMarker" || tailEvent[1].type === "listItemIndent") {} else {
              break;
            }
          }
          if (firstBlankLineIndex && (!lineIndex || firstBlankLineIndex < lineIndex)) {
            listItem._spread = true;
          }
          listItem.end = Object.assign({}, lineIndex ? events[lineIndex][1].start : event[1].end);
          insertions.push({
            at: lineIndex || index,
            event: ["exit", listItem, event[2]]
          });
        }
        if (event[1].type === "listItemPrefix") {
          const item = {
            type: "listItem",
            _spread: false,
            start: Object.assign({}, event[1].start),
            end: undefined
          };
          listItem = item;
          insertions.push({
            at: index,
            event: ["enter", item, event[2]]
          });
          firstBlankLineIndex = undefined;
          atMarker = true;
        }
      }
    }
    const listEvents = events.splice(start);
    let insertion = 0;
    index = -1;
    while (++index < listEvents.length) {
      while (insertion < insertions.length && insertions[insertion].at === start + index) {
        events.push(insertions[insertion++].event);
      }
      events.push(listEvents[index]);
    }
    events[start][1]._spread = listSpread;
  }
  function opener(create, and) {
    return open;
    function open(token) {
      enter.call(this, create(token), token);
      if (and)
        and.call(this, token);
    }
  }
  function buffer() {
    this.stack.push({
      type: "fragment",
      children: []
    });
  }
  function enter(node, token, errorHandler) {
    const parent = this.stack[this.stack.length - 1];
    const siblings = parent.children;
    siblings.push(node);
    this.stack.push(node);
    this.tokenStack.push([token, errorHandler || undefined]);
    node.position = {
      start: point3(token.start),
      end: undefined
    };
  }
  function closer(and) {
    return close;
    function close(token) {
      if (and)
        and.call(this, token);
      exit.call(this, token);
    }
  }
  function exit(token, onExitError) {
    const node = this.stack.pop();
    const open = this.tokenStack.pop();
    if (!open) {
      throw new Error("Cannot close `" + token.type + "` (" + stringifyPosition({
        start: token.start,
        end: token.end
      }) + "): it’s not open");
    }
    if (open[0].type !== token.type) {
      if (onExitError) {
        onExitError.call(this, token, open[0]);
      } else {
        const handler = open[1] || defaultOnError;
        handler.call(this, token, open[0]);
      }
    }
    node.position.end = point3(token.end);
  }
  function resume() {
    return toString(this.stack.pop());
  }
  function onenterlistordered() {
    this.data.expectingFirstListItemValue = true;
  }
  function onenterlistitemvalue(token) {
    if (this.data.expectingFirstListItemValue) {
      const ancestor = this.stack[this.stack.length - 2];
      ancestor.start = Number.parseInt(this.sliceSerialize(token), 10);
      this.data.expectingFirstListItemValue = undefined;
    }
  }
  function onexitcodefencedfenceinfo() {
    const data = this.resume();
    const node = this.stack[this.stack.length - 1];
    node.lang = data;
  }
  function onexitcodefencedfencemeta() {
    const data = this.resume();
    const node = this.stack[this.stack.length - 1];
    node.meta = data;
  }
  function onexitcodefencedfence() {
    if (this.data.flowCodeInside)
      return;
    this.buffer();
    this.data.flowCodeInside = true;
  }
  function onexitcodefenced() {
    const data = this.resume();
    const node = this.stack[this.stack.length - 1];
    node.value = data.replace(/^(\r?\n|\r)|(\r?\n|\r)$/g, "");
    this.data.flowCodeInside = undefined;
  }
  function onexitcodeindented() {
    const data = this.resume();
    const node = this.stack[this.stack.length - 1];
    node.value = data.replace(/(\r?\n|\r)$/g, "");
  }
  function onexitdefinitionlabelstring(token) {
    const label = this.resume();
    const node = this.stack[this.stack.length - 1];
    node.label = label;
    node.identifier = normalizeIdentifier(this.sliceSerialize(token)).toLowerCase();
  }
  function onexitdefinitiontitlestring() {
    const data = this.resume();
    const node = this.stack[this.stack.length - 1];
    node.title = data;
  }
  function onexitdefinitiondestinationstring() {
    const data = this.resume();
    const node = this.stack[this.stack.length - 1];
    node.url = data;
  }
  function onexitatxheadingsequence(token) {
    const node = this.stack[this.stack.length - 1];
    if (!node.depth) {
      const depth = this.sliceSerialize(token).length;
      node.depth = depth;
    }
  }
  function onexitsetextheadingtext() {
    this.data.setextHeadingSlurpLineEnding = true;
  }
  function onexitsetextheadinglinesequence(token) {
    const node = this.stack[this.stack.length - 1];
    node.depth = this.sliceSerialize(token).codePointAt(0) === 61 ? 1 : 2;
  }
  function onexitsetextheading() {
    this.data.setextHeadingSlurpLineEnding = undefined;
  }
  function onenterdata(token) {
    const node = this.stack[this.stack.length - 1];
    const siblings = node.children;
    let tail = siblings[siblings.length - 1];
    if (!tail || tail.type !== "text") {
      tail = text();
      tail.position = {
        start: point3(token.start),
        end: undefined
      };
      siblings.push(tail);
    }
    this.stack.push(tail);
  }
  function onexitdata(token) {
    const tail = this.stack.pop();
    tail.value += this.sliceSerialize(token);
    tail.position.end = point3(token.end);
  }
  function onexitlineending(token) {
    const context = this.stack[this.stack.length - 1];
    if (this.data.atHardBreak) {
      const tail = context.children[context.children.length - 1];
      tail.position.end = point3(token.end);
      this.data.atHardBreak = undefined;
      return;
    }
    if (!this.data.setextHeadingSlurpLineEnding && config.canContainEols.includes(context.type)) {
      onenterdata.call(this, token);
      onexitdata.call(this, token);
    }
  }
  function onexithardbreak() {
    this.data.atHardBreak = true;
  }
  function onexithtmlflow() {
    const data = this.resume();
    const node = this.stack[this.stack.length - 1];
    node.value = data;
  }
  function onexithtmltext() {
    const data = this.resume();
    const node = this.stack[this.stack.length - 1];
    node.value = data;
  }
  function onexitcodetext() {
    const data = this.resume();
    const node = this.stack[this.stack.length - 1];
    node.value = data;
  }
  function onexitlink() {
    const node = this.stack[this.stack.length - 1];
    if (this.data.inReference) {
      const referenceType = this.data.referenceType || "shortcut";
      node.type += "Reference";
      node.referenceType = referenceType;
      delete node.url;
      delete node.title;
    } else {
      delete node.identifier;
      delete node.label;
    }
    this.data.referenceType = undefined;
  }
  function onexitimage() {
    const node = this.stack[this.stack.length - 1];
    if (this.data.inReference) {
      const referenceType = this.data.referenceType || "shortcut";
      node.type += "Reference";
      node.referenceType = referenceType;
      delete node.url;
      delete node.title;
    } else {
      delete node.identifier;
      delete node.label;
    }
    this.data.referenceType = undefined;
  }
  function onexitlabeltext(token) {
    const string = this.sliceSerialize(token);
    const ancestor = this.stack[this.stack.length - 2];
    ancestor.label = decodeString(string);
    ancestor.identifier = normalizeIdentifier(string).toLowerCase();
  }
  function onexitlabel() {
    const fragment = this.stack[this.stack.length - 1];
    const value = this.resume();
    const node = this.stack[this.stack.length - 1];
    this.data.inReference = true;
    if (node.type === "link") {
      const children = fragment.children;
      node.children = children;
    } else {
      node.alt = value;
    }
  }
  function onexitresourcedestinationstring() {
    const data = this.resume();
    const node = this.stack[this.stack.length - 1];
    node.url = data;
  }
  function onexitresourcetitlestring() {
    const data = this.resume();
    const node = this.stack[this.stack.length - 1];
    node.title = data;
  }
  function onexitresource() {
    this.data.inReference = undefined;
  }
  function onenterreference() {
    this.data.referenceType = "collapsed";
  }
  function onexitreferencestring(token) {
    const label = this.resume();
    const node = this.stack[this.stack.length - 1];
    node.label = label;
    node.identifier = normalizeIdentifier(this.sliceSerialize(token)).toLowerCase();
    this.data.referenceType = "full";
  }
  function onexitcharacterreferencemarker(token) {
    this.data.characterReferenceType = token.type;
  }
  function onexitcharacterreferencevalue(token) {
    const data = this.sliceSerialize(token);
    const type = this.data.characterReferenceType;
    let value;
    if (type) {
      value = decodeNumericCharacterReference(data, type === "characterReferenceMarkerNumeric" ? 10 : 16);
      this.data.characterReferenceType = undefined;
    } else {
      const result = decodeNamedCharacterReference(data);
      value = result;
    }
    const tail = this.stack[this.stack.length - 1];
    tail.value += value;
  }
  function onexitcharacterreference(token) {
    const tail = this.stack.pop();
    tail.position.end = point3(token.end);
  }
  function onexitautolinkprotocol(token) {
    onexitdata.call(this, token);
    const node = this.stack[this.stack.length - 1];
    node.url = this.sliceSerialize(token);
  }
  function onexitautolinkemail(token) {
    onexitdata.call(this, token);
    const node = this.stack[this.stack.length - 1];
    node.url = "mailto:" + this.sliceSerialize(token);
  }
  function blockQuote() {
    return {
      type: "blockquote",
      children: [],
      position: undefined
    };
  }
  function codeFlow() {
    return {
      type: "code",
      lang: null,
      meta: null,
      value: "",
      position: undefined
    };
  }
  function codeText() {
    return {
      type: "inlineCode",
      value: "",
      position: undefined
    };
  }
  function definition() {
    return {
      type: "definition",
      identifier: "",
      label: null,
      title: null,
      url: "",
      position: undefined
    };
  }
  function emphasis() {
    return {
      type: "emphasis",
      children: [],
      position: undefined
    };
  }
  function heading() {
    return {
      type: "heading",
      depth: 0,
      children: [],
      position: undefined
    };
  }
  function hardBreak() {
    return {
      type: "break",
      position: undefined
    };
  }
  function html() {
    return {
      type: "html",
      value: "",
      position: undefined
    };
  }
  function image() {
    return {
      type: "image",
      title: null,
      url: "",
      alt: null,
      position: undefined
    };
  }
  function link() {
    return {
      type: "link",
      title: null,
      url: "",
      children: [],
      position: undefined
    };
  }
  function list(token) {
    return {
      type: "list",
      ordered: token.type === "listOrdered",
      start: null,
      spread: token._spread,
      children: [],
      position: undefined
    };
  }
  function listItem(token) {
    return {
      type: "listItem",
      spread: token._spread,
      checked: null,
      children: [],
      position: undefined
    };
  }
  function paragraph() {
    return {
      type: "paragraph",
      children: [],
      position: undefined
    };
  }
  function strong() {
    return {
      type: "strong",
      children: [],
      position: undefined
    };
  }
  function text() {
    return {
      type: "text",
      value: "",
      position: undefined
    };
  }
  function thematicBreak() {
    return {
      type: "thematicBreak",
      position: undefined
    };
  }
}
function point3(d) {
  return {
    line: d.line,
    column: d.column,
    offset: d.offset
  };
}
function configure(combined, extensions) {
  let index = -1;
  while (++index < extensions.length) {
    const value = extensions[index];
    if (Array.isArray(value)) {
      configure(combined, value);
    } else {
      extension(combined, value);
    }
  }
}
function extension(combined, extension) {
  let key;
  for (key in extension) {
    if (own2.call(extension, key)) {
      switch (key) {
        case "canContainEols": {
          const right = extension[key];
          if (right) {
            combined[key].push(...right);
          }
          break;
        }
        case "transforms": {
          const right = extension[key];
          if (right) {
            combined[key].push(...right);
          }
          break;
        }
        case "afterExit":
        case "beforeEnter": {
          const right = extension[key];
          if (right) {
            combined[key].push(right);
          }
          break;
        }
        case "enter":
        case "exit": {
          const right = extension[key];
          if (right) {
            Object.assign(combined[key], right);
          }
          break;
        }
      }
    }
  }
}
function defaultOnError(left, right) {
  if (left) {
    throw new Error("Cannot close `" + left.type + "` (" + stringifyPosition({
      start: left.start,
      end: left.end
    }) + "): a different token (`" + right.type + "`, " + stringifyPosition({
      start: right.start,
      end: right.end
    }) + ") is open");
  }
  throw new Error("Cannot close document, a token (`" + right.type + "`, " + stringifyPosition({
    start: right.start,
    end: right.end
  }) + ") is still open");
}
// node_modules/remark-parse/lib/index.js
function remarkParse(options) {
  const self2 = this;
  self2.parser = parser;
  function parser(doc) {
    return fromMarkdown(doc, {
      ...self2.data("settings"),
      ...options,
      extensions: self2.data("micromarkExtensions") || [],
      mdastExtensions: self2.data("fromMarkdownExtensions") || []
    });
  }
}
// node_modules/@ungap/structured-clone/esm/types.js
var VOID = -1;
var PRIMITIVE = 0;
var ARRAY = 1;
var OBJECT = 2;
var DATE = 3;
var REGEXP = 4;
var MAP = 5;
var SET = 6;
var ERROR = 7;
var BIGINT = 8;

// node_modules/@ungap/structured-clone/esm/deserialize.js
var { defineProperty } = Object;
var env = typeof self === "object" ? self : globalThis;
var guard = (name, init) => {
  switch (name) {
    case "Function":
    case "SharedWorker":
    case "Worker":
    case "eval":
    case "setInterval":
    case "setTimeout":
      throw new TypeError("unable to deserialize " + name);
  }
  return new env[name](init);
};
var deserializer = ($, _) => {
  const as = (out, index) => {
    $.set(index, out);
    return out;
  };
  const unpair = (index) => {
    if ($.has(index))
      return $.get(index);
    const [type, value] = _[index];
    switch (type) {
      case PRIMITIVE:
      case VOID:
        return as(value, index);
      case ARRAY: {
        const arr = as([], index);
        for (const index of value)
          arr.push(unpair(index));
        return arr;
      }
      case OBJECT: {
        const object = as({}, index);
        for (const [key, index] of value) {
          const k = unpair(key), value = unpair(index);
          if (k === "__proto__")
            defineProperty(object, k, {
              value,
              configurable: true,
              enumerable: true,
              writable: true
            });
          else
            object[k] = value;
        }
        return object;
      }
      case DATE:
        return as(new Date(value), index);
      case REGEXP: {
        const { source, flags } = value;
        return as(new RegExp(source, flags), index);
      }
      case MAP: {
        const map = as(new Map, index);
        for (const [key, index] of value)
          map.set(unpair(key), unpair(index));
        return map;
      }
      case SET: {
        const set = as(new Set, index);
        for (const index of value)
          set.add(unpair(index));
        return set;
      }
      case ERROR: {
        const { name, message } = value;
        return as(typeof env[name] === "function" ? guard(name, message) : new Error(message), index);
      }
      case BIGINT:
        return as(BigInt(value), index);
      case "BigInt":
        return as(Object(BigInt(value)), index);
      case "ArrayBuffer":
        return as(new Uint8Array(value).buffer, value);
      case "DataView": {
        const { buffer } = new Uint8Array(value);
        return as(new DataView(buffer), value);
      }
      case "-0":
        return -0;
    }
    return as(guard(type, value), index);
  };
  return unpair;
};
var deserialize = (serialized) => deserializer(new Map, serialized)(0);

// node_modules/@ungap/structured-clone/esm/serialize.js
var EMPTY = "";
var { toString: toString2 } = {};
var { keys, is } = Object;
var typeOf = (value) => {
  const type = typeof value;
  if (type !== "object" || !value)
    return [PRIMITIVE, type];
  const asString = toString2.call(value).slice(8, -1);
  switch (asString) {
    case "Array":
      return [ARRAY, EMPTY];
    case "Object":
      return [OBJECT, EMPTY];
    case "Date":
      return [DATE, EMPTY];
    case "RegExp":
      return [REGEXP, EMPTY];
    case "Map":
      return [MAP, EMPTY];
    case "Set":
      return [SET, EMPTY];
    case "DataView":
      return [ARRAY, asString];
  }
  if (asString.includes("Array"))
    return [ARRAY, asString];
  if (value instanceof Error)
    return [ERROR, value.name || "Error"];
  return [OBJECT, asString];
};
var shouldSkip = ([TYPE, type]) => TYPE === PRIMITIVE && (type === "function" || type === "symbol");
var serializer = (strict, json, $, _) => {
  const as = (out, value) => {
    const index = _.push(out) - 1;
    $.set(value, index);
    return index;
  };
  const pair = (value) => {
    if ($.has(value))
      return $.get(value);
    let [TYPE, type] = typeOf(value);
    switch (TYPE) {
      case PRIMITIVE: {
        let entry = value;
        switch (type) {
          case "bigint":
            TYPE = BIGINT;
            entry = value.toString();
            break;
          case "number":
            if (!value && is(value, -0))
              return _.push(["-0"]) - 1;
            break;
          case "function":
          case "symbol":
            if (strict)
              throw new TypeError("unable to serialize " + type);
            entry = null;
            break;
          case "undefined":
            return as([VOID], value);
        }
        return as([TYPE, entry], value);
      }
      case ARRAY: {
        if (type) {
          let spread = value;
          if (type === "DataView") {
            spread = new Uint8Array(value.buffer);
          } else if (type === "ArrayBuffer") {
            spread = new Uint8Array(value);
          }
          return as([type, [...spread]], value);
        }
        const arr = [];
        const index = as([TYPE, arr], value);
        for (const entry of value)
          arr.push(pair(entry));
        return index;
      }
      case OBJECT: {
        if (type) {
          switch (type) {
            case "BigInt":
              return as([type, value.toString()], value);
            case "Boolean":
            case "Number":
            case "String":
              return as([type, value.valueOf()], value);
          }
        }
        if (json && "toJSON" in value)
          return pair(value.toJSON());
        const entries = [];
        const index = as([TYPE, entries], value);
        for (const key of keys(value)) {
          if (strict || !shouldSkip(typeOf(value[key])))
            entries.push([pair(key), pair(value[key])]);
        }
        return index;
      }
      case DATE:
        return as([TYPE, isNaN(value.getTime()) ? EMPTY : value.toISOString()], value);
      case REGEXP: {
        const { source, flags } = value;
        return as([TYPE, { source, flags }], value);
      }
      case MAP: {
        const entries = [];
        const index = as([TYPE, entries], value);
        for (const [key, entry] of value) {
          if (strict || !(shouldSkip(typeOf(key)) || shouldSkip(typeOf(entry))))
            entries.push([pair(key), pair(entry)]);
        }
        return index;
      }
      case SET: {
        const entries = [];
        const index = as([TYPE, entries], value);
        for (const entry of value) {
          if (strict || !shouldSkip(typeOf(entry)))
            entries.push(pair(entry));
        }
        return index;
      }
    }
    const { message } = value;
    return as([TYPE, { name: type, message }], value);
  };
  return pair;
};
var serialize = (value, { json, lossy } = {}) => {
  const _ = [];
  return serializer(!(json || lossy), !!json, new Map, _)(value), _;
};

// node_modules/@ungap/structured-clone/esm/index.js
var esm_default = typeof structuredClone === "function" ? (any, options) => options && (("json" in options) || ("lossy" in options)) ? deserialize(serialize(any, options)) : structuredClone(any) : (any, options) => deserialize(serialize(any, options));

// node_modules/mdast-util-to-hast/lib/footer.js
function defaultFootnoteBackContent(_, rereferenceIndex) {
  const result = [{ type: "text", value: "↩" }];
  if (rereferenceIndex > 1) {
    result.push({
      type: "element",
      tagName: "sup",
      properties: {},
      children: [{ type: "text", value: String(rereferenceIndex) }]
    });
  }
  return result;
}
function defaultFootnoteBackLabel(referenceIndex, rereferenceIndex) {
  return "Back to reference " + (referenceIndex + 1) + (rereferenceIndex > 1 ? "-" + rereferenceIndex : "");
}
function footer(state) {
  const clobberPrefix = typeof state.options.clobberPrefix === "string" ? state.options.clobberPrefix : "user-content-";
  const footnoteBackContent = state.options.footnoteBackContent || defaultFootnoteBackContent;
  const footnoteBackLabel = state.options.footnoteBackLabel || defaultFootnoteBackLabel;
  const footnoteLabel = state.options.footnoteLabel || "Footnotes";
  const footnoteLabelTagName = state.options.footnoteLabelTagName || "h2";
  const footnoteLabelProperties = state.options.footnoteLabelProperties || {
    className: ["sr-only"]
  };
  const listItems = [];
  let referenceIndex = -1;
  while (++referenceIndex < state.footnoteOrder.length) {
    const definition = state.footnoteById.get(state.footnoteOrder[referenceIndex]);
    if (!definition) {
      continue;
    }
    const content = state.all(definition);
    const id = String(definition.identifier).toUpperCase();
    const safeId = normalizeUri(id.toLowerCase());
    let rereferenceIndex = 0;
    const backReferences = [];
    const counts = state.footnoteCounts.get(id);
    while (counts !== undefined && ++rereferenceIndex <= counts) {
      if (backReferences.length > 0) {
        backReferences.push({ type: "text", value: " " });
      }
      let children = typeof footnoteBackContent === "string" ? footnoteBackContent : footnoteBackContent(referenceIndex, rereferenceIndex);
      if (typeof children === "string") {
        children = { type: "text", value: children };
      }
      backReferences.push({
        type: "element",
        tagName: "a",
        properties: {
          href: "#" + clobberPrefix + "fnref-" + safeId + (rereferenceIndex > 1 ? "-" + rereferenceIndex : ""),
          dataFootnoteBackref: "",
          ariaLabel: typeof footnoteBackLabel === "string" ? footnoteBackLabel : footnoteBackLabel(referenceIndex, rereferenceIndex),
          className: ["data-footnote-backref"]
        },
        children: Array.isArray(children) ? children : [children]
      });
    }
    const tail = content[content.length - 1];
    if (tail && tail.type === "element" && tail.tagName === "p") {
      const tailTail = tail.children[tail.children.length - 1];
      if (tailTail && tailTail.type === "text") {
        tailTail.value += " ";
      } else {
        tail.children.push({ type: "text", value: " " });
      }
      tail.children.push(...backReferences);
    } else {
      content.push(...backReferences);
    }
    const listItem = {
      type: "element",
      tagName: "li",
      properties: { id: clobberPrefix + "fn-" + safeId },
      children: state.wrap(content, true)
    };
    state.patch(definition, listItem);
    listItems.push(listItem);
  }
  if (listItems.length === 0) {
    return;
  }
  return {
    type: "element",
    tagName: "section",
    properties: { dataFootnotes: true, className: ["footnotes"] },
    children: [
      {
        type: "element",
        tagName: footnoteLabelTagName,
        properties: {
          ...esm_default(footnoteLabelProperties),
          id: "footnote-label"
        },
        children: [{ type: "text", value: footnoteLabel }]
      },
      { type: "text", value: `
` },
      {
        type: "element",
        tagName: "ol",
        properties: {},
        children: state.wrap(listItems, true)
      },
      { type: "text", value: `
` }
    ]
  };
}

// node_modules/unist-util-is/lib/index.js
var convert = function(test) {
  if (test === null || test === undefined) {
    return ok3;
  }
  if (typeof test === "function") {
    return castFactory(test);
  }
  if (typeof test === "object") {
    return Array.isArray(test) ? anyFactory(test) : propertiesFactory(test);
  }
  if (typeof test === "string") {
    return typeFactory(test);
  }
  throw new Error("Expected function, string, or object as test");
};
function anyFactory(tests) {
  const checks = [];
  let index = -1;
  while (++index < tests.length) {
    checks[index] = convert(tests[index]);
  }
  return castFactory(any);
  function any(...parameters) {
    let index = -1;
    while (++index < checks.length) {
      if (checks[index].apply(this, parameters))
        return true;
    }
    return false;
  }
}
function propertiesFactory(check) {
  const checkAsRecord = check;
  return castFactory(all);
  function all(node) {
    const nodeAsRecord = node;
    let key;
    for (key in check) {
      if (nodeAsRecord[key] !== checkAsRecord[key])
        return false;
    }
    return true;
  }
}
function typeFactory(check) {
  return castFactory(type);
  function type(node) {
    return node && node.type === check;
  }
}
function castFactory(testFunction) {
  return check;
  function check(value, index, parent) {
    return Boolean(looksLikeANode(value) && testFunction.call(this, value, typeof index === "number" ? index : undefined, parent || undefined));
  }
}
function ok3() {
  return true;
}
function looksLikeANode(value) {
  return value !== null && typeof value === "object" && "type" in value;
}
// node_modules/unist-util-visit-parents/lib/color.js
function color(d) {
  return d;
}

// node_modules/unist-util-visit-parents/lib/index.js
var empty2 = [];
var CONTINUE = true;
var EXIT = false;
var SKIP = "skip";
function visitParents(tree, test, visitor, reverse) {
  let check;
  if (typeof test === "function" && typeof visitor !== "function") {
    reverse = visitor;
    visitor = test;
  } else {
    check = test;
  }
  const is = convert(check);
  const step = reverse ? -1 : 1;
  factory(tree, undefined, [])();
  function factory(node, index, parents) {
    const value = node && typeof node === "object" ? node : {};
    if (typeof value.type === "string") {
      const name = typeof value.tagName === "string" ? value.tagName : typeof value.name === "string" ? value.name : undefined;
      Object.defineProperty(visit, "name", {
        value: "node (" + color(node.type + (name ? "<" + name + ">" : "")) + ")"
      });
    }
    return visit;
    function visit() {
      let result = empty2;
      let subresult;
      let offset;
      let grandparents;
      if (!test || is(node, index, parents[parents.length - 1] || undefined)) {
        result = toResult(visitor(node, parents));
        if (result[0] === EXIT) {
          return result;
        }
      }
      if ("children" in node && node.children) {
        const nodeAsParent = node;
        if (nodeAsParent.children && result[0] !== SKIP) {
          offset = (reverse ? nodeAsParent.children.length : -1) + step;
          grandparents = parents.concat(nodeAsParent);
          while (offset > -1 && offset < nodeAsParent.children.length) {
            const child = nodeAsParent.children[offset];
            subresult = factory(child, offset, grandparents)();
            if (subresult[0] === EXIT) {
              return subresult;
            }
            offset = typeof subresult[1] === "number" ? subresult[1] : offset + step;
          }
        }
      }
      return result;
    }
  }
}
function toResult(value) {
  if (Array.isArray(value)) {
    return value;
  }
  if (typeof value === "number") {
    return [CONTINUE, value];
  }
  return value === null || value === undefined ? empty2 : [value];
}
// node_modules/unist-util-visit/lib/index.js
function visit(tree, testOrVisitor, visitorOrReverse, maybeReverse) {
  let reverse;
  let test;
  let visitor;
  if (typeof testOrVisitor === "function" && typeof visitorOrReverse !== "function") {
    test = undefined;
    visitor = testOrVisitor;
    reverse = visitorOrReverse;
  } else {
    test = testOrVisitor;
    visitor = visitorOrReverse;
    reverse = maybeReverse;
  }
  visitParents(tree, test, overload, reverse);
  function overload(node, parents) {
    const parent = parents[parents.length - 1];
    const index = parent ? parent.children.indexOf(node) : undefined;
    return visitor(node, index, parent);
  }
}
// node_modules/mdast-util-to-hast/lib/handlers/blockquote.js
function blockquote(state, node) {
  const result = {
    type: "element",
    tagName: "blockquote",
    properties: {},
    children: state.wrap(state.all(node), true)
  };
  state.patch(node, result);
  return state.applyData(node, result);
}

// node_modules/mdast-util-to-hast/lib/handlers/break.js
function hardBreak(state, node) {
  const result = { type: "element", tagName: "br", properties: {}, children: [] };
  state.patch(node, result);
  return [state.applyData(node, result), { type: "text", value: `
` }];
}

// node_modules/mdast-util-to-hast/lib/handlers/code.js
function code(state, node) {
  const value = node.value ? node.value + `
` : "";
  const properties = {};
  const language = node.lang ? node.lang.split(/\s+/) : [];
  if (language.length > 0) {
    properties.className = ["language-" + language[0]];
  }
  let result = {
    type: "element",
    tagName: "code",
    properties,
    children: [{ type: "text", value }]
  };
  if (node.meta) {
    result.data = { meta: node.meta };
  }
  state.patch(node, result);
  result = state.applyData(node, result);
  result = { type: "element", tagName: "pre", properties: {}, children: [result] };
  state.patch(node, result);
  return result;
}

// node_modules/mdast-util-to-hast/lib/handlers/delete.js
function strikethrough(state, node) {
  const result = {
    type: "element",
    tagName: "del",
    properties: {},
    children: state.all(node)
  };
  state.patch(node, result);
  return state.applyData(node, result);
}

// node_modules/mdast-util-to-hast/lib/handlers/emphasis.js
function emphasis(state, node) {
  const result = {
    type: "element",
    tagName: "em",
    properties: {},
    children: state.all(node)
  };
  state.patch(node, result);
  return state.applyData(node, result);
}

// node_modules/mdast-util-to-hast/lib/handlers/footnote-reference.js
function footnoteReference(state, node) {
  const clobberPrefix = typeof state.options.clobberPrefix === "string" ? state.options.clobberPrefix : "user-content-";
  const id = String(node.identifier).toUpperCase();
  const safeId = normalizeUri(id.toLowerCase());
  const index = state.footnoteOrder.indexOf(id);
  let counter;
  let reuseCounter = state.footnoteCounts.get(id);
  if (reuseCounter === undefined) {
    reuseCounter = 0;
    state.footnoteOrder.push(id);
    counter = state.footnoteOrder.length;
  } else {
    counter = index + 1;
  }
  reuseCounter += 1;
  state.footnoteCounts.set(id, reuseCounter);
  const link = {
    type: "element",
    tagName: "a",
    properties: {
      href: "#" + clobberPrefix + "fn-" + safeId,
      id: clobberPrefix + "fnref-" + safeId + (reuseCounter > 1 ? "-" + reuseCounter : ""),
      dataFootnoteRef: true,
      ariaDescribedBy: ["footnote-label"]
    },
    children: [{ type: "text", value: String(counter) }]
  };
  state.patch(node, link);
  const sup = {
    type: "element",
    tagName: "sup",
    properties: {},
    children: [link]
  };
  state.patch(node, sup);
  return state.applyData(node, sup);
}

// node_modules/mdast-util-to-hast/lib/handlers/heading.js
function heading(state, node) {
  const result = {
    type: "element",
    tagName: "h" + node.depth,
    properties: {},
    children: state.all(node)
  };
  state.patch(node, result);
  return state.applyData(node, result);
}

// node_modules/mdast-util-to-hast/lib/handlers/html.js
function html3(state, node) {
  if (state.options.allowDangerousHtml) {
    const result = { type: "raw", value: node.value };
    state.patch(node, result);
    return state.applyData(node, result);
  }
  return;
}

// node_modules/mdast-util-to-hast/lib/revert.js
function revert(state, node) {
  const subtype = node.referenceType;
  let suffix = "]";
  if (subtype === "collapsed") {
    suffix += "[]";
  } else if (subtype === "full") {
    suffix += "[" + (node.label || node.identifier) + "]";
  }
  if (node.type === "imageReference") {
    return [{ type: "text", value: "![" + node.alt + suffix }];
  }
  const contents = state.all(node);
  const head = contents[0];
  if (head && head.type === "text") {
    head.value = "[" + head.value;
  } else {
    contents.unshift({ type: "text", value: "[" });
  }
  const tail = contents[contents.length - 1];
  if (tail && tail.type === "text") {
    tail.value += suffix;
  } else {
    contents.push({ type: "text", value: suffix });
  }
  return contents;
}

// node_modules/mdast-util-to-hast/lib/handlers/image-reference.js
function imageReference(state, node) {
  const id = String(node.identifier).toUpperCase();
  const definition = state.definitionById.get(id);
  if (!definition) {
    return revert(state, node);
  }
  const properties = { src: normalizeUri(definition.url || ""), alt: node.alt };
  if (definition.title !== null && definition.title !== undefined) {
    properties.title = definition.title;
  }
  const result = { type: "element", tagName: "img", properties, children: [] };
  state.patch(node, result);
  return state.applyData(node, result);
}

// node_modules/mdast-util-to-hast/lib/handlers/image.js
function image(state, node) {
  const properties = { src: normalizeUri(node.url) };
  if (node.alt !== null && node.alt !== undefined) {
    properties.alt = node.alt;
  }
  if (node.title !== null && node.title !== undefined) {
    properties.title = node.title;
  }
  const result = { type: "element", tagName: "img", properties, children: [] };
  state.patch(node, result);
  return state.applyData(node, result);
}

// node_modules/mdast-util-to-hast/lib/handlers/inline-code.js
function inlineCode(state, node) {
  const text = { type: "text", value: node.value.replace(/\r?\n|\r/g, " ") };
  state.patch(node, text);
  const result = {
    type: "element",
    tagName: "code",
    properties: {},
    children: [text]
  };
  state.patch(node, result);
  return state.applyData(node, result);
}

// node_modules/mdast-util-to-hast/lib/handlers/link-reference.js
function linkReference(state, node) {
  const id = String(node.identifier).toUpperCase();
  const definition = state.definitionById.get(id);
  if (!definition) {
    return revert(state, node);
  }
  const properties = { href: normalizeUri(definition.url || "") };
  if (definition.title !== null && definition.title !== undefined) {
    properties.title = definition.title;
  }
  const result = {
    type: "element",
    tagName: "a",
    properties,
    children: state.all(node)
  };
  state.patch(node, result);
  return state.applyData(node, result);
}

// node_modules/mdast-util-to-hast/lib/handlers/link.js
function link(state, node) {
  const properties = { href: normalizeUri(node.url) };
  if (node.title !== null && node.title !== undefined) {
    properties.title = node.title;
  }
  const result = {
    type: "element",
    tagName: "a",
    properties,
    children: state.all(node)
  };
  state.patch(node, result);
  return state.applyData(node, result);
}

// node_modules/mdast-util-to-hast/lib/handlers/list-item.js
function listItem(state, node, parent) {
  const results = state.all(node);
  const loose = parent ? listLoose(parent) : listItemLoose(node);
  const properties = {};
  const children = [];
  if (typeof node.checked === "boolean") {
    const head = results[0];
    let paragraph;
    if (head && head.type === "element" && head.tagName === "p") {
      paragraph = head;
    } else {
      paragraph = { type: "element", tagName: "p", properties: {}, children: [] };
      results.unshift(paragraph);
    }
    if (paragraph.children.length > 0) {
      paragraph.children.unshift({ type: "text", value: " " });
    }
    paragraph.children.unshift({
      type: "element",
      tagName: "input",
      properties: { type: "checkbox", checked: node.checked, disabled: true },
      children: []
    });
    properties.className = ["task-list-item"];
  }
  let index = -1;
  while (++index < results.length) {
    const child = results[index];
    if (loose || index !== 0 || child.type !== "element" || child.tagName !== "p") {
      children.push({ type: "text", value: `
` });
    }
    if (child.type === "element" && child.tagName === "p" && !loose) {
      children.push(...child.children);
    } else {
      children.push(child);
    }
  }
  const tail = results[results.length - 1];
  if (tail && (loose || tail.type !== "element" || tail.tagName !== "p")) {
    children.push({ type: "text", value: `
` });
  }
  const result = { type: "element", tagName: "li", properties, children };
  state.patch(node, result);
  return state.applyData(node, result);
}
function listLoose(node) {
  let loose = false;
  if (node.type === "list") {
    loose = node.spread || false;
    const children = node.children;
    let index = -1;
    while (!loose && ++index < children.length) {
      loose = listItemLoose(children[index]);
    }
  }
  return loose;
}
function listItemLoose(node) {
  const spread = node.spread;
  return spread === null || spread === undefined ? node.children.length > 1 : spread;
}

// node_modules/mdast-util-to-hast/lib/handlers/list.js
function list2(state, node) {
  const properties = {};
  const results = state.all(node);
  let index = -1;
  if (typeof node.start === "number" && node.start !== 1) {
    properties.start = node.start;
  }
  while (++index < results.length) {
    const child = results[index];
    if (child.type === "element" && child.tagName === "li" && child.properties && Array.isArray(child.properties.className) && child.properties.className.includes("task-list-item")) {
      properties.className = ["contains-task-list"];
      break;
    }
  }
  const result = {
    type: "element",
    tagName: node.ordered ? "ol" : "ul",
    properties,
    children: state.wrap(results, true)
  };
  state.patch(node, result);
  return state.applyData(node, result);
}

// node_modules/mdast-util-to-hast/lib/handlers/paragraph.js
function paragraph(state, node) {
  const result = {
    type: "element",
    tagName: "p",
    properties: {},
    children: state.all(node)
  };
  state.patch(node, result);
  return state.applyData(node, result);
}

// node_modules/mdast-util-to-hast/lib/handlers/root.js
function root2(state, node) {
  const result = { type: "root", children: state.wrap(state.all(node)) };
  state.patch(node, result);
  return state.applyData(node, result);
}

// node_modules/mdast-util-to-hast/lib/handlers/strong.js
function strong(state, node) {
  const result = {
    type: "element",
    tagName: "strong",
    properties: {},
    children: state.all(node)
  };
  state.patch(node, result);
  return state.applyData(node, result);
}

// node_modules/mdast-util-to-hast/lib/handlers/table.js
function table(state, node) {
  const rows = state.all(node);
  const firstRow = rows.shift();
  const tableContent = [];
  if (firstRow) {
    const head = {
      type: "element",
      tagName: "thead",
      properties: {},
      children: state.wrap([firstRow], true)
    };
    state.patch(node.children[0], head);
    tableContent.push(head);
  }
  if (rows.length > 0) {
    const body = {
      type: "element",
      tagName: "tbody",
      properties: {},
      children: state.wrap(rows, true)
    };
    const start = pointStart(node.children[1]);
    const end = pointEnd(node.children[node.children.length - 1]);
    if (start && end)
      body.position = { start, end };
    tableContent.push(body);
  }
  const result = {
    type: "element",
    tagName: "table",
    properties: {},
    children: state.wrap(tableContent, true)
  };
  state.patch(node, result);
  return state.applyData(node, result);
}

// node_modules/mdast-util-to-hast/lib/handlers/table-row.js
function tableRow(state, node, parent) {
  const siblings = parent ? parent.children : undefined;
  const rowIndex = siblings ? siblings.indexOf(node) : 1;
  const tagName = rowIndex === 0 ? "th" : "td";
  const align = parent && parent.type === "table" ? parent.align : undefined;
  const length = align ? align.length : node.children.length;
  let cellIndex = -1;
  const cells = [];
  while (++cellIndex < length) {
    const cell = node.children[cellIndex];
    const properties = {};
    const alignValue = align ? align[cellIndex] : undefined;
    if (alignValue) {
      properties.align = alignValue;
    }
    let result = { type: "element", tagName, properties, children: [] };
    if (cell) {
      result.children = state.all(cell);
      state.patch(cell, result);
      result = state.applyData(cell, result);
    }
    cells.push(result);
  }
  const result = {
    type: "element",
    tagName: "tr",
    properties: {},
    children: state.wrap(cells, true)
  };
  state.patch(node, result);
  return state.applyData(node, result);
}

// node_modules/mdast-util-to-hast/lib/handlers/table-cell.js
function tableCell(state, node) {
  const result = {
    type: "element",
    tagName: "td",
    properties: {},
    children: state.all(node)
  };
  state.patch(node, result);
  return state.applyData(node, result);
}

// node_modules/trim-lines/index.js
var tab = 9;
var space = 32;
function trimLines(value) {
  const source = String(value);
  const search = /\r?\n|\r/g;
  let match = search.exec(source);
  let last = 0;
  const lines = [];
  while (match) {
    lines.push(trimLine(source.slice(last, match.index), last > 0, true), match[0]);
    last = match.index + match[0].length;
    match = search.exec(source);
  }
  lines.push(trimLine(source.slice(last), last > 0, false));
  return lines.join("");
}
function trimLine(value, start, end) {
  let startIndex = 0;
  let endIndex = value.length;
  if (start) {
    let code = value.codePointAt(startIndex);
    while (code === tab || code === space) {
      startIndex++;
      code = value.codePointAt(startIndex);
    }
  }
  if (end) {
    let code = value.codePointAt(endIndex - 1);
    while (code === tab || code === space) {
      endIndex--;
      code = value.codePointAt(endIndex - 1);
    }
  }
  return endIndex > startIndex ? value.slice(startIndex, endIndex) : "";
}

// node_modules/mdast-util-to-hast/lib/handlers/text.js
function text4(state, node) {
  const result = { type: "text", value: trimLines(String(node.value)) };
  state.patch(node, result);
  return state.applyData(node, result);
}

// node_modules/mdast-util-to-hast/lib/handlers/thematic-break.js
function thematicBreak2(state, node) {
  const result = {
    type: "element",
    tagName: "hr",
    properties: {},
    children: []
  };
  state.patch(node, result);
  return state.applyData(node, result);
}

// node_modules/mdast-util-to-hast/lib/handlers/index.js
var handlers = {
  blockquote,
  break: hardBreak,
  code,
  delete: strikethrough,
  emphasis,
  footnoteReference,
  heading,
  html: html3,
  imageReference,
  image,
  inlineCode,
  linkReference,
  link,
  listItem,
  list: list2,
  paragraph,
  root: root2,
  strong,
  table,
  tableCell,
  tableRow,
  text: text4,
  thematicBreak: thematicBreak2,
  toml: ignore,
  yaml: ignore,
  definition: ignore,
  footnoteDefinition: ignore
};
function ignore() {
  return;
}

// node_modules/mdast-util-to-hast/lib/state.js
var own3 = {}.hasOwnProperty;
var emptyOptions3 = {};
function createState(tree, options) {
  const settings = options || emptyOptions3;
  const definitionById = new Map;
  const footnoteById = new Map;
  const footnoteCounts = new Map;
  const handlers2 = { ...handlers, ...settings.handlers };
  const state = {
    all,
    applyData,
    definitionById,
    footnoteById,
    footnoteCounts,
    footnoteOrder: [],
    handlers: handlers2,
    one,
    options: settings,
    patch,
    wrap
  };
  visit(tree, function(node) {
    if (node.type === "definition" || node.type === "footnoteDefinition") {
      const map = node.type === "definition" ? definitionById : footnoteById;
      const id = String(node.identifier).toUpperCase();
      if (!map.has(id)) {
        map.set(id, node);
      }
    }
  });
  return state;
  function one(node, parent) {
    const type = node.type;
    const handle = state.handlers[type];
    if (own3.call(state.handlers, type) && handle) {
      return handle(state, node, parent);
    }
    if (state.options.passThrough && state.options.passThrough.includes(type)) {
      if ("children" in node) {
        const { children, ...shallow } = node;
        const result = esm_default(shallow);
        result.children = state.all(node);
        return result;
      }
      return esm_default(node);
    }
    const unknown = state.options.unknownHandler || defaultUnknownHandler;
    return unknown(state, node, parent);
  }
  function all(parent) {
    const values = [];
    if ("children" in parent) {
      const nodes = parent.children;
      let index = -1;
      while (++index < nodes.length) {
        const result = state.one(nodes[index], parent);
        if (result) {
          if (index && nodes[index - 1].type === "break") {
            if (!Array.isArray(result) && result.type === "text") {
              result.value = trimMarkdownSpaceStart(result.value);
            }
            if (!Array.isArray(result) && result.type === "element") {
              const head = result.children[0];
              if (head && head.type === "text") {
                head.value = trimMarkdownSpaceStart(head.value);
              }
            }
          }
          if (Array.isArray(result)) {
            values.push(...result);
          } else {
            values.push(result);
          }
        }
      }
    }
    return values;
  }
}
function patch(from, to) {
  if (from.position)
    to.position = position(from);
}
function applyData(from, to) {
  let result = to;
  if (from && from.data) {
    const hName = from.data.hName;
    const hChildren = from.data.hChildren;
    const hProperties = from.data.hProperties;
    if (typeof hName === "string") {
      if (result.type === "element") {
        result.tagName = hName;
      } else {
        const children = "children" in result ? result.children : [result];
        result = { type: "element", tagName: hName, properties: {}, children };
      }
    }
    if (result.type === "element" && hProperties) {
      Object.assign(result.properties, esm_default(hProperties));
    }
    if ("children" in result && result.children && hChildren !== null && hChildren !== undefined) {
      result.children = hChildren;
    }
  }
  return result;
}
function defaultUnknownHandler(state, node) {
  const data = node.data || {};
  const result = "value" in node && !(own3.call(data, "hProperties") || own3.call(data, "hChildren")) ? { type: "text", value: node.value } : {
    type: "element",
    tagName: "div",
    properties: {},
    children: state.all(node)
  };
  state.patch(node, result);
  return state.applyData(node, result);
}
function wrap(nodes, loose) {
  const result = [];
  let index = -1;
  if (loose) {
    result.push({ type: "text", value: `
` });
  }
  while (++index < nodes.length) {
    if (index)
      result.push({ type: "text", value: `
` });
    result.push(nodes[index]);
  }
  if (loose && nodes.length > 0) {
    result.push({ type: "text", value: `
` });
  }
  return result;
}
function trimMarkdownSpaceStart(value) {
  let index = 0;
  let code = value.charCodeAt(index);
  while (code === 9 || code === 32) {
    index++;
    code = value.charCodeAt(index);
  }
  return value.slice(index);
}

// node_modules/mdast-util-to-hast/lib/index.js
function toHast(tree, options) {
  const state = createState(tree, options);
  const node = state.one(tree, undefined);
  const foot = footer(state);
  const result = Array.isArray(node) ? { type: "root", children: node } : node || { type: "root", children: [] };
  if (foot) {
    ok2("children" in result);
    result.children.push({ type: "text", value: `
` }, foot);
  }
  return result;
}
// node_modules/remark-rehype/lib/index.js
function remarkRehype(destination, options) {
  if (destination && "run" in destination) {
    return async function(tree, file) {
      const hastTree = toHast(tree, { file, ...options });
      await destination.run(hastTree, file);
    };
  }
  return function(tree, file) {
    return toHast(tree, { file, ...destination || options });
  };
}
// node_modules/bail/index.js
function bail(error) {
  if (error) {
    throw error;
  }
}

// node_modules/unified/lib/index.js
var import_extend = __toESM(require_extend(), 1);

// node_modules/is-plain-obj/index.js
function isPlainObject(value) {
  if (typeof value !== "object" || value === null) {
    return false;
  }
  const prototype = Object.getPrototypeOf(value);
  return (prototype === null || prototype === Object.prototype || Object.getPrototypeOf(prototype) === null) && !(Symbol.toStringTag in value) && !(Symbol.iterator in value);
}

// node_modules/trough/lib/index.js
function trough() {
  const fns = [];
  const pipeline = { run, use };
  return pipeline;
  function run(...values) {
    let middlewareIndex = -1;
    const callback = values.pop();
    if (typeof callback !== "function") {
      throw new TypeError("Expected function as last argument, not " + callback);
    }
    next(null, ...values);
    function next(error, ...output) {
      const fn = fns[++middlewareIndex];
      let index = -1;
      if (error) {
        callback(error);
        return;
      }
      while (++index < values.length) {
        if (output[index] === null || output[index] === undefined) {
          output[index] = values[index];
        }
      }
      values = output;
      if (fn) {
        wrap2(fn, next)(...output);
      } else {
        callback(null, ...output);
      }
    }
  }
  function use(middelware) {
    if (typeof middelware !== "function") {
      throw new TypeError("Expected `middelware` to be a function, not " + middelware);
    }
    fns.push(middelware);
    return pipeline;
  }
}
function wrap2(middleware, callback) {
  let called;
  return wrapped;
  function wrapped(...parameters) {
    const fnExpectsCallback = middleware.length > parameters.length;
    let result;
    if (fnExpectsCallback) {
      parameters.push(done);
    }
    try {
      result = middleware.apply(this, parameters);
    } catch (error) {
      const exception = error;
      if (fnExpectsCallback && called) {
        throw exception;
      }
      return done(exception);
    }
    if (!fnExpectsCallback) {
      if (result && result.then && typeof result.then === "function") {
        result.then(then, done);
      } else if (result instanceof Error) {
        done(result);
      } else {
        then(result);
      }
    }
  }
  function done(error, ...output) {
    if (!called) {
      called = true;
      callback(error, ...output);
    }
  }
  function then(value) {
    done(null, value);
  }
}
// node_modules/vfile/lib/minpath.browser.js
var minpath = { basename, dirname, extname, join, sep: "/" };
function basename(path, extname) {
  if (extname !== undefined && typeof extname !== "string") {
    throw new TypeError('"ext" argument must be a string');
  }
  assertPath(path);
  let start = 0;
  let end = -1;
  let index = path.length;
  let seenNonSlash;
  if (extname === undefined || extname.length === 0 || extname.length > path.length) {
    while (index--) {
      if (path.codePointAt(index) === 47) {
        if (seenNonSlash) {
          start = index + 1;
          break;
        }
      } else if (end < 0) {
        seenNonSlash = true;
        end = index + 1;
      }
    }
    return end < 0 ? "" : path.slice(start, end);
  }
  if (extname === path) {
    return "";
  }
  let firstNonSlashEnd = -1;
  let extnameIndex = extname.length - 1;
  while (index--) {
    if (path.codePointAt(index) === 47) {
      if (seenNonSlash) {
        start = index + 1;
        break;
      }
    } else {
      if (firstNonSlashEnd < 0) {
        seenNonSlash = true;
        firstNonSlashEnd = index + 1;
      }
      if (extnameIndex > -1) {
        if (path.codePointAt(index) === extname.codePointAt(extnameIndex--)) {
          if (extnameIndex < 0) {
            end = index;
          }
        } else {
          extnameIndex = -1;
          end = firstNonSlashEnd;
        }
      }
    }
  }
  if (start === end) {
    end = firstNonSlashEnd;
  } else if (end < 0) {
    end = path.length;
  }
  return path.slice(start, end);
}
function dirname(path) {
  assertPath(path);
  if (path.length === 0) {
    return ".";
  }
  let end = -1;
  let index = path.length;
  let unmatchedSlash;
  while (--index) {
    if (path.codePointAt(index) === 47) {
      if (unmatchedSlash) {
        end = index;
        break;
      }
    } else if (!unmatchedSlash) {
      unmatchedSlash = true;
    }
  }
  return end < 0 ? path.codePointAt(0) === 47 ? "/" : "." : end === 1 && path.codePointAt(0) === 47 ? "//" : path.slice(0, end);
}
function extname(path) {
  assertPath(path);
  let index = path.length;
  let end = -1;
  let startPart = 0;
  let startDot = -1;
  let preDotState = 0;
  let unmatchedSlash;
  while (index--) {
    const code = path.codePointAt(index);
    if (code === 47) {
      if (unmatchedSlash) {
        startPart = index + 1;
        break;
      }
      continue;
    }
    if (end < 0) {
      unmatchedSlash = true;
      end = index + 1;
    }
    if (code === 46) {
      if (startDot < 0) {
        startDot = index;
      } else if (preDotState !== 1) {
        preDotState = 1;
      }
    } else if (startDot > -1) {
      preDotState = -1;
    }
  }
  if (startDot < 0 || end < 0 || preDotState === 0 || preDotState === 1 && startDot === end - 1 && startDot === startPart + 1) {
    return "";
  }
  return path.slice(startDot, end);
}
function join(...segments) {
  let index = -1;
  let joined;
  while (++index < segments.length) {
    assertPath(segments[index]);
    if (segments[index]) {
      joined = joined === undefined ? segments[index] : joined + "/" + segments[index];
    }
  }
  return joined === undefined ? "." : normalize2(joined);
}
function normalize2(path) {
  assertPath(path);
  const absolute = path.codePointAt(0) === 47;
  let value = normalizeString(path, !absolute);
  if (value.length === 0 && !absolute) {
    value = ".";
  }
  if (value.length > 0 && path.codePointAt(path.length - 1) === 47) {
    value += "/";
  }
  return absolute ? "/" + value : value;
}
function normalizeString(path, allowAboveRoot) {
  let result = "";
  let lastSegmentLength = 0;
  let lastSlash = -1;
  let dots = 0;
  let index = -1;
  let code;
  let lastSlashIndex;
  while (++index <= path.length) {
    if (index < path.length) {
      code = path.codePointAt(index);
    } else if (code === 47) {
      break;
    } else {
      code = 47;
    }
    if (code === 47) {
      if (lastSlash === index - 1 || dots === 1) {} else if (lastSlash !== index - 1 && dots === 2) {
        if (result.length < 2 || lastSegmentLength !== 2 || result.codePointAt(result.length - 1) !== 46 || result.codePointAt(result.length - 2) !== 46) {
          if (result.length > 2) {
            lastSlashIndex = result.lastIndexOf("/");
            if (lastSlashIndex !== result.length - 1) {
              if (lastSlashIndex < 0) {
                result = "";
                lastSegmentLength = 0;
              } else {
                result = result.slice(0, lastSlashIndex);
                lastSegmentLength = result.length - 1 - result.lastIndexOf("/");
              }
              lastSlash = index;
              dots = 0;
              continue;
            }
          } else if (result.length > 0) {
            result = "";
            lastSegmentLength = 0;
            lastSlash = index;
            dots = 0;
            continue;
          }
        }
        if (allowAboveRoot) {
          result = result.length > 0 ? result + "/.." : "..";
          lastSegmentLength = 2;
        }
      } else {
        if (result.length > 0) {
          result += "/" + path.slice(lastSlash + 1, index);
        } else {
          result = path.slice(lastSlash + 1, index);
        }
        lastSegmentLength = index - lastSlash - 1;
      }
      lastSlash = index;
      dots = 0;
    } else if (code === 46 && dots > -1) {
      dots++;
    } else {
      dots = -1;
    }
  }
  return result;
}
function assertPath(path) {
  if (typeof path !== "string") {
    throw new TypeError("Path must be a string. Received " + JSON.stringify(path));
  }
}

// node_modules/vfile/lib/minproc.browser.js
var minproc = { cwd };
function cwd() {
  return "/";
}

// node_modules/vfile/lib/minurl.shared.js
function isUrl(fileUrlOrPath) {
  return Boolean(fileUrlOrPath !== null && typeof fileUrlOrPath === "object" && "href" in fileUrlOrPath && fileUrlOrPath.href && "protocol" in fileUrlOrPath && fileUrlOrPath.protocol && fileUrlOrPath.auth === undefined);
}

// node_modules/vfile/lib/minurl.browser.js
function urlToPath(path) {
  if (typeof path === "string") {
    path = new URL(path);
  } else if (!isUrl(path)) {
    const error = new TypeError('The "path" argument must be of type string or an instance of URL. Received `' + path + "`");
    error.code = "ERR_INVALID_ARG_TYPE";
    throw error;
  }
  if (path.protocol !== "file:") {
    const error = new TypeError("The URL must be of scheme file");
    error.code = "ERR_INVALID_URL_SCHEME";
    throw error;
  }
  return getPathFromURLPosix(path);
}
function getPathFromURLPosix(url) {
  if (url.hostname !== "") {
    const error = new TypeError('File URL host must be "localhost" or empty on darwin');
    error.code = "ERR_INVALID_FILE_URL_HOST";
    throw error;
  }
  const pathname = url.pathname;
  let index = -1;
  while (++index < pathname.length) {
    if (pathname.codePointAt(index) === 37 && pathname.codePointAt(index + 1) === 50) {
      const third = pathname.codePointAt(index + 2);
      if (third === 70 || third === 102) {
        const error = new TypeError("File URL path must not include encoded / characters");
        error.code = "ERR_INVALID_FILE_URL_PATH";
        throw error;
      }
    }
  }
  return decodeURIComponent(pathname);
}

// node_modules/vfile/lib/index.js
var order = [
  "history",
  "path",
  "basename",
  "stem",
  "extname",
  "dirname"
];

class VFile {
  constructor(value) {
    let options;
    if (!value) {
      options = {};
    } else if (isUrl(value)) {
      options = { path: value };
    } else if (typeof value === "string" || isUint8Array(value)) {
      options = { value };
    } else {
      options = value;
    }
    this.cwd = "cwd" in options ? "" : minproc.cwd();
    this.data = {};
    this.history = [];
    this.messages = [];
    this.value;
    this.map;
    this.result;
    this.stored;
    let index = -1;
    while (++index < order.length) {
      const field = order[index];
      if (field in options && options[field] !== undefined && options[field] !== null) {
        this[field] = field === "history" ? [...options[field]] : options[field];
      }
    }
    let field;
    for (field in options) {
      if (!order.includes(field)) {
        this[field] = options[field];
      }
    }
  }
  get basename() {
    return typeof this.path === "string" ? minpath.basename(this.path) : undefined;
  }
  set basename(basename) {
    assertNonEmpty(basename, "basename");
    assertPart(basename, "basename");
    this.path = minpath.join(this.dirname || "", basename);
  }
  get dirname() {
    return typeof this.path === "string" ? minpath.dirname(this.path) : undefined;
  }
  set dirname(dirname) {
    assertPath2(this.basename, "dirname");
    this.path = minpath.join(dirname || "", this.basename);
  }
  get extname() {
    return typeof this.path === "string" ? minpath.extname(this.path) : undefined;
  }
  set extname(extname) {
    assertPart(extname, "extname");
    assertPath2(this.dirname, "extname");
    if (extname) {
      if (extname.codePointAt(0) !== 46) {
        throw new Error("`extname` must start with `.`");
      }
      if (extname.includes(".", 1)) {
        throw new Error("`extname` cannot contain multiple dots");
      }
    }
    this.path = minpath.join(this.dirname, this.stem + (extname || ""));
  }
  get path() {
    return this.history[this.history.length - 1];
  }
  set path(path) {
    if (isUrl(path)) {
      path = urlToPath(path);
    }
    assertNonEmpty(path, "path");
    if (this.path !== path) {
      this.history.push(path);
    }
  }
  get stem() {
    return typeof this.path === "string" ? minpath.basename(this.path, this.extname) : undefined;
  }
  set stem(stem) {
    assertNonEmpty(stem, "stem");
    assertPart(stem, "stem");
    this.path = minpath.join(this.dirname || "", stem + (this.extname || ""));
  }
  fail(causeOrReason, optionsOrParentOrPlace, origin) {
    const message = this.message(causeOrReason, optionsOrParentOrPlace, origin);
    message.fatal = true;
    throw message;
  }
  info(causeOrReason, optionsOrParentOrPlace, origin) {
    const message = this.message(causeOrReason, optionsOrParentOrPlace, origin);
    message.fatal = undefined;
    return message;
  }
  message(causeOrReason, optionsOrParentOrPlace, origin) {
    const message = new VFileMessage(causeOrReason, optionsOrParentOrPlace, origin);
    if (this.path) {
      message.name = this.path + ":" + message.name;
      message.file = this.path;
    }
    message.fatal = false;
    this.messages.push(message);
    return message;
  }
  toString(encoding) {
    if (this.value === undefined) {
      return "";
    }
    if (typeof this.value === "string") {
      return this.value;
    }
    const decoder = new TextDecoder(encoding || undefined);
    return decoder.decode(this.value);
  }
}
function assertPart(part, name) {
  if (part && part.includes(minpath.sep)) {
    throw new Error("`" + name + "` cannot be a path: did not expect `" + minpath.sep + "`");
  }
}
function assertNonEmpty(part, name) {
  if (!part) {
    throw new Error("`" + name + "` cannot be empty");
  }
}
function assertPath2(path, name) {
  if (!path) {
    throw new Error("Setting `" + name + "` requires `path` to be set too");
  }
}
function isUint8Array(value) {
  return Boolean(value && typeof value === "object" && "byteLength" in value && "byteOffset" in value);
}
// node_modules/unified/lib/callable-instance.js
var CallableInstance = function(property) {
  const self2 = this;
  const constr = self2.constructor;
  const proto = constr.prototype;
  const value = proto[property];
  const apply = function() {
    return value.apply(apply, arguments);
  };
  Object.setPrototypeOf(apply, proto);
  return apply;
};

// node_modules/unified/lib/index.js
var own4 = {}.hasOwnProperty;

class Processor extends CallableInstance {
  constructor() {
    super("copy");
    this.Compiler = undefined;
    this.Parser = undefined;
    this.attachers = [];
    this.compiler = undefined;
    this.freezeIndex = -1;
    this.frozen = undefined;
    this.namespace = {};
    this.parser = undefined;
    this.transformers = trough();
  }
  copy() {
    const destination = new Processor;
    let index = -1;
    while (++index < this.attachers.length) {
      const attacher = this.attachers[index];
      destination.use(...attacher);
    }
    destination.data(import_extend.default(true, {}, this.namespace));
    return destination;
  }
  data(key, value) {
    if (typeof key === "string") {
      if (arguments.length === 2) {
        assertUnfrozen("data", this.frozen);
        this.namespace[key] = value;
        return this;
      }
      return own4.call(this.namespace, key) && this.namespace[key] || undefined;
    }
    if (key) {
      assertUnfrozen("data", this.frozen);
      this.namespace = key;
      return this;
    }
    return this.namespace;
  }
  freeze() {
    if (this.frozen) {
      return this;
    }
    const self2 = this;
    while (++this.freezeIndex < this.attachers.length) {
      const [attacher, ...options] = this.attachers[this.freezeIndex];
      if (options[0] === false) {
        continue;
      }
      if (options[0] === true) {
        options[0] = undefined;
      }
      const transformer = attacher.call(self2, ...options);
      if (typeof transformer === "function") {
        this.transformers.use(transformer);
      }
    }
    this.frozen = true;
    this.freezeIndex = Number.POSITIVE_INFINITY;
    return this;
  }
  parse(file) {
    this.freeze();
    const realFile = vfile(file);
    const parser = this.parser || this.Parser;
    assertParser("parse", parser);
    return parser(String(realFile), realFile);
  }
  process(file, done) {
    const self2 = this;
    this.freeze();
    assertParser("process", this.parser || this.Parser);
    assertCompiler("process", this.compiler || this.Compiler);
    return done ? executor(undefined, done) : new Promise(executor);
    function executor(resolve, reject) {
      const realFile = vfile(file);
      const parseTree = self2.parse(realFile);
      self2.run(parseTree, realFile, function(error, tree, file) {
        if (error || !tree || !file) {
          return realDone(error);
        }
        const compileTree = tree;
        const compileResult = self2.stringify(compileTree, file);
        if (looksLikeAValue(compileResult)) {
          file.value = compileResult;
        } else {
          file.result = compileResult;
        }
        realDone(error, file);
      });
      function realDone(error, file) {
        if (error || !file) {
          reject(error);
        } else if (resolve) {
          resolve(file);
        } else {
          ok2(done, "`done` is defined if `resolve` is not");
          done(undefined, file);
        }
      }
    }
  }
  processSync(file) {
    let complete = false;
    let result;
    this.freeze();
    assertParser("processSync", this.parser || this.Parser);
    assertCompiler("processSync", this.compiler || this.Compiler);
    this.process(file, realDone);
    assertDone("processSync", "process", complete);
    ok2(result, "we either bailed on an error or have a tree");
    return result;
    function realDone(error, file) {
      complete = true;
      bail(error);
      result = file;
    }
  }
  run(tree, file, done) {
    assertNode(tree);
    this.freeze();
    const transformers = this.transformers;
    if (!done && typeof file === "function") {
      done = file;
      file = undefined;
    }
    return done ? executor(undefined, done) : new Promise(executor);
    function executor(resolve, reject) {
      ok2(typeof file !== "function", "`file` can’t be a `done` anymore, we checked");
      const realFile = vfile(file);
      transformers.run(tree, realFile, realDone);
      function realDone(error, outputTree, file) {
        const resultingTree = outputTree || tree;
        if (error) {
          reject(error);
        } else if (resolve) {
          resolve(resultingTree);
        } else {
          ok2(done, "`done` is defined if `resolve` is not");
          done(undefined, resultingTree, file);
        }
      }
    }
  }
  runSync(tree, file) {
    let complete = false;
    let result;
    this.run(tree, file, realDone);
    assertDone("runSync", "run", complete);
    ok2(result, "we either bailed on an error or have a tree");
    return result;
    function realDone(error, tree) {
      bail(error);
      result = tree;
      complete = true;
    }
  }
  stringify(tree, file) {
    this.freeze();
    const realFile = vfile(file);
    const compiler = this.compiler || this.Compiler;
    assertCompiler("stringify", compiler);
    assertNode(tree);
    return compiler(tree, realFile);
  }
  use(value, ...parameters) {
    const attachers = this.attachers;
    const namespace = this.namespace;
    assertUnfrozen("use", this.frozen);
    if (value === null || value === undefined) {} else if (typeof value === "function") {
      addPlugin(value, parameters);
    } else if (typeof value === "object") {
      if (Array.isArray(value)) {
        addList(value);
      } else {
        addPreset(value);
      }
    } else {
      throw new TypeError("Expected usable value, not `" + value + "`");
    }
    return this;
    function add(value) {
      if (typeof value === "function") {
        addPlugin(value, []);
      } else if (typeof value === "object") {
        if (Array.isArray(value)) {
          const [plugin, ...parameters] = value;
          addPlugin(plugin, parameters);
        } else {
          addPreset(value);
        }
      } else {
        throw new TypeError("Expected usable value, not `" + value + "`");
      }
    }
    function addPreset(result) {
      if (!("plugins" in result) && !("settings" in result)) {
        throw new Error("Expected usable value but received an empty preset, which is probably a mistake: presets typically come with `plugins` and sometimes with `settings`, but this has neither");
      }
      addList(result.plugins);
      if (result.settings) {
        namespace.settings = import_extend.default(true, namespace.settings, result.settings);
      }
    }
    function addList(plugins) {
      let index = -1;
      if (plugins === null || plugins === undefined) {} else if (Array.isArray(plugins)) {
        while (++index < plugins.length) {
          const thing = plugins[index];
          add(thing);
        }
      } else {
        throw new TypeError("Expected a list of plugins, not `" + plugins + "`");
      }
    }
    function addPlugin(plugin, parameters) {
      let index = -1;
      let entryIndex = -1;
      while (++index < attachers.length) {
        if (attachers[index][0] === plugin) {
          entryIndex = index;
          break;
        }
      }
      if (entryIndex === -1) {
        attachers.push([plugin, ...parameters]);
      } else if (parameters.length > 0) {
        let [primary, ...rest] = parameters;
        const currentPrimary = attachers[entryIndex][1];
        if (isPlainObject(currentPrimary) && isPlainObject(primary)) {
          primary = import_extend.default(true, currentPrimary, primary);
        }
        attachers[entryIndex] = [plugin, primary, ...rest];
      }
    }
  }
}
var unified = new Processor().freeze();
function assertParser(name, value) {
  if (typeof value !== "function") {
    throw new TypeError("Cannot `" + name + "` without `parser`");
  }
}
function assertCompiler(name, value) {
  if (typeof value !== "function") {
    throw new TypeError("Cannot `" + name + "` without `compiler`");
  }
}
function assertUnfrozen(name, frozen) {
  if (frozen) {
    throw new Error("Cannot call `" + name + "` on a frozen processor.\nCreate a new processor first, by calling it: use `processor()` instead of `processor`.");
  }
}
function assertNode(node) {
  if (!isPlainObject(node) || typeof node.type !== "string") {
    throw new TypeError("Expected node, got `" + node + "`");
  }
}
function assertDone(name, asyncName, complete) {
  if (!complete) {
    throw new Error("`" + name + "` finished async. Use `" + asyncName + "` instead");
  }
}
function vfile(value) {
  return looksLikeAVFile(value) ? value : new VFile(value);
}
function looksLikeAVFile(value) {
  return Boolean(value && typeof value === "object" && "message" in value && "messages" in value);
}
function looksLikeAValue(value) {
  return typeof value === "string" || isUint8Array2(value);
}
function isUint8Array2(value) {
  return Boolean(value && typeof value === "object" && "byteLength" in value && "byteOffset" in value);
}
// node_modules/react-markdown/lib/index.js
var changelog = "https://github.com/remarkjs/react-markdown/blob/main/changelog.md";
var emptyPlugins = [];
var emptyRemarkRehypeOptions = { allowDangerousHtml: true };
var safeProtocol = /^(https?|ircs?|mailto|xmpp)$/i;
var deprecations = [
  { from: "astPlugins", id: "remove-buggy-html-in-markdown-parser" },
  { from: "allowDangerousHtml", id: "remove-buggy-html-in-markdown-parser" },
  {
    from: "allowNode",
    id: "replace-allownode-allowedtypes-and-disallowedtypes",
    to: "allowElement"
  },
  {
    from: "allowedTypes",
    id: "replace-allownode-allowedtypes-and-disallowedtypes",
    to: "allowedElements"
  },
  {
    from: "disallowedTypes",
    id: "replace-allownode-allowedtypes-and-disallowedtypes",
    to: "disallowedElements"
  },
  { from: "escapeHtml", id: "remove-buggy-html-in-markdown-parser" },
  { from: "includeElementIndex", id: "#remove-includeelementindex" },
  {
    from: "includeNodeIndex",
    id: "change-includenodeindex-to-includeelementindex"
  },
  { from: "linkTarget", id: "remove-linktarget" },
  { from: "plugins", id: "change-plugins-to-remarkplugins", to: "remarkPlugins" },
  { from: "rawSourcePos", id: "#remove-rawsourcepos" },
  { from: "renderers", id: "change-renderers-to-components", to: "components" },
  { from: "source", id: "change-source-to-children", to: "children" },
  { from: "sourcePos", id: "#remove-sourcepos" },
  { from: "transformImageUri", id: "#add-urltransform", to: "urlTransform" },
  { from: "transformLinkUri", id: "#add-urltransform", to: "urlTransform" }
];
function Markdown(options) {
  const processor = createProcessor(options);
  const file = createFile(options);
  return post2(processor.runSync(processor.parse(file), file), options);
}
function createProcessor(options) {
  const rehypePlugins = options.rehypePlugins || emptyPlugins;
  const remarkPlugins = options.remarkPlugins || emptyPlugins;
  const remarkRehypeOptions = options.remarkRehypeOptions ? { ...options.remarkRehypeOptions, ...emptyRemarkRehypeOptions } : emptyRemarkRehypeOptions;
  const processor = unified().use(remarkParse).use(remarkPlugins).use(remarkRehype, remarkRehypeOptions).use(rehypePlugins);
  return processor;
}
function createFile(options) {
  const children = options.children || "";
  const file = new VFile;
  if (typeof children === "string") {
    file.value = children;
  } else {
    unreachable("Unexpected value `" + children + "` for `children` prop, expected `string`");
  }
  return file;
}
function post2(tree, options) {
  const allowedElements = options.allowedElements;
  const allowElement = options.allowElement;
  const components = options.components;
  const disallowedElements = options.disallowedElements;
  const skipHtml = options.skipHtml;
  const unwrapDisallowed = options.unwrapDisallowed;
  const urlTransform = options.urlTransform || defaultUrlTransform;
  for (const deprecation of deprecations) {
    if (Object.hasOwn(options, deprecation.from)) {
      unreachable("Unexpected `" + deprecation.from + "` prop, " + (deprecation.to ? "use `" + deprecation.to + "` instead" : "remove it") + " (see <" + changelog + "#" + deprecation.id + "> for more info)");
    }
  }
  if (allowedElements && disallowedElements) {
    unreachable("Unexpected combined `allowedElements` and `disallowedElements`, expected one or the other");
  }
  if (options.className) {
    tree = {
      type: "element",
      tagName: "div",
      properties: { className: options.className },
      children: tree.type === "root" ? tree.children : [tree]
    };
  }
  visit(tree, transform);
  return toJsxRuntime(tree, {
    Fragment: import_jsx_runtime.Fragment,
    components,
    ignoreInvalidStyle: true,
    jsx: import_jsx_runtime.jsx,
    jsxs: import_jsx_runtime.jsxs,
    passKeys: true,
    passNode: true
  });
  function transform(node, index, parent) {
    if (node.type === "raw" && parent && typeof index === "number") {
      if (skipHtml) {
        parent.children.splice(index, 1);
      } else {
        parent.children[index] = { type: "text", value: node.value };
      }
      return index;
    }
    if (node.type === "element") {
      let key;
      for (key in urlAttributes) {
        if (Object.hasOwn(urlAttributes, key) && Object.hasOwn(node.properties, key)) {
          const value = node.properties[key];
          const test = urlAttributes[key];
          if (test === null || test.includes(node.tagName)) {
            node.properties[key] = urlTransform(String(value || ""), key, node);
          }
        }
      }
    }
    if (node.type === "element") {
      let remove = allowedElements ? !allowedElements.includes(node.tagName) : disallowedElements ? disallowedElements.includes(node.tagName) : false;
      if (!remove && allowElement && typeof index === "number") {
        remove = !allowElement(node, index, parent);
      }
      if (remove && parent && typeof index === "number") {
        if (unwrapDisallowed && node.children) {
          parent.children.splice(index, 1, ...node.children);
        } else {
          parent.children.splice(index, 1);
        }
        return index;
      }
    }
  }
}
function defaultUrlTransform(value) {
  const colon = value.indexOf(":");
  const questionMark = value.indexOf("?");
  const numberSign = value.indexOf("#");
  const slash = value.indexOf("/");
  if (colon === -1 || slash !== -1 && colon > slash || questionMark !== -1 && colon > questionMark || numberSign !== -1 && colon > numberSign || safeProtocol.test(value.slice(0, colon))) {
    return value;
  }
  return "";
}
// node_modules/ccount/index.js
function ccount(value, character) {
  const source = String(value);
  if (typeof character !== "string") {
    throw new TypeError("Expected character");
  }
  let count = 0;
  let index = source.indexOf(character);
  while (index !== -1) {
    count++;
    index = source.indexOf(character, index + character.length);
  }
  return count;
}

// node_modules/escape-string-regexp/index.js
function escapeStringRegexp(string) {
  if (typeof string !== "string") {
    throw new TypeError("Expected a string");
  }
  return string.replace(/[|\\{}()[\]^$+*?.]/g, "\\$&").replace(/-/g, "\\x2d");
}

// node_modules/mdast-util-find-and-replace/lib/index.js
function findAndReplace(tree, list, options) {
  const settings = options || {};
  const ignored = convert(settings.ignore || []);
  const pairs = toPairs(list);
  let pairIndex = -1;
  while (++pairIndex < pairs.length) {
    visitParents(tree, "text", visitor);
  }
  function visitor(node, parents) {
    let index = -1;
    let grandparent;
    while (++index < parents.length) {
      const parent = parents[index];
      const siblings = grandparent ? grandparent.children : undefined;
      if (ignored(parent, siblings ? siblings.indexOf(parent) : undefined, grandparent)) {
        return;
      }
      grandparent = parent;
    }
    if (grandparent) {
      return handler(node, parents);
    }
  }
  function handler(node, parents) {
    const parent = parents[parents.length - 1];
    const find = pairs[pairIndex][0];
    const replace = pairs[pairIndex][1];
    let start = 0;
    const siblings = parent.children;
    const index = siblings.indexOf(node);
    let change = false;
    let nodes = [];
    find.lastIndex = 0;
    let match = find.exec(node.value);
    while (match) {
      const position = match.index;
      const matchObject = {
        index: match.index,
        input: match.input,
        stack: [...parents, node]
      };
      let value = replace(...match, matchObject);
      if (typeof value === "string") {
        value = value.length > 0 ? { type: "text", value } : undefined;
      }
      if (value === false) {
        find.lastIndex = position + 1;
      } else {
        if (start !== position) {
          nodes.push({
            type: "text",
            value: node.value.slice(start, position)
          });
        }
        if (Array.isArray(value)) {
          nodes.push(...value);
        } else if (value) {
          nodes.push(value);
        }
        start = position + match[0].length;
        change = true;
      }
      if (!find.global) {
        break;
      }
      match = find.exec(node.value);
    }
    if (change) {
      if (start < node.value.length) {
        nodes.push({ type: "text", value: node.value.slice(start) });
      }
      parent.children.splice(index, 1, ...nodes);
    } else {
      nodes = [node];
    }
    return index + nodes.length;
  }
}
function toPairs(tupleOrList) {
  const result = [];
  if (!Array.isArray(tupleOrList)) {
    throw new TypeError("Expected find and replace tuple or list of tuples");
  }
  const list = !tupleOrList[0] || Array.isArray(tupleOrList[0]) ? tupleOrList : [tupleOrList];
  let index = -1;
  while (++index < list.length) {
    const tuple = list[index];
    result.push([toExpression(tuple[0]), toFunction(tuple[1])]);
  }
  return result;
}
function toExpression(find) {
  return typeof find === "string" ? new RegExp(escapeStringRegexp(find), "g") : find;
}
function toFunction(replace) {
  return typeof replace === "function" ? replace : function() {
    return replace;
  };
}
// node_modules/mdast-util-gfm-autolink-literal/lib/index.js
var inConstruct = "phrasing";
var notInConstruct = ["autolink", "link", "image", "label"];
function gfmAutolinkLiteralFromMarkdown() {
  return {
    transforms: [transformGfmAutolinkLiterals],
    enter: {
      literalAutolink: enterLiteralAutolink,
      literalAutolinkEmail: enterLiteralAutolinkValue,
      literalAutolinkHttp: enterLiteralAutolinkValue,
      literalAutolinkWww: enterLiteralAutolinkValue
    },
    exit: {
      literalAutolink: exitLiteralAutolink,
      literalAutolinkEmail: exitLiteralAutolinkEmail,
      literalAutolinkHttp: exitLiteralAutolinkHttp,
      literalAutolinkWww: exitLiteralAutolinkWww
    }
  };
}
function gfmAutolinkLiteralToMarkdown() {
  return {
    unsafe: [
      {
        character: "@",
        before: "[+\\-.\\w]",
        after: "[\\-.\\w]",
        inConstruct,
        notInConstruct
      },
      {
        character: ".",
        before: "[Ww]",
        after: "[\\-.\\w]",
        inConstruct,
        notInConstruct
      },
      {
        character: ":",
        before: "[ps]",
        after: "\\/",
        inConstruct,
        notInConstruct
      }
    ]
  };
}
function enterLiteralAutolink(token) {
  this.enter({ type: "link", title: null, url: "", children: [] }, token);
}
function enterLiteralAutolinkValue(token) {
  this.config.enter.autolinkProtocol.call(this, token);
}
function exitLiteralAutolinkHttp(token) {
  this.config.exit.autolinkProtocol.call(this, token);
}
function exitLiteralAutolinkWww(token) {
  this.config.exit.data.call(this, token);
  const node = this.stack[this.stack.length - 1];
  ok2(node.type === "link");
  node.url = "http://" + this.sliceSerialize(token);
}
function exitLiteralAutolinkEmail(token) {
  this.config.exit.autolinkEmail.call(this, token);
}
function exitLiteralAutolink(token) {
  this.exit(token);
}
function transformGfmAutolinkLiterals(tree) {
  findAndReplace(tree, [
    [/(https?:\/\/|www(?=\.))([-.\w]+)([^ \t\r\n]*)/gi, findUrl],
    [/(?<=^|\s|\p{P}|\p{S})([-.\w+]+)@([-\w]+(?:\.[-\w]+)+)/gu, findEmail]
  ], { ignore: ["link", "linkReference"] });
}
function findUrl(_, protocol, domain, path, match) {
  let prefix = "";
  if (!previous2(match)) {
    return false;
  }
  if (/^w/i.test(protocol)) {
    domain = protocol + domain;
    protocol = "";
    prefix = "http://";
  }
  if (!isCorrectDomain(domain)) {
    return false;
  }
  const parts = splitUrl(domain + path);
  if (!parts[0])
    return false;
  const result = {
    type: "link",
    title: null,
    url: prefix + protocol + parts[0],
    children: [{ type: "text", value: protocol + parts[0] }]
  };
  if (parts[1]) {
    return [result, { type: "text", value: parts[1] }];
  }
  return result;
}
function findEmail(_, atext, label, match) {
  if (!previous2(match, true) || /[-\d_]$/.test(label)) {
    return false;
  }
  return {
    type: "link",
    title: null,
    url: "mailto:" + atext + "@" + label,
    children: [{ type: "text", value: atext + "@" + label }]
  };
}
function isCorrectDomain(domain) {
  const parts = domain.split(".");
  if (parts.length < 2 || parts[parts.length - 1] && (/_/.test(parts[parts.length - 1]) || !/[a-zA-Z\d]/.test(parts[parts.length - 1])) || parts[parts.length - 2] && (/_/.test(parts[parts.length - 2]) || !/[a-zA-Z\d]/.test(parts[parts.length - 2]))) {
    return false;
  }
  return true;
}
function splitUrl(url) {
  const trailExec = /[!"&'),.:;<>?\]}]+$/.exec(url);
  if (!trailExec) {
    return [url, undefined];
  }
  url = url.slice(0, trailExec.index);
  let trail = trailExec[0];
  let closingParenIndex = trail.indexOf(")");
  const openingParens = ccount(url, "(");
  let closingParens = ccount(url, ")");
  while (closingParenIndex !== -1 && openingParens > closingParens) {
    url += trail.slice(0, closingParenIndex + 1);
    trail = trail.slice(closingParenIndex + 1);
    closingParenIndex = trail.indexOf(")");
    closingParens++;
  }
  return [url, trail];
}
function previous2(match, email) {
  const code = match.input.charCodeAt(match.index - 1);
  return (match.index === 0 || unicodeWhitespace(code) || unicodePunctuation(code)) && (!email || code !== 47);
}
// node_modules/mdast-util-gfm-footnote/lib/index.js
footnoteReference2.peek = footnoteReferencePeek;
function enterFootnoteCallString() {
  this.buffer();
}
function enterFootnoteCall(token) {
  this.enter({ type: "footnoteReference", identifier: "", label: "" }, token);
}
function enterFootnoteDefinitionLabelString() {
  this.buffer();
}
function enterFootnoteDefinition(token) {
  this.enter({ type: "footnoteDefinition", identifier: "", label: "", children: [] }, token);
}
function exitFootnoteCallString(token) {
  const label = this.resume();
  const node = this.stack[this.stack.length - 1];
  ok2(node.type === "footnoteReference");
  node.identifier = normalizeIdentifier(this.sliceSerialize(token)).toLowerCase();
  node.label = label;
}
function exitFootnoteCall(token) {
  this.exit(token);
}
function exitFootnoteDefinitionLabelString(token) {
  const label = this.resume();
  const node = this.stack[this.stack.length - 1];
  ok2(node.type === "footnoteDefinition");
  node.identifier = normalizeIdentifier(this.sliceSerialize(token)).toLowerCase();
  node.label = label;
}
function exitFootnoteDefinition(token) {
  this.exit(token);
}
function footnoteReferencePeek() {
  return "[";
}
function footnoteReference2(node, _, state, info) {
  const tracker = state.createTracker(info);
  let value = tracker.move("[^");
  const exit = state.enter("footnoteReference");
  const subexit = state.enter("reference");
  value += tracker.move(state.safe(state.associationId(node), { after: "]", before: value }));
  subexit();
  exit();
  value += tracker.move("]");
  return value;
}
function gfmFootnoteFromMarkdown() {
  return {
    enter: {
      gfmFootnoteCallString: enterFootnoteCallString,
      gfmFootnoteCall: enterFootnoteCall,
      gfmFootnoteDefinitionLabelString: enterFootnoteDefinitionLabelString,
      gfmFootnoteDefinition: enterFootnoteDefinition
    },
    exit: {
      gfmFootnoteCallString: exitFootnoteCallString,
      gfmFootnoteCall: exitFootnoteCall,
      gfmFootnoteDefinitionLabelString: exitFootnoteDefinitionLabelString,
      gfmFootnoteDefinition: exitFootnoteDefinition
    }
  };
}
function gfmFootnoteToMarkdown(options) {
  let firstLineBlank = false;
  if (options && options.firstLineBlank) {
    firstLineBlank = true;
  }
  return {
    handlers: { footnoteDefinition, footnoteReference: footnoteReference2 },
    unsafe: [{ character: "[", inConstruct: ["label", "phrasing", "reference"] }]
  };
  function footnoteDefinition(node, _, state, info) {
    const tracker = state.createTracker(info);
    let value = tracker.move("[^");
    const exit = state.enter("footnoteDefinition");
    const subexit = state.enter("label");
    value += tracker.move(state.safe(state.associationId(node), { before: value, after: "]" }));
    subexit();
    value += tracker.move("]:");
    if (node.children && node.children.length > 0) {
      tracker.shift(4);
      value += tracker.move((firstLineBlank ? `
` : " ") + state.indentLines(state.containerFlow(node, tracker.current()), firstLineBlank ? mapAll : mapExceptFirst));
    }
    exit();
    return value;
  }
}
function mapExceptFirst(line, index, blank) {
  return index === 0 ? line : mapAll(line, index, blank);
}
function mapAll(line, index, blank) {
  return (blank ? "" : "    ") + line;
}
// node_modules/mdast-util-gfm-strikethrough/lib/index.js
var constructsWithoutStrikethrough = [
  "autolink",
  "destinationLiteral",
  "destinationRaw",
  "reference",
  "titleQuote",
  "titleApostrophe"
];
handleDelete.attention = attentionDelete;
handleDelete.peek = peekDelete;
function gfmStrikethroughFromMarkdown() {
  return {
    canContainEols: ["delete"],
    enter: { strikethrough: enterStrikethrough },
    exit: { strikethrough: exitStrikethrough }
  };
}
function gfmStrikethroughToMarkdown() {
  return {
    handlers: { delete: handleDelete },
    unsafe: [
      {
        character: "~",
        inConstruct: "phrasing",
        notInConstruct: constructsWithoutStrikethrough
      }
    ]
  };
}
function enterStrikethrough(token) {
  this.enter({ type: "delete", children: [], position: undefined }, token);
}
function exitStrikethrough(token) {
  this.exit(token);
}
function handleDelete(node, _, state, info) {
  const tracker = state.createTracker(info);
  const sequence = state.stack.includes("strikethrough") ? "~" : "~~";
  const exit = state.enter("strikethrough");
  let value = tracker.move(sequence);
  value += state.containerPhrasing(node, {
    ...tracker.current(),
    before: value,
    after: "~"
  });
  value += tracker.move(sequence);
  exit();
  return value;
}
function attentionDelete() {
  return { construct: "strikethrough", markers: ["~"], sizes: [2, 1] };
}
function peekDelete() {
  return "~";
}
// node_modules/markdown-table/index.js
function defaultStringLength(value) {
  return value.length;
}
function markdownTable(table, options) {
  const settings = options || {};
  const align = (settings.align || []).concat();
  const stringLength = settings.stringLength || defaultStringLength;
  const alignments = [];
  const cellMatrix = [];
  const sizeMatrix = [];
  const longestCellByColumn = [];
  let mostCellsPerRow = 0;
  let rowIndex = -1;
  while (++rowIndex < table.length) {
    const row = [];
    const sizes = [];
    let columnIndex = -1;
    if (table[rowIndex].length > mostCellsPerRow) {
      mostCellsPerRow = table[rowIndex].length;
    }
    while (++columnIndex < table[rowIndex].length) {
      const cell = serialize2(table[rowIndex][columnIndex]);
      if (settings.alignDelimiters !== false) {
        const size = stringLength(cell);
        sizes[columnIndex] = size;
        if (longestCellByColumn[columnIndex] === undefined || size > longestCellByColumn[columnIndex]) {
          longestCellByColumn[columnIndex] = size;
        }
      }
      row.push(cell);
    }
    cellMatrix[rowIndex] = row;
    sizeMatrix[rowIndex] = sizes;
  }
  let columnIndex = -1;
  if (typeof align === "object" && "length" in align) {
    while (++columnIndex < mostCellsPerRow) {
      alignments[columnIndex] = toAlignment(align[columnIndex]);
    }
  } else {
    const code = toAlignment(align);
    while (++columnIndex < mostCellsPerRow) {
      alignments[columnIndex] = code;
    }
  }
  columnIndex = -1;
  const row = [];
  const sizes = [];
  while (++columnIndex < mostCellsPerRow) {
    const code = alignments[columnIndex];
    let before = "";
    let after = "";
    if (code === 99) {
      before = ":";
      after = ":";
    } else if (code === 108) {
      before = ":";
    } else if (code === 114) {
      after = ":";
    }
    let size = settings.alignDelimiters === false ? 1 : Math.max(1, longestCellByColumn[columnIndex] - before.length - after.length);
    const cell = before + "-".repeat(size) + after;
    if (settings.alignDelimiters !== false) {
      size = before.length + size + after.length;
      if (size > longestCellByColumn[columnIndex]) {
        longestCellByColumn[columnIndex] = size;
      }
      sizes[columnIndex] = size;
    }
    row[columnIndex] = cell;
  }
  cellMatrix.splice(1, 0, row);
  sizeMatrix.splice(1, 0, sizes);
  rowIndex = -1;
  const lines = [];
  while (++rowIndex < cellMatrix.length) {
    const row = cellMatrix[rowIndex];
    const sizes = sizeMatrix[rowIndex];
    columnIndex = -1;
    const line = [];
    while (++columnIndex < mostCellsPerRow) {
      const cell = row[columnIndex] || "";
      let before = "";
      let after = "";
      if (settings.alignDelimiters !== false) {
        const size = longestCellByColumn[columnIndex] - (sizes[columnIndex] || 0);
        const code = alignments[columnIndex];
        if (code === 114) {
          before = " ".repeat(size);
        } else if (code === 99) {
          if (size % 2) {
            before = " ".repeat(size / 2 + 0.5);
            after = " ".repeat(size / 2 - 0.5);
          } else {
            before = " ".repeat(size / 2);
            after = before;
          }
        } else {
          after = " ".repeat(size);
        }
      }
      if (settings.delimiterStart !== false && !columnIndex) {
        line.push("|");
      }
      if (settings.padding !== false && !(settings.alignDelimiters === false && cell === "") && (settings.delimiterStart !== false || columnIndex)) {
        line.push(" ");
      }
      if (settings.alignDelimiters !== false) {
        line.push(before);
      }
      line.push(cell);
      if (settings.alignDelimiters !== false) {
        line.push(after);
      }
      if (settings.padding !== false) {
        line.push(" ");
      }
      if (settings.delimiterEnd !== false || columnIndex !== mostCellsPerRow - 1) {
        line.push("|");
      }
    }
    lines.push(settings.delimiterEnd === false ? line.join("").replace(/ +$/, "") : line.join(""));
  }
  return lines.join(`
`);
}
function serialize2(value) {
  return value === null || value === undefined ? "" : String(value);
}
function toAlignment(value) {
  const code = typeof value === "string" ? value.codePointAt(0) : 0;
  return code === 67 || code === 99 ? 99 : code === 76 || code === 108 ? 108 : code === 82 || code === 114 ? 114 : 0;
}
// node_modules/mdast-util-to-markdown/lib/handle/blockquote.js
function blockquote2(node, _, state, info) {
  const exit = state.enter("blockquote");
  const tracker = state.createTracker(info);
  tracker.move("> ");
  tracker.shift(2);
  const value = state.indentLines(state.containerFlow(node, tracker.current()), map);
  exit();
  return value;
}
function map(line, _, blank) {
  return ">" + (blank ? "" : " ") + line;
}

// node_modules/mdast-util-to-markdown/lib/util/pattern-in-scope.js
function patternInScope(stack, pattern) {
  return listInScope(stack, pattern.inConstruct, true) && !listInScope(stack, pattern.notInConstruct, false);
}
function listInScope(stack, list, none) {
  if (typeof list === "string") {
    list = [list];
  }
  if (!list || list.length === 0) {
    return none;
  }
  let index = -1;
  while (++index < list.length) {
    if (stack.includes(list[index])) {
      return true;
    }
  }
  return false;
}

// node_modules/mdast-util-to-markdown/lib/handle/break.js
function hardBreak2(_, _1, state, info) {
  let index = -1;
  while (++index < state.unsafe.length) {
    const pattern = state.unsafe[index];
    if (pattern.character === `
` && !pattern.before && !pattern.after && patternInScope(state.stack, pattern)) {
      return /[\t ]/.test(info.before) ? "" : " ";
    }
  }
  return "\\\n";
}

// node_modules/longest-streak/index.js
function longestStreak(value, substring) {
  const source = String(value);
  let index = source.indexOf(substring);
  let expected = index;
  let count = 0;
  let max = 0;
  if (typeof substring !== "string") {
    throw new TypeError("Expected substring");
  }
  while (index !== -1) {
    if (index === expected) {
      if (++count > max) {
        max = count;
      }
    } else {
      count = 1;
    }
    expected = index + substring.length;
    index = source.indexOf(substring, expected);
  }
  return max;
}

// node_modules/mdast-util-to-markdown/lib/util/format-code-as-indented.js
function formatCodeAsIndented(node, state) {
  return Boolean(state.options.fences === false && node.value && !node.lang && /[^\n\r ]/.test(node.value) && !/^[\t ]*(?:[\n\r]|$)|(?:^|[\n\r])[\t ]*$/.test(node.value));
}

// node_modules/mdast-util-to-markdown/lib/util/check-fence.js
function checkFence(state) {
  const marker = state.options.fence || "`";
  if (marker !== "`" && marker !== "~") {
    throw new Error("Cannot serialize code with `" + marker + "` for `options.fence`, expected `` ` `` or `~`");
  }
  return marker;
}

// node_modules/mdast-util-to-markdown/lib/handle/code.js
function code2(node, _, state, info) {
  const marker = checkFence(state);
  const raw = node.value || "";
  if (formatCodeAsIndented(node, state)) {
    const exit = state.enter("codeIndented");
    const value = state.indentLines(raw, map2);
    exit();
    return value;
  }
  const tracker = state.createTracker(info);
  const sequence = marker.repeat(Math.max(longestStreak(raw, marker) + 1, 3));
  const exit = state.enter("codeFenced");
  const suffix = marker === "`" ? "GraveAccent" : "Tilde";
  let value = tracker.move(sequence);
  if (node.lang) {
    const subexit = state.enter(`codeFencedLang${suffix}`);
    value += tracker.move(state.safe(node.lang, {
      before: value,
      after: " ",
      encode: ["`"],
      ...tracker.current()
    }));
    subexit();
  }
  if (node.lang && node.meta) {
    const subexit = state.enter(`codeFencedMeta${suffix}`);
    value += tracker.move(" ");
    value += tracker.move(state.safe(node.meta, {
      before: value,
      after: `
`,
      encode: ["`"],
      ...tracker.current()
    }));
    subexit();
  }
  value += tracker.move(`
`);
  if (raw) {
    value += tracker.move(raw + `
`);
  }
  value += tracker.move(sequence);
  exit();
  return value;
}
function map2(line, _, blank) {
  return (blank ? "" : "    ") + line;
}

// node_modules/mdast-util-to-markdown/lib/util/check-quote.js
function checkQuote(state) {
  const marker = state.options.quote || '"';
  if (marker !== '"' && marker !== "'") {
    throw new Error("Cannot serialize title with `" + marker + "` for `options.quote`, expected `\"`, or `'`");
  }
  return marker;
}

// node_modules/mdast-util-to-markdown/lib/handle/definition.js
function definition2(node, _, state, info) {
  const quote = checkQuote(state);
  const suffix = quote === '"' ? "Quote" : "Apostrophe";
  const exit = state.enter("definition");
  let subexit = state.enter("label");
  const tracker = state.createTracker(info);
  let value = tracker.move("[");
  value += tracker.move(state.safe(state.associationId(node), {
    before: value,
    after: "]",
    ...tracker.current()
  }));
  value += tracker.move("]: ");
  subexit();
  if (!node.url || /[\0- \u007F]/.test(node.url)) {
    subexit = state.enter("destinationLiteral");
    value += tracker.move("<");
    value += tracker.move(state.safe(node.url, { before: value, after: ">", ...tracker.current() }));
    value += tracker.move(">");
  } else {
    subexit = state.enter("destinationRaw");
    value += tracker.move(state.safe(node.url, {
      before: value,
      after: node.title ? " " : `
`,
      ...tracker.current()
    }));
  }
  subexit();
  if (node.title) {
    subexit = state.enter(`title${suffix}`);
    value += tracker.move(" " + quote);
    value += tracker.move(state.safe(node.title, {
      before: value,
      after: quote,
      ...tracker.current()
    }));
    value += tracker.move(quote);
    subexit();
  }
  exit();
  return value;
}

// node_modules/mdast-util-to-markdown/lib/util/check-emphasis.js
function checkEmphasis(state) {
  const marker = state.options.emphasis || "*";
  if (marker !== "*" && marker !== "_") {
    throw new Error("Cannot serialize emphasis with `" + marker + "` for `options.emphasis`, expected `*`, or `_`");
  }
  return marker;
}

// node_modules/mdast-util-to-markdown/lib/handle/emphasis.js
emphasis2.attention = attention2;
emphasis2.peek = peek;
function emphasis2(node, _, state, info) {
  const exit = state.enter("phrasing");
  const value = state.containerPhrasing({ type: "root", children: [node] }, info);
  exit();
  return value;
}
function attention2(_, state) {
  const marker = checkEmphasis(state);
  return {
    construct: "emphasis",
    markers: marker === "*" ? ["*", "_"] : ["_", "*"],
    sizes: [1]
  };
}
function peek(_, _1, state) {
  return state.options.emphasis || "*";
}

// node_modules/mdast-util-to-markdown/lib/util/encode-character-reference.js
function encodeCharacterReference(code) {
  return "&#x" + code.toString(16).toUpperCase() + ";";
}

// node_modules/mdast-util-to-markdown/lib/util/format-heading-as-setext.js
function formatHeadingAsSetext(node, state) {
  let literalWithBreak = false;
  visit(node, function(node) {
    if ("value" in node && /\r?\n|\r/.test(node.value) || node.type === "break") {
      literalWithBreak = true;
      return EXIT;
    }
  });
  return Boolean((!node.depth || node.depth < 3) && toString(node) && (state.options.setext || literalWithBreak));
}

// node_modules/mdast-util-to-markdown/lib/handle/heading.js
function heading2(node, _, state, info) {
  const rank = Math.max(Math.min(6, node.depth || 1), 1);
  const tracker = state.createTracker(info);
  if (formatHeadingAsSetext(node, state)) {
    const exit = state.enter("headingSetext");
    const subexit = state.enter("phrasing");
    const value = state.containerPhrasing(node, {
      ...tracker.current(),
      before: `
`,
      after: `
`
    });
    subexit();
    exit();
    return value + `
` + (rank === 1 ? "=" : "-").repeat(value.length - (Math.max(value.lastIndexOf("\r"), value.lastIndexOf(`
`)) + 1));
  }
  const sequence = "#".repeat(rank);
  const exit = state.enter("headingAtx");
  const subexit = state.enter("phrasing");
  tracker.move(sequence + " ");
  let value = state.containerPhrasing(node, {
    before: "# ",
    after: `
`,
    ...tracker.current()
  });
  const head = value.charCodeAt(0);
  if (head === 9 || head === 32) {
    value = encodeCharacterReference(head) + value.slice(1);
  }
  value = value ? sequence + " " + value : sequence;
  if (state.options.closeAtx) {
    value += " " + sequence;
  }
  subexit();
  exit();
  return value;
}

// node_modules/mdast-util-to-markdown/lib/handle/html.js
html4.peek = htmlPeek;
function html4(node) {
  return node.value || "";
}
function htmlPeek() {
  return "<";
}

// node_modules/mdast-util-to-markdown/lib/handle/image.js
image2.peek = imagePeek;
function image2(node, _, state, info) {
  const quote = checkQuote(state);
  const suffix = quote === '"' ? "Quote" : "Apostrophe";
  const exit = state.enter("image");
  let subexit = state.enter("label");
  const tracker = state.createTracker(info);
  let value = tracker.move("![");
  value += tracker.move(state.safe(node.alt, { before: value, after: "]", ...tracker.current() }));
  value += tracker.move("](");
  subexit();
  if (!node.url && node.title || /[\0- \u007F]/.test(node.url)) {
    subexit = state.enter("destinationLiteral");
    value += tracker.move("<");
    value += tracker.move(state.safe(node.url, { before: value, after: ">", ...tracker.current() }));
    value += tracker.move(">");
  } else {
    subexit = state.enter("destinationRaw");
    value += tracker.move(state.safe(node.url, {
      before: value,
      after: node.title ? " " : ")",
      ...tracker.current()
    }));
  }
  subexit();
  if (node.title) {
    subexit = state.enter(`title${suffix}`);
    value += tracker.move(" " + quote);
    value += tracker.move(state.safe(node.title, {
      before: value,
      after: quote,
      ...tracker.current()
    }));
    value += tracker.move(quote);
    subexit();
  }
  value += tracker.move(")");
  exit();
  return value;
}
function imagePeek() {
  return "!";
}

// node_modules/mdast-util-to-markdown/lib/handle/image-reference.js
imageReference2.peek = imageReferencePeek;
function imageReference2(node, _, state, info) {
  const type = node.referenceType;
  const exit = state.enter("imageReference");
  let subexit = state.enter("label");
  const tracker = state.createTracker(info);
  let value = tracker.move("![");
  const alt = state.safe(node.alt, {
    before: value,
    after: "]",
    ...tracker.current()
  });
  value += tracker.move(alt + "][");
  subexit();
  const stack = state.stack;
  state.stack = stack.filter(function(d) {
    return d !== "phrasing";
  });
  subexit = state.enter("reference");
  const reference = state.safe(state.associationId(node), {
    before: value,
    after: "]",
    ...tracker.current()
  });
  subexit();
  state.stack = stack;
  exit();
  if (type === "full" || !alt || alt !== reference) {
    value += tracker.move(reference + "]");
  } else if (type === "shortcut") {
    value = value.slice(0, -1);
  } else {
    value += tracker.move("]");
  }
  return value;
}
function imageReferencePeek() {
  return "!";
}

// node_modules/mdast-util-to-markdown/lib/handle/inline-code.js
inlineCode2.peek = inlineCodePeek;
function inlineCode2(node, _, state) {
  let value = node.value || "";
  let sequence = "`";
  let index = -1;
  while (new RegExp("(^|[^`])" + sequence + "([^`]|$)").test(value)) {
    sequence += "`";
  }
  if (/[^\n\r ]/.test(value) && (/^[\n\r ]/.test(value) && /[\n\r ]$/.test(value) || /^`|`$/.test(value))) {
    value = " " + value + " ";
  }
  while (++index < state.unsafe.length) {
    const pattern = state.unsafe[index];
    const expression = state.compilePattern(pattern);
    if (!pattern.atBreak)
      continue;
    let match;
    while (match = expression.exec(value)) {
      let position = match.index;
      if (value.charCodeAt(position) === 10 && value.charCodeAt(position - 1) === 13) {
        position--;
      }
      value = value.slice(0, position) + " " + value.slice(match.index + 1);
    }
  }
  return sequence + value + sequence;
}
function inlineCodePeek() {
  return "`";
}

// node_modules/mdast-util-to-markdown/lib/util/format-link-as-autolink.js
function formatLinkAsAutolink(node, state) {
  const raw = toString(node);
  return Boolean(!state.options.resourceLink && node.url && !node.title && node.children && node.children.length === 1 && node.children[0].type === "text" && (raw === node.url || "mailto:" + raw === node.url) && /^[a-z][+\-.a-z]+:/i.test(node.url) && !/[\0- <>\u007F]/.test(node.url));
}

// node_modules/mdast-util-to-markdown/lib/handle/link.js
link2.peek = linkPeek;
function link2(node, _, state, info) {
  const quote = checkQuote(state);
  const suffix = quote === '"' ? "Quote" : "Apostrophe";
  const tracker = state.createTracker(info);
  if (formatLinkAsAutolink(node, state)) {
    const stack = state.stack;
    state.stack = stack.filter(function(d) {
      return d !== "phrasing";
    });
    const exit = state.enter("autolink");
    let value = tracker.move("<");
    value += tracker.move(state.containerPhrasing(node, {
      before: value,
      after: ">",
      ...tracker.current()
    }));
    value += tracker.move(">");
    exit();
    state.stack = stack;
    return value;
  }
  const exit = state.enter("link");
  let subexit = state.enter("label");
  let value = tracker.move("[");
  value += tracker.move(state.containerPhrasing(node, {
    before: value,
    after: "](",
    ...tracker.current()
  }));
  value += tracker.move("](");
  subexit();
  if (!node.url && node.title || /[\0- \u007F]/.test(node.url)) {
    subexit = state.enter("destinationLiteral");
    value += tracker.move("<");
    value += tracker.move(state.safe(node.url, { before: value, after: ">", ...tracker.current() }));
    value += tracker.move(">");
  } else {
    subexit = state.enter("destinationRaw");
    value += tracker.move(state.safe(node.url, {
      before: value,
      after: node.title ? " " : ")",
      ...tracker.current()
    }));
  }
  subexit();
  if (node.title) {
    subexit = state.enter(`title${suffix}`);
    value += tracker.move(" " + quote);
    value += tracker.move(state.safe(node.title, {
      before: value,
      after: quote,
      ...tracker.current()
    }));
    value += tracker.move(quote);
    subexit();
  }
  value += tracker.move(")");
  exit();
  return value;
}
function linkPeek(node, _, state) {
  return formatLinkAsAutolink(node, state) ? "<" : "[";
}

// node_modules/mdast-util-to-markdown/lib/handle/link-reference.js
linkReference2.peek = linkReferencePeek;
function linkReference2(node, _, state, info) {
  const type = node.referenceType;
  const exit = state.enter("linkReference");
  let subexit = state.enter("label");
  const tracker = state.createTracker(info);
  let value = tracker.move("[");
  const text = state.containerPhrasing(node, {
    before: value,
    after: "]",
    ...tracker.current()
  });
  value += tracker.move(text + "][");
  subexit();
  const stack = state.stack;
  state.stack = stack.filter(function(d) {
    return d !== "phrasing";
  });
  subexit = state.enter("reference");
  const reference = state.safe(state.associationId(node), {
    before: value,
    after: "]",
    ...tracker.current()
  });
  subexit();
  state.stack = stack;
  exit();
  if (type === "full" || !text || text !== reference) {
    value += tracker.move(reference + "]");
  } else if (type === "shortcut") {
    value = value.slice(0, -1);
  } else {
    value += tracker.move("]");
  }
  return value;
}
function linkReferencePeek() {
  return "[";
}

// node_modules/mdast-util-to-markdown/lib/util/check-bullet.js
function checkBullet(state) {
  const marker = state.options.bullet || "*";
  if (marker !== "*" && marker !== "+" && marker !== "-") {
    throw new Error("Cannot serialize items with `" + marker + "` for `options.bullet`, expected `*`, `+`, or `-`");
  }
  return marker;
}

// node_modules/mdast-util-to-markdown/lib/util/check-bullet-other.js
function checkBulletOther(state) {
  const bullet = checkBullet(state);
  const bulletOther = state.options.bulletOther;
  if (!bulletOther) {
    return bullet === "*" ? "-" : "*";
  }
  if (bulletOther !== "*" && bulletOther !== "+" && bulletOther !== "-") {
    throw new Error("Cannot serialize items with `" + bulletOther + "` for `options.bulletOther`, expected `*`, `+`, or `-`");
  }
  if (bulletOther === bullet) {
    throw new Error("Expected `bullet` (`" + bullet + "`) and `bulletOther` (`" + bulletOther + "`) to be different");
  }
  return bulletOther;
}

// node_modules/mdast-util-to-markdown/lib/util/check-bullet-ordered.js
function checkBulletOrdered(state) {
  const marker = state.options.bulletOrdered || ".";
  if (marker !== "." && marker !== ")") {
    throw new Error("Cannot serialize items with `" + marker + "` for `options.bulletOrdered`, expected `.` or `)`");
  }
  return marker;
}

// node_modules/mdast-util-to-markdown/lib/util/check-rule.js
function checkRule(state) {
  const marker = state.options.rule || "*";
  if (marker !== "*" && marker !== "-" && marker !== "_") {
    throw new Error("Cannot serialize rules with `" + marker + "` for `options.rule`, expected `*`, `-`, or `_`");
  }
  return marker;
}

// node_modules/mdast-util-to-markdown/lib/handle/list.js
function list3(node, parent, state, info) {
  const exit = state.enter("list");
  const bulletCurrent = state.bulletCurrent;
  let bullet = node.ordered ? checkBulletOrdered(state) : checkBullet(state);
  const bulletOther = node.ordered ? bullet === "." ? ")" : "." : checkBulletOther(state);
  let useDifferentMarker = parent && state.bulletLastUsed ? bullet === state.bulletLastUsed : false;
  if (!node.ordered) {
    const firstListItem = node.children ? node.children[0] : undefined;
    if ((bullet === "*" || bullet === "-") && firstListItem && (!firstListItem.children || !firstListItem.children[0]) && state.stack[state.stack.length - 1] === "list" && state.stack[state.stack.length - 2] === "listItem" && state.stack[state.stack.length - 3] === "list" && state.stack[state.stack.length - 4] === "listItem" && state.indexStack[state.indexStack.length - 1] === 0 && state.indexStack[state.indexStack.length - 2] === 0 && state.indexStack[state.indexStack.length - 3] === 0) {
      useDifferentMarker = true;
    }
    if (checkRule(state) === bullet && firstListItem) {
      let index = -1;
      while (++index < node.children.length) {
        const item = node.children[index];
        if (item && item.type === "listItem" && item.children && item.children[0] && item.children[0].type === "thematicBreak") {
          useDifferentMarker = true;
          break;
        }
      }
    }
  }
  if (useDifferentMarker) {
    bullet = bulletOther;
  }
  state.bulletCurrent = bullet;
  const value = state.containerFlow(node, info);
  state.bulletLastUsed = bullet;
  state.bulletCurrent = bulletCurrent;
  exit();
  return value;
}

// node_modules/mdast-util-to-markdown/lib/util/check-list-item-indent.js
function checkListItemIndent(state) {
  const style = state.options.listItemIndent || "one";
  if (style !== "tab" && style !== "one" && style !== "mixed") {
    throw new Error("Cannot serialize items with `" + style + "` for `options.listItemIndent`, expected `tab`, `one`, or `mixed`");
  }
  return style;
}

// node_modules/mdast-util-to-markdown/lib/handle/list-item.js
function listItem2(node, parent, state, info) {
  const listItemIndent = checkListItemIndent(state);
  let bullet = state.bulletCurrent || checkBullet(state);
  if (parent && parent.type === "list" && parent.ordered) {
    bullet = (typeof parent.start === "number" && parent.start > -1 ? parent.start : 1) + (state.options.incrementListMarker === false ? 0 : parent.children.indexOf(node)) + bullet;
  }
  let size = bullet.length + 1;
  if (listItemIndent === "tab" || listItemIndent === "mixed" && (parent && parent.type === "list" && parent.spread || node.spread)) {
    size = Math.ceil(size / 4) * 4;
  }
  const tracker = state.createTracker(info);
  tracker.move(bullet + " ".repeat(size - bullet.length));
  tracker.shift(size);
  const exit = state.enter("listItem");
  const value = state.indentLines(state.containerFlow(node, tracker.current()), map);
  exit();
  return value;
  function map(line, index, blank) {
    if (index) {
      return (blank ? "" : " ".repeat(size)) + line;
    }
    return (blank ? bullet : bullet + " ".repeat(size - bullet.length)) + line;
  }
}

// node_modules/mdast-util-to-markdown/lib/handle/paragraph.js
function paragraph2(node, _, state, info) {
  const exit = state.enter("paragraph");
  const subexit = state.enter("phrasing");
  const value = state.containerPhrasing(node, info);
  subexit();
  exit();
  return value;
}

// node_modules/mdast-util-phrasing/lib/index.js
var phrasing = convert([
  "break",
  "delete",
  "emphasis",
  "footnote",
  "footnoteReference",
  "image",
  "imageReference",
  "inlineCode",
  "inlineMath",
  "link",
  "linkReference",
  "mdxJsxTextElement",
  "mdxTextExpression",
  "strong",
  "text",
  "textDirective"
]);
// node_modules/mdast-util-to-markdown/lib/handle/root.js
function root3(node, _, state, info) {
  const hasPhrasing = node.children.some(function(d) {
    return phrasing(d);
  });
  if (!hasPhrasing)
    return state.containerFlow(node, info);
  const exit = state.enter("phrasing");
  const value = state.containerPhrasing(node, info);
  exit();
  return value;
}

// node_modules/mdast-util-to-markdown/lib/util/check-strong.js
function checkStrong(state) {
  const marker = state.options.strong || "*";
  if (marker !== "*" && marker !== "_") {
    throw new Error("Cannot serialize strong with `" + marker + "` for `options.strong`, expected `*`, or `_`");
  }
  return marker;
}

// node_modules/mdast-util-to-markdown/lib/handle/strong.js
strong2.attention = attention3;
strong2.peek = peek2;
function strong2(node, _, state, info) {
  const exit = state.enter("phrasing");
  const value = state.containerPhrasing({ type: "root", children: [node] }, info);
  exit();
  return value;
}
function attention3(_, state) {
  const marker = checkStrong(state);
  return {
    construct: "strong",
    markers: marker === "*" ? ["*", "_"] : ["_", "*"],
    sizes: [2]
  };
}
function peek2(_, _1, state) {
  return state.options.strong || "*";
}

// node_modules/mdast-util-to-markdown/lib/handle/text.js
function text5(node, _, state, info) {
  return state.safe(node.value, info);
}

// node_modules/mdast-util-to-markdown/lib/util/check-rule-repetition.js
function checkRuleRepetition(state) {
  const repetition = state.options.ruleRepetition || 3;
  if (repetition < 3) {
    throw new Error("Cannot serialize rules with repetition `" + repetition + "` for `options.ruleRepetition`, expected `3` or more");
  }
  return repetition;
}

// node_modules/mdast-util-to-markdown/lib/handle/thematic-break.js
function thematicBreak3(_, _1, state) {
  const value = (checkRule(state) + (state.options.ruleSpaces ? " " : "")).repeat(checkRuleRepetition(state));
  return state.options.ruleSpaces ? value.slice(0, -1) : value;
}

// node_modules/mdast-util-to-markdown/lib/handle/index.js
var handle = {
  blockquote: blockquote2,
  break: hardBreak2,
  code: code2,
  definition: definition2,
  emphasis: emphasis2,
  hardBreak: hardBreak2,
  heading: heading2,
  html: html4,
  image: image2,
  imageReference: imageReference2,
  inlineCode: inlineCode2,
  link: link2,
  linkReference: linkReference2,
  list: list3,
  listItem: listItem2,
  paragraph: paragraph2,
  root: root3,
  strong: strong2,
  text: text5,
  thematicBreak: thematicBreak3
};
// node_modules/mdast-util-gfm-table/lib/index.js
function gfmTableFromMarkdown() {
  return {
    enter: {
      table: enterTable,
      tableData: enterCell,
      tableHeader: enterCell,
      tableRow: enterRow
    },
    exit: {
      codeText: exitCodeText,
      table: exitTable,
      tableData: exit2,
      tableHeader: exit2,
      tableRow: exit2
    }
  };
}
function enterTable(token) {
  const align = token._align;
  ok2(align, "expected `_align` on table");
  this.enter({
    type: "table",
    align: align.map(function(d) {
      return d === "none" ? null : d;
    }),
    children: []
  }, token);
  this.data.inTable = true;
}
function exitTable(token) {
  this.exit(token);
  this.data.inTable = undefined;
}
function enterRow(token) {
  this.enter({ type: "tableRow", children: [] }, token);
}
function exit2(token) {
  this.exit(token);
}
function enterCell(token) {
  this.enter({ type: "tableCell", children: [] }, token);
}
function exitCodeText(token) {
  let value = this.resume();
  if (this.data.inTable) {
    value = value.replace(/\\([\\|])/g, replace);
  }
  const node = this.stack[this.stack.length - 1];
  ok2(node.type === "inlineCode");
  node.value = value;
  this.exit(token);
}
function replace($0, $1) {
  return $1 === "|" ? $1 : $0;
}
function gfmTableToMarkdown(options) {
  const settings = options || {};
  const padding = settings.tableCellPadding;
  const alignDelimiters = settings.tablePipeAlign;
  const stringLength = settings.stringLength;
  const around = padding ? " " : "|";
  return {
    unsafe: [
      { character: "\r", inConstruct: "tableCell" },
      { character: `
`, inConstruct: "tableCell" },
      { atBreak: true, character: "|", after: "[\t :-]" },
      { character: "|", inConstruct: "tableCell" },
      { atBreak: true, character: ":", after: "-" },
      { atBreak: true, character: "-", after: "[:|-]" }
    ],
    handlers: {
      inlineCode: inlineCodeWithTable,
      table: handleTable,
      tableCell: handleTableCell,
      tableRow: handleTableRow
    }
  };
  function handleTable(node, _, state, info) {
    return serializeData(handleTableAsData(node, state, info), node.align);
  }
  function handleTableRow(node, _, state, info) {
    const row = handleTableRowAsData(node, state, info);
    const value = serializeData([row]);
    return value.slice(0, value.indexOf(`
`));
  }
  function handleTableCell(node, _, state, info) {
    const exit = state.enter("tableCell");
    const subexit = state.enter("phrasing");
    const value = state.containerPhrasing(node, {
      ...info,
      before: around,
      after: around
    });
    subexit();
    exit();
    return value;
  }
  function serializeData(matrix, align) {
    return markdownTable(matrix, {
      align,
      alignDelimiters,
      padding,
      stringLength
    });
  }
  function handleTableAsData(node, state, info) {
    const children = node.children;
    let index = -1;
    const result = [];
    const subexit = state.enter("table");
    while (++index < children.length) {
      result[index] = handleTableRowAsData(children[index], state, info);
    }
    subexit();
    return result;
  }
  function handleTableRowAsData(node, state, info) {
    const children = node.children;
    let index = -1;
    const result = [];
    const subexit = state.enter("tableRow");
    while (++index < children.length) {
      result[index] = handleTableCell(children[index], node, state, info);
    }
    subexit();
    return result;
  }
  function inlineCodeWithTable(node, parent, state) {
    let value = handle.inlineCode(node, parent, state);
    if (state.stack.includes("tableCell")) {
      value = value.replace(/\|/g, "\\$&");
    }
    return value;
  }
}
// node_modules/mdast-util-gfm-task-list-item/lib/index.js
function gfmTaskListItemFromMarkdown() {
  return {
    exit: {
      taskListCheckValueChecked: exitCheck,
      taskListCheckValueUnchecked: exitCheck,
      paragraph: exitParagraphWithTaskListItem
    }
  };
}
function gfmTaskListItemToMarkdown() {
  return {
    unsafe: [{ atBreak: true, character: "-", after: "[:|-]" }],
    handlers: { listItem: listItemWithTaskListItem }
  };
}
function exitCheck(token) {
  const node = this.stack[this.stack.length - 2];
  ok2(node.type === "listItem");
  node.checked = token.type === "taskListCheckValueChecked";
}
function exitParagraphWithTaskListItem(token) {
  const parent = this.stack[this.stack.length - 2];
  if (parent && parent.type === "listItem" && typeof parent.checked === "boolean") {
    const node = this.stack[this.stack.length - 1];
    ok2(node.type === "paragraph");
    const head = node.children[0];
    if (head && head.type === "text") {
      const siblings = parent.children;
      let index = -1;
      let firstParaghraph;
      while (++index < siblings.length) {
        const sibling = siblings[index];
        if (sibling.type === "paragraph") {
          firstParaghraph = sibling;
          break;
        }
      }
      if (firstParaghraph === node) {
        head.value = head.value.slice(1);
        if (head.value.length === 0) {
          node.children.shift();
        } else if (node.position && head.position && typeof head.position.start.offset === "number") {
          head.position.start.column++;
          head.position.start.offset++;
          node.position.start = Object.assign({}, head.position.start);
        }
      }
    }
  }
  this.exit(token);
}
function listItemWithTaskListItem(node, parent, state, info) {
  const head = node.children[0];
  const checkable = typeof node.checked === "boolean" && head && head.type === "paragraph";
  const checkbox = "[" + (node.checked ? "x" : " ") + "] ";
  const tracker = state.createTracker(info);
  if (checkable) {
    tracker.move(checkbox);
  }
  let value = handle.listItem(node, parent, state, {
    ...info,
    ...tracker.current()
  });
  if (checkable) {
    value = value.replace(/^(?:[*+-]|\d+\.)([\r\n]| {1,3})/, check);
  }
  return value;
  function check($0) {
    return $0 + checkbox;
  }
}
// node_modules/mdast-util-gfm/lib/index.js
function gfmFromMarkdown() {
  return [
    gfmAutolinkLiteralFromMarkdown(),
    gfmFootnoteFromMarkdown(),
    gfmStrikethroughFromMarkdown(),
    gfmTableFromMarkdown(),
    gfmTaskListItemFromMarkdown()
  ];
}
function gfmToMarkdown(options) {
  return {
    extensions: [
      gfmAutolinkLiteralToMarkdown(),
      gfmFootnoteToMarkdown(options),
      gfmStrikethroughToMarkdown(),
      gfmTableToMarkdown(options),
      gfmTaskListItemToMarkdown()
    ]
  };
}
// node_modules/micromark-extension-gfm-autolink-literal/lib/syntax.js
var wwwPrefix = {
  tokenize: tokenizeWwwPrefix,
  partial: true
};
var domain = {
  tokenize: tokenizeDomain,
  partial: true
};
var path = {
  tokenize: tokenizePath,
  partial: true
};
var trail = {
  tokenize: tokenizeTrail,
  partial: true
};
var emailDomainDotTrail = {
  tokenize: tokenizeEmailDomainDotTrail,
  partial: true
};
var wwwAutolink = {
  name: "wwwAutolink",
  tokenize: tokenizeWwwAutolink,
  previous: previousWww
};
var protocolAutolink = {
  name: "protocolAutolink",
  tokenize: tokenizeProtocolAutolink,
  previous: previousProtocol
};
var emailAutolink = {
  name: "emailAutolink",
  tokenize: tokenizeEmailAutolink,
  previous: previousEmail
};
var text6 = {};
function gfmAutolinkLiteral() {
  return {
    text: text6
  };
}
var code3 = 48;
while (code3 < 123) {
  text6[code3] = emailAutolink;
  code3++;
  if (code3 === 58)
    code3 = 65;
  else if (code3 === 91)
    code3 = 97;
}
text6[43] = emailAutolink;
text6[45] = emailAutolink;
text6[46] = emailAutolink;
text6[95] = emailAutolink;
text6[72] = [emailAutolink, protocolAutolink];
text6[104] = [emailAutolink, protocolAutolink];
text6[87] = [emailAutolink, wwwAutolink];
text6[119] = [emailAutolink, wwwAutolink];
function tokenizeEmailAutolink(effects, ok, nok) {
  const self2 = this;
  let dot;
  let data;
  return start;
  function start(code) {
    if (!gfmAtext(code) || !previousEmail.call(self2, self2.previous) || previousUnbalanced(self2.events)) {
      return nok(code);
    }
    effects.enter("literalAutolink");
    effects.enter("literalAutolinkEmail");
    return atext(code);
  }
  function atext(code) {
    if (gfmAtext(code)) {
      effects.consume(code);
      return atext;
    }
    if (code === 64) {
      effects.consume(code);
      return emailDomain;
    }
    return nok(code);
  }
  function emailDomain(code) {
    if (code === 46) {
      return effects.check(emailDomainDotTrail, emailDomainAfter, emailDomainDot)(code);
    }
    if (code === 45 || code === 95 || asciiAlphanumeric(code)) {
      data = true;
      effects.consume(code);
      return emailDomain;
    }
    return emailDomainAfter(code);
  }
  function emailDomainDot(code) {
    effects.consume(code);
    dot = true;
    return emailDomain;
  }
  function emailDomainAfter(code) {
    if (data && dot && asciiAlpha(self2.previous)) {
      effects.exit("literalAutolinkEmail");
      effects.exit("literalAutolink");
      return ok(code);
    }
    return nok(code);
  }
}
function tokenizeWwwAutolink(effects, ok, nok) {
  const self2 = this;
  return wwwStart;
  function wwwStart(code) {
    if (code !== 87 && code !== 119 || !previousWww.call(self2, self2.previous) || previousUnbalanced(self2.events)) {
      return nok(code);
    }
    effects.enter("literalAutolink");
    effects.enter("literalAutolinkWww");
    return effects.check(wwwPrefix, effects.attempt(domain, effects.attempt(path, wwwAfter), nok), nok)(code);
  }
  function wwwAfter(code) {
    effects.exit("literalAutolinkWww");
    effects.exit("literalAutolink");
    return ok(code);
  }
}
function tokenizeProtocolAutolink(effects, ok, nok) {
  const self2 = this;
  let buffer = "";
  let seen = false;
  return protocolStart;
  function protocolStart(code) {
    if ((code === 72 || code === 104) && previousProtocol.call(self2, self2.previous) && !previousUnbalanced(self2.events)) {
      effects.enter("literalAutolink");
      effects.enter("literalAutolinkHttp");
      buffer += String.fromCodePoint(code);
      effects.consume(code);
      return protocolPrefixInside;
    }
    return nok(code);
  }
  function protocolPrefixInside(code) {
    if (asciiAlpha(code) && buffer.length < 5) {
      buffer += String.fromCodePoint(code);
      effects.consume(code);
      return protocolPrefixInside;
    }
    if (code === 58) {
      const protocol = buffer.toLowerCase();
      if (protocol === "http" || protocol === "https") {
        effects.consume(code);
        return protocolSlashesInside;
      }
    }
    return nok(code);
  }
  function protocolSlashesInside(code) {
    if (code === 47) {
      effects.consume(code);
      if (seen) {
        return afterProtocol;
      }
      seen = true;
      return protocolSlashesInside;
    }
    return nok(code);
  }
  function afterProtocol(code) {
    return code === null || asciiControl(code) || markdownLineEndingOrSpace(code) || unicodeWhitespace(code) || unicodePunctuation(code) ? nok(code) : effects.attempt(domain, effects.attempt(path, protocolAfter), nok)(code);
  }
  function protocolAfter(code) {
    effects.exit("literalAutolinkHttp");
    effects.exit("literalAutolink");
    return ok(code);
  }
}
function tokenizeWwwPrefix(effects, ok, nok) {
  let size = 0;
  return wwwPrefixInside;
  function wwwPrefixInside(code) {
    if ((code === 87 || code === 119) && size < 3) {
      size++;
      effects.consume(code);
      return wwwPrefixInside;
    }
    if (code === 46 && size === 3) {
      effects.consume(code);
      return wwwPrefixAfter;
    }
    return nok(code);
  }
  function wwwPrefixAfter(code) {
    return code === null ? nok(code) : ok(code);
  }
}
function tokenizeDomain(effects, ok, nok) {
  let underscoreInLastSegment;
  let underscoreInLastLastSegment;
  let seen;
  return domainInside;
  function domainInside(code) {
    if (code === 46 || code === 95) {
      return effects.check(trail, domainAfter, domainAtPunctuation)(code);
    }
    if (code === null || markdownLineEndingOrSpace(code) || unicodeWhitespace(code) || code !== 45 && unicodePunctuation(code)) {
      return domainAfter(code);
    }
    seen = true;
    effects.consume(code);
    return domainInside;
  }
  function domainAtPunctuation(code) {
    if (code === 95) {
      underscoreInLastSegment = true;
    } else {
      underscoreInLastLastSegment = underscoreInLastSegment;
      underscoreInLastSegment = undefined;
    }
    effects.consume(code);
    return domainInside;
  }
  function domainAfter(code) {
    if (underscoreInLastLastSegment || underscoreInLastSegment || !seen) {
      return nok(code);
    }
    return ok(code);
  }
}
function tokenizePath(effects, ok) {
  let sizeOpen = 0;
  let sizeClose = 0;
  return pathInside;
  function pathInside(code) {
    if (code === 40) {
      sizeOpen++;
      effects.consume(code);
      return pathInside;
    }
    if (code === 41 && sizeClose < sizeOpen) {
      return pathAtPunctuation(code);
    }
    if (code === 33 || code === 34 || code === 38 || code === 39 || code === 41 || code === 42 || code === 44 || code === 46 || code === 58 || code === 59 || code === 60 || code === 63 || code === 93 || code === 95 || code === 126) {
      return effects.check(trail, ok, pathAtPunctuation)(code);
    }
    if (code === null || markdownLineEndingOrSpace(code) || unicodeWhitespace(code)) {
      return ok(code);
    }
    effects.consume(code);
    return pathInside;
  }
  function pathAtPunctuation(code) {
    if (code === 41) {
      sizeClose++;
    }
    effects.consume(code);
    return pathInside;
  }
}
function tokenizeTrail(effects, ok, nok) {
  return trail;
  function trail(code) {
    if (code === 33 || code === 34 || code === 39 || code === 41 || code === 42 || code === 44 || code === 46 || code === 58 || code === 59 || code === 63 || code === 95 || code === 126) {
      effects.consume(code);
      return trail;
    }
    if (code === 38) {
      effects.consume(code);
      return trailCharacterReferenceStart;
    }
    if (code === 93) {
      effects.consume(code);
      return trailBracketAfter;
    }
    if (code === 60 || code === null || markdownLineEndingOrSpace(code) || unicodeWhitespace(code)) {
      return ok(code);
    }
    return nok(code);
  }
  function trailBracketAfter(code) {
    if (code === null || code === 40 || code === 91 || markdownLineEndingOrSpace(code) || unicodeWhitespace(code)) {
      return ok(code);
    }
    return trail(code);
  }
  function trailCharacterReferenceStart(code) {
    return asciiAlpha(code) ? trailCharacterReferenceInside(code) : nok(code);
  }
  function trailCharacterReferenceInside(code) {
    if (code === 59) {
      effects.consume(code);
      return trail;
    }
    if (asciiAlpha(code)) {
      effects.consume(code);
      return trailCharacterReferenceInside;
    }
    return nok(code);
  }
}
function tokenizeEmailDomainDotTrail(effects, ok, nok) {
  return start;
  function start(code) {
    effects.consume(code);
    return after;
  }
  function after(code) {
    return asciiAlphanumeric(code) ? nok(code) : ok(code);
  }
}
function previousWww(code) {
  return code === null || code === 40 || code === 42 || code === 95 || code === 91 || code === 93 || code === 126 || markdownLineEndingOrSpace(code);
}
function previousProtocol(code) {
  return !asciiAlpha(code);
}
function previousEmail(code) {
  return !(code === 47 || gfmAtext(code));
}
function gfmAtext(code) {
  return code === 43 || code === 45 || code === 46 || code === 95 || asciiAlphanumeric(code);
}
function previousUnbalanced(events) {
  let index = events.length;
  let result = false;
  while (index--) {
    const token = events[index][1];
    if ((token.type === "labelLink" || token.type === "labelImage") && !token._balanced) {
      result = true;
      break;
    }
    if (token._gfmAutolinkLiteralWalkedInto) {
      result = false;
      break;
    }
  }
  if (events.length > 0 && !result) {
    events[events.length - 1][1]._gfmAutolinkLiteralWalkedInto = true;
  }
  return result;
}
// node_modules/micromark-extension-gfm-footnote/lib/syntax.js
var indent = {
  tokenize: tokenizeIndent2,
  partial: true
};
function gfmFootnote() {
  return {
    document: {
      [91]: {
        name: "gfmFootnoteDefinition",
        tokenize: tokenizeDefinitionStart,
        continuation: {
          tokenize: tokenizeDefinitionContinuation
        },
        exit: gfmFootnoteDefinitionEnd
      }
    },
    text: {
      [91]: {
        name: "gfmFootnoteCall",
        tokenize: tokenizeGfmFootnoteCall
      },
      [93]: {
        name: "gfmPotentialFootnoteCall",
        add: "after",
        tokenize: tokenizePotentialGfmFootnoteCall,
        resolveTo: resolveToPotentialGfmFootnoteCall
      }
    }
  };
}
function tokenizePotentialGfmFootnoteCall(effects, ok, nok) {
  const self2 = this;
  let index = self2.events.length;
  const defined = self2.parser.gfmFootnotes || (self2.parser.gfmFootnotes = []);
  let labelStart;
  while (index--) {
    const token = self2.events[index][1];
    if (token.type === "labelImage") {
      labelStart = token;
      break;
    }
    if (token.type === "gfmFootnoteCall" || token.type === "labelLink" || token.type === "label" || token.type === "image" || token.type === "link") {
      break;
    }
  }
  return start;
  function start(code) {
    if (!labelStart || !labelStart._balanced) {
      return nok(code);
    }
    const id = normalizeIdentifier(self2.sliceSerialize({
      start: labelStart.end,
      end: self2.now()
    }));
    if (id.codePointAt(0) !== 94 || !defined.includes(id.slice(1))) {
      return nok(code);
    }
    effects.enter("gfmFootnoteCallLabelMarker");
    effects.consume(code);
    effects.exit("gfmFootnoteCallLabelMarker");
    return ok(code);
  }
}
function resolveToPotentialGfmFootnoteCall(events, context) {
  let index = events.length;
  let labelStart;
  while (index--) {
    if (events[index][1].type === "labelImage" && events[index][0] === "enter") {
      labelStart = events[index][1];
      break;
    }
  }
  events[index + 1][1].type = "data";
  events[index + 3][1].type = "gfmFootnoteCallLabelMarker";
  const call = {
    type: "gfmFootnoteCall",
    start: Object.assign({}, events[index + 3][1].start),
    end: Object.assign({}, events[events.length - 1][1].end)
  };
  const marker = {
    type: "gfmFootnoteCallMarker",
    start: Object.assign({}, events[index + 3][1].end),
    end: Object.assign({}, events[index + 3][1].end)
  };
  marker.end.column++;
  marker.end.offset++;
  marker.end._bufferIndex++;
  const string = {
    type: "gfmFootnoteCallString",
    start: Object.assign({}, marker.end),
    end: Object.assign({}, events[events.length - 1][1].start)
  };
  const chunk = {
    type: "chunkString",
    contentType: "string",
    start: Object.assign({}, string.start),
    end: Object.assign({}, string.end)
  };
  const replacement = [
    events[index + 1],
    events[index + 2],
    ["enter", call, context],
    events[index + 3],
    events[index + 4],
    ["enter", marker, context],
    ["exit", marker, context],
    ["enter", string, context],
    ["enter", chunk, context],
    ["exit", chunk, context],
    ["exit", string, context],
    events[events.length - 2],
    events[events.length - 1],
    ["exit", call, context]
  ];
  events.splice(index, events.length - index + 1, ...replacement);
  return events;
}
function tokenizeGfmFootnoteCall(effects, ok, nok) {
  const self2 = this;
  const defined = self2.parser.gfmFootnotes || (self2.parser.gfmFootnotes = []);
  let size = 0;
  let data;
  return start;
  function start(code) {
    effects.enter("gfmFootnoteCall");
    effects.enter("gfmFootnoteCallLabelMarker");
    effects.consume(code);
    effects.exit("gfmFootnoteCallLabelMarker");
    return callStart;
  }
  function callStart(code) {
    if (code !== 94)
      return nok(code);
    effects.enter("gfmFootnoteCallMarker");
    effects.consume(code);
    effects.exit("gfmFootnoteCallMarker");
    effects.enter("gfmFootnoteCallString");
    effects.enter("chunkString").contentType = "string";
    return callData;
  }
  function callData(code) {
    if (size > 999 || code === 93 && !data || code === null || code === 91 || markdownLineEndingOrSpace(code)) {
      return nok(code);
    }
    if (code === 93) {
      effects.exit("chunkString");
      const token = effects.exit("gfmFootnoteCallString");
      if (!defined.includes(normalizeIdentifier(self2.sliceSerialize(token)))) {
        return nok(code);
      }
      effects.enter("gfmFootnoteCallLabelMarker");
      effects.consume(code);
      effects.exit("gfmFootnoteCallLabelMarker");
      effects.exit("gfmFootnoteCall");
      return ok;
    }
    if (!markdownLineEndingOrSpace(code)) {
      data = true;
    }
    size++;
    effects.consume(code);
    return code === 92 ? callEscape : callData;
  }
  function callEscape(code) {
    if (code === 91 || code === 92 || code === 93) {
      effects.consume(code);
      size++;
      return callData;
    }
    return callData(code);
  }
}
function tokenizeDefinitionStart(effects, ok, nok) {
  const self2 = this;
  const defined = self2.parser.gfmFootnotes || (self2.parser.gfmFootnotes = []);
  let identifier;
  let size = 0;
  let data;
  return start;
  function start(code) {
    effects.enter("gfmFootnoteDefinition")._container = true;
    effects.enter("gfmFootnoteDefinitionLabel");
    effects.enter("gfmFootnoteDefinitionLabelMarker");
    effects.consume(code);
    effects.exit("gfmFootnoteDefinitionLabelMarker");
    return labelAtMarker;
  }
  function labelAtMarker(code) {
    if (code === 94) {
      effects.enter("gfmFootnoteDefinitionMarker");
      effects.consume(code);
      effects.exit("gfmFootnoteDefinitionMarker");
      effects.enter("gfmFootnoteDefinitionLabelString");
      effects.enter("chunkString").contentType = "string";
      return labelInside;
    }
    return nok(code);
  }
  function labelInside(code) {
    if (size > 999 || code === 93 && !data || code === null || code === 91 || markdownLineEndingOrSpace(code)) {
      return nok(code);
    }
    if (code === 93) {
      effects.exit("chunkString");
      const token = effects.exit("gfmFootnoteDefinitionLabelString");
      identifier = normalizeIdentifier(self2.sliceSerialize(token));
      effects.enter("gfmFootnoteDefinitionLabelMarker");
      effects.consume(code);
      effects.exit("gfmFootnoteDefinitionLabelMarker");
      effects.exit("gfmFootnoteDefinitionLabel");
      return labelAfter;
    }
    if (!markdownLineEndingOrSpace(code)) {
      data = true;
    }
    size++;
    effects.consume(code);
    return code === 92 ? labelEscape : labelInside;
  }
  function labelEscape(code) {
    if (code === 91 || code === 92 || code === 93) {
      effects.consume(code);
      size++;
      return labelInside;
    }
    return labelInside(code);
  }
  function labelAfter(code) {
    if (code === 58) {
      effects.enter("definitionMarker");
      effects.consume(code);
      effects.exit("definitionMarker");
      if (!defined.includes(identifier)) {
        defined.push(identifier);
      }
      return factorySpace(effects, whitespaceAfter, "gfmFootnoteDefinitionWhitespace");
    }
    return nok(code);
  }
  function whitespaceAfter(code) {
    return ok(code);
  }
}
function tokenizeDefinitionContinuation(effects, ok, nok) {
  return effects.check(blankLine, ok, effects.attempt(indent, ok, nok));
}
function gfmFootnoteDefinitionEnd(effects) {
  effects.exit("gfmFootnoteDefinition");
}
function tokenizeIndent2(effects, ok, nok) {
  const self2 = this;
  return factorySpace(effects, afterPrefix, "gfmFootnoteDefinitionIndent", 4 + 1);
  function afterPrefix(code) {
    const tail = self2.events[self2.events.length - 1];
    return tail && tail[1].type === "gfmFootnoteDefinitionIndent" && tail[2].sliceSerialize(tail[1], true).length === 4 ? ok(code) : nok(code);
  }
}
// node_modules/micromark-extension-gfm-strikethrough/lib/syntax.js
function gfmStrikethrough(options) {
  const options_ = options || {};
  let single = options_.singleTilde;
  const tokenizer = {
    name: "strikethrough",
    tokenize: tokenizeStrikethrough,
    resolveAll: resolveAllStrikethrough
  };
  if (single === null || single === undefined) {
    single = true;
  }
  return {
    text: {
      [126]: tokenizer
    },
    insideSpan: {
      null: [tokenizer]
    },
    attentionMarkers: {
      null: [126]
    }
  };
  function resolveAllStrikethrough(events, context) {
    let index = -1;
    while (++index < events.length) {
      if (events[index][0] === "enter" && events[index][1].type === "strikethroughSequenceTemporary" && events[index][1]._close) {
        let open = index;
        while (open--) {
          if (events[open][0] === "exit" && events[open][1].type === "strikethroughSequenceTemporary" && events[open][1]._open && events[index][1].end.offset - events[index][1].start.offset === events[open][1].end.offset - events[open][1].start.offset) {
            events[index][1].type = "strikethroughSequence";
            events[open][1].type = "strikethroughSequence";
            const strikethrough = {
              type: "strikethrough",
              start: Object.assign({}, events[open][1].start),
              end: Object.assign({}, events[index][1].end)
            };
            const text = {
              type: "strikethroughText",
              start: Object.assign({}, events[open][1].end),
              end: Object.assign({}, events[index][1].start)
            };
            const nextEvents = [["enter", strikethrough, context], ["enter", events[open][1], context], ["exit", events[open][1], context], ["enter", text, context]];
            const insideSpan = context.parser.constructs.insideSpan.null;
            if (insideSpan) {
              splice(nextEvents, nextEvents.length, 0, resolveAll(insideSpan, events.slice(open + 1, index), context));
            }
            splice(nextEvents, nextEvents.length, 0, [["exit", text, context], ["enter", events[index][1], context], ["exit", events[index][1], context], ["exit", strikethrough, context]]);
            splice(events, open - 1, index - open + 3, nextEvents);
            index = open + nextEvents.length - 2;
            break;
          }
        }
      }
    }
    index = -1;
    while (++index < events.length) {
      if (events[index][1].type === "strikethroughSequenceTemporary") {
        events[index][1].type = "data";
      }
    }
    return events;
  }
  function tokenizeStrikethrough(effects, ok, nok) {
    const previous = this.previous;
    const events = this.events;
    let size = 0;
    return start;
    function start(code) {
      if (previous === 126 && events[events.length - 1][1].type !== "characterEscape") {
        return nok(code);
      }
      effects.enter("strikethroughSequenceTemporary");
      return more(code);
    }
    function more(code) {
      const before = classifyCharacter(previous);
      if (code === 126) {
        if (size > 1)
          return nok(code);
        effects.consume(code);
        size++;
        return more;
      }
      if (size < 2 && !single)
        return nok(code);
      const token = effects.exit("strikethroughSequenceTemporary");
      const after = classifyCharacter(code);
      token._open = !after || after === 2 && Boolean(before);
      token._close = !before || before === 2 && Boolean(after);
      return ok(code);
    }
  }
}
// node_modules/micromark-extension-gfm-table/lib/edit-map.js
class EditMap2 {
  constructor() {
    this.map = [];
    this.index = new Map;
  }
  add(index, remove, add) {
    addImplementation2(this, index, remove, add);
  }
  consume(events) {
    this.map.sort(function(a, b) {
      return a[0] - b[0];
    });
    if (this.map.length === 0) {
      return;
    }
    let index = this.map.length;
    const vecs = [];
    while (index > 0) {
      index -= 1;
      vecs.push(events.slice(this.map[index][0] + this.map[index][1]), this.map[index][2]);
      events.length = this.map[index][0];
    }
    vecs.push(events.slice());
    events.length = 0;
    let slice = vecs.pop();
    while (slice) {
      for (const element of slice) {
        events.push(element);
      }
      slice = vecs.pop();
    }
    this.map.length = 0;
    this.index.clear();
  }
}
function addImplementation2(editMap, at, remove, add) {
  if (remove === 0 && add.length === 0) {
    return;
  }
  const existing = editMap.index.get(at);
  if (existing) {
    existing[1] += remove;
    existing[2].push(...add);
    return;
  }
  const change = [at, remove, add];
  editMap.map.push(change);
  editMap.index.set(at, change);
}

// node_modules/micromark-extension-gfm-table/lib/infer.js
function gfmTableAlign(events, index) {
  let inDelimiterRow = false;
  const align = [];
  while (index < events.length) {
    const event = events[index];
    if (inDelimiterRow) {
      if (event[0] === "enter") {
        if (event[1].type === "tableContent") {
          align.push(events[index + 1][1].type === "tableDelimiterMarker" ? "left" : "none");
        }
      } else if (event[1].type === "tableContent") {
        if (events[index - 1][1].type === "tableDelimiterMarker") {
          const alignIndex = align.length - 1;
          align[alignIndex] = align[alignIndex] === "left" ? "center" : "right";
        }
      } else if (event[1].type === "tableDelimiterRow") {
        break;
      }
    } else if (event[0] === "enter" && event[1].type === "tableDelimiterRow") {
      inDelimiterRow = true;
    }
    index += 1;
  }
  return align;
}

// node_modules/micromark-extension-gfm-table/lib/syntax.js
function gfmTable() {
  return {
    flow: {
      null: {
        name: "table",
        tokenize: tokenizeTable,
        resolveAll: resolveTable
      }
    }
  };
}
function tokenizeTable(effects, ok, nok) {
  const self2 = this;
  let size = 0;
  let sizeB = 0;
  let seen;
  return start;
  function start(code) {
    let index = self2.events.length - 1;
    while (index > -1) {
      const {
        type
      } = self2.events[index][1];
      if (type === "lineEnding" || type === "linePrefix") {
        index--;
      } else {
        break;
      }
    }
    const tail = index > -1 ? self2.events[index][1].type : null;
    const next = tail === "tableHead" || tail === "tableRow" ? bodyRowStart : headRowBefore;
    if (next === bodyRowStart && self2.parser.lazy[self2.now().line]) {
      return nok(code);
    }
    return next(code);
  }
  function headRowBefore(code) {
    effects.enter("tableHead");
    effects.enter("tableRow");
    return headRowStart(code);
  }
  function headRowStart(code) {
    if (code === 124) {
      return headRowBreak(code);
    }
    seen = true;
    sizeB += 1;
    return headRowBreak(code);
  }
  function headRowBreak(code) {
    if (code === null) {
      return nok(code);
    }
    if (markdownLineEnding(code)) {
      if (sizeB > 1) {
        sizeB = 0;
        self2.interrupt = true;
        effects.exit("tableRow");
        effects.enter("lineEnding");
        effects.consume(code);
        effects.exit("lineEnding");
        return headDelimiterStart;
      }
      return nok(code);
    }
    if (markdownSpace(code)) {
      return factorySpace(effects, headRowBreak, "whitespace")(code);
    }
    sizeB += 1;
    if (seen) {
      seen = false;
      size += 1;
    }
    if (code === 124) {
      effects.enter("tableCellDivider");
      effects.consume(code);
      effects.exit("tableCellDivider");
      seen = true;
      return headRowBreak;
    }
    effects.enter("data");
    return headRowData(code);
  }
  function headRowData(code) {
    if (code === null || code === 124 || markdownLineEndingOrSpace(code)) {
      effects.exit("data");
      return headRowBreak(code);
    }
    effects.consume(code);
    return code === 92 ? headRowEscape : headRowData;
  }
  function headRowEscape(code) {
    if (code === 92 || code === 124) {
      effects.consume(code);
      return headRowData;
    }
    return headRowData(code);
  }
  function headDelimiterStart(code) {
    self2.interrupt = false;
    if (self2.parser.lazy[self2.now().line]) {
      return nok(code);
    }
    effects.enter("tableDelimiterRow");
    seen = false;
    if (markdownSpace(code)) {
      return factorySpace(effects, headDelimiterBefore, "linePrefix", self2.parser.constructs.disable.null.includes("codeIndented") ? undefined : 4)(code);
    }
    return headDelimiterBefore(code);
  }
  function headDelimiterBefore(code) {
    if (code === 45 || code === 58) {
      return headDelimiterValueBefore(code);
    }
    if (code === 124) {
      seen = true;
      effects.enter("tableCellDivider");
      effects.consume(code);
      effects.exit("tableCellDivider");
      return headDelimiterCellBefore;
    }
    return headDelimiterNok(code);
  }
  function headDelimiterCellBefore(code) {
    if (markdownSpace(code)) {
      return factorySpace(effects, headDelimiterValueBefore, "whitespace")(code);
    }
    return headDelimiterValueBefore(code);
  }
  function headDelimiterValueBefore(code) {
    if (code === 58) {
      sizeB += 1;
      seen = true;
      effects.enter("tableDelimiterMarker");
      effects.consume(code);
      effects.exit("tableDelimiterMarker");
      return headDelimiterLeftAlignmentAfter;
    }
    if (code === 45) {
      sizeB += 1;
      return headDelimiterLeftAlignmentAfter(code);
    }
    if (code === null || markdownLineEnding(code)) {
      return headDelimiterCellAfter(code);
    }
    return headDelimiterNok(code);
  }
  function headDelimiterLeftAlignmentAfter(code) {
    if (code === 45) {
      effects.enter("tableDelimiterFiller");
      return headDelimiterFiller(code);
    }
    return headDelimiterNok(code);
  }
  function headDelimiterFiller(code) {
    if (code === 45) {
      effects.consume(code);
      return headDelimiterFiller;
    }
    if (code === 58) {
      seen = true;
      effects.exit("tableDelimiterFiller");
      effects.enter("tableDelimiterMarker");
      effects.consume(code);
      effects.exit("tableDelimiterMarker");
      return headDelimiterRightAlignmentAfter;
    }
    effects.exit("tableDelimiterFiller");
    return headDelimiterRightAlignmentAfter(code);
  }
  function headDelimiterRightAlignmentAfter(code) {
    if (markdownSpace(code)) {
      return factorySpace(effects, headDelimiterCellAfter, "whitespace")(code);
    }
    return headDelimiterCellAfter(code);
  }
  function headDelimiterCellAfter(code) {
    if (code === 124) {
      return headDelimiterBefore(code);
    }
    if (code === null || markdownLineEnding(code)) {
      if (!seen || size !== sizeB) {
        return headDelimiterNok(code);
      }
      effects.exit("tableDelimiterRow");
      effects.exit("tableHead");
      return ok(code);
    }
    return headDelimiterNok(code);
  }
  function headDelimiterNok(code) {
    return nok(code);
  }
  function bodyRowStart(code) {
    effects.enter("tableRow");
    return bodyRowBreak(code);
  }
  function bodyRowBreak(code) {
    if (code === 124) {
      effects.enter("tableCellDivider");
      effects.consume(code);
      effects.exit("tableCellDivider");
      return bodyRowBreak;
    }
    if (code === null || markdownLineEnding(code)) {
      effects.exit("tableRow");
      return ok(code);
    }
    if (markdownSpace(code)) {
      return factorySpace(effects, bodyRowBreak, "whitespace")(code);
    }
    effects.enter("data");
    return bodyRowData(code);
  }
  function bodyRowData(code) {
    if (code === null || code === 124 || markdownLineEndingOrSpace(code)) {
      effects.exit("data");
      return bodyRowBreak(code);
    }
    effects.consume(code);
    return code === 92 ? bodyRowEscape : bodyRowData;
  }
  function bodyRowEscape(code) {
    if (code === 92 || code === 124) {
      effects.consume(code);
      return bodyRowData;
    }
    return bodyRowData(code);
  }
}
function resolveTable(events, context) {
  let index = -1;
  let inFirstCellAwaitingPipe = true;
  let rowKind = 0;
  let lastCell = [0, 0, 0, 0];
  let cell = [0, 0, 0, 0];
  let afterHeadAwaitingFirstBodyRow = false;
  let lastTableEnd = 0;
  let currentTable;
  let currentBody;
  let currentCell;
  const map = new EditMap2;
  while (++index < events.length) {
    const event = events[index];
    const token = event[1];
    if (event[0] === "enter") {
      if (token.type === "tableHead") {
        afterHeadAwaitingFirstBodyRow = false;
        if (lastTableEnd !== 0) {
          flushTableEnd(map, context, lastTableEnd, currentTable, currentBody);
          currentBody = undefined;
          lastTableEnd = 0;
        }
        currentTable = {
          type: "table",
          start: Object.assign({}, token.start),
          end: Object.assign({}, token.end)
        };
        map.add(index, 0, [["enter", currentTable, context]]);
      } else if (token.type === "tableRow" || token.type === "tableDelimiterRow") {
        inFirstCellAwaitingPipe = true;
        currentCell = undefined;
        lastCell = [0, 0, 0, 0];
        cell = [0, index + 1, 0, 0];
        if (afterHeadAwaitingFirstBodyRow) {
          afterHeadAwaitingFirstBodyRow = false;
          currentBody = {
            type: "tableBody",
            start: Object.assign({}, token.start),
            end: Object.assign({}, token.end)
          };
          map.add(index, 0, [["enter", currentBody, context]]);
        }
        rowKind = token.type === "tableDelimiterRow" ? 2 : currentBody ? 3 : 1;
      } else if (rowKind && (token.type === "data" || token.type === "tableDelimiterMarker" || token.type === "tableDelimiterFiller")) {
        inFirstCellAwaitingPipe = false;
        if (cell[2] === 0) {
          if (lastCell[1] !== 0) {
            cell[0] = cell[1];
            currentCell = flushCell(map, context, lastCell, rowKind, undefined, currentCell);
            lastCell = [0, 0, 0, 0];
          }
          cell[2] = index;
        }
      } else if (token.type === "tableCellDivider") {
        if (inFirstCellAwaitingPipe) {
          inFirstCellAwaitingPipe = false;
        } else {
          if (lastCell[1] !== 0) {
            cell[0] = cell[1];
            currentCell = flushCell(map, context, lastCell, rowKind, undefined, currentCell);
          }
          lastCell = cell;
          cell = [lastCell[1], index, 0, 0];
        }
      }
    } else if (token.type === "tableHead") {
      afterHeadAwaitingFirstBodyRow = true;
      lastTableEnd = index;
    } else if (token.type === "tableRow" || token.type === "tableDelimiterRow") {
      lastTableEnd = index;
      if (lastCell[1] !== 0) {
        cell[0] = cell[1];
        currentCell = flushCell(map, context, lastCell, rowKind, index, currentCell);
      } else if (cell[1] !== 0) {
        currentCell = flushCell(map, context, cell, rowKind, index, currentCell);
      }
      rowKind = 0;
    } else if (rowKind && (token.type === "data" || token.type === "tableDelimiterMarker" || token.type === "tableDelimiterFiller")) {
      cell[3] = index;
    }
  }
  if (lastTableEnd !== 0) {
    flushTableEnd(map, context, lastTableEnd, currentTable, currentBody);
  }
  map.consume(context.events);
  index = -1;
  while (++index < context.events.length) {
    const event = context.events[index];
    if (event[0] === "enter" && event[1].type === "table") {
      event[1]._align = gfmTableAlign(context.events, index);
    }
  }
  return events;
}
function flushCell(map, context, range, rowKind, rowEnd, previousCell) {
  const groupName = rowKind === 1 ? "tableHeader" : rowKind === 2 ? "tableDelimiter" : "tableData";
  const valueName = "tableContent";
  if (range[0] !== 0) {
    previousCell.end = Object.assign({}, getPoint(context.events, range[0]));
    map.add(range[0], 0, [["exit", previousCell, context]]);
  }
  const now = getPoint(context.events, range[1]);
  previousCell = {
    type: groupName,
    start: Object.assign({}, now),
    end: Object.assign({}, now)
  };
  map.add(range[1], 0, [["enter", previousCell, context]]);
  if (range[2] !== 0) {
    const relatedStart = getPoint(context.events, range[2]);
    const relatedEnd = getPoint(context.events, range[3]);
    const valueToken = {
      type: valueName,
      start: Object.assign({}, relatedStart),
      end: Object.assign({}, relatedEnd)
    };
    map.add(range[2], 0, [["enter", valueToken, context]]);
    if (rowKind !== 2) {
      const start = context.events[range[2]];
      const end = context.events[range[3]];
      start[1].end = Object.assign({}, end[1].end);
      start[1].type = "chunkText";
      start[1].contentType = "text";
      if (range[3] > range[2] + 1) {
        const a = range[2] + 1;
        const b = range[3] - range[2] - 1;
        map.add(a, b, []);
      }
    }
    map.add(range[3] + 1, 0, [["exit", valueToken, context]]);
  }
  if (rowEnd !== undefined) {
    previousCell.end = Object.assign({}, getPoint(context.events, rowEnd));
    map.add(rowEnd, 0, [["exit", previousCell, context]]);
    previousCell = undefined;
  }
  return previousCell;
}
function flushTableEnd(map, context, index, table, tableBody) {
  const exits = [];
  const related = getPoint(context.events, index);
  if (tableBody) {
    tableBody.end = Object.assign({}, related);
    exits.push(["exit", tableBody, context]);
  }
  table.end = Object.assign({}, related);
  exits.push(["exit", table, context]);
  map.add(index + 1, 0, exits);
}
function getPoint(events, index) {
  const event = events[index];
  const side = event[0] === "enter" ? "start" : "end";
  return event[1][side];
}
// node_modules/micromark-extension-gfm-task-list-item/lib/syntax.js
var tasklistCheck = {
  name: "tasklistCheck",
  tokenize: tokenizeTasklistCheck
};
function gfmTaskListItem() {
  return {
    text: {
      [91]: tasklistCheck
    }
  };
}
function tokenizeTasklistCheck(effects, ok, nok) {
  const self2 = this;
  return open;
  function open(code) {
    if (self2.previous !== null || !self2._gfmTasklistFirstContentOfListItem) {
      return nok(code);
    }
    effects.enter("taskListCheck");
    effects.enter("taskListCheckMarker");
    effects.consume(code);
    effects.exit("taskListCheckMarker");
    return inside;
  }
  function inside(code) {
    if (markdownLineEndingOrSpace(code)) {
      effects.enter("taskListCheckValueUnchecked");
      effects.consume(code);
      effects.exit("taskListCheckValueUnchecked");
      return close;
    }
    if (code === 88 || code === 120) {
      effects.enter("taskListCheckValueChecked");
      effects.consume(code);
      effects.exit("taskListCheckValueChecked");
      return close;
    }
    return nok(code);
  }
  function close(code) {
    if (code === 93) {
      effects.enter("taskListCheckMarker");
      effects.consume(code);
      effects.exit("taskListCheckMarker");
      effects.exit("taskListCheck");
      return after;
    }
    return nok(code);
  }
  function after(code) {
    if (markdownLineEnding(code)) {
      return ok(code);
    }
    if (markdownSpace(code)) {
      return effects.check({
        tokenize: spaceThenNonSpace
      }, ok, nok)(code);
    }
    return nok(code);
  }
}
function spaceThenNonSpace(effects, ok, nok) {
  return factorySpace(effects, after, "whitespace");
  function after(code) {
    return code === null ? nok(code) : ok(code);
  }
}
// node_modules/micromark-extension-gfm/index.js
function gfm(options) {
  return combineExtensions([
    gfmAutolinkLiteral(),
    gfmFootnote(),
    gfmStrikethrough(options),
    gfmTable(),
    gfmTaskListItem()
  ]);
}

// node_modules/remark-gfm/lib/index.js
var emptyOptions4 = {};
function remarkGfm(options) {
  const self2 = this;
  const settings = options || emptyOptions4;
  const data = self2.data();
  const micromarkExtensions = data.micromarkExtensions || (data.micromarkExtensions = []);
  const fromMarkdownExtensions = data.fromMarkdownExtensions || (data.fromMarkdownExtensions = []);
  const toMarkdownExtensions = data.toMarkdownExtensions || (data.toMarkdownExtensions = []);
  micromarkExtensions.push(gfm(settings));
  fromMarkdownExtensions.push(gfmFromMarkdown());
  toMarkdownExtensions.push(gfmToMarkdown(settings));
}
// src/sidepanel/markdown.tsx
var jsx_runtime5 = __toESM(require_jsx_runtime(), 1);
var COMPONENTS = {
  a: (props) => /* @__PURE__ */ jsx_runtime5.jsx("a", {
    ...props,
    target: "_blank",
    rel: "noopener noreferrer"
  })
};
function Markdown2(props) {
  return /* @__PURE__ */ jsx_runtime5.jsx("div", {
    className: "markdown",
    children: /* @__PURE__ */ jsx_runtime5.jsx(Markdown, {
      remarkPlugins: [remarkGfm],
      components: COMPONENTS,
      children: props.text
    })
  });
}
function ToolCallBlock(props) {
  return /* @__PURE__ */ jsx_runtime5.jsxs("details", {
    className: "tool-call",
    children: [
      /* @__PURE__ */ jsx_runtime5.jsxs("summary", {
        children: [
          props.streaming ? /* @__PURE__ */ jsx_runtime5.jsx("span", {
            className: "spinner"
          }) : /* @__PURE__ */ jsx_runtime5.jsx("span", {
            className: "tool-icon",
            children: "⚙"
          }),
          /* @__PURE__ */ jsx_runtime5.jsx("span", {
            className: "grow",
            children: props.title || t2("AI tool")
          })
        ]
      }),
      props.content && /* @__PURE__ */ jsx_runtime5.jsx("div", {
        className: "tool-call-body",
        children: /* @__PURE__ */ jsx_runtime5.jsx(Markdown2, {
          text: props.content
        })
      })
    ]
  });
}
function AssistantContent(props) {
  const segments = import_react6.default.useMemo(() => parseToolCallSegments(props.content), [props.content]);
  return /* @__PURE__ */ jsx_runtime5.jsx(jsx_runtime5.Fragment, {
    children: segments.map((segment, i) => segment.type === "text" ? segment.value.trim() ? /* @__PURE__ */ jsx_runtime5.jsx(Markdown2, {
      text: segment.value
    }, i) : null : /* @__PURE__ */ jsx_runtime5.jsx(ToolCallBlock, {
      title: segment.title,
      content: segment.content,
      streaming: segment.streaming
    }, i))
  });
}

// src/sidepanel/message-view.tsx
var jsx_runtime6 = __toESM(require_jsx_runtime(), 1);
function Attachments(props) {
  if (!props.attachments.length)
    return null;
  return /* @__PURE__ */ jsx_runtime6.jsx("div", {
    className: "attachments",
    children: props.attachments.map((a, i) => a.content_type.startsWith("image/") ? /* @__PURE__ */ jsx_runtime6.jsx("a", {
      href: a.file_url,
      target: "_blank",
      rel: "noopener noreferrer",
      children: /* @__PURE__ */ jsx_runtime6.jsx("img", {
        src: a.file_url,
        alt: a.filename
      })
    }, i) : /* @__PURE__ */ jsx_runtime6.jsx("a", {
      className: "file",
      href: a.file_url,
      target: "_blank",
      rel: "noopener noreferrer",
      children: a.filename
    }, i))
  });
}
function MessageView(props) {
  const { message } = props;
  if (message.role === "user") {
    return /* @__PURE__ */ jsx_runtime6.jsxs("div", {
      className: "message user",
      children: [
        /* @__PURE__ */ jsx_runtime6.jsx("div", {
          className: "bubble",
          children: message.content
        }),
        /* @__PURE__ */ jsx_runtime6.jsx(Attachments, {
          attachments: message.attachments ?? []
        })
      ]
    });
  }
  if (message.role !== "assistant")
    return null;
  return /* @__PURE__ */ jsx_runtime6.jsxs("div", {
    className: "message assistant",
    children: [
      /* @__PURE__ */ jsx_runtime6.jsx(AssistantContent, {
        content: message.content ?? ""
      }),
      /* @__PURE__ */ jsx_runtime6.jsx(Attachments, {
        attachments: message.attachments ?? []
      })
    ]
  });
}
function activityLabel(activity) {
  switch (activity.phase) {
    case "context_building":
    case "relevant_history":
    case "rag_query":
      return t2("Preparing…");
    case "model_call":
    case "reasoning":
      return t2("Thinking…");
    case "tool_call_pending":
    case "tool_call":
    case "silent_tool":
      return activity.toolDisplayName ? `${t2("Using")} ${activity.toolDisplayName}` : t2("Using a tool…");
    default:
      return "";
  }
}
function StreamingMessage(props) {
  const label = activityLabel(props.activity);
  return /* @__PURE__ */ jsx_runtime6.jsxs("div", {
    className: "message assistant",
    children: [
      /* @__PURE__ */ jsx_runtime6.jsx(AssistantContent, {
        content: props.content
      }),
      label && /* @__PURE__ */ jsx_runtime6.jsxs("div", {
        className: "streaming-activity",
        children: [
          /* @__PURE__ */ jsx_runtime6.jsx("span", {
            className: "spinner"
          }),
          label
        ]
      })
    ]
  });
}

// src/sidepanel/chat-view.tsx
var jsx_runtime7 = __toESM(require_jsx_runtime(), 1);
var TARGET_STORAGE_KEY = "ayeto.browser.chat_target";
var CHAT_STORAGE_KEY = "ayeto.browser.chat";
var STOP_GIVE_UP_MS = 20000;
function readStoredTarget() {
  try {
    return parseTargetKey(localStorage.getItem(TARGET_STORAGE_KEY));
  } catch {
    return null;
  }
}
function storeTarget(target) {
  try {
    localStorage.setItem(TARGET_STORAGE_KEY, targetKey(target));
  } catch {}
}
function readStoredChat() {
  try {
    const stored = JSON.parse(localStorage.getItem(CHAT_STORAGE_KEY) ?? "null");
    return typeof stored?.conversation_id === "string" ? stored : null;
  } catch {
    return null;
  }
}
function forgetStoredChat() {
  storeChat(null);
}
function storeChat(chat) {
  try {
    if (chat)
      localStorage.setItem(CHAT_STORAGE_KEY, JSON.stringify(chat));
    else
      localStorage.removeItem(CHAT_STORAGE_KEY);
  } catch {}
}
function withPrompt(messages, prompt) {
  const last = messages[messages.length - 1];
  if (!prompt || last?.role === "user" && last.content === prompt)
    return messages;
  return [...messages, { id: `local-${Date.now()}`, timestamp: Date.now(), role: "user", content: prompt, attachments: [] }];
}
function validTarget(target, assistants, models) {
  if (target?.kind === "assistant" && assistants.some((a) => a.id === target.id))
    return target;
  if (target?.kind === "model" && models.some((m) => m.model_id === target.id))
    return target;
  if (assistants.length)
    return { kind: "assistant", id: assistants[0].id };
  if (models.length)
    return { kind: "model", id: models[0].model_id };
  return null;
}
function ChatView(props) {
  const { api, state, send, abortRef, hidden } = props;
  const currentTab = useCurrentTab();
  const currentTabId = currentTab.id;
  const [assistants, setAssistants] = import_react7.default.useState(null);
  const [models, setModels] = import_react7.default.useState([]);
  const [target, setTarget] = import_react7.default.useState(readStoredTarget());
  const [conversationId, setConversationId] = import_react7.default.useState(() => readStoredChat()?.conversation_id ?? null);
  const [messages, setMessages] = import_react7.default.useState([]);
  const [stream, setStream] = import_react7.default.useState(null);
  const [error, setError] = import_react7.default.useState("");
  const [historyOpen, setHistoryOpen] = import_react7.default.useState(false);
  const streamRef = import_react7.default.useRef(null);
  const stopTimer = import_react7.default.useRef(null);
  const finishRef = import_react7.default.useRef(null);
  const attachRef = import_react7.default.useRef(async () => false);
  const conversationRef = import_react7.default.useRef(conversationId);
  conversationRef.current = conversationId;
  const scrollRef = import_react7.default.useRef(null);
  const stickToBottom = import_react7.default.useRef(true);
  import_react7.default.useEffect(() => {
    const abort = new AbortController;
    Promise.all([api.assistants(abort.signal), api.models(abort.signal).catch(() => [])]).then(([assistantList, modelList]) => {
      setAssistants(assistantList);
      setModels(modelList);
      setTarget((current) => validTarget(current, assistantList, modelList));
    }).catch((e) => {
      if (e?.name !== "AbortError")
        setError(String(e?.message ?? e));
    });
    return () => abort.abort();
  }, [api]);
  import_react7.default.useEffect(() => {
    if (target)
      storeTarget(target);
  }, [target]);
  import_react7.default.useEffect(() => {
    const el = scrollRef.current;
    if (el && stickToBottom.current)
      el.scrollTop = el.scrollHeight;
  }, [messages, stream]);
  const onScroll = () => {
    const el = scrollRef.current;
    if (el)
      stickToBottom.current = el.scrollHeight - el.scrollTop - el.clientHeight < 40;
  };
  const reload = import_react7.default.useCallback(async (id) => {
    try {
      const conversation = await api.conversation(id);
      if (conversationRef.current === id)
        setMessages(conversation.messages);
      return conversation;
    } catch (e) {
      if (!(e instanceof ApiError && e.status === 404))
        setError(String(e?.message ?? e));
      return null;
    }
  }, [api]);
  const follow = import_react7.default.useCallback((id, open) => {
    let acc = createStreamAccumulator();
    let frame = 0;
    let ended = false;
    const render = () => {
      frame = 0;
      setStream({ content: acc.content, activity: snapshotActivity(acc) });
    };
    const end = async (e) => {
      if (ended)
        return;
      ended = true;
      if (frame)
        cancelAnimationFrame(frame);
      if (stopTimer.current)
        clearTimeout(stopTimer.current);
      stopTimer.current = null;
      streamRef.current = null;
      finishRef.current = null;
      const busy = e?.status === 409;
      if (e && conversationRef.current === id)
        setError(busy ? t2("The assistant is still answering here. Send your message once it is done.") : e.message);
      if (busy)
        setMessages((prev) => prev.filter((m) => !m.id.startsWith("local-")));
      await reload(id);
      if (conversationRef.current === id)
        storeChat({ conversation_id: id });
      setStream(null);
      if (busy)
        attachRef.current(id);
    };
    render();
    streamRef.current = open({
      onEvent: (event) => {
        applyStreamEvent(acc, event);
        if (!frame)
          frame = requestAnimationFrame(render);
      },
      onReset: () => {
        acc = createStreamAccumulator();
        render();
      },
      onDone: () => void end(),
      onError: (e) => void end(e)
    });
    finishRef.current = () => {
      streamRef.current?.detach();
      end();
    };
  }, [reload]);
  const attach = import_react7.default.useCallback(async (id, prompt) => {
    let active = null;
    try {
      active = await api.activeStream(id);
    } catch {}
    if (!active || streamRef.current || conversationRef.current !== id)
      return false;
    const stream = active;
    setMessages((prev) => withPrompt(prev, prompt));
    follow(id, (handlers) => api.followStream(stream, handlers));
    return true;
  }, [api, follow]);
  attachRef.current = attach;
  const stop = import_react7.default.useCallback(() => {
    const current = streamRef.current;
    if (!current)
      return;
    current.stop();
    send({ type: "stop" });
    if (!stopTimer.current)
      stopTimer.current = setTimeout(() => {
        stopTimer.current = null;
        if (streamRef.current === current)
          finishRef.current?.();
      }, STOP_GIVE_UP_MS);
  }, [send]);
  import_react7.default.useEffect(() => {
    abortRef.current = stop;
    return () => {
      abortRef.current = null;
    };
  }, [stop, abortRef]);
  import_react7.default.useEffect(() => {
    const stored = readStoredChat();
    if (!stored)
      return;
    (async () => {
      const conversation = await reload(stored.conversation_id);
      const following = await attach(stored.conversation_id, stored.prompt);
      if (!following && !conversation && conversationRef.current === stored.conversation_id) {
        setConversationId(null);
        storeChat(null);
      } else if (!following && stored.prompt) {
        storeChat({ conversation_id: stored.conversation_id });
      }
    })();
    return () => {
      streamRef.current?.detach();
      streamRef.current = null;
    };
  }, [reload, attach]);
  import_react7.default.useEffect(() => {
    const onVisibility = () => {
      const id = conversationRef.current;
      if (document.visibilityState === "visible" && id && !streamRef.current)
        attach(id);
    };
    document.addEventListener("visibilitychange", onVisibility);
    return () => document.removeEventListener("visibilitychange", onVisibility);
  }, [attach]);
  const newChat = () => {
    if (stream)
      return;
    setConversationId(null);
    storeChat(null);
    setMessages([]);
    setError("");
  };
  const openConversation = (conversation) => {
    if (stream)
      return;
    setConversationId(conversation.id);
    storeChat({ conversation_id: conversation.id });
    setMessages(conversation.messages);
    setTarget(conversation.assistant_id ? { kind: "assistant", id: conversation.assistant_id } : { kind: "model", id: conversation.model });
    setError("");
    setHistoryOpen(false);
    conversationRef.current = conversation.id;
    reload(conversation.id).then(() => attach(conversation.id));
  };
  const changeTarget = (next) => {
    setTarget(next);
    if (conversationId && targetKey(next) !== targetKey(target))
      newChat();
  };
  const submit = (text, files) => {
    if (!target || stream)
      return;
    const id = conversationId ?? crypto.randomUUID();
    setConversationId(id);
    conversationRef.current = id;
    storeChat({ conversation_id: id, prompt: text });
    setError("");
    stickToBottom.current = true;
    setMessages((prev) => [...prev, {
      id: `local-${Date.now()}`,
      timestamp: Date.now(),
      role: "user",
      content: text,
      attachments: files.map((f) => ({ filename: f.filename, content_type: f.mime_type, file_url: f.mime_type.startsWith("image/") ? f.data : "" }))
    }]);
    follow(id, (handlers) => api.chatStream({
      conversation_id: id,
      ...target.kind === "assistant" ? { assistant_id: target.id } : { model: target.id },
      message: text,
      ...files.length ? { attachments: files } : {}
    }, handlers));
  };
  const currentIsGiven = state.tabs.some((tab) => tab.tab_id === currentTabId);
  const restriction = tabRestriction(currentTab.url, state);
  const assistant = target?.kind === "assistant" ? assistants?.find((a) => a.id === target.id) ?? null : null;
  const model = target?.kind === "model" ? models.find((m) => m.model_id === target.id) ?? null : null;
  const targetName = assistant?.name ?? model?.display_name ?? "";
  if (historyOpen && state.api_key_id && !hidden) {
    return /* @__PURE__ */ jsx_runtime7.jsx(HistoryView, {
      api,
      apiKeyId: state.api_key_id,
      assistants: assistants ?? [],
      models,
      activeId: conversationId,
      onOpen: openConversation,
      onClose: () => setHistoryOpen(false)
    });
  }
  return /* @__PURE__ */ jsx_runtime7.jsxs("div", {
    className: "chat",
    style: hidden ? { display: "none" } : undefined,
    children: [
      /* @__PURE__ */ jsx_runtime7.jsxs("div", {
        className: "chat-toolbar",
        children: [
          /* @__PURE__ */ jsx_runtime7.jsx(AssistantPicker, {
            api,
            assistants,
            models,
            value: target,
            disabled: !!stream,
            onChange: changeTarget
          }),
          /* @__PURE__ */ jsx_runtime7.jsx("button", {
            className: "btn plain",
            disabled: !!stream,
            onClick: newChat,
            title: t2("New chat"),
            children: "＋"
          }),
          /* @__PURE__ */ jsx_runtime7.jsx("button", {
            className: "btn plain",
            disabled: !!stream || !state.api_key_id,
            onClick: () => setHistoryOpen(true),
            title: t2("History"),
            children: "☰"
          })
        ]
      }),
      /* @__PURE__ */ jsx_runtime7.jsxs("div", {
        className: "chat-messages",
        ref: scrollRef,
        onScroll,
        children: [
          messages.length === 0 && !stream && /* @__PURE__ */ jsx_runtime7.jsxs("div", {
            className: "chat-empty",
            children: [
              target && /* @__PURE__ */ jsx_runtime7.jsx("div", {
                className: "chat-empty-avatar",
                children: /* @__PURE__ */ jsx_runtime7.jsx(AssistantAvatar, {
                  api,
                  assistant,
                  label: targetName,
                  size: 48
                })
              }),
              /* @__PURE__ */ jsx_runtime7.jsx("h2", {
                children: targetName || t2("Chat")
              }),
              (assistant?.description || model?.description) && /* @__PURE__ */ jsx_runtime7.jsx("div", {
                className: "muted",
                children: assistant?.description || model?.description
              }),
              /* @__PURE__ */ jsx_runtime7.jsx("div", {
                className: "muted",
                children: t2("Ask about the pages you give the agent, or let it open and read new ones.")
              })
            ]
          }),
          messages.map((m) => /* @__PURE__ */ jsx_runtime7.jsx(MessageView, {
            message: m
          }, m.id)),
          stream && /* @__PURE__ */ jsx_runtime7.jsx(StreamingMessage, {
            content: stream.content,
            activity: stream.activity
          }),
          error && /* @__PURE__ */ jsx_runtime7.jsx("div", {
            className: "error chat-error",
            children: error
          })
        ]
      }),
      state.status !== "connected" && /* @__PURE__ */ jsx_runtime7.jsx("div", {
        className: "notice warning",
        children: t2("The browser is not connected to AYETO: the assistant cannot see your tabs now.")
      }),
      state.status === "connected" && currentTabId !== null && !currentIsGiven && restriction && /* @__PURE__ */ jsx_runtime7.jsx("div", {
        className: "notice",
        children: /* @__PURE__ */ jsx_runtime7.jsxs("span", {
          className: "grow",
          children: [
            t2("The agent cannot work on this page."),
            " ",
            t2(restriction)
          ]
        })
      }),
      state.status === "connected" && state.tabs.length === 0 && currentTabId !== null && !restriction && /* @__PURE__ */ jsx_runtime7.jsxs("div", {
        className: "notice",
        children: [
          /* @__PURE__ */ jsx_runtime7.jsx("span", {
            className: "grow",
            children: t2("The agent has no tab yet.")
          }),
          /* @__PURE__ */ jsx_runtime7.jsx("button", {
            className: "btn",
            onClick: () => send({ type: "give_tab", tab_id: currentTabId }),
            children: t2("Give this tab to the agent")
          })
        ]
      }),
      state.status === "connected" && state.tabs.length > 0 && currentTabId !== null && !currentIsGiven && !restriction && /* @__PURE__ */ jsx_runtime7.jsxs("div", {
        className: "notice",
        children: [
          /* @__PURE__ */ jsx_runtime7.jsx("span", {
            className: "grow",
            children: t2("The agent does not see this tab.")
          }),
          /* @__PURE__ */ jsx_runtime7.jsx("button", {
            className: "btn plain",
            onClick: () => send({ type: "give_tab", tab_id: currentTabId }),
            children: t2("Give it")
          })
        ]
      }),
      /* @__PURE__ */ jsx_runtime7.jsx(Composer, {
        placeholder: targetName ? `${t2("Message")} ${targetName}` : t2("Message"),
        disabled: !target,
        streaming: !!stream,
        onSend: (text, files) => void submit(text, files),
        onStop: stop,
        onError: setError
      })
    ]
  });
}

// src/sidepanel/confirmation-card.tsx
var import_react8 = __toESM(require_react(), 1);
var jsx_runtime8 = __toESM(require_jsx_runtime(), 1);
function ConfirmationCard(props) {
  const { confirmation, send } = props;
  const [now, setNow] = import_react8.default.useState(Date.now());
  import_react8.default.useEffect(() => {
    const timer = setInterval(() => setNow(Date.now()), 1000);
    return () => clearInterval(timer);
  }, []);
  const seconds = Math.max(0, Math.round((confirmation.expires_at - now) / 1000));
  let host = "";
  try {
    host = confirmation.url ? new URL(confirmation.url).host : "";
  } catch {}
  return /* @__PURE__ */ jsx_runtime8.jsxs("div", {
    className: "confirmation",
    role: "alertdialog",
    "aria-live": "assertive",
    children: [
      /* @__PURE__ */ jsx_runtime8.jsxs("div", {
        className: "confirmation-head",
        children: [
          /* @__PURE__ */ jsx_runtime8.jsx("span", {
            className: "badge",
            children: confirmation.kind === "tool" ? t2("The assistant wants to use a tool") : t2("The agent wants to act")
          }),
          /* @__PURE__ */ jsx_runtime8.jsxs("span", {
            className: "muted",
            children: [
              seconds,
              " s"
            ]
          })
        ]
      }),
      /* @__PURE__ */ jsx_runtime8.jsx("div", {
        className: "confirmation-title",
        children: confirmation.title
      }),
      host && /* @__PURE__ */ jsx_runtime8.jsxs("div", {
        className: "muted",
        children: [
          t2("on"),
          " ",
          host
        ]
      }),
      /* @__PURE__ */ jsx_runtime8.jsx("div", {
        className: "muted",
        children: t2(confirmation.reason)
      }),
      confirmation.details && /* @__PURE__ */ jsx_runtime8.jsx("pre", {
        className: "confirmation-details",
        children: confirmation.details
      }),
      /* @__PURE__ */ jsx_runtime8.jsxs("div", {
        className: "row",
        children: [
          /* @__PURE__ */ jsx_runtime8.jsx("button", {
            className: "btn primary grow",
            onClick: () => send({ type: "confirm", id: confirmation.id, allow: true }),
            children: t2("Allow")
          }),
          /* @__PURE__ */ jsx_runtime8.jsx("button", {
            className: "btn danger grow",
            onClick: () => send({ type: "confirm", id: confirmation.id, allow: false }),
            children: t2("Deny")
          })
        ]
      })
    ]
  });
}

// src/sidepanel/pairing-view.tsx
var import_react9 = __toESM(require_react(), 1);
var jsx_runtime9 = __toESM(require_jsx_runtime(), 1);
function PairingView(props) {
  const { state, send } = props;
  const [deviceName, setDeviceName] = import_react9.default.useState(state.device_name);
  if (state.pairing) {
    return /* @__PURE__ */ jsx_runtime9.jsxs("div", {
      className: "card",
      children: [
        /* @__PURE__ */ jsx_runtime9.jsx("h2", {
          children: t2("Confirm this code in AYETO")
        }),
        /* @__PURE__ */ jsx_runtime9.jsx("div", {
          className: "code",
          children: state.pairing.code
        }),
        /* @__PURE__ */ jsx_runtime9.jsx("div", {
          className: "muted",
          children: t2("The approval page opened in a new tab. Log in if needed and confirm the code.")
        }),
        /* @__PURE__ */ jsx_runtime9.jsxs("div", {
          className: "row wrap",
          children: [
            /* @__PURE__ */ jsx_runtime9.jsx("button", {
              className: "btn primary",
              onClick: () => chrome.tabs.create({ url: state.pairing.verify_url }),
              children: t2("Open the approval page")
            }),
            /* @__PURE__ */ jsx_runtime9.jsx("button", {
              className: "btn",
              onClick: () => send({ type: "cancel_pairing" }),
              children: t2("Cancel")
            })
          ]
        })
      ]
    });
  }
  return /* @__PURE__ */ jsx_runtime9.jsxs("div", {
    className: "card",
    children: [
      /* @__PURE__ */ jsx_runtime9.jsx("h2", {
        children: t2("Connect this browser to AYETO")
      }),
      /* @__PURE__ */ jsx_runtime9.jsx("div", {
        className: "muted",
        children: t2("Your assistant will be able to read and use the tabs you give it.")
      }),
      /* @__PURE__ */ jsx_runtime9.jsx("label", {
        className: "label",
        htmlFor: "device-name",
        children: t2("Browser name")
      }),
      /* @__PURE__ */ jsx_runtime9.jsx("input", {
        id: "device-name",
        className: "input",
        value: deviceName,
        maxLength: 64,
        onChange: (e) => setDeviceName(e.target.value),
        onBlur: () => send({ type: "set_device_name", device_name: deviceName })
      }),
      /* @__PURE__ */ jsx_runtime9.jsx("div", {
        className: "muted",
        children: t2("Shown in AYETO next to your connectors")
      }),
      state.error && /* @__PURE__ */ jsx_runtime9.jsx("div", {
        className: "error",
        children: t2(state.error)
      }),
      /* @__PURE__ */ jsx_runtime9.jsx("button", {
        className: "btn primary",
        onClick: () => send({ type: "pair" }),
        children: t2("Connect to AYETO")
      }),
      { mode: "production", serverUrl: "https://ayeto.ai", appUrl: "https://ayeto.ai/app" }.mode === "development" && /* @__PURE__ */ jsx_runtime9.jsxs("div", {
        className: "muted",
        children: [
          t2("Server"),
          ": ",
          SERVER_URL
        ]
      })
    ]
  });
}

// src/sidepanel/settings-view.tsx
var import_react10 = __toESM(require_react(), 1);
var jsx_runtime10 = __toESM(require_jsx_runtime(), 1);
var CONFIRM_MODES = [
  { mode: "risky", label: "Ask before submitting forms, paying, sending or deleting" },
  { mode: "all", label: "Ask before every action" },
  { mode: "never", label: "Never ask (not recommended)" }
];
var BLOCKED_SAVE_DELAY_MS = 600;
function SettingsView(props) {
  const { state, send } = props;
  const connected = state.status === "connected" || state.status === "connecting";
  const [blocked, setBlocked] = import_react10.default.useState(state.blocked_domains.join(`
`));
  const currentTabId = useCurrentTabId();
  const editing = import_react10.default.useRef(false);
  const saveTimer = import_react10.default.useRef(null);
  import_react10.default.useEffect(() => {
    if (!editing.current)
      setBlocked(state.blocked_domains.join(`
`));
  }, [state.blocked_domains]);
  const saveBlocked = import_react10.default.useCallback((text) => {
    if (saveTimer.current)
      clearTimeout(saveTimer.current);
    saveTimer.current = null;
    send({ type: "set_blocked_domains", domains: text.split(/[\s,]+/).filter(Boolean) });
  }, [send]);
  const editBlocked = (text) => {
    setBlocked(text);
    if (saveTimer.current)
      clearTimeout(saveTimer.current);
    saveTimer.current = setTimeout(() => saveBlocked(text), BLOCKED_SAVE_DELAY_MS);
  };
  const blockCurrentSite = async () => {
    if (currentTabId === null)
      return;
    const tab = await chrome.tabs.get(currentTabId).catch(() => null);
    if (!tab?.url || !/^https?:/.test(tab.url))
      return;
    saveBlocked(`${blocked}
${new URL(tab.url).hostname}`);
  };
  return /* @__PURE__ */ jsx_runtime10.jsxs(jsx_runtime10.Fragment, {
    children: [
      /* @__PURE__ */ jsx_runtime10.jsxs("div", {
        className: "card",
        children: [
          /* @__PURE__ */ jsx_runtime10.jsx("h2", {
            children: t2("Connection")
          }),
          /* @__PURE__ */ jsx_runtime10.jsxs("div", {
            className: "small",
            children: [
              /* @__PURE__ */ jsx_runtime10.jsxs("span", {
                className: "label",
                children: [
                  t2("Server"),
                  ":"
                ]
              }),
              " ",
              state.server_url
            ]
          }),
          /* @__PURE__ */ jsx_runtime10.jsxs("div", {
            className: "small",
            children: [
              /* @__PURE__ */ jsx_runtime10.jsxs("span", {
                className: "label",
                children: [
                  t2("API key"),
                  ":"
                ]
              }),
              " ",
              state.api_key_name || "-"
            ]
          }),
          state.error && /* @__PURE__ */ jsx_runtime10.jsx("div", {
            className: "error",
            children: t2(state.error)
          }),
          /* @__PURE__ */ jsx_runtime10.jsxs("div", {
            className: "row wrap",
            children: [
              connected ? /* @__PURE__ */ jsx_runtime10.jsx("button", {
                className: "btn",
                onClick: () => send({ type: "disconnect" }),
                children: t2("Disconnect")
              }) : /* @__PURE__ */ jsx_runtime10.jsx("button", {
                className: "btn primary",
                onClick: () => send({ type: "connect" }),
                children: t2("Connect")
              }),
              /* @__PURE__ */ jsx_runtime10.jsx("button", {
                className: "btn danger",
                onClick: () => {
                  if (window.confirm(t2("Forget this browser? Its API key is deleted in AYETO and stops working.")))
                    send({ type: "unpair" });
                },
                children: t2("Forget this browser")
              })
            ]
          })
        ]
      }),
      /* @__PURE__ */ jsx_runtime10.jsxs("div", {
        className: "card",
        children: [
          /* @__PURE__ */ jsx_runtime10.jsx("h2", {
            children: t2("Confirmations")
          }),
          CONFIRM_MODES.map(({ mode, label }) => /* @__PURE__ */ jsx_runtime10.jsxs("label", {
            className: "row small",
            children: [
              /* @__PURE__ */ jsx_runtime10.jsx("input", {
                type: "radio",
                name: "confirm-mode",
                checked: state.confirm_mode === mode,
                onChange: () => send({ type: "set_confirm_mode", mode })
              }),
              t2(label)
            ]
          }, mode)),
          /* @__PURE__ */ jsx_runtime10.jsx("div", {
            className: "muted",
            children: t2("Tools of the assistant that send data out of AYETO (e-mail, web requests) always ask in conversations from this browser. Passwords and card numbers are never typed by the agent.")
          })
        ]
      }),
      /* @__PURE__ */ jsx_runtime10.jsxs("div", {
        className: "card",
        children: [
          /* @__PURE__ */ jsx_runtime10.jsx("h2", {
            children: t2("Blocked sites")
          }),
          /* @__PURE__ */ jsx_runtime10.jsx("div", {
            className: "muted",
            children: t2("The agent never reads or uses these sites (one domain per line, subdomains included), e.g. your bank.")
          }),
          /* @__PURE__ */ jsx_runtime10.jsx("textarea", {
            className: "input",
            rows: 4,
            value: blocked,
            placeholder: "mybank.com",
            onChange: (e) => editBlocked(e.target.value),
            onFocus: () => {
              editing.current = true;
            },
            onBlur: () => {
              editing.current = false;
              saveBlocked(blocked);
            }
          }),
          /* @__PURE__ */ jsx_runtime10.jsx("div", {
            className: "row",
            children: /* @__PURE__ */ jsx_runtime10.jsx("button", {
              className: "btn",
              onClick: () => void blockCurrentSite(),
              children: t2("Block the current site")
            })
          })
        ]
      })
    ]
  });
}

// src/sidepanel/status.tsx
var jsx_runtime11 = __toESM(require_jsx_runtime(), 1);
var LABELS = {
  unpaired: "Not connected",
  pairing: "Waiting for approval",
  connecting: "Connecting…",
  connected: "Connected",
  disconnected: "Disconnected",
  error: "Error"
};
function ConnectionBadge(props) {
  return /* @__PURE__ */ jsx_runtime11.jsxs("span", {
    className: "row small",
    children: [
      /* @__PURE__ */ jsx_runtime11.jsx("span", {
        className: `dot ${props.status}`
      }),
      t2(LABELS[props.status])
    ]
  });
}

// src/sidepanel/use-api.ts
var import_react11 = __toESM(require_react(), 1);

// src/shared/storage.ts
var SETTINGS_KEY = "ayeto.settings";
var SESSION_KEY = "ayeto.session";
var DEFAULT_SESSION = {
  group_ids: [],
  agent_tab_id: null
};
async function loadSettings() {
  const stored = await chrome.storage.local.get(SETTINGS_KEY);
  return { ...DEFAULT_SETTINGS, ...stored[SETTINGS_KEY] ?? {} };
}
async function saveSettings(update) {
  const settings = { ...await loadSettings(), ...update };
  await chrome.storage.local.set({ [SETTINGS_KEY]: settings });
  return settings;
}
async function loadSession() {
  const stored = await chrome.storage.session.get(SESSION_KEY);
  return { ...DEFAULT_SESSION, ...stored[SESSION_KEY] ?? {} };
}
async function saveSession(update) {
  const session = { ...await loadSession(), ...update };
  await chrome.storage.session.set({ [SESSION_KEY]: session });
  return session;
}

// src/sidepanel/use-api.ts
function useSettings() {
  const [settings, setSettings] = import_react11.default.useState(null);
  import_react11.default.useEffect(() => {
    let alive = true;
    const refresh = () => void loadSettings().then((s) => alive && setSettings(s));
    refresh();
    const onChanged = (_, area) => {
      if (area === "local")
        refresh();
    };
    chrome.storage.onChanged.addListener(onChanged);
    return () => {
      alive = false;
      chrome.storage.onChanged.removeListener(onChanged);
    };
  }, []);
  return settings;
}
function useApi(settings) {
  const apiKey = settings?.api_key ?? null;
  return import_react11.default.useMemo(() => apiKey ? new AyetoApi(SERVER_URL, apiKey) : null, [apiKey]);
}

// src/sidepanel/app.tsx
var jsx_runtime12 = __toESM(require_jsx_runtime(), 1);
function App() {
  const { state, send } = useWorker();
  const settings = useSettings();
  const api = useApi(settings);
  const [view, setView] = import_react12.default.useState("chat");
  const abortChat = import_react12.default.useRef(null);
  const paired = state?.paired;
  import_react12.default.useEffect(() => {
    if (paired !== false)
      return;
    forgetStoredChat();
    setView("chat");
  }, [paired]);
  if (!state)
    return /* @__PURE__ */ jsx_runtime12.jsx("div", {
      className: "app"
    });
  const stopAll = () => {
    abortChat.current?.();
    send({ type: "stop" });
  };
  return /* @__PURE__ */ jsx_runtime12.jsxs("div", {
    className: "app",
    children: [
      /* @__PURE__ */ jsx_runtime12.jsxs("div", {
        className: "header",
        children: [
          /* @__PURE__ */ jsx_runtime12.jsx("img", {
            src: "icons/icon32.png",
            alt: ""
          }),
          /* @__PURE__ */ jsx_runtime12.jsx("span", {
            className: "title",
            children: "AYETO"
          }),
          /* @__PURE__ */ jsx_runtime12.jsx(ConnectionBadge, {
            status: state.status
          }),
          state.paired && /* @__PURE__ */ jsx_runtime12.jsx("button", {
            className: "btn plain icon",
            title: t2("Settings"),
            onClick: () => setView(view === "settings" ? "chat" : "settings"),
            children: view === "settings" ? "✕" : "⚙"
          })
        ]
      }),
      state.paired && view !== "settings" && /* @__PURE__ */ jsx_runtime12.jsxs("div", {
        className: "view-tabs",
        children: [
          /* @__PURE__ */ jsx_runtime12.jsx("button", {
            className: view === "chat" ? "active" : "",
            onClick: () => setView("chat"),
            children: t2("Chat")
          }),
          /* @__PURE__ */ jsx_runtime12.jsxs("button", {
            className: view === "tabs" ? "active" : "",
            onClick: () => setView("tabs"),
            children: [
              t2("Agent tabs"),
              state.tabs.length > 0 ? ` (${state.tabs.length})` : ""
            ]
          })
        ]
      }),
      !state.paired && /* @__PURE__ */ jsx_runtime12.jsx("div", {
        className: "content",
        children: /* @__PURE__ */ jsx_runtime12.jsx(PairingView, {
          state,
          send
        })
      }),
      state.paired && view === "settings" && /* @__PURE__ */ jsx_runtime12.jsx("div", {
        className: "content",
        children: /* @__PURE__ */ jsx_runtime12.jsx(SettingsView, {
          state,
          send
        })
      }),
      state.paired && view === "tabs" && /* @__PURE__ */ jsx_runtime12.jsx("div", {
        className: "content",
        children: /* @__PURE__ */ jsx_runtime12.jsx(AgentTabs, {
          state,
          send
        })
      }),
      state.paired && api && /* @__PURE__ */ jsx_runtime12.jsx(ChatView, {
        api,
        state,
        send,
        abortRef: abortChat,
        hidden: view !== "chat"
      }),
      state.confirmation && /* @__PURE__ */ jsx_runtime12.jsx(ConfirmationCard, {
        confirmation: state.confirmation,
        send
      }),
      state.activity && !state.confirmation && /* @__PURE__ */ jsx_runtime12.jsxs("div", {
        className: "activity",
        children: [
          /* @__PURE__ */ jsx_runtime12.jsx("span", {
            className: "spinner"
          }),
          /* @__PURE__ */ jsx_runtime12.jsx("span", {
            className: "grow small",
            children: state.activity.operation
          }),
          /* @__PURE__ */ jsx_runtime12.jsx("button", {
            className: "btn danger",
            onClick: stopAll,
            children: t2("Stop")
          })
        ]
      })
    ]
  });
}

// src/sidepanel/main.tsx
var jsx_runtime13 = __toESM(require_jsx_runtime(), 1);
import_client.createRoot(document.getElementById("root")).render(/* @__PURE__ */ jsx_runtime13.jsx(App, {}));

//# debugId=9997167713117BF864756E2164756E21
//# sourceMappingURL=main.js.map
